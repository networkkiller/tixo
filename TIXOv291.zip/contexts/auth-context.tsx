"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"
import { authenticateUser } from "@/lib/auth"
import type { User, AuthContextType } from "@/types"

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Check for stored user session
    const storedUser = localStorage.getItem("user")
    if (storedUser) {
      try {
        const parsedUser = JSON.parse(storedUser)
        console.log("🔄 Restored user from localStorage:", parsedUser)
        setUser(parsedUser)
      } catch (error) {
        console.error("❌ Error parsing stored user:", error)
        localStorage.removeItem("user")
      }
    }
    setIsLoading(false)
  }, [])

  const login = async (email: string, password: string): Promise<boolean> => {
    console.log("🚀 Login attempt:", { email, password })
    setIsLoading(true)

    try {
      const authenticatedUser = await authenticateUser(email, password)
      console.log("🔐 Authentication result:", authenticatedUser)

      if (authenticatedUser) {
        setUser(authenticatedUser)
        localStorage.setItem("user", JSON.stringify(authenticatedUser))
        console.log("✅ Login successful, user set:", authenticatedUser)
        return true
      }

      console.log("❌ Login failed")
      return false
    } catch (error) {
      console.error("❌ Login error:", error)
      return false
    } finally {
      setIsLoading(false)
    }
  }

  const logout = () => {
    console.log("🚪 Logging out user:", user)
    setUser(null)
    localStorage.removeItem("user")
  }

  const value: AuthContextType = {
    user,
    login,
    logout,
    isLoading,
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
