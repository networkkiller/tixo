// Navigation system
const ROLE_MODULES = {
  "super-admin": [
    { id: "dashboard", name: "Dashboard", icon: "fas fa-chart-bar", path: "dashboard" },
    { id: "schools", name: "Colegios", icon: "fas fa-school", path: "schools" },
    { id: "users", name: "Usuarios", icon: "fas fa-users", path: "users" },
    { id: "subscriptions", name: "Suscripciones", icon: "fas fa-credit-card", path: "subscriptions" },
    { id: "logs", name: "Logs", icon: "fas fa-file-alt", path: "logs" },
    { id: "settings", name: "Configuración", icon: "fas fa-cog", path: "settings" },
    { id: "support", name: "Soporte", icon: "fas fa-life-ring", path: "support" },
  ],
  director: [
    { id: "dashboard", name: "Dashboard", icon: "fas fa-chart-bar", path: "dashboard" },
    { id: "academic", name: "Académico", icon: "fas fa-book-open", path: "academic" },
    { id: "users", name: "Usuarios", icon: "fas fa-users", path: "users" },
    { id: "grades", name: "Calificaciones", icon: "fas fa-clipboard-check", path: "grades" },
    { id: "billing", name: "Facturación", icon: "fas fa-credit-card", path: "billing" },
    { id: "communication", name: "Comunicación", icon: "fas fa-comments", path: "communication" },
    { id: "reports", name: "Reportes", icon: "fas fa-chart-line", path: "reports" },
    { id: "planning", name: "Planificación", icon: "fas fa-calendar", path: "planning" },
  ],
  profesor: [
    { id: "dashboard", name: "Dashboard", icon: "fas fa-chart-bar", path: "dashboard" },
    { id: "courses", name: "Mis Cursos", icon: "fas fa-book-open", path: "courses" },
    { id: "grades", name: "Calificaciones", icon: "fas fa-clipboard-check", path: "grades" },
    { id: "tasks", name: "Planificación de Tareas", icon: "fas fa-calendar", path: "tasks" },
    { id: "communication", name: "Comunicación", icon: "fas fa-comments", path: "communication" },
    { id: "history", name: "Historial Académico", icon: "fas fa-file-alt", path: "history" },
  ],
  padre: [
    { id: "dashboard", name: "Dashboard", icon: "fas fa-chart-bar", path: "dashboard" },
    { id: "grades", name: "Calificaciones", icon: "fas fa-clipboard-check", path: "grades" },
    { id: "attendance", name: "Asistencia", icon: "fas fa-calendar-check", path: "attendance" },
    { id: "tasks", name: "Tareas y Actividades", icon: "fas fa-book-open", path: "tasks" },
    { id: "communication", name: "Comunicación", icon: "fas fa-comments", path: "communication" },
    { id: "history", name: "Historial Académico", icon: "fas fa-file-alt", path: "history" },
  ],
  contable: [
    { id: "dashboard", name: "Dashboard Financiero", icon: "fas fa-chart-bar", path: "dashboard" },
    { id: "billing", name: "Facturación", icon: "fas fa-file-invoice", path: "billing" },
    { id: "accounts-receivable", name: "Cuentas por Cobrar", icon: "fas fa-credit-card", path: "accounts-receivable" },
    { id: "expenses", name: "Egresos y Gastos", icon: "fas fa-arrow-down", path: "expenses" },
    { id: "payroll", name: "Nómina", icon: "fas fa-users", path: "payroll" },
    { id: "reports", name: "Informes Financieros", icon: "fas fa-chart-pie", path: "reports" },
    { id: "student-profile", name: "Perfil Financiero", icon: "fas fa-user-check", path: "student-profile" },
  ],
  coordinador: [
    { id: "dashboard", name: "Dashboard", icon: "fas fa-chart-bar", path: "dashboard" },
    { id: "students", name: "Gestión de Estudiantes", icon: "fas fa-users", path: "students" },
    { id: "teachers", name: "Gestión de Docentes", icon: "fas fa-graduation-cap", path: "teachers" },
    { id: "parents", name: "Gestión de Padres", icon: "fas fa-user-plus", path: "parents" },
    { id: "archive", name: "Archivo Institucional", icon: "fas fa-folder-open", path: "archive" },
    { id: "calendar", name: "Calendario y Citas", icon: "fas fa-calendar", path: "calendar" },
    { id: "reports", name: "Reportes Académicos", icon: "fas fa-file-alt", path: "reports" },
    { id: "communication", name: "Comunicación", icon: "fas fa-comments", path: "communication" },
    { id: "enrollment", name: "Inscripción y Reinscripción", icon: "fas fa-clipboard-check", path: "enrollment" },
  ],
}

function initializeSidebar(role) {
  const sidebarNav = document.getElementById("sidebar-nav")
  const modules = ROLE_MODULES[role] || []

  sidebarNav.innerHTML = ""

  modules.forEach((module) => {
    const navItem = document.createElement("a")
    navItem.className = "nav-item"
    navItem.href = "#"
    navItem.dataset.module = module.id
    navItem.dataset.role = role
    navItem.innerHTML = `
            <i class="${module.icon}"></i>
            ${module.name}
        `

    navItem.addEventListener("click", (e) => {
      e.preventDefault()
      navigateToModule(module.id, role)
    })

    sidebarNav.appendChild(navItem)
  })

  // Set first module as active
  if (modules.length > 0) {
    navigateToModule(modules[0].id, role)
  }
}

function navigateToModule(moduleId, role) {
  // Update active navigation item
  const navItems = document.querySelectorAll(".nav-item")
  navItems.forEach((item) => {
    item.classList.remove("active")
    if (item.dataset.module === moduleId) {
      item.classList.add("active")
    }
  })

  // Load module content
  loadModuleContent(moduleId, role)

  // Update browser history
  const state = { module: moduleId, role: role }
  const url = `#/${role}/${moduleId}`
  history.pushState(state, "", url)
}

function loadModuleContent(moduleId, role) {
  const contentArea = document.getElementById("content-area")

  // Show loading state
  showLoading(contentArea)

  // Simulate loading delay
  setTimeout(() => {
    try {
      // Load module-specific content
      const moduleFunction = `load${capitalize(role)}${capitalize(moduleId)}`

      if (window[moduleFunction]) {
        window[moduleFunction](contentArea)
      } else {
        loadDefaultModuleContent(moduleId, role, contentArea)
      }
    } catch (error) {
      console.error("Error loading module:", error)
      loadErrorContent(contentArea, moduleId)
    }
  }, 500)
}

function loadDefaultModuleContent(moduleId, role, container) {
  const module = ROLE_MODULES[role]?.find((m) => m.id === moduleId)
  const moduleName = module ? module.name : "Módulo"

  container.innerHTML = `
        <div class="card">
            <div class="card-header">
                <h2 class="card-title">${moduleName}</h2>
                <p class="card-description">Contenido del módulo ${moduleName}</p>
            </div>
            <div class="card-content">
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-header">
                            <span class="stat-title">Total</span>
                            <div class="stat-icon">
                                <i class="fas fa-chart-bar"></i>
                            </div>
                        </div>
                        <div class="stat-value">1,234</div>
                        <div class="stat-change positive">+12% vs mes anterior</div>
                    </div>
                    <div class="stat-card success">
                        <div class="stat-header">
                            <span class="stat-title">Activos</span>
                            <div class="stat-icon" style="background: var(--success)">
                                <i class="fas fa-check"></i>
                            </div>
                        </div>
                        <div class="stat-value">987</div>
                        <div class="stat-change positive">+8% vs mes anterior</div>
                    </div>
                    <div class="stat-card warning">
                        <div class="stat-header">
                            <span class="stat-title">Pendientes</span>
                            <div class="stat-icon" style="background: var(--warning)">
                                <i class="fas fa-clock"></i>
                            </div>
                        </div>
                        <div class="stat-value">156</div>
                        <div class="stat-change negative">-3% vs mes anterior</div>
                    </div>
                    <div class="stat-card error">
                        <div class="stat-header">
                            <span class="stat-title">Problemas</span>
                            <div class="stat-icon" style="background: var(--error)">
                                <i class="fas fa-exclamation"></i>
                            </div>
                        </div>
                        <div class="stat-value">23</div>
                        <div class="stat-change positive">-15% vs mes anterior</div>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Datos Recientes</h3>
                        <button class="btn btn-primary">
                            <i class="fas fa-plus"></i>
                            Agregar Nuevo
                        </button>
                    </div>
                    <div class="card-content">
                        <div class="table-container">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Nombre</th>
                                        <th>Estado</th>
                                        <th>Fecha</th>
                                        <th>Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>#001</td>
                                        <td>Elemento de ejemplo</td>
                                        <td><span class="badge badge-success">Activo</span></td>
                                        <td>${formatDate(new Date())}</td>
                                        <td>
                                            <button class="btn btn-small">
                                                <i class="fas fa-eye"></i>
                                            </button>
                                            <button class="btn btn-small">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>#002</td>
                                        <td>Segundo elemento</td>
                                        <td><span class="badge badge-warning">Pendiente</span></td>
                                        <td>${formatDate(new Date(Date.now() - 86400000))}</td>
                                        <td>
                                            <button class="btn btn-small">
                                                <i class="fas fa-eye"></i>
                                            </button>
                                            <button class="btn btn-small">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>#003</td>
                                        <td>Tercer elemento</td>
                                        <td><span class="badge badge-error">Inactivo</span></td>
                                        <td>${formatDate(new Date(Date.now() - 172800000))}</td>
                                        <td>
                                            <button class="btn btn-small">
                                                <i class="fas fa-eye"></i>
                                            </button>
                                            <button class="btn btn-small">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `
}

function loadErrorContent(container, moduleId) {
  container.innerHTML = `
        <div class="card">
            <div class="card-content text-center">
                <i class="fas fa-exclamation-triangle" style="font-size: 3rem; color: var(--warning); margin-bottom: 1rem;"></i>
                <h3>Error al cargar el módulo</h3>
                <p class="text-gray">No se pudo cargar el contenido del módulo "${moduleId}"</p>
                <button class="btn btn-primary" onclick="location.reload()">
                    <i class="fas fa-refresh"></i>
                    Reintentar
                </button>
            </div>
        </div>
    `
}

function toggleSidebar() {
  const sidebar = document.querySelector(".sidebar")
  sidebar.classList.toggle("open")
}

function capitalize(str) {
  return str.charAt(0).toUpperCase() + str.slice(1)
}

function showLoading(container) {
  container.innerHTML = `
        <div class="card">
            <div class="card-content text-center">
                <i class="fas fa-spinner fa-spin" style="font-size: 3rem; color: var(--primary); margin-bottom: 1rem;"></i>
                <h3>Cargando...</h3>
            </div>
        </div>
    `
}

function formatDate(date) {
  const options = { year: "numeric", month: "long", day: "numeric" }
  return date.toLocaleDateString("es-ES", options)
}

// Export functions
window.initializeSidebar = initializeSidebar
window.navigateToModule = navigateToModule
window.toggleSidebar = toggleSidebar
