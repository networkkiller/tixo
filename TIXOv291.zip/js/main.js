// Main application initialization
document.addEventListener("DOMContentLoaded", () => {
  initializeApp()
})

function initializeApp() {
  console.log("🚀 Inicializando EduGestión360...")

  // Check if user is already logged in
  const currentUser = getCurrentUser()

  if (currentUser) {
    console.log("👤 Usuario encontrado:", currentUser.name)
    showDashboard(currentUser.role)
    loadUserData(currentUser)
  } else {
    console.log("🏠 Mostrando página de inicio")
    showLanding()
  }

  // Initialize event listeners
  initializeEventListeners()

  // Initialize scroll animations
  initializeScrollAnimations()

  console.log("✅ Aplicación inicializada correctamente")
}

function initializeEventListeners() {
  // Handle window resize
  window.addEventListener("resize", handleResize)

  // Handle navigation
  window.addEventListener("popstate", handlePopState)

  // Handle clicks outside dropdowns
  document.addEventListener("click", handleOutsideClick)

  // Handle keyboard shortcuts
  document.addEventListener("keydown", handleKeyboardShortcuts)
}

function initializeScrollAnimations() {
  const observerOptions = {
    threshold: 0.1,
    rootMargin: "0px 0px -50px 0px",
  }

  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("revealed")
      }
    })
  }, observerOptions)

  // Observe all scroll-reveal elements
  document.querySelectorAll(".scroll-reveal").forEach((el) => {
    observer.observe(el)
  })
}

function handleResize() {
  // Handle responsive behavior
  if (window.innerWidth <= 768) {
    const sidebar = document.querySelector(".sidebar")
    if (sidebar && sidebar.classList.contains("open")) {
      sidebar.classList.remove("open")
    }
  }

  // Update mobile menu
  updateMobileMenu()
}

function handlePopState(event) {
  // Handle browser back/forward navigation
  if (event.state) {
    navigateToModule(event.state.module, event.state.role)
  }
}

function handleOutsideClick(event) {
  // Close dropdowns when clicking outside
  const userMenu = document.getElementById("user-menu-dropdown")
  const userMenuBtn = document.querySelector(".user-menu-btn")

  if (userMenu && !userMenuBtn.contains(event.target)) {
    userMenu.classList.remove("active")
  }

  // Close mobile menu when clicking outside
  const sidebar = document.querySelector(".sidebar")
  const sidebarToggle = document.querySelector(".sidebar-toggle")

  if (
    sidebar &&
    sidebar.classList.contains("open") &&
    !sidebar.contains(event.target) &&
    !sidebarToggle.contains(event.target)
  ) {
    sidebar.classList.remove("open")
  }
}

function handleKeyboardShortcuts(event) {
  // Handle keyboard shortcuts
  if (event.ctrlKey || event.metaKey) {
    switch (event.key) {
      case "k":
        event.preventDefault()
        focusSearch()
        break
      case "/":
        event.preventDefault()
        focusSearch()
        break
    }
  }

  // Handle escape key
  if (event.key === "Escape") {
    closeAllModals()
    closeAllDropdowns()
  }
}

function focusSearch() {
  const searchInput = document.querySelector(".search-input")
  if (searchInput) {
    searchInput.focus()
  }
}

function closeAllModals() {
  const modals = document.querySelectorAll(".modal.active")
  modals.forEach((modal) => {
    modal.classList.remove("active")
  })
  document.body.style.overflow = ""
}

function closeAllDropdowns() {
  const dropdowns = document.querySelectorAll(".dropdown.active")
  dropdowns.forEach((dropdown) => {
    dropdown.classList.remove("active")
  })

  const userMenu = document.getElementById("user-menu-dropdown")
  if (userMenu) {
    userMenu.classList.remove("active")
  }
}

function updateMobileMenu() {
  const navLinks = document.querySelector(".nav-links")
  const mobileMenuBtn = document.querySelector(".mobile-menu-btn")

  if (window.innerWidth <= 768) {
    if (navLinks) navLinks.style.display = "none"
    if (mobileMenuBtn) mobileMenuBtn.style.display = "block"
  } else {
    if (navLinks) navLinks.style.display = "flex"
    if (mobileMenuBtn) mobileMenuBtn.style.display = "none"
  }
}

// Page navigation functions
function showLanding() {
  hideAllPages()
  document.getElementById("landing-page").classList.add("active")
  updatePageTitle("EduGestión360 - Sistema de Gestión Educativa")

  // Add scroll reveal animations
  setTimeout(() => {
    document.querySelectorAll(".scroll-reveal").forEach((el) => {
      el.classList.add("animate-slideInUp")
    })
  }, 100)
}

function showLogin() {
  hideAllPages()
  document.getElementById("login-page").classList.add("active")
  updatePageTitle("Iniciar Sesión - EduGestión360")

  // Focus on email input
  setTimeout(() => {
    const emailInput = document.getElementById("email")
    if (emailInput) emailInput.focus()
  }, 300)
}

function showDashboard(role) {
  hideAllPages()
  document.getElementById("dashboard").classList.add("active")
  initializeDashboard(role)
  updatePageTitle(`Dashboard - EduGestión360`)
}

function hideAllPages() {
  const pages = document.querySelectorAll(".page")
  pages.forEach((page) => page.classList.remove("active"))
}

function updatePageTitle(title) {
  document.title = title
}

// Mobile menu functions
function toggleMobileMenu() {
  const navLinks = document.querySelector(".nav-links")
  if (navLinks) {
    navLinks.style.display = navLinks.style.display === "flex" ? "none" : "flex"
  }
}

// User menu functions
function toggleUserMenu() {
  const userMenu = document.getElementById("user-menu-dropdown")
  if (userMenu) {
    userMenu.classList.toggle("active")
  }
}

function showProfile() {
  createModal(
    "Mi Perfil",
    `
    <div class="space-y-4">
      <div class="text-center">
        <div class="user-avatar" style="width: 80px; height: 80px; margin: 0 auto 1rem;">
          <i class="fas fa-user" style="font-size: 2rem;"></i>
        </div>
        <h3 class="font-semibold text-lg">${getCurrentUser()?.name || "Usuario"}</h3>
        <p class="text-gray-600">${getCurrentUser()?.email || "email@ejemplo.com"}</p>
      </div>
      <div class="form-group">
        <label>Nombre completo</label>
        <input type="text" class="form-control" value="${getCurrentUser()?.name || ""}" readonly>
      </div>
      <div class="form-group">
        <label>Correo electrónico</label>
        <input type="email" class="form-control" value="${getCurrentUser()?.email || ""}" readonly>
      </div>
      <div class="form-group">
        <label>Rol</label>
        <input type="text" class="form-control" value="${getRoleName(getCurrentUser()?.role)}" readonly>
      </div>
    </div>
  `,
    [{ text: "Cerrar", class: "btn-outline", onclick: 'hideModal("profile-modal")' }],
  )
}

function showSettings() {
  createModal(
    "Configuración",
    `
    <div class="space-y-4">
      <div class="form-group">
        <label>Tema</label>
        <select class="form-control">
          <option>Claro</option>
          <option>Oscuro</option>
          <option>Automático</option>
        </select>
      </div>
      <div class="form-group">
        <label>Idioma</label>
        <select class="form-control">
          <option>Español</option>
          <option>English</option>
        </select>
      </div>
      <div class="form-group">
        <label class="checkbox-label">
          <input type="checkbox" checked>
          <span class="checkmark"></span>
          Notificaciones por email
        </label>
      </div>
      <div class="form-group">
        <label class="checkbox-label">
          <input type="checkbox" checked>
          <span class="checkmark"></span>
          Notificaciones push
        </label>
      </div>
    </div>
  `,
    [
      { text: "Cancelar", class: "btn-outline", onclick: 'hideModal("settings-modal")' },
      { text: "Guardar", class: "btn-primary", onclick: "saveSettings()" },
    ],
  )
}

function saveSettings() {
  showNotification("Configuración guardada correctamente", "success")
  hideModal("settings-modal")
}

function showNotifications() {
  createModal(
    "Notificaciones",
    `
    <div class="space-y-4">
      <div class="notification-item p-4 border rounded-lg">
        <div class="flex items-start gap-3">
          <div class="notification-icon bg-blue-100 p-2 rounded-full">
            <i class="fas fa-info-circle text-blue-600"></i>
          </div>
          <div class="flex-1">
            <h4 class="font-semibold">Nueva actualización disponible</h4>
            <p class="text-gray-600 text-sm">Se ha lanzado una nueva versión del sistema</p>
            <span class="text-xs text-gray-500">Hace 2 horas</span>
          </div>
        </div>
      </div>
      <div class="notification-item p-4 border rounded-lg">
        <div class="flex items-start gap-3">
          <div class="notification-icon bg-green-100 p-2 rounded-full">
            <i class="fas fa-check-circle text-green-600"></i>
          </div>
          <div class="flex-1">
            <h4 class="font-semibold">Backup completado</h4>
            <p class="text-gray-600 text-sm">El backup automático se ha completado exitosamente</p>
            <span class="text-xs text-gray-500">Hace 1 día</span>
          </div>
        </div>
      </div>
      <div class="notification-item p-4 border rounded-lg">
        <div class="flex items-start gap-3">
          <div class="notification-icon bg-yellow-100 p-2 rounded-full">
            <i class="fas fa-exclamation-triangle text-yellow-600"></i>
          </div>
          <div class="flex-1">
            <h4 class="font-semibold">Mantenimiento programado</h4>
            <p class="text-gray-600 text-sm">El sistema estará en mantenimiento el domingo de 2:00 AM a 4:00 AM</p>
            <span class="text-xs text-gray-500">Hace 2 días</span>
          </div>
        </div>
      </div>
    </div>
  `,
    [
      { text: "Marcar todas como leídas", class: "btn-outline", onclick: "markAllAsRead()" },
      { text: "Cerrar", class: "btn-primary", onclick: 'hideModal("notifications-modal")' },
    ],
  )
}

function showMessages() {
  createModal(
    "Mensajes",
    `
    <div class="space-y-4">
      <div class="message-item p-4 border rounded-lg">
        <div class="flex items-start gap-3">
          <div class="user-avatar">
            <i class="fas fa-user"></i>
          </div>
          <div class="flex-1">
            <div class="flex justify-between items-start">
              <h4 class="font-semibold">María González</h4>
              <span class="text-xs text-gray-500">10:30 AM</span>
            </div>
            <p class="text-gray-600 text-sm">Hola, necesito revisar los reportes del mes pasado...</p>
          </div>
        </div>
      </div>
      <div class="message-item p-4 border rounded-lg">
        <div class="flex items-start gap-3">
          <div class="user-avatar">
            <i class="fas fa-user"></i>
          </div>
          <div class="flex-1">
            <div class="flex justify-between items-start">
              <h4 class="font-semibold">Carlos Rodríguez</h4>
              <span class="text-xs text-gray-500">Ayer</span>
            </div>
            <p class="text-gray-600 text-sm">¿Podemos programar una reunión para revisar las calificaciones?</p>
          </div>
        </div>
      </div>
    </div>
  `,
    [
      { text: "Ver todos", class: "btn-outline", onclick: "viewAllMessages()" },
      { text: "Cerrar", class: "btn-primary", onclick: 'hideModal("messages-modal")' },
    ],
  )
}

function markAllAsRead() {
  showNotification("Todas las notificaciones marcadas como leídas", "success")
  hideModal("notifications-modal")
}

function viewAllMessages() {
  showNotification("Redirigiendo a mensajes...", "info")
  hideModal("messages-modal")
}

// Password toggle function
function togglePassword() {
  const passwordInput = document.getElementById("password")
  const toggleBtn = document.querySelector(".password-toggle i")

  if (passwordInput.type === "password") {
    passwordInput.type = "text"
    toggleBtn.className = "fas fa-eye-slash"
  } else {
    passwordInput.type = "password"
    toggleBtn.className = "fas fa-eye"
  }
}

// Utility functions
function formatCurrency(amount) {
  return new Intl.NumberFormat("es-DO", {
    style: "currency",
    currency: "DOP",
  }).format(amount)
}

function formatDate(date) {
  return new Intl.DateTimeFormat("es-DO", {
    year: "numeric",
    month: "long",
    day: "numeric",
  }).format(new Date(date))
}

function formatDateTime(date) {
  return new Intl.DateTimeFormat("es-\
