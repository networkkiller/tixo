// Authentication system
const AUTH_KEY = "edugestión360_auth"

// Mock user data
const MOCK_USERS = {
  "admin@edugestión360.com": {
    id: 1,
    email: "admin@edugestión360.com",
    name: "Super Administrador",
    role: "super-admin",
    password: "admin123",
  },
  "director@colegio.com": {
    id: 2,
    email: "director@colegio.com",
    name: "María González",
    role: "director",
    password: "director123",
  },
  "profesor@colegio.com": {
    id: 3,
    email: "profesor@colegio.com",
    name: "Carlos Rodríguez",
    role: "profesor",
    password: "profesor123",
  },
  "padre@familia.com": {
    id: 4,
    email: "padre@familia.com",
    name: "Ana Martínez",
    role: "padre",
    password: "padre123",
  },
  "contable@colegio.com": {
    id: 5,
    email: "contable@colegio.com",
    name: "Luis Fernández",
    role: "contable",
    password: "contable123",
  },
  "coordinador@colegio.com": {
    id: 6,
    email: "coordinador@colegio.com",
    name: "Laura Sánchez",
    role: "coordinador",
    password: "coordinador123",
  },
}

function handleLogin(event) {
  event.preventDefault()

  const formData = new FormData(event.target)
  const email = formData.get("email")
  const password = formData.get("password")
  const role = formData.get("role")

  // Validate credentials
  const user = MOCK_USERS[email]

  if (!user) {
    window.showNotification("Usuario no encontrado", "error")
    return
  }

  if (user.password !== password) {
    window.showNotification("Contraseña incorrecta", "error")
    return
  }

  if (user.role !== role) {
    window.showNotification("Rol seleccionado no coincide con el usuario", "error")
    return
  }

  // Save user session
  saveUserSession(user)

  // Show success message
  window.showNotification(`Bienvenido, ${user.name}`, "success")

  // Redirect to dashboard
  setTimeout(() => {
    window.showDashboard(user.role)
    loadUserData(user)
  }, 1000)
}

function saveUserSession(user) {
  const sessionData = {
    id: user.id,
    email: user.email,
    name: user.name,
    role: user.role,
    loginTime: new Date().toISOString(),
  }

  localStorage.setItem(AUTH_KEY, JSON.stringify(sessionData))
}

function getCurrentUser() {
  const sessionData = localStorage.getItem(AUTH_KEY)
  if (sessionData) {
    try {
      return JSON.parse(sessionData)
    } catch (error) {
      console.error("Error parsing session data:", error)
      localStorage.removeItem(AUTH_KEY)
    }
  }
  return null
}

function logout() {
  // Clear session
  localStorage.removeItem(AUTH_KEY)

  // Show notification
  window.showNotification("Sesión cerrada correctamente", "info")

  // Redirect to landing page
  setTimeout(() => {
    window.showLanding()
  }, 1000)
}

function loadUserData(user) {
  // Update user name in header
  const userNameElement = document.getElementById("user-name")
  if (userNameElement) {
    userNameElement.textContent = user.name
  }

  // Update page title
  const pageTitleElement = document.getElementById("page-title")
  if (pageTitleElement) {
    pageTitleElement.textContent = getRoleName(user.role)
  }
}

function getRoleName(role) {
  const roleNames = {
    "super-admin": "Super Administrador",
    director: "Panel del Director",
    profesor: "Panel del Profesor",
    padre: "Panel del Padre",
    contable: "Panel Contable",
    coordinador: "Panel del Coordinador de Registro y Control Académico",
  }
  return roleNames[role] || "Dashboard"
}

function requireAuth() {
  const currentUser = getCurrentUser()
  if (!currentUser) {
    window.showLogin()
    return false
  }
  return currentUser
}

function hasRole(requiredRole) {
  const currentUser = getCurrentUser()
  return currentUser && currentUser.role === requiredRole
}

// Export functions
window.handleLogin = handleLogin
window.logout = logout
window.getCurrentUser = getCurrentUser
window.loadUserData = loadUserData
window.requireAuth = requireAuth
window.hasRole = hasRole
