// Contable module functions
function loadContableDashboard(container) {
  const formatDate = (date) => date.toLocaleDateString()
  container.innerHTML = `
        <div class="space-y-6">
            <!-- Header -->
            <div class="flex justify-between items-center">
                <div>
                    <h1 class="text-3xl font-bold text-gray-900">Dashboard Financiero</h1>
                    <p class="text-gray-600 mt-1">Vista ejecutiva del estado financiero institucional</p>
                </div>
                <div class="flex gap-3">
                    <button class="btn btn-outline">
                        <i class="fas fa-download"></i>
                        Exportar Reporte
                    </button>
                    <button class="btn btn-primary">
                        <i class="fas fa-plus"></i>
                        Nueva Transacción
                    </button>
                </div>
            </div>

            <!-- KPI Cards -->
            <div class="stats-grid">
                <div class="stat-card success">
                    <div class="stat-header">
                        <span class="stat-title">Ingresos del Mes</span>
                        <div class="stat-icon" style="background: var(--success)">
                            <i class="fas fa-arrow-up"></i>
                        </div>
                    </div>
                    <div class="stat-value">RD$2,450,000</div>
                    <div class="stat-change positive">+15% vs mes anterior</div>
                </div>

                <div class="stat-card error">
                    <div class="stat-header">
                        <span class="stat-title">Egresos del Mes</span>
                        <div class="stat-icon" style="background: var(--error)">
                            <i class="fas fa-arrow-down"></i>
                        </div>
                    </div>
                    <div class="stat-value">RD$1,850,000</div>
                    <div class="stat-change negative">+8% vs mes anterior</div>
                </div>

                <div class="stat-card info">
                    <div class="stat-header">
                        <span class="stat-title">Utilidad Neta</span>
                        <div class="stat-icon" style="background: var(--info)">
                            <i class="fas fa-chart-line"></i>
                        </div>
                    </div>
                    <div class="stat-value">RD$600,000</div>
                    <div class="stat-change positive">+25% vs mes anterior</div>
                </div>

                <div class="stat-card warning">
                    <div class="stat-header">
                        <span class="stat-title">Cuentas por Cobrar</span>
                        <div class="stat-icon" style="background: var(--warning)">
                            <i class="fas fa-clock"></i>
                        </div>
                    </div>
                    <div class="stat-value">RD$320,000</div>
                    <div class="stat-change negative">-5% vs mes anterior</div>
                </div>
            </div>

            <!-- Charts and Tables -->
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Flujo de Caja Mensual</h3>
                        <p class="card-description">Ingresos vs Egresos últimos 6 meses</p>
                    </div>
                    <div class="card-content">
                        <div class="chart-placeholder" style="height: 300px; background: var(--gray-100); border-radius: var(--radius-md); display: flex; align-items: center; justify-content: center; color: var(--gray-500);">
                            <div class="text-center">
                                <i class="fas fa-chart-bar" style="font-size: 3rem; margin-bottom: 1rem;"></i>
                                <p>Gráfico de Flujo de Caja</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Distribución de Gastos</h3>
                        <p class="card-description">Categorías de gastos del mes actual</p>
                    </div>
                    <div class="card-content">
                        <div class="chart-placeholder" style="height: 300px; background: var(--gray-100); border-radius: var(--radius-md); display: flex; align-items: center; justify-content: center; color: var(--gray-500);">
                            <div class="text-center">
                                <i class="fas fa-chart-pie" style="font-size: 3rem; margin-bottom: 1rem;"></i>
                                <p>Gráfico de Distribución</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Recent Transactions -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Transacciones Recientes</h3>
                    <p class="card-description">Últimas operaciones financieras registradas</p>
                </div>
                <div class="card-content">
                    <div class="table-container">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Fecha</th>
                                    <th>Descripción</th>
                                    <th>Tipo</th>
                                    <th>Monto</th>
                                    <th>Estado</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>${formatDate(new Date())}</td>
                                    <td>Pago mensualidad - Ana García</td>
                                    <td><span class="badge badge-success">Ingreso</span></td>
                                    <td class="text-success font-semibold">+RD$15,000</td>
                                    <td><span class="badge badge-success">Completado</span></td>
                                    <td>
                                        <button class="btn btn-small">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>${formatDate(new Date(Date.now() - 86400000))}</td>
                                    <td>Pago nómina profesores</td>
                                    <td><span class="badge badge-error">Egreso</span></td>
                                    <td class="text-error font-semibold">-RD$125,000</td>
                                    <td><span class="badge badge-success">Completado</span></td>
                                    <td>
                                        <button class="btn btn-small">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>${formatDate(new Date(Date.now() - 172800000))}</td>
                                    <td>Compra materiales oficina</td>
                                    <td><span class="badge badge-error">Egreso</span></td>
                                    <td class="text-error font-semibold">-RD$8,500</td>
                                    <td><span class="badge badge-warning">Pendiente</span></td>
                                    <td>
                                        <button class="btn btn-small">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    `
}

function loadContablePayroll(container) {
  const formatDate = (date) => date.toLocaleDateString()
  container.innerHTML = `
        <div class="space-y-6">
            <!-- Header -->
            <div class="flex justify-between items-center">
                <div>
                    <h1 class="text-3xl font-bold text-gray-900">Gestión de Nómina</h1>
                    <p class="text-gray-600 mt-1">Administra pagos del personal docente y administrativo</p>
                </div>
                <button class="btn btn-primary" onclick="showAddEmployeeModal()">
                    <i class="fas fa-plus"></i>
                    Agregar Empleado
                </button>
            </div>

            <!-- KPI Cards -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-header">
                        <span class="stat-title">Empleados Activos</span>
                        <div class="stat-icon">
                            <i class="fas fa-users"></i>
                        </div>
                    </div>
                    <div class="stat-value">24</div>
                </div>

                <div class="stat-card success">
                    <div class="stat-header">
                        <span class="stat-title">Pagado Este Mes</span>
                        <div class="stat-icon" style="background: var(--success)">
                            <i class="fas fa-dollar-sign"></i>
                        </div>
                    </div>
                    <div class="stat-value">RD$680,000</div>
                </div>

                <div class="stat-card info">
                    <div class="stat-header">
                        <span class="stat-title">Nómina Total</span>
                        <div class="stat-icon" style="background: var(--info)">
                            <i class="fas fa-file-invoice"></i>
                        </div>
                    </div>
                    <div class="stat-value">RD$750,000</div>
                </div>

                <div class="stat-card warning">
                    <div class="stat-header">
                        <span class="stat-title">% Presupuesto Usado</span>
                        <div class="stat-icon" style="background: var(--warning)">
                            <i class="fas fa-calendar"></i>
                        </div>
                    </div>
                    <div class="stat-value">85.2%</div>
                </div>
            </div>

            <!-- Tabs -->
            <div class="card">
                <div class="card-header">
                    <div class="flex justify-between items-center">
                        <div>
                            <h3 class="card-title">Personal Registrado</h3>
                            <p class="card-description">Gestiona la información del personal docente y administrativo</p>
                        </div>
                        <div class="flex gap-3">
                            <button class="btn btn-outline">
                                <i class="fas fa-download"></i>
                                Exportar
                            </button>
                            <button class="btn btn-primary" onclick="showGeneratePayrollModal()">
                                <i class="fas fa-file-invoice"></i>
                                Generar Nómina
                            </button>
                        </div>
                    </div>
                </div>
                <div class="card-content">
                    <div class="table-container">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Nombre</th>
                                    <th>Cargo</th>
                                    <th>Departamento</th>
                                    <th>Contrato</th>
                                    <th>Salario Base</th>
                                    <th>Estado</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td class="font-medium">María González</td>
                                    <td>Directora</td>
                                    <td>Dirección</td>
                                    <td><span class="badge badge-info">Fijo</span></td>
                                    <td>RD$45,000</td>
                                    <td><span class="badge badge-success">Activo</span></td>
                                    <td>
                                        <button class="btn btn-small">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <button class="btn btn-small">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="font-medium">Carlos Rodríguez</td>
                                    <td>Profesor de Matemáticas</td>
                                    <td>Académico</td>
                                    <td><span class="badge badge-info">Fijo</span></td>
                                    <td>RD$28,000</td>
                                    <td><span class="badge badge-success">Activo</span></td>
                                    <td>
                                        <button class="btn btn-small">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <button class="btn btn-small">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="font-medium">Ana Martínez</td>
                                    <td>Secretaria</td>
                                    <td>Administración</td>
                                    <td><span class="badge badge-info">Fijo</span></td>
                                    <td>RD$22,000</td>
                                    <td><span class="badge badge-success">Activo</span></td>
                                    <td>
                                        <button class="btn btn-small">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <button class="btn btn-small">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    `
}

function loadContableStudentProfile(container) {
  const formatDate = (date) => date.toLocaleDateString()
  container.innerHTML = `
        <div class="space-y-6">
            <!-- Header -->
            <div>
                <h1 class="text-3xl font-bold text-gray-900">Perfil Financiero del Estudiante</h1>
                <p class="text-gray-600 mt-1">Vista detallada de la situación financiera por estudiante</p>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <!-- Student List -->
                <div class="card lg:col-span-1">
                    <div class="card-header">
                        <h3 class="card-title">Lista de Estudiantes</h3>
                        <p class="card-description">Selecciona un estudiante para ver su perfil financiero</p>
                    </div>
                    <div class="card-content">
                        <div class="space-y-4">
                            <div class="input-group">
                                <i class="fas fa-search input-icon"></i>
                                <input type="text" placeholder="Buscar estudiante..." class="form-control">
                            </div>

                            <div class="space-y-2">
                                <div class="p-3 border border-indigo-500 bg-indigo-50 rounded-lg cursor-pointer">
                                    <div class="flex justify-between items-start">
                                        <div>
                                            <p class="font-medium text-gray-900">Ana García Pérez</p>
                                            <p class="text-sm text-gray-600">3ro A - Primaria</p>
                                            <p class="text-sm text-gray-500">María Pérez</p>
                                        </div>
                                        <div class="text-right">
                                            <span class="badge badge-warning">🟡 Pago parcial</span>
                                            <p class="text-sm text-red-600 mt-1">RD$15,000</p>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="p-3 border border-gray-200 rounded-lg cursor-pointer hover:border-gray-300">
                                    <div class="flex justify-between items-start">
                                        <div>
                                            <p class="font-medium text-gray-900">Carlos Rodríguez López</p>
                                            <p class="text-sm text-gray-600">5to B - Primaria</p>
                                            <p class="text-sm text-gray-500">Juan Rodríguez</p>
                                        </div>
                                        <div class="text-right">
                                            <span class="badge badge-success">🟢 Al día</span>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="p-3 border border-gray-200 rounded-lg cursor-pointer hover:border-gray-300">
                                    <div class="flex justify-between items-start">
                                        <div>
                                            <p class="font-medium text-gray-900">Sofía Martínez Cruz</p>
                                            <p class="text-sm text-gray-600">1ro C - Secundaria</p>
                                            <p class="text-sm text-gray-500">Carmen Cruz</p>
                                        </div>
                                        <div class="text-right">
                                            <span class="badge badge-error">🔴 Vencido</span>
                                            <p class="text-sm text-red-600 mt-1">RD$45,000</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Student Profile -->
                <div class="lg:col-span-2 space-y-6">
                    <!-- Student Info -->
                    <div class="card">
                        <div class="card-header">
                            <div class="flex justify-between items-start">
                                <div>
                                    <h3 class="card-title flex items-center gap-2">
                                        <i class="fas fa-user"></i>
                                        Ana García Pérez
                                    </h3>
                                    <p class="card-description">3ro A - Primaria</p>
                                </div>
                                <div class="flex gap-2">
                                    <span class="badge badge-warning">🟡 Pago parcial</span>
                                    <span class="badge badge-warning">🟡 Medio</span>
                                </div>
                            </div>
                        </div>
                        <div class="card-content">
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div class="space-y-4">
                                    <div class="flex items-center gap-3">
                                        <i class="fas fa-book-open text-gray-500"></i>
                                        <div>
                                            <p class="text-sm text-gray-600">Curso Actual</p>
                                            <p class="font-medium">3ro A - Primaria</p>
                                        </div>
                                    </div>
                                    <div class="flex items-center gap-3">
                                        <i class="fas fa-user text-gray-500"></i>
                                        <div>
                                            <p class="text-sm text-gray-600">Tutor Responsable</p>
                                            <p class="font-medium">María Pérez</p>
                                        </div>
                                    </div>
                                    <div class="flex items-center gap-3">
                                        <i class="fas fa-phone text-gray-500"></i>
                                        <div>
                                            <p class="text-sm text-gray-600">Teléfono</p>
                                            <p class="font-medium">809-555-0123</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="space-y-4">
                                    <div class="flex items-center gap-3">
                                        <i class="fas fa-envelope text-gray-500"></i>
                                        <div>
                                            <p class="text-sm text-gray-600">Email</p>
                                            <p class="font-medium">maria.perez@email.com</p>
                                        </div>
                                    </div>
                                    <div class="flex items-center gap-3">
                                        <i class="fas fa-dollar-sign text-gray-500"></i>
                                        <div>
                                            <p class="text-sm text-gray-600">Deuda Actual</p>
                                            <p class="font-medium text-red-600">RD$15,000</p>
                                        </div>
                                    </div>
                                    <div class="flex items-center gap-3">
                                        <i class="fas fa-calendar text-gray-500"></i>
                                        <div>
                                            <p class="text-sm text-gray-600">Último Pago</p>
                                            <p class="font-medium">2024-01-15</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Financial Details -->
                    <div class="card">
                        <div class="card-header">
                            <div class="flex justify-between items-center">
                                <h3 class="card-title">Facturas Generadas</h3>
                                <div class="flex gap-3">
                                    <button class="btn btn-primary">
                                        <i class="fas fa-file-invoice"></i>
                                        Nueva Factura
                                    </button>
                                    <button class="btn btn-outline">
                                        <i class="fas fa-credit-card"></i>
                                        Registrar Pago
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="card-content">
                            <div class="table-container">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Número</th>
                                            <th>Concepto</th>
                                            <th>Emisión</th>
                                            <th>Vencimiento</th>
                                            <th>Monto</th>
                                            <th>Estado</th>
                                            <th>Acciones</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td class="font-medium">INV-2024-001</td>
                                            <td>Mensualidad Enero</td>
                                            <td>2024-01-01</td>
                                            <td>2024-01-31</td>
                                            <td>RD$15,000</td>
                                            <td><span class="badge badge-warning">Pendiente</span></td>
                                            <td>
                                                <button class="btn btn-small">
                                                    <i class="fas fa-eye"></i>
                                                </button>
                                                <button class="btn btn-small">
                                                    <i class="fas fa-download"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="font-medium">INV-2023-012</td>
                                            <td>Mensualidad Diciembre</td>
                                            <td>2023-12-01</td>
                                            <td>2023-12-31</td>
                                            <td>RD$15,000</td>
                                            <td><span class="badge badge-success">Pagada</span></td>
                                            <td>
                                                <button class="btn btn-small">
                                                    <i class="fas fa-eye"></i>
                                                </button>
                                                <button class="btn btn-small">
                                                    <i class="fas fa-download"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <!-- Quick Actions -->
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Acciones Rápidas</h3>
                        </div>
                        <div class="card-content">
                            <div class="flex flex-wrap gap-3">
                                <button class="btn btn-outline">
                                    <i class="fas fa-paper-plane"></i>
                                    Enviar Recordatorio
                                </button>
                                <button class="btn btn-outline">
                                    <i class="fas fa-download"></i>
                                    Estado de Cuenta
                                </button>
                                <button class="btn btn-outline">
                                    <i class="fas fa-phone"></i>
                                    Contactar Tutor
                                </button>
                                <button class="btn btn-outline">
                                    <i class="fas fa-file-alt"></i>
                                    Historial Completo
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `
}

// Modal functions for Contable module
function showAddEmployeeModal() {
  const modalContent = `
        <form onsubmit="handleAddEmployee(event)">
            <div class="form-row">
                <div class="form-group">
                    <label for="employeeName">Nombre Completo</label>
                    <input type="text" id="employeeName" name="name" required>
                </div>
                <div class="form-group">
                    <label for="employeePosition">Cargo</label>
                    <input type="text" id="employeePosition" name="position" required>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label for="employeeDepartment">Departamento</label>
                    <select id="employeeDepartment" name="department" required>
                        <option value="">Seleccionar departamento</option>
                        <option value="direccion">Dirección</option>
                        <option value="academico">Académico</option>
                        <option value="administracion">Administración</option>
                        <option value="mantenimiento">Mantenimiento</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="employeeContract">Tipo de Contrato</label>
                    <select id="employeeContract" name="contract" required>
                        <option value="">Tipo de contrato</option>
                        <option value="fijo">Fijo</option>
                        <option value="temporal">Temporal</option>
                        <option value="honorario">Honorario</option>
                    </select>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label for="employeeSalary">Salario Base</label>
                    <input type="number" id="employeeSalary" name="salary" required>
                </div>
                <div class="form-group">
                    <label for="employeeStartDate">Fecha de Ingreso</label>
                    <input type="date" id="employeeStartDate" name="startDate" required>
                </div>
            </div>
            <div class="form-group">
                <label for="employeeBankAccount">Cuenta Bancaria (Opcional)</label>
                <input type="text" id="employeeBankAccount" name="bankAccount">
            </div>
        </form>
    `

  const actions = [
    { text: "Cancelar", class: "btn-outline", onclick: 'hideModal("add-employee-modal")' },
    {
      text: "Guardar Empleado",
      class: "btn-primary",
      onclick: 'document.querySelector("#add-employee-modal form").submit()',
    },
  ]

  createModal("Agregar Nuevo Empleado", modalContent, actions)
}

function showGeneratePayrollModal() {
  const modalContent = `
        <form onsubmit="handleGeneratePayroll(event)">
            <div class="form-group">
                <label for="payrollPeriod">Período</label>
                <input type="text" id="payrollPeriod" value="Enero 2024" disabled>
            </div>
            <div class="form-group">
                <label for="includeBonuses">Incluir Bonificaciones</label>
                <select id="includeBonuses" name="bonuses">
                    <option value="yes">Sí, incluir bonificaciones</option>
                    <option value="no">No incluir</option>
                </select>
            </div>
            <div class="form-group">
                <label for="overtimeCalculation">Calcular Horas Extra</label>
                <select id="overtimeCalculation" name="overtime">
                    <option value="auto">Cálculo automático</option>
                    <option value="manual">Ingreso manual</option>
                </select>
            </div>
        </form>
    `

  const actions = [
    { text: "Cancelar", class: "btn-outline", onclick: 'hideModal("generate-payroll-modal")' },
    {
      text: "Generar Nómina",
      class: "btn-primary",
      onclick: 'document.querySelector("#generate-payroll-modal form").submit()',
    },
  ]

  createModal("Generar Nómina", modalContent, actions)
}

function handleAddEmployee(event) {
  event.preventDefault()
  showNotification("Empleado agregado correctamente", "success")
  hideModal("add-employee-modal")
  // Reload the payroll module
  loadContablePayroll(document.getElementById("content-area"))
}

function handleGeneratePayroll(event) {
  event.preventDefault()
  showNotification("Nómina generada correctamente", "success")
  hideModal("generate-payroll-modal")
}

// Helper functions
function createModal(title, content, actions) {
  const modal = document.createElement("div")
  modal.id = "add-employee-modal"
  modal.className = "modal"
  modal.innerHTML = `
        <div class="modal-content">
            <div class="modal-header">
                <h2>${title}</h2>
                <button class="close-btn" onclick="hideModal('add-employee-modal')">&times;</button>
            </div>
            <div class="modal-body">
                ${content}
            </div>
            <div class="modal-footer">
                ${actions.map((action) => `<button class="btn ${action.class}" onclick="${action.onclick}">${action.text}</button>`).join("")}
            </div>
        </div>
    `
  document.body.appendChild(modal)
  modal.style.display = "block"
}

function showNotification(message, type) {
  const notification = document.createElement("div")
  notification.className = `notification ${type}`
  notification.textContent = message
  document.body.appendChild(notification)
  setTimeout(() => {
    document.body.removeChild(notification)
  }, 3000)
}

function hideModal(modalId) {
  const modal = document.getElementById(modalId)
  if (modal) {
    modal.style.display = "none"
  }
}

// Export functions
window.loadContableDashboard = loadContableDashboard
window.loadContablePayroll = loadContablePayroll
window.loadContableStudentProfile = loadContableStudentProfile
window.showAddEmployeeModal = showAddEmployeeModal
window.showGeneratePayrollModal = showGeneratePayrollModal
window.handleAddEmployee = handleAddEmployee
window.handleGeneratePayroll = handleGeneratePayroll
