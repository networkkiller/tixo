// Utility functions for the application
function createElement(tag, className = "", content = "") {
  const element = document.createElement(tag)
  if (className) element.className = className
  if (content) element.innerHTML = content
  return element
}

function formatNumber(number) {
  return new Intl.NumberFormat("es-DO").format(number)
}

function formatPercentage(number) {
  return new Intl.NumberFormat("es-DO", {
    style: "percent",
    minimumFractionDigits: 1,
    maximumFractionDigits: 1,
  }).format(number / 100)
}

function validateEmail(email) {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  return emailRegex.test(email)
}

function validatePhone(phone) {
  const phoneRegex = /^[\d\s\-+$$$$]+$/
  return phoneRegex.test(phone) && phone.length >= 10
}

function sanitizeInput(input) {
  const div = document.createElement("div")
  div.textContent = input
  return div.innerHTML
}

function copyToClipboard(text) {
  navigator.clipboard
    .writeText(text)
    .then(() => {
      window.showNotification("Copiado al portapapeles", "success")
    })
    .catch(() => {
      window.showNotification("Error al copiar", "error")
    })
}

function downloadFile(data, filename, type = "text/plain") {
  const blob = new Blob([data], { type })
  const url = URL.createObjectURL(blob)
  const link = document.createElement("a")
  link.href = url
  link.download = filename
  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)
  URL.revokeObjectURL(url)
}

function getRandomColor() {
  const colors = [
    "var(--primary)",
    "var(--secondary)",
    "var(--success)",
    "var(--warning)",
    "var(--error)",
    "var(--info)",
  ]
  return colors[Math.floor(Math.random() * colors.length)]
}

function truncateText(text, maxLength) {
  if (text.length <= maxLength) return text
  return text.substr(0, maxLength) + "..."
}

function isValidDate(dateString) {
  const date = new Date(dateString)
  return date instanceof Date && !isNaN(date)
}

function addDays(date, days) {
  const result = new Date(date)
  result.setDate(result.getDate() + days)
  return result
}

function getDaysDifference(date1, date2) {
  const timeDifference = Math.abs(date2.getTime() - date1.getTime())
  return Math.ceil(timeDifference / (1000 * 3600 * 24))
}

// Export utility functions
window.createElement = createElement
window.formatNumber = formatNumber
window.formatPercentage = formatPercentage
window.validateEmail = validateEmail
window.validatePhone = validatePhone
window.sanitizeInput = sanitizeInput
window.copyToClipboard = copyToClipboard
window.downloadFile = downloadFile
window.getRandomColor = getRandomColor
window.truncateText = truncateText
window.isValidDate = isValidDate
window.addDays = addDays
window.getDaysDifference = getDaysDifference

// Declare showNotification function
window.showNotification = (message, type) => {
  console.log(`Notification: ${message} (Type: ${type})`)
}
