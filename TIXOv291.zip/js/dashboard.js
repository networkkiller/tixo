// Dashboard initialization and management
const ROLE_MODULES = {
  "super-admin": [{ id: "module1" }, { id: "module2" }],
  director: [{ id: "module3" }],
  profesor: [{ id: "module4" }],
  padre: [{ id: "module5" }],
  contable: [{ id: "module6" }],
  coordinador: [{ id: "module7" }],
}

function initializeSidebar(role) {
  // Sidebar initialization logic here
  console.log(`Initializing sidebar for ${role}`)
}

function navigateToModule(moduleId, role) {
  // Navigation logic here
  console.log(`Navigating to module ${moduleId} for ${role}`)
}

function initializeDashboard(role) {
  // Initialize sidebar navigation
  initializeSidebar(role)

  // Update page title
  updateDashboardTitle(role)

  // Load initial module
  const modules = ROLE_MODULES[role]
  if (modules && modules.length > 0) {
    navigateToModule(modules[0].id, role)
  }
}

function updateDashboardTitle(role) {
  const titles = {
    "super-admin": "Panel de Super Administrador",
    director: "Panel del Director",
    profesor: "Panel del Profesor",
    padre: "Panel del Padre de Familia",
    contable: "Panel Contable",
    coordinador: "Panel del Coordinador de Registro y Control Académico",
  }

  const pageTitle = document.getElementById("page-title")
  if (pageTitle) {
    pageTitle.textContent = titles[role] || "Dashboard"
  }
}

// Export functions
window.initializeDashboard = initializeDashboard
