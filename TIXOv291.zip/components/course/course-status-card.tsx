"use client"

import type React from "react"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Button } from "@/components/ui/button"
import {
  BookOpen,
  Users,
  Calendar,
  UserCheck,
  AlertTriangle,
  Clock,
  Eye,
  Edit,
  MessageSquare,
  Save,
  X,
} from "lucide-react"
import { type Course, CourseInteroperabilityService } from "@/lib/course-interoperability"
import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface CourseStatusCardProps {
  course: Course
  userRole: "director" | "coordinador-academico" | "coordinador"
  onViewDetails?: (courseId: string) => void
  onEdit?: (courseId: string) => void
  onRequestConfiguration?: (courseId: string) => void
}

export function CourseStatusCard({
  course,
  userRole,
  onViewDetails,
  onEdit,
  onRequestConfiguration,
}: CourseStatusCardProps) {
  const statusBadge = CourseInteroperabilityService.getCourseStatusBadge(course)
  const config = course.configurationStatus
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [editFormData, setEditFormData] = useState({
    nivelEducativo: course.nivelEducativo || "inicial",
    grade: course.grade,
    section: course.section,
    turn: course.turn,
    capacity: course.capacity,
    teacher: course.teacher || "unassigned",
    modalidad: course.modalidad || "regular",
    notes: course.notes || "",
  })

  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Here you would typically call an API to update the course
    if (onEdit) {
      // Pass both the course ID and the updated data
      onEdit(course.id)
      console.log("Course data updated:", editFormData)
    }
    setIsEditDialogOpen(false)
  }

  const handleInputChange = (field: string, value: string | number) => {
    setEditFormData((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  const getActionButtons = () => {
    switch (userRole) {
      case "director":
        return (
          <div className="flex gap-2">
            <Button size="sm" variant="ghost" onClick={() => onViewDetails?.(course.id)}>
              <Eye className="h-4 w-4" />
            </Button>
            <Button
              size="sm"
              variant="outline"
              className="flex items-center gap-1 text-blue-600 hover:text-blue-700 hover:bg-blue-50 border-blue-200 bg-transparent"
              onClick={() => setIsEditDialogOpen(true)}
              title="Editar datos del curso"
            >
              <Edit className="h-4 w-4" />
              <span className="hidden sm:inline text-xs">Editar Curso</span>
            </Button>
            {!config.isComplete && (
              <Button
                size="sm"
                variant="ghost"
                onClick={() => onRequestConfiguration?.(course.id)}
                title="Solicitar configuración pendiente"
              >
                <MessageSquare className="h-4 w-4 text-orange-500" />
              </Button>
            )}
          </div>
        )

      case "coordinador-academico":
        return (
          <div className="flex gap-2">
            <Button size="sm" variant="ghost" onClick={() => onViewDetails?.(course.id)}>
              <Eye className="h-4 w-4" />
            </Button>
            {!config.hasSubjects && (
              <Button size="sm" variant="outline" className="text-xs bg-transparent">
                Configurar Materias
              </Button>
            )}
            {!config.hasSchedule && (
              <Button size="sm" variant="outline" className="text-xs bg-transparent">
                Crear Horario
              </Button>
            )}
          </div>
        )

      case "coordinador":
        return (
          <div className="flex gap-2">
            <Button size="sm" variant="ghost" onClick={() => onViewDetails?.(course.id)}>
              <Eye className="h-4 w-4" />
            </Button>
            {course.studentsCount < course.capacity && (
              <Button size="sm" variant="outline" className="text-xs bg-transparent">
                Asignar Estudiantes
              </Button>
            )}
          </div>
        )

      default:
        return null
    }
  }

  return (
    <>
      <Card className="bg-white border-gray-200 hover:border-purple-300 transition-all duration-300 hover:shadow-lg">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-gray-900 text-lg">{course.name}</CardTitle>
            <Badge className={statusBadge.color}>{statusBadge.text}</Badge>
          </div>
          <div className="flex items-center gap-4 text-sm text-gray-600">
            <span>Turno: {course.turn}</span>
            <span>
              Capacidad: {course.studentsCount}/{course.capacity}
            </span>
          </div>
        </CardHeader>

        <CardContent className="space-y-4">
          {/* Progreso de configuración */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-600">Configuración</span>
              <span className="font-medium">{config.completionPercentage}%</span>
            </div>
            <Progress value={config.completionPercentage} className="h-2" />
          </div>

          {/* Estado de componentes */}
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div className="flex items-center gap-2">
              <BookOpen className={`h-4 w-4 ${config.hasSubjects ? "text-green-600" : "text-gray-400"}`} />
              <span className={config.hasSubjects ? "text-green-600" : "text-gray-500"}>
                {config.hasSubjects ? "✅ Materias" : "❌ Materias"}
              </span>
            </div>

            <div className="flex items-center gap-2">
              <UserCheck className={`h-4 w-4 ${config.hasTeacher ? "text-green-600" : "text-gray-400"}`} />
              <span className={config.hasTeacher ? "text-green-600" : "text-gray-500"}>
                {config.hasTeacher ? "✅ Docente" : "❌ Docente"}
              </span>
            </div>

            <div className="flex items-center gap-2">
              <Calendar className={`h-4 w-4 ${config.hasSchedule ? "text-green-600" : "text-gray-400"}`} />
              <span className={config.hasSchedule ? "text-green-600" : "text-gray-500"}>
                {config.hasSchedule ? "✅ Horario" : "❌ Horario"}
              </span>
            </div>

            <div className="flex items-center gap-2">
              <Users className={`h-4 w-4 ${config.hasStudents ? "text-green-600" : "text-gray-400"}`} />
              <span className={config.hasStudents ? "text-green-600" : "text-gray-500"}>
                {config.hasStudents ? "✅ Estudiantes" : "❌ Estudiantes"}
              </span>
            </div>
          </div>

          {/* Información adicional */}
          <div className="pt-2 border-t border-gray-100">
            <div className="text-xs text-gray-500 space-y-1">
              <div>Creado: {new Date(course.createdAt).toLocaleDateString()}</div>
              {course.teacher && course.teacher !== "unassigned" && <div>Encargado: {course.teacher}</div>}
            </div>
          </div>

          {/* Alertas específicas por rol */}
          {userRole === "coordinador-academico" && !config.hasSubjects && (
            <div className="flex items-center gap-2 p-2 bg-yellow-50 rounded-lg border border-yellow-200">
              <AlertTriangle className="h-4 w-4 text-yellow-600" />
              <span className="text-xs text-yellow-700">Requiere configuración de materias</span>
            </div>
          )}

          {userRole === "coordinador" && !config.hasStudents && (
            <div className="flex items-center gap-2 p-2 bg-blue-50 rounded-lg border border-blue-200">
              <Clock className="h-4 w-4 text-blue-600" />
              <span className="text-xs text-blue-700">Disponible para asignación de estudiantes</span>
            </div>
          )}

          {/* Botones de acción */}
          <div className="pt-2 border-t border-gray-100">{getActionButtons()}</div>
        </CardContent>
      </Card>

      {/* Edit Course Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle className="text-xl font-semibold flex items-center gap-2">
              <Edit className="h-5 w-5 text-blue-600" />
              Editar Curso
            </DialogTitle>
          </DialogHeader>

          <form onSubmit={handleEditSubmit} className="space-y-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="nivelEducativo">Nivel Educativo</Label>
                <Select
                  value={editFormData.nivelEducativo}
                  onValueChange={(value) => handleInputChange("nivelEducativo", value)}
                >
                  <SelectTrigger id="nivelEducativo" className="bg-white border-gray-300">
                    <SelectValue placeholder="Seleccionar nivel educativo" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="inicial">Inicial</SelectItem>
                    <SelectItem value="primaria">Primaria</SelectItem>
                    <SelectItem value="secundaria">Secundaria</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="grade">Grado</Label>
                <Select value={editFormData.grade} onValueChange={(value) => handleInputChange("grade", value)}>
                  <SelectTrigger id="grade" className="bg-white border-gray-300">
                    <SelectValue placeholder="Seleccionar grado" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="inicial-3">Inicial 3 años</SelectItem>
                    <SelectItem value="inicial-4">Inicial 4 años</SelectItem>
                    <SelectItem value="inicial-5">Inicial 5 años</SelectItem>
                    <SelectItem value="1ro">1ro Primaria</SelectItem>
                    <SelectItem value="2do">2do Primaria</SelectItem>
                    <SelectItem value="3ro">3ro Primaria</SelectItem>
                    <SelectItem value="4to">4to Primaria</SelectItem>
                    <SelectItem value="5to">5to Primaria</SelectItem>
                    <SelectItem value="6to">6to Primaria</SelectItem>
                    <SelectItem value="1ro-sec">1ro Secundaria</SelectItem>
                    <SelectItem value="2do-sec">2do Secundaria</SelectItem>
                    <SelectItem value="3ro-sec">3ro Secundaria</SelectItem>
                    <SelectItem value="4to-sec">4to Secundaria</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="section">Sección</Label>
                <Select value={editFormData.section} onValueChange={(value) => handleInputChange("section", value)}>
                  <SelectTrigger id="section" className="bg-white border-gray-300">
                    <SelectValue placeholder="Seleccionar sección" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="A">A</SelectItem>
                    <SelectItem value="B">B</SelectItem>
                    <SelectItem value="C">C</SelectItem>
                    <SelectItem value="D">D</SelectItem>
                    <SelectItem value="E">E</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="turn">Turno</Label>
                <Select value={editFormData.turn} onValueChange={(value) => handleInputChange("turn", value)}>
                  <SelectTrigger id="turn" className="bg-white border-gray-300">
                    <SelectValue placeholder="Seleccionar turno" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="mañana">Mañana (7:00 AM - 12:00 PM)</SelectItem>
                    <SelectItem value="tarde">Tarde (1:00 PM - 6:00 PM)</SelectItem>
                    <SelectItem value="extendida">Extendida (7:00 AM - 4:00 PM)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="capacity">Capacidad</Label>
                <Input
                  id="capacity"
                  type="number"
                  value={editFormData.capacity}
                  onChange={(e) => handleInputChange("capacity", Number.parseInt(e.target.value) || 0)}
                  min="1"
                  className="bg-white border-gray-300"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="modalidad">Modalidad</Label>
                <Select value={editFormData.modalidad} onValueChange={(value) => handleInputChange("modalidad", value)}>
                  <SelectTrigger id="modalidad" className="bg-white border-gray-300">
                    <SelectValue placeholder="Seleccionar modalidad" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="regular">Regular</SelectItem>
                    <SelectItem value="academica">Académica</SelectItem>
                    <SelectItem value="tecnica">Técnica</SelectItem>
                    <SelectItem value="artistica">Artística</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="teacher">Profesor Encargado</Label>
              <Select value={editFormData.teacher} onValueChange={(value) => handleInputChange("teacher", value)}>
                <SelectTrigger id="teacher" className="bg-white border-gray-300">
                  <SelectValue placeholder="Seleccionar profesor" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="unassigned">Sin asignar</SelectItem>
                  <SelectItem value="teacher_001">María González - Matemáticas</SelectItem>
                  <SelectItem value="teacher_002">Roberto Sánchez - Lenguaje</SelectItem>
                  <SelectItem value="teacher_003">Ana Martínez - Ciencias</SelectItem>
                  <SelectItem value="teacher_004">Carlos López - Historia</SelectItem>
                  <SelectItem value="teacher_005">Lucía Fernández - Inglés</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes">Notas Adicionales</Label>
              <Input
                id="notes"
                value={editFormData.notes}
                onChange={(e) => handleInputChange("notes", e.target.value)}
                className="bg-white border-gray-300"
              />
            </div>

            <DialogFooter className="pt-4 border-t border-gray-200">
              <Button
                type="button"
                variant="outline"
                onClick={() => setIsEditDialogOpen(false)}
                className="border-gray-300 text-gray-600 hover:bg-gray-50"
              >
                <X className="mr-2 h-4 w-4" />
                Cancelar
              </Button>
              <Button
                type="submit"
                className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white"
              >
                <Save className="mr-2 h-4 w-4" />
                Guardar Cambios
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </>
  )
}
