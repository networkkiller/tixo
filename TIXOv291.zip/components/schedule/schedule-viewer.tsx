"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Calendar, Clock, Download, Edit, ArrowLeft, BookOpen, Users, BarChart, FileText } from "lucide-react"
import type { Course } from "@/lib/course-interoperability"

interface ScheduleViewerProps {
  course: Course
  schedule: { [key: string]: { [key: string]: any } }
  onEdit?: () => void
  onBack?: () => void
}

export function ScheduleViewer({ course, schedule, onEdit, onBack }: ScheduleViewerProps) {
  const [activeDay, setActiveDay] = useState<string | null>(null)
  const days = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes"]

  // Determinar si es jornada extendida basado en la cantidad de slots
  const isExtendedSchedule = Object.keys(schedule).length > 6

  const timeSlots = Object.keys(schedule).sort((a, b) => {
    const aNum = Number.parseInt(a.split("_")[1])
    const bNum = Number.parseInt(b.split("_")[1])
    return aNum - bNum
  })

  const getTimeLabel = (slotId: string) => {
    const hour = Number.parseInt(slotId.split("_")[1])
    return `${hour.toString().padStart(2, "0")}:00 - ${(hour + 1).toString().padStart(2, "0")}:00`
  }

  const getSubjectStats = () => {
    const stats: { [subject: string]: { count: number; teacher: string; color: string } } = {}

    Object.values(schedule).forEach((daySchedule) => {
      Object.values(daySchedule).forEach((cell) => {
        if (cell.type === "class") {
          if (!stats[cell.subject]) {
            stats[cell.subject] = {
              count: 0,
              teacher: cell.teacher,
              color: cell.color,
            }
          }
          stats[cell.subject].count++
        }
      })
    })

    return stats
  }

  const getBreakStats = () => {
    let breakCount = 0
    const breakNames: string[] = []

    Object.values(schedule).forEach((daySchedule) => {
      Object.values(daySchedule).forEach((cell) => {
        if (cell.type === "break") {
          breakCount++
          if (!breakNames.includes(cell.subject)) {
            breakNames.push(cell.subject)
          }
        }
      })
    })

    return { count: breakCount, names: breakNames }
  }

  const downloadSchedule = () => {
    const scheduleData = {
      curso: course.name,
      turno: isExtendedSchedule ? "Jornada Extendida" : course.turn,
      profesor_encargado: course.teacher,
      horario: schedule,
      fecha_generacion: new Date().toLocaleDateString(),
    }

    const blob = new Blob([JSON.stringify(scheduleData, null, 2)], { type: "application/json" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `horario_${course.name.replace(/\s+/g, "_")}.json`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  const renderCell = (timeSlot: string, day: string) => {
    const cell = schedule[timeSlot]?.[day]
    if (!cell) return null

    if (cell.type === "empty") {
      return (
        <td key={`${timeSlot}-${day}`} className="border border-gray-300 p-1">
          <div className="h-16 bg-gray-50 rounded flex items-center justify-center text-gray-400 text-sm">Libre</div>
        </td>
      )
    }

    if (cell.type === "break") {
      return (
        <td key={`${timeSlot}-${day}`} className="border border-gray-300 p-1">
          <div className={`h-16 rounded flex items-center justify-center text-sm font-medium ${cell.color}`}>
            <div className="text-center">
              <div>{cell.subject}</div>
              <div className="text-xs opacity-75">Receso</div>
            </div>
          </div>
        </td>
      )
    }

    return (
      <td key={`${timeSlot}-${day}`} className="border border-gray-300 p-1">
        <div className={`h-16 rounded p-2 text-xs ${cell.color}`}>
          <div className="font-medium truncate">{cell.subject}</div>
          <div className="truncate opacity-75">{cell.teacher}</div>
        </div>
      </td>
    )
  }

  const subjectStats = getSubjectStats()
  const breakStats = getBreakStats()

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="outline" onClick={onBack}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Volver
            </Button>
            <div>
              <h1 className="text-2xl font-bold">📅 Horario - {course.name}</h1>
              <p className="text-gray-600">
                {isExtendedSchedule ? "Jornada Extendida (8:00-16:00)" : course.turn} • {course.teacher} •{" "}
                {timeSlots.length} bloques por día
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Button variant="outline" onClick={downloadSchedule}>
              <Download className="h-4 w-4 mr-2" />📥 Descargar
            </Button>
            {onEdit && (
              <Button onClick={onEdit} className="bg-blue-600 hover:bg-blue-700">
                <Edit className="h-4 w-4 mr-2" />
                ✏️ Editar Horario
              </Button>
            )}
          </div>
        </div>
      </div>

      <div className="p-4">
        <Tabs defaultValue="schedule" className="space-y-4">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="schedule" className="flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              Horario Semanal
            </TabsTrigger>
            <TabsTrigger value="subjects" className="flex items-center gap-2">
              <BookOpen className="h-4 w-4" />
              Materias
            </TabsTrigger>
            <TabsTrigger value="stats" className="flex items-center gap-2">
              <BarChart className="h-4 w-4" />
              Estadísticas
            </TabsTrigger>
          </TabsList>

          <TabsContent value="schedule">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="h-5 w-5" />
                  Horario Semanal - {course.name}
                </CardTitle>
                <CardDescription>
                  {isExtendedSchedule
                    ? "Jornada extendida de 8 horas (8:00 AM - 4:00 PM) con recesos programados"
                    : "Jornada regular con horario estándar"}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse border border-gray-300">
                    <thead>
                      <tr>
                        <th className="border border-gray-300 p-3 bg-gray-50 font-medium min-w-[120px]">
                          <div className="flex items-center gap-2">
                            <Clock className="h-4 w-4" />
                            Hora
                          </div>
                        </th>
                        {days.map((day) => (
                          <th key={day} className="border border-gray-300 p-3 bg-gray-50 font-medium min-w-[150px]">
                            {day}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {timeSlots.map((slot) => (
                        <tr key={slot}>
                          <td className="border border-gray-300 p-3 bg-gray-50 font-medium text-sm">
                            <div className="text-center">
                              <div>{getTimeLabel(slot)}</div>
                              <div className="text-xs text-gray-600 mt-1">Bloque {slot.split("_")[1]}</div>
                            </div>
                          </td>
                          {days.map((day) => renderCell(slot, day))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Leyenda */}
                <div className="mt-4 p-4 bg-gray-50 rounded-lg">
                  <h4 className="font-medium mb-2">📋 Leyenda:</h4>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-sm">
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 bg-gray-100 border border-gray-300 rounded"></div>
                      <span>Libre</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 bg-yellow-100 border border-yellow-300 rounded"></div>
                      <span>Receso</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 bg-blue-100 border border-blue-300 rounded"></div>
                      <span>Clase</span>
                    </div>
                  </div>
                  {isExtendedSchedule && (
                    <div className="mt-2 text-xs text-blue-600">
                      💡 <strong>Jornada Extendida:</strong> Este horario incluye recesos de mañana, almuerzo y tarde
                      para optimizar el aprendizaje.
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="subjects">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {Object.entries(subjectStats).map(([subject, stats]) => (
                <Card key={subject}>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg flex items-center gap-2">
                      <BookOpen className="h-5 w-5" />
                      {subject}
                    </CardTitle>
                    <CardDescription>{stats.teacher}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">Horas semanales:</span>
                        <Badge variant="secondary">{stats.count}h</Badge>
                      </div>
                      <div
                        className={`w-full h-2 rounded-full ${stats.color.replace("text-", "bg-").replace("border-", "bg-")}`}
                      ></div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="stats">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <BookOpen className="h-4 w-4" />
                    Total Materias
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{Object.keys(subjectStats).length}</div>
                  <p className="text-xs text-gray-600">Materias diferentes</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <Clock className="h-4 w-4" />
                    Horas de Clase
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {Object.values(subjectStats).reduce((sum, stats) => sum + stats.count, 0)}
                  </div>
                  <p className="text-xs text-gray-600">Horas semanales</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <Users className="h-4 w-4" />
                    Docentes
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {new Set(Object.values(subjectStats).map((stats) => stats.teacher)).size}
                  </div>
                  <p className="text-xs text-gray-600">Profesores únicos</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <FileText className="h-4 w-4" />
                    Recesos
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{breakStats.names.length}</div>
                  <p className="text-xs text-gray-600">
                    {isExtendedSchedule ? "Mañana, Almuerzo, Tarde" : "Receso regular"}
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Distribución por día */}
            <Card className="mt-4">
              <CardHeader>
                <CardTitle>📊 Distribución por Día</CardTitle>
                <CardDescription>Cantidad de clases por día de la semana</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {days.map((day) => {
                    const dayClasses = timeSlots.filter((slot) => schedule[slot]?.[day]?.type === "class").length

                    const dayBreaks = timeSlots.filter((slot) => schedule[slot]?.[day]?.type === "break").length

                    return (
                      <div key={day} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div className="font-medium">{day}</div>
                        <div className="flex items-center gap-4 text-sm">
                          <span className="text-blue-600">{dayClasses} clases</span>
                          <span className="text-yellow-600">{dayBreaks} recesos</span>
                          <span className="text-gray-500">{timeSlots.length - dayClasses - dayBreaks} libres</span>
                        </div>
                      </div>
                    )
                  })}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
