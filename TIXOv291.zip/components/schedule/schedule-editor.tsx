"use client"

import { Calendar } from "@/components/ui/calendar"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Progress } from "@/components/ui/progress"
import {
  Save,
  CheckCircle,
  RotateCcw,
  Trash2,
  Download,
  ArrowLeft,
  AlertTriangle,
  Clock,
  BookOpen,
  Coffee,
  GripVertical,
  X,
  Wand2,
  Settings,
} from "lucide-react"
import type { Course } from "@/lib/course-interoperability"

interface Subject {
  id: string
  name: string
  teacher: string
  teacherId: string
  weeklyHours: number
  assignedHours: number
  area: string
  color: string
  isCore: boolean
}

interface TimeSlot {
  id: string
  start: string
  end: string
  label: string
  isBreakTime?: boolean
}

interface ScheduleCell {
  id?: string
  subject?: string
  teacher?: string
  teacherId?: string
  type: "class" | "break" | "empty"
  color?: string
  isFixed?: boolean
  hasConflict?: boolean
  conflictInfo?: string
}

interface TeacherSchedule {
  [day: string]: {
    [timeSlot: string]: {
      status: "libre" | "ocupado" | "recreo" | "ausencia"
      course?: string
      subject?: string
    }
  }
}

interface ScheduleEditorProps {
  course: Course
  mode: "edit" | "view"
  onSave?: (schedule: any) => void
  onCancel?: () => void
  initialSchedule?: { [key: string]: { [key: string]: ScheduleCell } }
}

export function ScheduleEditor({ course, mode, onSave, onCancel, initialSchedule }: ScheduleEditorProps) {
  const [schedule, setSchedule] = useState<{ [key: string]: { [key: string]: ScheduleCell } }>({})
  const [availableSubjects, setAvailableSubjects] = useState<Subject[]>([])
  const [timeSlots, setTimeSlots] = useState<TimeSlot[]>([])
  const [draggedItem, setDraggedItem] = useState<any>(null)
  const [validationErrors, setValidationErrors] = useState<string[]>([])
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false)
  const [isBreakDialogOpen, setIsBreakDialogOpen] = useState(false)
  const [selectedCell, setSelectedCell] = useState<{ timeSlot: string; day: string } | null>(null)
  const [breakConfig, setBreakConfig] = useState({
    name: "RECESO",
    duration: 15,
    applyToAllDays: true,
    isFixed: true,
  })
  const [teacherSchedules, setTeacherSchedules] = useState<{ [teacherId: string]: TeacherSchedule }>({})
  const [hoveredCell, setHoveredCell] = useState<{ timeSlot: string; day: string } | null>(null)
  const [showConflicts, setShowConflicts] = useState(true)
  const [isGenerating, setIsGenerating] = useState(false)
  const [scheduleConfig, setScheduleConfig] = useState({
    startTime: "08:00",
    endTime: "13:00",
    blocksPerDay: 6,
    includeBreaks: true,
    breakDuration: 15,
    avoidConsecutiveBlocks: true,
    prioritizeComplexSubjects: true,
  })
  const [scheduleType, setScheduleType] = useState<"regular" | "extended">("regular")
  const [isConfigDialogOpen, setIsConfigDialogOpen] = useState(false)

  const days = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes"]
  const dragOverRef = useRef<HTMLDivElement>(null)

  // Inicializar datos
  useEffect(() => {
    initializeTimeSlots()
    initializeSubjects()
    initializeTeacherSchedules()
  }, [course, scheduleType])

  // Add a separate useEffect for schedule initialization
  useEffect(() => {
    if (timeSlots.length > 0) {
      if (initialSchedule) {
        setSchedule(initialSchedule)
      } else {
        initializeEmptySchedule()
      }
    }
  }, [timeSlots, initialSchedule])

  const initializeTimeSlots = () => {
    const slots: TimeSlot[] = []

    // Determinar horarios según el tipo de jornada
    let startHour: number
    let endHour: number

    if (scheduleType === "extended") {
      // Jornada extendida: 8:00 AM - 4:00 PM
      startHour = 8
      endHour = 16
    } else {
      // Jornada regular: mañana o tarde
      startHour = course.turn === "Mañana" ? 8 : course.turn === "Tarde" ? 14 : 8
      endHour = course.turn === "Mañana" ? 13 : course.turn === "Tarde" ? 18 : 13
    }

    for (let hour = startHour; hour < endHour; hour++) {
      slots.push({
        id: `slot_${hour}`,
        start: `${hour.toString().padStart(2, "0")}:00`,
        end: `${(hour + 1).toString().padStart(2, "0")}:00`,
        label: `${hour.toString().padStart(2, "0")}:00 - ${(hour + 1).toString().padStart(2, "0")}:00`,
      })
    }

    setTimeSlots(slots)
  }

  const initializeSubjects = () => {
    // Más materias para jornada extendida
    const extendedSubjects: Subject[] = [
      {
        id: "math_1",
        name: "Matemáticas",
        teacher: "Ana María Rodríguez",
        teacherId: "teacher_1",
        weeklyHours: scheduleType === "extended" ? 7 : 5,
        assignedHours: 0,
        area: "Ciencias Exactas",
        color: "bg-blue-100 border-blue-300 text-blue-800",
        isCore: true,
      },
      {
        id: "spanish_1",
        name: "Lengua Española",
        teacher: "Carlos Eduardo Mendoza",
        teacherId: "teacher_2",
        weeklyHours: scheduleType === "extended" ? 6 : 4,
        assignedHours: 0,
        area: "Humanidades",
        color: "bg-purple-100 border-purple-300 text-purple-800",
        isCore: true,
      },
      {
        id: "science_1",
        name: "Ciencias Naturales",
        teacher: "María Elena González",
        teacherId: "teacher_3",
        weeklyHours: scheduleType === "extended" ? 5 : 3,
        assignedHours: 0,
        area: "Ciencias Naturales",
        color: "bg-green-100 border-green-300 text-green-800",
        isCore: true,
      },
      {
        id: "social_1",
        name: "Ciencias Sociales",
        teacher: "Luis Alberto Pérez",
        teacherId: "teacher_4",
        weeklyHours: scheduleType === "extended" ? 5 : 3,
        assignedHours: 0,
        area: "Ciencias Sociales",
        color: "bg-orange-100 border-orange-300 text-orange-800",
        isCore: true,
      },
      {
        id: "english_1",
        name: "Inglés",
        teacher: "Elena Victoria Vásquez",
        teacherId: "teacher_5",
        weeklyHours: scheduleType === "extended" ? 5 : 3,
        assignedHours: 0,
        area: "Idiomas",
        color: "bg-indigo-100 border-indigo-300 text-indigo-800",
        isCore: true,
      },
      {
        id: "pe_1",
        name: "Educación Física",
        teacher: "Pedro Antonio Sánchez",
        teacherId: "teacher_6",
        weeklyHours: scheduleType === "extended" ? 4 : 2,
        assignedHours: 0,
        area: "Deportes",
        color: "bg-red-100 border-red-300 text-red-800",
        isCore: true,
      },
    ]

    // Materias adicionales para jornada extendida
    if (scheduleType === "extended") {
      extendedSubjects.push(
        {
          id: "art_1",
          name: "Educación Artística",
          teacher: "Carmen Jiménez",
          teacherId: "teacher_7",
          weeklyHours: 3,
          assignedHours: 0,
          area: "Arte",
          color: "bg-pink-100 border-pink-300 text-pink-800",
          isCore: false,
        },
        {
          id: "music_1",
          name: "Música",
          teacher: "Roberto Gómez",
          teacherId: "teacher_8",
          weeklyHours: 2,
          assignedHours: 0,
          area: "Arte",
          color: "bg-purple-100 border-purple-300 text-purple-800",
          isCore: false,
        },
        {
          id: "tech_1",
          name: "Tecnología",
          teacher: "Fernando Martínez",
          teacherId: "teacher_9",
          weeklyHours: 3,
          assignedHours: 0,
          area: "Tecnología",
          color: "bg-cyan-100 border-cyan-300 text-cyan-800",
          isCore: false,
        },
      )
    }

    setAvailableSubjects(extendedSubjects)
  }

  const initializeTeacherSchedules = () => {
    // Simular horarios de docentes en otros cursos
    const mockSchedules: { [teacherId: string]: TeacherSchedule } = {
      teacher_1: {
        Lunes: {
          "9:00-10:00": { status: "ocupado", course: "5to A", subject: "Matemáticas" },
          "11:00-12:00": { status: "ocupado", course: "6to B", subject: "Álgebra" },
        },
        Martes: {
          "8:00-9:00": { status: "ocupado", course: "5to A", subject: "Matemáticas" },
          "10:00-11:00": { status: "recreo" },
        },
        Miércoles: {
          "9:00-10:00": { status: "ocupado", course: "5to A", subject: "Matemáticas" },
        },
        Jueves: {
          "11:00-12:00": { status: "ocupado", course: "6to B", subject: "Álgebra" },
          "12:00-13:00": { status: "ausencia" },
        },
        Viernes: {
          "8:00-9:00": { status: "ocupado", course: "5to A", subject: "Matemáticas" },
        },
      },
      teacher_2: {
        Lunes: {
          "10:00-11:00": { status: "ocupado", course: "4to C", subject: "Literatura" },
        },
        Martes: {
          "9:00-10:00": { status: "ocupado", course: "4to C", subject: "Lengua Española" },
          "10:00-11:00": { status: "recreo" },
        },
        Miércoles: {
          "10:00-11:00": { status: "ocupado", course: "4to C", subject: "Literatura" },
        },
        Jueves: {
          "9:00-10:00": { status: "ocupado", course: "4to C", subject: "Lengua Española" },
        },
        Viernes: {
          "11:00-12:00": { status: "ocupado", course: "3ro A", subject: "Redacción" },
        },
      },
    }

    setTeacherSchedules(mockSchedules)
  }

  const initializeEmptySchedule = () => {
    if (timeSlots.length === 0) return

    const emptySchedule: { [key: string]: { [key: string]: ScheduleCell } } = {}

    timeSlots.forEach((slot) => {
      emptySchedule[slot.id] = {}
      days.forEach((day) => {
        emptySchedule[slot.id][day] = { type: "empty" }
      })
    })

    setSchedule(emptySchedule)
  }

  // Validaciones
  const validateDrop = (timeSlot: string, day: string, item: any): string[] => {
    const errors: string[] = []

    // Verificar si la celda ya está ocupada
    if (schedule[timeSlot]?.[day]?.type !== "empty") {
      errors.push("Esta celda ya está ocupada")
    }

    // Verificar disponibilidad del docente
    if (item.teacherId && teacherSchedules[item.teacherId]) {
      const teacherSchedule = teacherSchedules[item.teacherId]
      const slotLabel = timeSlots.find((s) => s.id === timeSlot)?.label || ""
      const daySchedule = teacherSchedule[day]

      if (daySchedule && daySchedule[slotLabel]) {
        const status = daySchedule[slotLabel].status
        if (status === "ocupado") {
          errors.push(
            `El docente ${item.teacher} ya está ocupado en ${daySchedule[slotLabel].course} - ${daySchedule[slotLabel].subject}`,
          )
        } else if (status === "ausencia") {
          errors.push(`El docente ${item.teacher} tiene ausencia programada en este horario`)
        }
      }
    }

    // Verificar carga horaria
    if (item.assignedHours >= item.weeklyHours) {
      errors.push(`La materia ${item.name} ya tiene asignadas todas sus horas semanales (${item.weeklyHours}h)`)
    }

    // Verificar límites de jornada
    const slot = timeSlots.find((s) => s.id === timeSlot)
    if (!slot) {
      errors.push("Franja horaria no válida")
    }

    return errors
  }

  const checkTeacherConflict = (timeSlot: string, day: string, teacherId: string): boolean => {
    if (!teacherSchedules[teacherId]) return false

    const slotLabel = timeSlots.find((s) => s.id === timeSlot)?.label || ""
    const daySchedule = teacherSchedules[teacherId][day]

    if (daySchedule && daySchedule[slotLabel]) {
      return daySchedule[slotLabel].status === "ocupado"
    }

    return false
  }

  // Drag and Drop handlers
  const handleDragStart = (e: React.DragEvent, item: Subject) => {
    setDraggedItem(item)
    e.dataTransfer.effectAllowed = "move"
  }

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
    e.dataTransfer.dropEffect = "move"
  }

  const handleDrop = (e: React.DragEvent, timeSlot: string, day: string) => {
    e.preventDefault()
    if (!draggedItem || mode === "view") return

    const errors = validateDrop(timeSlot, day, draggedItem)
    if (errors.length > 0) {
      setValidationErrors(errors)
      return
    }

    const newSchedule = { ...schedule }

    // Si es un movimiento desde otra celda, limpiar la anterior
    if (draggedItem.fromSlot && draggedItem.fromDay) {
      newSchedule[draggedItem.fromSlot][draggedItem.fromDay] = { type: "empty" }
    }

    // Colocar en nueva posición
    newSchedule[timeSlot][day] = {
      id: `${draggedItem.id}-${timeSlot}-${day}`,
      subject: draggedItem.name,
      teacher: draggedItem.teacher,
      teacherId: draggedItem.teacherId,
      type: "class",
      color: draggedItem.color,
      hasConflict: checkTeacherConflict(timeSlot, day, draggedItem.teacherId),
    }

    // Actualizar horas asignadas
    const updatedSubjects = availableSubjects.map((subject) =>
      subject.id === draggedItem.id ? { ...subject, assignedHours: subject.assignedHours + 1 } : subject,
    )

    setSchedule(newSchedule)
    setAvailableSubjects(updatedSubjects)
    setDraggedItem(null)
    setHasUnsavedChanges(true)
    setValidationErrors([])
  }

  const handleCellDragStart = (e: React.DragEvent, timeSlot: string, day: string) => {
    const cell = schedule[timeSlot][day]
    if (cell.type === "class") {
      const subject = availableSubjects.find((s) => s.name === cell.subject)
      if (subject) {
        setDraggedItem({
          ...subject,
          fromSlot: timeSlot,
          fromDay: day,
        })
      }
    }
  }

  const removeCell = (timeSlot: string, day: string) => {
    if (mode === "view") return

    const cell = schedule[timeSlot][day]
    if (cell.type === "break" && cell.isFixed) {
      setValidationErrors(["Este receso es fijo y no puede ser eliminado"])
      return
    }

    const newSchedule = { ...schedule }
    newSchedule[timeSlot][day] = { type: "empty" }

    // Si era una clase, devolver la hora a la materia
    if (cell.type === "class" && cell.subject) {
      const updatedSubjects = availableSubjects.map((subject) =>
        subject.name === cell.subject ? { ...subject, assignedHours: Math.max(0, subject.assignedHours - 1) } : subject,
      )
      setAvailableSubjects(updatedSubjects)
    }

    setSchedule(newSchedule)
    setHasUnsavedChanges(true)
    setValidationErrors([])
  }

  const addBreak = (timeSlot: string, day: string) => {
    if (mode === "view") return

    setSelectedCell({ timeSlot, day })
    setIsBreakDialogOpen(true)
  }

  const confirmAddBreak = () => {
    if (!selectedCell) return

    const { timeSlot, day } = selectedCell
    const newSchedule = { ...schedule }

    if (breakConfig.applyToAllDays) {
      // Aplicar a todos los días
      days.forEach((d) => {
        if (newSchedule[timeSlot][d].type === "empty") {
          newSchedule[timeSlot][d] = {
            id: `break-${timeSlot}-${d}`,
            subject: breakConfig.name,
            type: "break",
            color: "bg-yellow-100 border-yellow-300 text-yellow-800",
            isFixed: breakConfig.isFixed,
          }
        }
      })
    } else {
      // Aplicar solo al día seleccionado
      newSchedule[timeSlot][day] = {
        id: `break-${timeSlot}-${day}`,
        subject: breakConfig.name,
        type: "break",
        color: "bg-yellow-100 border-yellow-300 text-yellow-800",
        isFixed: breakConfig.isFixed,
      }
    }

    setSchedule(newSchedule)
    setHasUnsavedChanges(true)
    setIsBreakDialogOpen(false)
    setSelectedCell(null)
    setBreakConfig({
      name: "RECESO",
      duration: 15,
      applyToAllDays: true,
      isFixed: true,
    })
  }

  const handleSave = (publish = false) => {
    // Validar horario completo
    const errors = validateCompleteSchedule()
    if (errors.length > 0) {
      setValidationErrors(errors)
      return
    }

    const scheduleData = {
      schedule,
      course: course.id,
      published: publish,
      createdAt: new Date().toISOString(),
      subjects: availableSubjects,
      scheduleType,
    }

    onSave?.(scheduleData)
    setHasUnsavedChanges(false)
  }

  const validateCompleteSchedule = (): string[] => {
    const errors: string[] = []

    // Verificar que todas las materias tengan sus horas asignadas
    availableSubjects.forEach((subject) => {
      if (subject.assignedHours < subject.weeklyHours) {
        errors.push(`${subject.name} necesita ${subject.weeklyHours - subject.assignedHours} horas más`)
      }
    })

    // Verificar conflictos de docentes
    const conflicts = findAllConflicts()
    if (conflicts.length > 0) {
      errors.push(`Se encontraron ${conflicts.length} conflictos de horario de docentes`)
    }

    return errors
  }

  const findAllConflicts = () => {
    const conflicts: any[] = []

    Object.keys(schedule).forEach((timeSlot) => {
      days.forEach((day) => {
        const cell = schedule[timeSlot][day]
        if (cell.type === "class" && cell.teacherId) {
          if (checkTeacherConflict(timeSlot, day, cell.teacherId)) {
            conflicts.push({ timeSlot, day, teacher: cell.teacher, subject: cell.subject })
          }
        }
      })
    })

    return conflicts
  }

  const undoChanges = () => {
    if (initialSchedule) {
      setSchedule(initialSchedule)
    } else {
      initializeEmptySchedule()
    }
    setHasUnsavedChanges(false)
    setValidationErrors([])
  }

  const downloadSchedule = () => {
    const scheduleData = {
      curso: course.name,
      turno: course.turn,
      profesor_encargado: course.teacher,
      horario: schedule,
      materias: availableSubjects,
      fecha_generacion: new Date().toLocaleDateString(),
      tipo_jornada: scheduleType === "extended" ? "Extendida" : "Regular",
    }

    const blob = new Blob([JSON.stringify(scheduleData, null, 2)], { type: "application/json" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `horario_${course.name.replace(/\s+/g, "_")}.json`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  const renderCell = (timeSlot: string, day: string) => {
    // Add safety check
    if (!schedule[timeSlot] || !schedule[timeSlot][day]) {
      return (
        <td key={`${timeSlot}-${day}`} className="border border-gray-300 p-1">
          <div className="h-16 bg-gray-50 rounded flex items-center justify-center text-gray-400 text-sm">
            Cargando...
          </div>
        </td>
      )
    }

    const cell = schedule[timeSlot][day]
    const isHovered = hoveredCell?.timeSlot === timeSlot && hoveredCell?.day === day

    return (
      <td
        key={`${timeSlot}-${day}`}
        className="border border-gray-300 p-1 relative"
        onDragOver={handleDragOver}
        onDrop={(e) => handleDrop(e, timeSlot, day)}
        onMouseEnter={() => setHoveredCell({ timeSlot, day })}
        onMouseLeave={() => setHoveredCell(null)}
      >
        {cell.type === "empty" ? (
          <div className="h-16 bg-gray-50 rounded flex items-center justify-center text-gray-400 text-sm hover:bg-gray-100 transition-colors">
            {mode === "edit" && isHovered && (
              <div className="flex gap-1">
                <Button size="sm" variant="ghost" onClick={() => addBreak(timeSlot, day)} className="h-6 w-6 p-0">
                  <Coffee className="h-3 w-3" />
                </Button>
              </div>
            )}
            {!isHovered && "Vacío"}
          </div>
        ) : cell.type === "break" ? (
          <div className={`h-16 rounded flex items-center justify-center text-sm font-medium ${cell.color} relative`}>
            <div className="text-center">
              <div>{cell.subject}</div>
              <div className="text-xs opacity-75">{breakConfig.duration} min</div>
            </div>
            {mode === "edit" && !cell.isFixed && (
              <Button
                size="sm"
                variant="ghost"
                onClick={() => removeCell(timeSlot, day)}
                className="absolute top-1 right-1 h-4 w-4 p-0 text-red-600 hover:text-red-700"
              >
                <X className="h-3 w-3" />
              </Button>
            )}
          </div>
        ) : (
          <div
            className={`h-16 rounded p-2 text-xs cursor-move relative ${cell.color} ${
              cell.hasConflict ? "ring-2 ring-red-500" : ""
            }`}
            draggable={mode === "edit"}
            onDragStart={(e) => handleCellDragStart(e, timeSlot, day)}
          >
            <div className="font-medium truncate">{cell.subject}</div>
            <div className="truncate opacity-75">{cell.teacher}</div>
            {cell.hasConflict && (
              <div className="absolute top-1 right-1">
                <AlertTriangle className="h-3 w-3 text-red-600" />
              </div>
            )}
            {mode === "edit" && (
              <div className="absolute top-1 left-1 opacity-0 hover:opacity-100 transition-opacity">
                <GripVertical className="h-3 w-3 text-gray-600" />
              </div>
            )}
            {mode === "edit" && (
              <Button
                size="sm"
                variant="ghost"
                onClick={() => removeCell(timeSlot, day)}
                className="absolute bottom-1 right-1 h-4 w-4 p-0 text-red-600 hover:text-red-700 opacity-0 hover:opacity-100 transition-opacity"
              >
                <Trash2 className="h-3 w-3" />
              </Button>
            )}
          </div>
        )}
      </td>
    )
  }

  const getSubjectProgress = (subject: Subject) => {
    const percentage = (subject.assignedHours / subject.weeklyHours) * 100
    return Math.min(percentage, 100)
  }

  const getProgressColor = (percentage: number) => {
    if (percentage === 100) return "bg-green-500"
    if (percentage >= 75) return "bg-blue-500"
    if (percentage >= 50) return "bg-yellow-500"
    return "bg-red-500"
  }

  const generateAutomaticSchedule = async () => {
    setIsGenerating(true)
    setValidationErrors([])

    try {
      // Simular generación
      await new Promise((resolve) => setTimeout(resolve, 2000))

      const newSchedule: { [key: string]: { [key: string]: ScheduleCell } } = {}

      // Inicializar horario vacío
      timeSlots.forEach((slot) => {
        newSchedule[slot.id] = {}
        days.forEach((day) => {
          newSchedule[slot.id][day] = { type: "empty" }
        })
      })

      // Insertar recesos automáticamente
      if (scheduleConfig.includeBreaks) {
        // Para jornada extendida, insertar dos recesos
        if (scheduleType === "extended") {
          // Primer receso (media mañana)
          const morningBreakIndex = Math.floor(timeSlots.length / 4)
          const morningBreakSlot = timeSlots[morningBreakIndex]

          // Segundo receso (almuerzo)
          const lunchBreakIndex = Math.floor(timeSlots.length / 2)
          const lunchBreakSlot = timeSlots[lunchBreakIndex]

          // Tercer receso (media tarde)
          const afternoonBreakIndex = Math.floor((timeSlots.length * 3) / 4)
          const afternoonBreakSlot = timeSlots[afternoonBreakIndex]

          days.forEach((day) => {
            // Receso de media mañana
            newSchedule[morningBreakSlot.id][day] = {
              id: `break-morning-${morningBreakSlot.id}-${day}`,
              type: "break",
              subject: "RECESO MAÑANA",
              color: "bg-yellow-100 border-yellow-300 text-yellow-800",
              isFixed: true,
            }

            // Receso de almuerzo (más largo)
            newSchedule[lunchBreakSlot.id][day] = {
              id: `break-lunch-${lunchBreakSlot.id}-${day}`,
              type: "break",
              subject: "ALMUERZO",
              color: "bg-orange-100 border-orange-300 text-orange-800",
              isFixed: true,
            }

            // Receso de media tarde
            newSchedule[afternoonBreakSlot.id][day] = {
              id: `break-afternoon-${afternoonBreakSlot.id}-${day}`,
              type: "break",
              subject: "RECESO TARDE",
              color: "bg-yellow-100 border-yellow-300 text-yellow-800",
              isFixed: true,
            }
          })
        } else {
          // Para jornada regular, un solo receso
          const breakSlotIndex = Math.floor(timeSlots.length / 2)
          const breakSlot = timeSlots[breakSlotIndex]

          days.forEach((day) => {
            newSchedule[breakSlot.id][day] = {
              id: `break-${breakSlot.id}-${day}`,
              type: "break",
              subject: "RECESO",
              color: "bg-yellow-100 border-yellow-300 text-yellow-800",
              isFixed: true,
            }
          })
        }
      }

      // Crear lista de slots disponibles (excluyendo recreos)
      const availableSlots: Array<{ slotId: string; day: string; priority: number }> = []

      timeSlots.forEach((slot, slotIndex) => {
        days.forEach((day) => {
          if (newSchedule[slot.id][day].type === "empty") {
            // Prioridad más alta para slots tempranos (menor índice = mayor prioridad)
            const priority = scheduleConfig.prioritizeComplexSubjects ? timeSlots.length - slotIndex : 1
            availableSlots.push({ slotId: slot.id, day, priority })
          }
        })
      })

      // Ordenar slots por prioridad (mayor prioridad primero)
      availableSlots.sort((a, b) => b.priority - a.priority)

      // Distribuir materias
      const subjectsToDistribute = [...availableSubjects]
      const complexSubjects = subjectsToDistribute.filter(
        (s) => s.area === "Ciencias Exactas" || s.area === "Ciencias Naturales",
      )
      const regularSubjects = subjectsToDistribute.filter((s) => !complexSubjects.includes(s))

      let slotIndex = 0

      // Función para asignar una materia a un slot
      const assignSubjectToSlot = (subject: Subject, targetHours: number) => {
        let assignedHours = 0
        let attempts = 0
        const maxAttempts = availableSlots.length * 2

        while (assignedHours < targetHours && slotIndex < availableSlots.length && attempts < maxAttempts) {
          const slot = availableSlots[slotIndex]

          // Verificar que el slot esté disponible
          if (newSchedule[slot.slotId][slot.day].type === "empty") {
            // Verificar conflictos de docente (simplificado para la demo)
            const hasConflict = Math.random() < 0.1 // 10% de probabilidad de conflicto

            newSchedule[slot.slotId][slot.day] = {
              id: `${subject.id}-${slot.slotId}-${slot.day}`,
              type: "class",
              subject: subject.name,
              teacher: subject.teacher,
              teacherId: subject.teacherId,
              color: subject.color,
              hasConflict: hasConflict,
            }

            assignedHours++
          }

          slotIndex++
          attempts++

          // Si llegamos al final, reiniciar desde el principio para materias regulares
          if (slotIndex >= availableSlots.length && assignedHours < targetHours) {
            slotIndex = 0
          }
        }

        return assignedHours
      }

      // Primero asignar materias complejas (en slots de alta prioridad)
      if (scheduleConfig.prioritizeComplexSubjects) {
        complexSubjects.forEach((subject) => {
          assignSubjectToSlot(subject, subject.weeklyHours)
        })
      }

      // Luego asignar materias regulares
      regularSubjects.forEach((subject) => {
        assignSubjectToSlot(subject, subject.weeklyHours)
      })

      // Si no se priorizan materias complejas, asignar todas juntas
      if (!scheduleConfig.prioritizeComplexSubjects) {
        complexSubjects.forEach((subject) => {
          assignSubjectToSlot(subject, subject.weeklyHours)
        })
      }

      // Actualizar horas asignadas en el estado
      const updatedSubjects = availableSubjects.map((subject) => {
        const assignedCount = Object.values(newSchedule)
          .flatMap((daySchedule) => Object.values(daySchedule))
          .filter((cell) => cell.type === "class" && cell.subject === subject.name).length

        return { ...subject, assignedHours: assignedCount }
      })

      setSchedule(newSchedule)
      setAvailableSubjects(updatedSubjects)
      setHasUnsavedChanges(true)

      // Mostrar mensaje de éxito
      setValidationErrors([])
    } catch (error) {
      setValidationErrors(["Error al generar el horario automáticamente. Intenta nuevamente."])
    } finally {
      setIsGenerating(false)
    }
  }

  const openConfigDialog = () => {
    setIsConfigDialogOpen(true)
  }

  if (timeSlots.length === 0 || Object.keys(schedule).length === 0) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Cargando horario...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Panel lateral de materias (solo en modo edición) */}
      {mode === "edit" && (
        <div className="w-80 bg-white border-r border-gray-200 p-4 overflow-y-auto">
          <div className="space-y-4">
            <div>
              <h3 className="font-semibold text-lg mb-3 flex items-center gap-2">
                <BookOpen className="h-5 w-5" />📦 Materias Disponibles
              </h3>
              <div className="space-y-3">
                {availableSubjects.map((subject) => (
                  <div
                    key={subject.id}
                    className={`p-3 rounded-lg border cursor-move hover:shadow-md transition-shadow ${subject.color}`}
                    draggable
                    onDragStart={(e) => handleDragStart(e, subject)}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="font-medium text-sm">{subject.name}</div>
                      <GripVertical className="h-4 w-4 text-gray-600" />
                    </div>
                    <div className="text-xs opacity-75 mb-2">{subject.teacher}</div>
                    <div className="space-y-1">
                      <div className="flex items-center justify-between text-xs">
                        <span>Horas asignadas</span>
                        <span className="font-medium">
                          {subject.assignedHours}/{subject.weeklyHours}
                        </span>
                      </div>
                      <Progress
                        value={getSubjectProgress(subject)}
                        className={`h-2 ${getProgressColor(getSubjectProgress(subject))}`}
                      />
                    </div>
                    {subject.assignedHours >= subject.weeklyHours && (
                      <Badge className="mt-2 bg-green-100 text-green-800 text-xs">✅ Completo</Badge>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Estadísticas */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm">📊 Estadísticas</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Materias completas:</span>
                  <span className="font-medium">
                    {availableSubjects.filter((s) => s.assignedHours >= s.weeklyHours).length}/
                    {availableSubjects.length}
                  </span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Horas asignadas:</span>
                  <span className="font-medium">
                    {availableSubjects.reduce((sum, s) => sum + s.assignedHours, 0)}/
                    {availableSubjects.reduce((sum, s) => sum + s.weeklyHours, 0)}
                  </span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Conflictos:</span>
                  <span className={`font-medium ${findAllConflicts().length > 0 ? "text-red-600" : "text-green-600"}`}>
                    {findAllConflicts().length}
                  </span>
                </div>
              </CardContent>
            </Card>

            {/* Tipo de jornada */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm">⏰ Tipo de Jornada</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <input
                      type="radio"
                      id="regular"
                      name="scheduleType"
                      checked={scheduleType === "regular"}
                      onChange={() => setScheduleType("regular")}
                      className="text-blue-600"
                    />
                    <label htmlFor="regular" className="text-sm">
                      Regular (5 horas)
                    </label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input
                      type="radio"
                      id="extended"
                      name="scheduleType"
                      checked={scheduleType === "extended"}
                      onChange={() => setScheduleType("extended")}
                      className="text-blue-600"
                    />
                    <label htmlFor="extended" className="text-sm">
                      Extendida (8 horas)
                    </label>
                  </div>
                  <div className="mt-2">
                    <Button size="sm" variant="outline" className="w-full bg-transparent" onClick={openConfigDialog}>
                      <Settings className="h-4 w-4 mr-2" />
                      Configuración Avanzada
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      )}

      {/* Área principal del horario */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <div className="bg-white border-b border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="outline" onClick={onCancel}>
                <ArrowLeft className="h-4 w-4 mr-2" />
                Volver
              </Button>
              <div>
                <h1 className="text-2xl font-bold">
                  {mode === "edit" ? "✏️ Editar Horario" : "📅 Ver Horario"} - {course.name}
                </h1>
                <p className="text-gray-600">
                  {scheduleType === "extended" ? "Jornada Extendida" : course.turn} • {course.teacher} •{" "}
                  {timeSlots.length} bloques por día
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {mode === "edit" && (
                <>
                  <Button variant="outline" onClick={generateAutomaticSchedule} disabled={isGenerating}>
                    <Wand2 className="h-4 w-4 mr-2" />
                    {isGenerating ? "Generando..." : "🤖 Generar Automático"}
                  </Button>
                  <Button variant="outline" onClick={undoChanges} disabled={!hasUnsavedChanges}>
                    <RotateCcw className="h-4 w-4 mr-2" />
                    ↩️ Deshacer
                  </Button>
                  <Button variant="outline" onClick={() => handleSave(false)} disabled={!hasUnsavedChanges}>
                    <Save className="h-4 w-4 mr-2" />💾 Guardar Borrador
                  </Button>
                  <Button onClick={() => handleSave(true)} className="bg-green-600 hover:bg-green-700">
                    <CheckCircle className="h-4 w-4 mr-2" />✅ Publicar Horario
                  </Button>
                </>
              )}
              <Button variant="outline" onClick={downloadSchedule}>
                <Download className="h-4 w-4 mr-2" />📥 Descargar PDF/Excel
              </Button>
            </div>
          </div>

          {/* Errores de validación */}
          {validationErrors.length > 0 && (
            <Alert className="mt-4 border-red-200 bg-red-50">
              <AlertTriangle className="h-4 w-4 text-red-600" />
              <AlertDescription>
                <div className="space-y-1">
                  {validationErrors.map((error, index) => (
                    <div key={index} className="text-red-700">
                      • {error}
                    </div>
                  ))}
                </div>
              </AlertDescription>
            </Alert>
          )}

          {/* Indicador de cambios sin guardar */}
          {hasUnsavedChanges && mode === "edit" && (
            <Alert className="mt-4 border-yellow-200 bg-yellow-50">
              <Clock className="h-4 w-4 text-yellow-600" />
              <AlertDescription className="text-yellow-700">
                Tienes cambios sin guardar. Recuerda guardar tu trabajo antes de salir.
              </AlertDescription>
            </Alert>
          )}
        </div>

        {/* Tabla del horario */}
        <div className="flex-1 p-4 overflow-auto">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Horario Semanal - {course.name} -{" "}
                {scheduleType === "extended" ? "Jornada Extendida (8:00-16:00)" : "Jornada Regular"}
              </CardTitle>
              <CardDescription>
                {mode === "edit"
                  ? "Arrastra las materias desde el panel lateral hacia las celdas del horario"
                  : "Vista de solo lectura del horario semanal"}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full border-collapse border border-gray-300">
                  <thead>
                    <tr>
                      <th className="border border-gray-300 p-3 bg-gray-50 font-medium min-w-[120px]">
                        <div className="flex items-center gap-2">
                          <Clock className="h-4 w-4" />
                          Hora
                        </div>
                      </th>
                      {days.map((day) => (
                        <th key={day} className="border border-gray-300 p-3 bg-gray-50 font-medium min-w-[150px]">
                          {day}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {timeSlots.map((slot) => (
                      <tr key={slot.id}>
                        <td className="border border-gray-300 p-3 bg-gray-50 font-medium text-sm">
                          <div className="text-center">
                            <div>{slot.label}</div>
                            <div className="text-xs text-gray-600 mt-1">Bloque {slot.id.split("_")[1]}</div>
                          </div>
                        </td>
                        {days.map((day) => renderCell(slot.id, day))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Leyenda */}
              <div className="mt-4 p-4 bg-gray-50 rounded-lg">
                <h4 className="font-medium mb-2">📋 Leyenda:</h4>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 bg-gray-100 border border-gray-300 rounded"></div>
                    <span>Vacío</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 bg-yellow-100 border border-yellow-300 rounded"></div>
                    <span>Receso</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 bg-blue-100 border border-blue-300 rounded"></div>
                    <span>Clase</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-red-600" />
                    <span>Conflicto de docente</span>
                  </div>
                </div>
                {mode === "edit" && (
                  <div className="mt-2 text-xs text-gray-600">
                    💡 <strong>Instrucciones:</strong> Arrastra materias desde el panel lateral • Haz clic en el ícono
                    de café para agregar recesos • Usa el ícono de papelera para eliminar bloques
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Dialog para agregar receso */}
      <Dialog open={isBreakDialogOpen} onOpenChange={setIsBreakDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Coffee className="h-5 w-5 text-yellow-600" />➕ Agregar Receso
            </DialogTitle>
            <DialogDescription>
              Configura el receso para{" "}
              {selectedCell &&
                `${days[days.indexOf(selectedCell.day)] || selectedCell.day} - ${
                  timeSlots.find((s) => s.id === selectedCell.timeSlot)?.label
                }`}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium">Nombre del receso</label>
              <Input
                value={breakConfig.name}
                onChange={(e) => setBreakConfig({ ...breakConfig, name: e.target.value })}
                placeholder="RECESO"
              />
            </div>

            <div>
              <label className="text-sm font-medium">Duración (minutos)</label>
              <Select
                value={breakConfig.duration.toString()}
                onValueChange={(value) => setBreakConfig({ ...breakConfig, duration: Number.parseInt(value) })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="10">10 minutos</SelectItem>
                  <SelectItem value="15">15 minutos</SelectItem>
                  <SelectItem value="20">20 minutos</SelectItem>
                  <SelectItem value="30">30 minutos</SelectItem>
                  {scheduleType === "extended" && <SelectItem value="45">45 minutos (almuerzo)</SelectItem>}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={breakConfig.applyToAllDays}
                  onChange={(e) => setBreakConfig({ ...breakConfig, applyToAllDays: e.target.checked })}
                  className="text-blue-600"
                />
                <span className="text-sm">Aplicar a todos los días de la semana</span>
              </label>
              <label className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={breakConfig.isFixed}
                  onChange={(e) => setBreakConfig({ ...breakConfig, isFixed: e.target.checked })}
                  className="text-blue-600"
                />
                <span className="text-sm">Marcar como receso fijo (no editable)</span>
              </label>
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button variant="outline" onClick={() => setIsBreakDialogOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={confirmAddBreak} className="bg-yellow-600 hover:bg-yellow-700">
              <Coffee className="mr-2 h-4 w-4" />
              Agregar Receso
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Dialog para configuración avanzada */}
      <Dialog open={isConfigDialogOpen} onOpenChange={setIsConfigDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Settings className="h-5 w-5 text-blue-600" />
              ⚙️ Configuración Avanzada
            </DialogTitle>
            <DialogDescription>
              Personaliza las opciones de generación automática y visualización del horario
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium">Tipo de Jornada</label>
              <div className="mt-2 space-y-2">
                <div className="flex items-center space-x-2">
                  <input
                    type="radio"
                    id="regular-config"
                    name="scheduleType-config"
                    checked={scheduleType === "regular"}
                    onChange={() => setScheduleType("regular")}
                    className="text-blue-600"
                  />
                  <label htmlFor="regular-config" className="text-sm">
                    Regular (5 horas) - {course.turn === "Mañana" ? "8:00-13:00" : "14:00-18:00"}
                  </label>
                </div>
                <div className="flex items-center space-x-2">
                  <input
                    type="radio"
                    id="extended-config"
                    name="scheduleType-config"
                    checked={scheduleType === "extended"}
                    onChange={() => setScheduleType("extended")}
                    className="text-blue-600"
                  />
                  <label htmlFor="extended-config" className="text-sm">
                    Extendida (8 horas) - 8:00-16:00
                  </label>
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Opciones de Generación Automática</label>
              <div className="space-y-2">
                <label className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    checked={scheduleConfig.includeBreaks}
                    onChange={(e) => setScheduleConfig({ ...scheduleConfig, includeBreaks: e.target.checked })}
                    className="text-blue-600"
                  />
                  <span className="text-sm">Incluir recesos automáticamente</span>
                </label>
                <label className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    checked={scheduleConfig.avoidConsecutiveBlocks}
                    onChange={(e) => setScheduleConfig({ ...scheduleConfig, avoidConsecutiveBlocks: e.target.checked })}
                    className="text-blue-600"
                  />
                  <span className="text-sm">Evitar bloques consecutivos de la misma materia</span>
                </label>
                <label className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    checked={scheduleConfig.prioritizeComplexSubjects}
                    onChange={(e) =>
                      setScheduleConfig({ ...scheduleConfig, prioritizeComplexSubjects: e.target.checked })
                    }
                    className="text-blue-600"
                  />
                  <span className="text-sm">Priorizar materias complejas en horas tempranas</span>
                </label>
              </div>
            </div>

            {scheduleType === "extended" && (
              <Alert className="border-blue-200 bg-blue-50">
                <AlertDescription className="text-blue-700">
                  <strong>Jornada Extendida:</strong> Se configurarán automáticamente 3 recesos:
                  <ul className="list-disc list-inside mt-1 text-sm">
                    <li>Receso de media mañana (15 min)</li>
                    <li>Almuerzo (45 min)</li>
                    <li>Receso de media tarde (15 min)</li>
                  </ul>
                </AlertDescription>
              </Alert>
            )}
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button variant="outline" onClick={() => setIsConfigDialogOpen(false)}>
              Cancelar
            </Button>
            <Button
              onClick={() => {
                setIsConfigDialogOpen(false)
                // Reiniciar el horario si cambia el tipo de jornada
                initializeTimeSlots()
                initializeSubjects()
                initializeEmptySchedule()
                setHasUnsavedChanges(true)
              }}
              className="bg-blue-600 hover:bg-blue-700"
            >
              <Settings className="mr-2 h-4 w-4" />
              Aplicar Configuración
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
