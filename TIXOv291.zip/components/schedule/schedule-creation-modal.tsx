"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  Calendar,
  Settings,
  Wand2,
  Edit,
  Save,
  Download,
  RefreshCw,
  AlertTriangle,
  CheckCircle,
  ArrowLeft,
  ArrowRight,
} from "lucide-react"
import type { Course } from "@/lib/course-interoperability"

interface Subject {
  id: string
  name: string
  teacher: string
  weeklyHours: number
  area: string
  isCore: boolean
}

interface TimeSlot {
  id: string
  start: string
  end: string
  label: string
}

interface ScheduleCell {
  subject?: string
  teacher?: string
  type: "class" | "break" | "empty"
  color?: string
}

interface ScheduleCreationModalProps {
  isOpen: boolean
  onClose: () => void
  course: Course
  onScheduleCreated: (courseId: string, schedule: any) => void
}

export function ScheduleCreationModal({ isOpen, onClose, course, onScheduleCreated }: ScheduleCreationModalProps) {
  const [currentStep, setCurrentStep] = useState(1)
  const [creationMethod, setCreationMethod] = useState<"manual" | "automatic">("automatic")
  const [isGenerating, setIsGenerating] = useState(false)
  const [generatedSchedule, setGeneratedSchedule] = useState<any>(null)
  const [manualSchedule, setManualSchedule] = useState<{ [key: string]: { [key: string]: ScheduleCell } }>({})
  const [validationErrors, setValidationErrors] = useState<string[]>([])
  const [scheduleConfig, setScheduleConfig] = useState({
    startTime: "08:00",
    endTime: "13:00",
    blocksPerDay: 6,
    includeBreaks: true,
    breakDuration: 15,
    avoidConsecutiveBlocks: true,
    prioritizeComplexSubjects: true,
  })

  // Datos de ejemplo para materias del curso
  const [courseSubjects] = useState<Subject[]>([
    {
      id: "math_1",
      name: "Matemáticas",
      teacher: "Ana María Rodríguez",
      weeklyHours: 5,
      area: "Ciencias Exactas",
      isCore: true,
    },
    {
      id: "spanish_1",
      name: "Lengua Española",
      teacher: "Carlos Eduardo Mendoza",
      weeklyHours: 4,
      area: "Humanidades",
      isCore: true,
    },
    {
      id: "science_1",
      name: "Ciencias Naturales",
      teacher: "María Elena González",
      weeklyHours: 3,
      area: "Ciencias Naturales",
      isCore: true,
    },
    {
      id: "social_1",
      name: "Ciencias Sociales",
      teacher: "Luis Alberto Pérez",
      weeklyHours: 3,
      area: "Ciencias Sociales",
      isCore: true,
    },
    {
      id: "english_1",
      name: "Inglés",
      teacher: "Elena Victoria Vásquez",
      weeklyHours: 3,
      area: "Idiomas",
      isCore: true,
    },
    {
      id: "pe_1",
      name: "Educación Física",
      teacher: "Pedro Antonio Sánchez",
      weeklyHours: 2,
      area: "Deportes",
      isCore: true,
    },
  ])

  const timeSlots: TimeSlot[] = [
    { id: "slot_1", start: "08:00", end: "09:00", label: "8:00 - 9:00" },
    { id: "slot_2", start: "09:00", end: "10:00", label: "9:00 - 10:00" },
    { id: "slot_3", start: "10:00", end: "11:00", label: "10:00 - 11:00" },
    { id: "slot_4", start: "11:00", end: "12:00", label: "11:00 - 12:00" },
    { id: "slot_5", start: "12:00", end: "13:00", label: "12:00 - 13:00" },
    { id: "slot_6", start: "13:00", end: "14:00", label: "13:00 - 14:00" },
  ]

  const days = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes"]

  useEffect(() => {
    if (isOpen) {
      setCurrentStep(1)
      setCreationMethod("automatic")
      setGeneratedSchedule(null)
      setValidationErrors([])
      initializeManualSchedule()
    }
  }, [isOpen])

  const initializeManualSchedule = () => {
    const schedule: { [key: string]: { [key: string]: ScheduleCell } } = {}

    timeSlots.forEach((slot) => {
      schedule[slot.id] = {}
      days.forEach((day) => {
        schedule[slot.id][day] = { type: "empty" }
      })
    })

    setManualSchedule(schedule)
  }

  const generateAutomaticSchedule = async () => {
    setIsGenerating(true)
    setValidationErrors([])

    try {
      // Simular generación
      await new Promise((resolve) => setTimeout(resolve, 2000))

      const schedule: { [key: string]: { [key: string]: ScheduleCell } } = {}

      // Inicializar horario vacío
      timeSlots.forEach((slot) => {
        schedule[slot.id] = {}
        days.forEach((day) => {
          schedule[slot.id][day] = { type: "empty" }
        })
      })

      // Insertar recesos automáticamente
      if (scheduleConfig.includeBreaks) {
        days.forEach((day) => {
          schedule["slot_3"][day] = {
            type: "break",
            subject: "RECESO",
            color: "bg-yellow-100 border-yellow-300 text-yellow-800",
          }
        })
      }

      // Distribuir materias inteligentemente
      const subjectsToDistribute = [...courseSubjects]
      const complexSubjects = subjectsToDistribute.filter(
        (s) => s.area === "Ciencias Exactas" || s.area === "Ciencias Naturales",
      )
      const regularSubjects = subjectsToDistribute.filter((s) => !complexSubjects.includes(s))

      // Priorizar materias complejas en horas tempranas
      if (scheduleConfig.prioritizeComplexSubjects) {
        complexSubjects.forEach((subject) => {
          let assignedHours = 0
          while (assignedHours < subject.weeklyHours) {
            const availableSlots = timeSlots.filter((slot) => slot.id !== "slot_3") // Evitar receso
            const randomDay = days[Math.floor(Math.random() * days.length)]
            const earlySlots = availableSlots.slice(0, 2) // Primeras 2 horas
            const randomSlot = earlySlots[Math.floor(Math.random() * earlySlots.length)]

            if (schedule[randomSlot.id][randomDay].type === "empty") {
              schedule[randomSlot.id][randomDay] = {
                type: "class",
                subject: subject.name,
                teacher: subject.teacher,
                color: getSubjectColor(subject.area),
              }
              assignedHours++
            }
          }
        })
      }

      // Distribuir materias regulares
      regularSubjects.forEach((subject) => {
        let assignedHours = 0
        while (assignedHours < subject.weeklyHours) {
          const availableSlots = timeSlots.filter((slot) => slot.id !== "slot_3") // Evitar receso
          const randomDay = days[Math.floor(Math.random() * days.length)]
          const randomSlot = availableSlots[Math.floor(Math.random() * availableSlots.length)]

          if (schedule[randomSlot.id][randomDay].type === "empty") {
            schedule[randomSlot.id][randomDay] = {
              type: "class",
              subject: subject.name,
              teacher: subject.teacher,
              color: getSubjectColor(subject.area),
            }
            assignedHours++
          }
        }
      })

      setGeneratedSchedule({
        schedule,
        stats: {
          totalBlocks: timeSlots.length * days.length,
          assignedBlocks: Object.values(schedule)
            .flatMap((daySchedule) => Object.values(daySchedule))
            .filter((cell) => cell.type === "class").length,
          breakBlocks: Object.values(schedule)
            .flatMap((daySchedule) => Object.values(daySchedule))
            .filter((cell) => cell.type === "break").length,
        },
      })

      setCurrentStep(3)
    } catch (error) {
      setValidationErrors(["Error al generar el horario automáticamente"])
    } finally {
      setIsGenerating(false)
    }
  }

  const getSubjectColor = (area: string): string => {
    const colorMap: { [key: string]: string } = {
      "Ciencias Exactas": "bg-blue-100 border-blue-300 text-blue-800",
      "Ciencias Naturales": "bg-green-100 border-green-300 text-green-800",
      Humanidades: "bg-purple-100 border-purple-300 text-purple-800",
      "Ciencias Sociales": "bg-orange-100 border-orange-300 text-orange-800",
      Deportes: "bg-red-100 border-red-300 text-red-800",
      Idiomas: "bg-indigo-100 border-indigo-300 text-indigo-800",
    }
    return colorMap[area] || "bg-gray-100 border-gray-300 text-gray-800"
  }

  const handleSaveSchedule = async (publish = false) => {
    const scheduleToSave = generatedSchedule?.schedule || manualSchedule

    try {
      // Simular guardado
      await new Promise((resolve) => setTimeout(resolve, 1000))

      onScheduleCreated(course.id, {
        schedule: scheduleToSave,
        method: creationMethod,
        published: publish,
        createdAt: new Date().toISOString(),
      })

      onClose()
    } catch (error) {
      setValidationErrors(["Error al guardar el horario"])
    }
  }

  const handleStepNavigation = (direction: "next" | "prev") => {
    if (direction === "next") {
      if (currentStep === 1) {
        setCurrentStep(2)
      } else if (currentStep === 2 && creationMethod === "automatic") {
        generateAutomaticSchedule()
      } else if (currentStep === 2 && creationMethod === "manual") {
        setCurrentStep(3)
      }
    } else {
      if (currentStep > 1) {
        setCurrentStep(currentStep - 1)
      }
    }
  }

  const renderScheduleGrid = (schedule: { [key: string]: { [key: string]: ScheduleCell } }) => {
    return (
      <div className="overflow-x-auto">
        <table className="w-full border-collapse border border-gray-300">
          <thead>
            <tr>
              <th className="border border-gray-300 p-2 bg-gray-50 font-medium">Hora</th>
              {days.map((day) => (
                <th key={day} className="border border-gray-300 p-2 bg-gray-50 font-medium">
                  {day}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {timeSlots.map((slot) => (
              <tr key={slot.id}>
                <td className="border border-gray-300 p-2 bg-gray-50 font-medium text-sm">{slot.label}</td>
                {days.map((day) => {
                  const cell = schedule[slot.id]?.[day]
                  return (
                    <td key={`${slot.id}-${day}`} className="border border-gray-300 p-1">
                      {cell?.type === "empty" ? (
                        <div className="h-12 bg-gray-50 rounded flex items-center justify-center text-gray-400 text-sm">
                          Vacío
                        </div>
                      ) : cell?.type === "break" ? (
                        <div
                          className={`h-12 rounded flex items-center justify-center text-sm font-medium ${cell.color}`}
                        >
                          {cell.subject}
                        </div>
                      ) : (
                        <div className={`h-12 rounded p-1 text-xs ${cell?.color}`}>
                          <div className="font-medium truncate">{cell?.subject}</div>
                          <div className="truncate opacity-75">{cell?.teacher}</div>
                        </div>
                      )}
                    </td>
                  )
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    )
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5 text-blue-600" />📅 Crear Horario - {course.name}
          </DialogTitle>
          <DialogDescription>
            Paso {currentStep} de 3:{" "}
            {currentStep === 1 ? "Selección de método" : currentStep === 2 ? "Configuración" : "Revisión y guardado"}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Indicador de progreso */}
          <div className="flex items-center space-x-2">
            {[1, 2, 3].map((step) => (
              <div key={step} className="flex items-center">
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                    currentStep >= step ? "bg-blue-600 text-white" : "bg-gray-200 text-gray-600"
                  }`}
                >
                  {step}
                </div>
                {step < 3 && (
                  <div className={`flex-1 h-1 mx-2 ${currentStep > step ? "bg-blue-600" : "bg-gray-200"}`} />
                )}
              </div>
            ))}
          </div>

          {/* Errores de validación */}
          {validationErrors.length > 0 && (
            <Alert className="border-red-200 bg-red-50">
              <AlertTriangle className="h-4 w-4 text-red-600" />
              <AlertDescription>
                <div className="space-y-1">
                  {validationErrors.map((error, index) => (
                    <div key={index} className="text-red-700">
                      • {error}
                    </div>
                  ))}
                </div>
              </AlertDescription>
            </Alert>
          )}

          {/* Paso 1: Selección de método */}
          {currentStep === 1 && (
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Información del Curso</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4 p-4 bg-gray-50 rounded-lg">
                    <div>
                      <label className="text-sm font-medium text-gray-600">Curso</label>
                      <p className="text-lg font-semibold">{course.name}</p>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-gray-600">Turno</label>
                      <p className="text-lg">{course.turn}</p>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-gray-600">Profesor Encargado</label>
                      <p className="text-lg">{course.teacher}</p>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-gray-600">Materias</label>
                      <p className="text-lg">{courseSubjects.length} configuradas</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>⚙️ Opciones de Creación</CardTitle>
                  <CardDescription>Selecciona cómo deseas crear el horario para este curso</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Card
                      className={`cursor-pointer transition-all ${
                        creationMethod === "automatic"
                          ? "border-blue-500 bg-blue-50"
                          : "border-gray-200 hover:border-gray-300"
                      }`}
                      onClick={() => setCreationMethod("automatic")}
                    >
                      <CardHeader className="pb-3">
                        <CardTitle className="flex items-center gap-2 text-lg">
                          <Wand2 className="h-5 w-5 text-blue-600" />🤖 Generación Automática
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-gray-600 mb-3">
                          El sistema construye el horario inteligentemente según reglas predefinidas
                        </p>
                        <ul className="text-xs space-y-1 text-gray-600">
                          <li>✅ Distribución equitativa de materias</li>
                          <li>✅ Recesos insertados automáticamente</li>
                          <li>✅ Evita solapamientos de docentes</li>
                          <li>✅ Respeta límites por jornada</li>
                          <li>✅ Prioriza materias complejas temprano</li>
                        </ul>
                        <Badge className="mt-3 bg-green-100 text-green-800">Recomendado</Badge>
                      </CardContent>
                    </Card>

                    <Card
                      className={`cursor-pointer transition-all ${
                        creationMethod === "manual"
                          ? "border-blue-500 bg-blue-50"
                          : "border-gray-200 hover:border-gray-300"
                      }`}
                      onClick={() => setCreationMethod("manual")}
                    >
                      <CardHeader className="pb-3">
                        <CardTitle className="flex items-center gap-2 text-lg">
                          <Edit className="h-5 w-5 text-purple-600" />📝 Creación Manual
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-gray-600 mb-3">
                          Construye el horario bloque por bloque con control total
                        </p>
                        <ul className="text-xs space-y-1 text-gray-600">
                          <li>✅ Control total sobre cada bloque</li>
                          <li>✅ Drag-and-drop de materias</li>
                          <li>✅ Inserción manual de recesos</li>
                          <li>✅ Validaciones en tiempo real</li>
                          <li>⚠️ Requiere más tiempo</li>
                        </ul>
                        <Badge className="mt-3 bg-purple-100 text-purple-800">Avanzado</Badge>
                      </CardContent>
                    </Card>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Paso 2: Configuración */}
          {currentStep === 2 && (
            <div className="space-y-6">
              {creationMethod === "automatic" ? (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Settings className="h-5 w-5" />
                      Configuración de Generación Automática
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="text-sm font-medium">Hora de Inicio</label>
                        <Input
                          type="time"
                          value={scheduleConfig.startTime}
                          onChange={(e) => setScheduleConfig({ ...scheduleConfig, startTime: e.target.value })}
                        />
                      </div>
                      <div>
                        <label className="text-sm font-medium">Hora de Fin</label>
                        <Input
                          type="time"
                          value={scheduleConfig.endTime}
                          onChange={(e) => setScheduleConfig({ ...scheduleConfig, endTime: e.target.value })}
                        />
                      </div>
                    </div>

                    <div>
                      <label className="text-sm font-medium">Bloques por Día</label>
                      <Select
                        value={scheduleConfig.blocksPerDay.toString()}
                        onValueChange={(value) =>
                          setScheduleConfig({ ...scheduleConfig, blocksPerDay: Number.parseInt(value) })
                        }
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="5">5 bloques</SelectItem>
                          <SelectItem value="6">6 bloques</SelectItem>
                          <SelectItem value="7">7 bloques</SelectItem>
                          <SelectItem value="8">8 bloques</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-3">
                      <label className="text-sm font-medium">Opciones Avanzadas</label>
                      <div className="space-y-2">
                        <label className="flex items-center space-x-2">
                          <input
                            type="checkbox"
                            checked={scheduleConfig.includeBreaks}
                            onChange={(e) => setScheduleConfig({ ...scheduleConfig, includeBreaks: e.target.checked })}
                            className="text-blue-600"
                          />
                          <span>Incluir recesos automáticamente</span>
                        </label>
                        <label className="flex items-center space-x-2">
                          <input
                            type="checkbox"
                            checked={scheduleConfig.avoidConsecutiveBlocks}
                            onChange={(e) =>
                              setScheduleConfig({ ...scheduleConfig, avoidConsecutiveBlocks: e.target.checked })
                            }
                            className="text-blue-600"
                          />
                          <span>Evitar bloques consecutivos de la misma materia</span>
                        </label>
                        <label className="flex items-center space-x-2">
                          <input
                            type="checkbox"
                            checked={scheduleConfig.prioritizeComplexSubjects}
                            onChange={(e) =>
                              setScheduleConfig({ ...scheduleConfig, prioritizeComplexSubjects: e.target.checked })
                            }
                            className="text-blue-600"
                          />
                          <span>Priorizar materias complejas en horas tempranas</span>
                        </label>
                      </div>
                    </div>

                    <Card className="bg-blue-50 border-blue-200">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-lg">Materias del Curso</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                          {courseSubjects.map((subject) => (
                            <div
                              key={subject.id}
                              className="flex items-center justify-between p-2 bg-white rounded border"
                            >
                              <div>
                                <div className="font-medium text-sm">{subject.name}</div>
                                <div className="text-xs text-gray-600">{subject.teacher}</div>
                              </div>
                              <Badge className="text-xs">{subject.weeklyHours}h</Badge>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  </CardContent>
                </Card>
              ) : (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Edit className="h-5 w-5" />
                      Editor Manual de Horario
                    </CardTitle>
                    <CardDescription>
                      Arrastra y suelta las materias en los bloques horarios. Las validaciones se aplicarán
                      automáticamente.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {/* Materias disponibles */}
                      <div>
                        <h4 className="font-medium mb-2">Materias Disponibles</h4>
                        <div className="flex flex-wrap gap-2">
                          {courseSubjects.map((subject) => (
                            <div
                              key={subject.id}
                              className={`p-2 rounded border cursor-move ${getSubjectColor(subject.area)}`}
                              draggable
                            >
                              <div className="font-medium text-sm">{subject.name}</div>
                              <div className="text-xs opacity-75">{subject.teacher}</div>
                              <div className="text-xs">({subject.weeklyHours}h restantes)</div>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Cuadrícula de horario */}
                      <div>
                        <h4 className="font-medium mb-2">Cuadrícula de Horario</h4>
                        {renderScheduleGrid(manualSchedule)}
                      </div>

                      <Alert className="border-blue-200 bg-blue-50">
                        <AlertTriangle className="h-4 w-4 text-blue-600" />
                        <AlertDescription className="text-blue-700">
                          <strong>Instrucciones:</strong>
                          <ul className="list-disc list-inside mt-1 text-sm">
                            <li>Arrastra las materias desde la lista hacia las celdas del horario</li>
                            <li>Las celdas grises están fuera del rango de jornada</li>
                            <li>Se validarán automáticamente las colisiones de docentes</li>
                            <li>Haz clic derecho en una celda para insertar un receso</li>
                          </ul>
                        </AlertDescription>
                      </Alert>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          )}

          {/* Paso 3: Revisión y guardado */}
          {currentStep === 3 && (
            <div className="space-y-6">
              {isGenerating ? (
                <Card>
                  <CardContent className="text-center py-12">
                    <RefreshCw className="h-12 w-12 mx-auto mb-4 animate-spin text-blue-600" />
                    <h3 className="text-lg font-semibold mb-2">Generando Horario...</h3>
                    <p className="text-gray-600">
                      El sistema está organizando las materias de forma inteligente. Esto puede tomar unos momentos.
                    </p>
                  </CardContent>
                </Card>
              ) : (
                <>
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <CheckCircle className="h-5 w-5 text-green-600" />
                        Horario Generado - {course.name}
                      </CardTitle>
                      <CardDescription>
                        Revisa el horario generado y realiza ajustes si es necesario antes de guardarlo
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      {generatedSchedule && (
                        <div className="space-y-4">
                          {/* Estadísticas */}
                          <div className="grid grid-cols-3 gap-4 p-4 bg-gray-50 rounded-lg">
                            <div className="text-center">
                              <div className="text-2xl font-bold text-blue-600">
                                {generatedSchedule.stats.assignedBlocks}
                              </div>
                              <div className="text-sm text-gray-600">Bloques de Clase</div>
                            </div>
                            <div className="text-center">
                              <div className="text-2xl font-bold text-yellow-600">
                                {generatedSchedule.stats.breakBlocks}
                              </div>
                              <div className="text-sm text-gray-600">Recesos</div>
                            </div>
                            <div className="text-center">
                              <div className="text-2xl font-bold text-gray-600">
                                {generatedSchedule.stats.totalBlocks -
                                  generatedSchedule.stats.assignedBlocks -
                                  generatedSchedule.stats.breakBlocks}
                              </div>
                              <div className="text-sm text-gray-600">Bloques Libres</div>
                            </div>
                          </div>

                          {/* Horario generado */}
                          {renderScheduleGrid(generatedSchedule.schedule)}
                        </div>
                      )}
                    </CardContent>
                  </Card>

                  <Card className="border-green-200 bg-green-50">
                    <CardHeader>
                      <CardTitle className="text-green-800">🎯 Acciones Disponibles</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <h4 className="font-medium text-green-800">Opciones de Guardado</h4>
                          <div className="space-y-2">
                            <Button
                              onClick={() => handleSaveSchedule(false)}
                              variant="outline"
                              className="w-full justify-start"
                            >
                              <Save className="mr-2 h-4 w-4" />💾 Guardar como Borrador
                            </Button>
                            <Button
                              onClick={() => handleSaveSchedule(true)}
                              className="w-full justify-start bg-green-600 hover:bg-green-700"
                            >
                              <CheckCircle className="mr-2 h-4 w-4" />✅ Publicar Horario
                            </Button>
                          </div>
                        </div>
                        <div className="space-y-2">
                          <h4 className="font-medium text-green-800">Otras Acciones</h4>
                          <div className="space-y-2">
                            <Button variant="outline" className="w-full justify-start bg-transparent">
                              <Edit className="mr-2 h-4 w-4" />
                              ✏️ Editar Manualmente
                            </Button>
                            <Button variant="outline" className="w-full justify-start bg-transparent">
                              <Download className="mr-2 h-4 w-4" />📥 Descargar PDF/Excel
                            </Button>
                            {creationMethod === "automatic" && (
                              <Button
                                variant="outline"
                                className="w-full justify-start bg-transparent"
                                onClick={generateAutomaticSchedule}
                              >
                                <RefreshCw className="mr-2 h-4 w-4" />🔁 Recalcular
                              </Button>
                            )}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </>
              )}
            </div>
          )}

          {/* Botones de navegación */}
          <div className="flex justify-between pt-4 border-t">
            <Button
              variant="outline"
              onClick={() => {
                if (currentStep === 1) {
                  onClose()
                } else {
                  handleStepNavigation("prev")
                }
              }}
              disabled={isGenerating}
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              {currentStep === 1 ? "Cancelar" : "Anterior"}
            </Button>

            {currentStep < 3 && (
              <Button
                onClick={() => handleStepNavigation("next")}
                disabled={isGenerating}
                className="bg-blue-600 hover:bg-blue-700"
              >
                {currentStep === 2 && creationMethod === "automatic" ? (
                  <>
                    <Wand2 className="mr-2 h-4 w-4" />
                    Generar Horario
                  </>
                ) : (
                  <>
                    Siguiente
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </>
                )}
              </Button>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
