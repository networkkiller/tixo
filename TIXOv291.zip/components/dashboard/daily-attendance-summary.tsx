"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import {
  CheckCircle,
  XCircle,
  RefreshCw,
  AlertTriangle,
  Clock,
  FileText,
  BarChart3,
  Calendar,
  Users,
  Eye,
} from "lucide-react"
import { format } from "date-fns"
import { es } from "date-fns/locale"

interface AttendanceStats {
  present: number
  absentWithoutSubstitute: number
  absentWithSubstitute: number
  justified: number
  late: number
  total: number
}

interface TeacherDetail {
  id: string
  name: string
  courses: string[]
  shift: string
  status: string
  observations?: string
  hasSubstitute?: boolean
}

export function DailyAttendanceSummary() {
  const [selectedDate, setSelectedDate] = useState(format(new Date(), "yyyy-MM-dd"))
  const [selectedShift, setSelectedShift] = useState("all")
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [modalData, setModalData] = useState<{
    title: string
    teachers: TeacherDetail[]
    status: string
  }>({
    title: "",
    teachers: [],
    status: "",
  })

  // Datos de ejemplo - en producción vendrían de la API
  const [attendanceStats, setAttendanceStats] = useState<AttendanceStats>({
    present: 12,
    absentWithoutSubstitute: 3,
    absentWithSubstitute: 2,
    justified: 1,
    late: 2,
    total: 20,
  })

  const teachersData: Record<string, TeacherDetail[]> = {
    present: [
      { id: "1", name: "María Pérez", courses: ["5to A", "6to B"], shift: "Mañana", status: "Presente" },
      { id: "2", name: "Carlos Mendoza", courses: ["3ro A"], shift: "Mañana", status: "Presente" },
      { id: "3", name: "Ana García", courses: ["4to B"], shift: "Tarde", status: "Presente" },
    ],
    absentWithoutSubstitute: [
      {
        id: "4",
        name: "Juan Gómez",
        courses: ["3ro B"],
        shift: "Tarde",
        status: "Ausente",
        observations: "Sin justificación",
        hasSubstitute: false,
      },
      {
        id: "5",
        name: "Luis Martín",
        courses: ["2do A", "2do B"],
        shift: "Mañana",
        status: "Ausente",
        observations: "No se presentó",
        hasSubstitute: false,
      },
      {
        id: "6",
        name: "Elena Rodríguez",
        courses: ["1ro C"],
        shift: "Tanda Extendida",
        status: "Ausente",
        observations: "Sin contacto",
        hasSubstitute: false,
      },
    ],
    absentWithSubstitute: [
      {
        id: "7",
        name: "Roberto Silva",
        courses: ["4to A"],
        shift: "Mañana",
        status: "Ausente",
        observations: "Licencia médica",
        hasSubstitute: true,
      },
      {
        id: "8",
        name: "Laura Vega",
        courses: ["5to C"],
        shift: "Tarde",
        status: "Ausente",
        observations: "Permiso personal",
        hasSubstitute: true,
      },
    ],
    justified: [
      {
        id: "9",
        name: "Pedro Sánchez",
        courses: ["6to A"],
        shift: "Mañana",
        status: "Justificado",
        observations: "Cita médica autorizada",
      },
    ],
    late: [
      {
        id: "10",
        name: "Carmen López",
        courses: ["1ro A"],
        shift: "Mañana",
        status: "Tarde",
        observations: "Llegó 8:45 AM",
      },
      {
        id: "11",
        name: "Javier Ramírez",
        courses: ["3ro C"],
        shift: "Tarde",
        status: "Tarde",
        observations: "Llegó 13:20 PM",
      },
    ],
  }

  // Filtrar estadísticas por turno
  const getFilteredStats = () => {
    if (selectedShift === "all") return attendanceStats

    // En producción, aquí se filtrarían los datos por turno
    return attendanceStats
  }

  const filteredStats = getFilteredStats()

  const handleStatClick = (status: string, title: string) => {
    const teachers = teachersData[status] || []
    setModalData({
      title,
      teachers,
      status,
    })
    setIsModalOpen(true)
  }

  const getAlertStatus = () => {
    if (filteredStats.absentWithoutSubstitute > 0) {
      return {
        type: "error",
        message: `¡Atención! ${filteredStats.absentWithoutSubstitute} docentes sin cobertura. Registre sustituciones lo antes posible.`,
        icon: <AlertTriangle className="h-4 w-4 text-red-500" />,
        borderColor: "border-red-500",
        bgColor: "bg-red-50",
      }
    }

    return {
      type: "success",
      message: "Todas las ausencias del día están gestionadas.",
      icon: <CheckCircle className="h-4 w-4 text-green-500" />,
      borderColor: "border-green-500",
      bgColor: "bg-green-50",
    }
  }

  const alertStatus = getAlertStatus()

  const statItems = [
    {
      key: "present",
      label: "Presentes",
      value: filteredStats.present,
      icon: <CheckCircle className="h-5 w-5 text-green-500" />,
      description: "Docentes que asistieron según horario",
      bgColor: "bg-green-50",
      textColor: "text-green-700",
      hoverColor: "hover:bg-green-100",
    },
    {
      key: "absentWithoutSubstitute",
      label: "Ausentes SIN sustitución",
      value: filteredStats.absentWithoutSubstitute,
      icon: <XCircle className="h-5 w-5 text-red-500" />,
      description: "Requieren acción inmediata",
      bgColor: "bg-red-50",
      textColor: "text-red-700",
      hoverColor: "hover:bg-red-100",
    },
    {
      key: "absentWithSubstitute",
      label: "Ausentes CON sustitución",
      value: filteredStats.absentWithSubstitute,
      icon: <RefreshCw className="h-5 w-5 text-blue-500" />,
      description: "Cubiertos por otro docente",
      bgColor: "bg-blue-50",
      textColor: "text-blue-700",
      hoverColor: "hover:bg-blue-100",
    },
    {
      key: "justified",
      label: "Justificados",
      value: filteredStats.justified,
      icon: <FileText className="h-5 w-5 text-yellow-500" />,
      description: "Licencia médica u otra justificación",
      bgColor: "bg-yellow-50",
      textColor: "text-yellow-700",
      hoverColor: "hover:bg-yellow-100",
    },
    {
      key: "late",
      label: "Llegada tarde",
      value: filteredStats.late,
      icon: <Clock className="h-5 w-5 text-orange-500" />,
      description: "Se marcaron con retardo",
      bgColor: "bg-orange-50",
      textColor: "text-orange-700",
      hoverColor: "hover:bg-orange-100",
    },
  ]

  return (
    <>
      <Card className={`${alertStatus.borderColor} border-2`}>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Calendar className="h-5 w-5 text-primary" />
              <CardTitle className="text-lg">Asistencia Docente del Día</CardTitle>
            </div>
            <div className="flex items-center space-x-2">
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="px-2 py-1 text-sm border rounded-md"
              />
              <Select value={selectedShift} onValueChange={setSelectedShift}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos los turnos</SelectItem>
                  <SelectItem value="morning">Mañana</SelectItem>
                  <SelectItem value="afternoon">Tarde</SelectItem>
                  <SelectItem value="extended">Tanda Extendida</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline" size="sm" asChild>
                <a href="/dashboard/coordinador-academico/attendance">
                  <Eye className="h-4 w-4 mr-1" />
                  Ver Registro Completo
                </a>
              </Button>
            </div>
          </div>
          <p className="text-sm text-muted-foreground">
            {format(new Date(selectedDate), "EEEE, d 'de' MMMM 'de' yyyy", { locale: es })} - Total:{" "}
            {filteredStats.total} docentes
          </p>
        </CardHeader>

        <CardContent className="space-y-4">
          {/* Alert Status */}
          <div className={`p-3 rounded-lg ${alertStatus.bgColor} flex items-center space-x-2`}>
            {alertStatus.icon}
            <span className="text-sm font-medium">{alertStatus.message}</span>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
            {statItems.map((item) => (
              <div
                key={item.key}
                onClick={() => handleStatClick(item.key, item.label)}
                className={`${item.bgColor} ${item.hoverColor} p-4 rounded-lg cursor-pointer transition-colors group`}
                title="Click para ver detalle"
              >
                <div className="flex items-center justify-between mb-2">
                  {item.icon}
                  <span className={`text-2xl font-bold ${item.textColor}`}>{item.value}</span>
                </div>
                <div className="space-y-1">
                  <p className={`text-sm font-medium ${item.textColor}`}>{item.label}</p>
                  <p className="text-xs text-muted-foreground">{item.description}</p>
                </div>
              </div>
            ))}
          </div>

          {/* Quick Actions */}
          <div className="flex items-center justify-between pt-2 border-t">
            <div className="flex items-center space-x-4">
              <Badge variant="outline" className="flex items-center space-x-1">
                <Users className="h-3 w-3" />
                <span>Total: {filteredStats.total}</span>
              </Badge>
              <Badge
                variant={filteredStats.absentWithoutSubstitute > 0 ? "destructive" : "default"}
                className="flex items-center space-x-1"
              >
                <AlertTriangle className="h-3 w-3" />
                <span>Sin cobertura: {filteredStats.absentWithoutSubstitute}</span>
              </Badge>
            </div>
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="sm" asChild>
                <a href="/dashboard/coordinador-academico/attendance?view=weekly">
                  <BarChart3 className="h-4 w-4 mr-1" />
                  Ver estadísticas semanales
                </a>
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Detail Modal */}
      <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              <Users className="h-5 w-5" />
              <span>{modalData.title}</span>
              <Badge variant="outline">{modalData.teachers.length} docentes</Badge>
            </DialogTitle>
            <DialogDescription>
              Detalle de docentes con estado: {modalData.title.toLowerCase()} -{" "}
              {format(new Date(selectedDate), "d 'de' MMMM 'de' yyyy", { locale: es })}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-3 max-h-96 overflow-y-auto">
            {modalData.teachers.length > 0 ? (
              modalData.teachers.map((teacher) => (
                <div key={teacher.id} className="p-3 border rounded-lg bg-muted/30">
                  <div className="flex items-start justify-between">
                    <div className="space-y-1">
                      <h4 className="font-medium">{teacher.name}</h4>
                      <p className="text-sm text-muted-foreground">
                        Cursos: {teacher.courses.join(", ")} • Turno: {teacher.shift}
                      </p>
                      {teacher.observations && (
                        <p className="text-sm text-muted-foreground">Observaciones: {teacher.observations}</p>
                      )}
                    </div>
                    <div className="flex items-center space-x-2">
                      {teacher.hasSubstitute !== undefined && (
                        <Badge variant={teacher.hasSubstitute ? "default" : "destructive"}>
                          {teacher.hasSubstitute ? "Con sustituto" : "Sin sustituto"}
                        </Badge>
                      )}
                      {modalData.status === "absentWithoutSubstitute" && (
                        <Button size="sm" variant="outline" asChild>
                          <a href={`/dashboard/coordinador-academico/substitutions?teacher=${teacher.id}`}>
                            <RefreshCw className="h-3 w-3 mr-1" />
                            Asignar Sustituto
                          </a>
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <Users className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>No hay docentes con este estado</p>
              </div>
            )}
          </div>

          <div className="flex justify-between items-center pt-4 border-t">
            <Button variant="outline" asChild>
              <a href="/dashboard/coordinador-academico/attendance">Ver registro completo</a>
            </Button>
            <Button onClick={() => setIsModalOpen(false)}>Cerrar</Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  )
}
