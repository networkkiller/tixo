"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Search, Clock, Calendar, User, BookOpen, MapPin } from "lucide-react"
import { format } from "date-fns"
import { es } from "date-fns/locale"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"

interface ClassSession {
  id: string
  subject: string
  teacher: string
  course: string
  classroom: string
  startTime: string
  endTime: string
  day: string
}

export function DailySchedule() {
  const [currentTime, setCurrentTime] = useState(new Date())
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedDay, setSelectedDay] = useState(format(new Date(), "EEEE", { locale: es }))
  const [showOnlyCurrent, setShowOnlyCurrent] = useState(false)
  const [filteredSessions, setFilteredSessions] = useState<ClassSession[]>([])

  // Datos de ejemplo para las sesiones de clase
  const classSessions: ClassSession[] = [
    {
      id: "1",
      subject: "Matemáticas",
      teacher: "Prof. Carlos Mendoza",
      course: "3ro Bachillerato A",
      classroom: "Aula 201",
      startTime: "08:00",
      endTime: "09:00",
      day: "lunes",
    },
    {
      id: "2",
      subject: "Lengua Española",
      teacher: "Prof. María López",
      course: "2do Bachillerato A",
      classroom: "Aula 102",
      startTime: "08:00",
      endTime: "09:00",
      day: "lunes",
    },
    {
      id: "3",
      subject: "Física",
      teacher: "Prof. Ana Gutiérrez",
      course: "4to Bachillerato B",
      classroom: "Laboratorio 1",
      startTime: "09:00",
      endTime: "10:00",
      day: "lunes",
    },
    {
      id: "4",
      subject: "Historia",
      teacher: "Prof. Javier Ramírez",
      course: "5to Bachillerato C",
      classroom: "Aula 305",
      startTime: "09:00",
      endTime: "10:00",
      day: "lunes",
    },
    {
      id: "5",
      subject: "Química",
      teacher: "Prof. Roberto Silva",
      course: "4to Bachillerato A",
      classroom: "Laboratorio 2",
      startTime: "10:00",
      endTime: "11:00",
      day: "lunes",
    },
    {
      id: "6",
      subject: "Inglés",
      teacher: "Prof. Laura Martín",
      course: "1ro Bachillerato B",
      classroom: "Aula 103",
      startTime: "10:00",
      endTime: "11:00",
      day: "lunes",
    },
    {
      id: "7",
      subject: "Matemáticas",
      teacher: "Prof. Carmen Vega",
      course: "1ro Bachillerato A",
      classroom: "Aula 101",
      startTime: "11:00",
      endTime: "12:00",
      day: "lunes",
    },
    {
      id: "8",
      subject: "Ciencias Naturales",
      teacher: "Prof. Lucía Fernández",
      course: "2do Bachillerato B",
      classroom: "Aula 202",
      startTime: "11:00",
      endTime: "12:00",
      day: "lunes",
    },
    {
      id: "9",
      subject: "Educación Física",
      teacher: "Prof. Pedro Sánchez",
      course: "3ro Bachillerato B",
      classroom: "Cancha Deportiva",
      startTime: "12:00",
      endTime: "13:00",
      day: "lunes",
    },
    {
      id: "10",
      subject: "Arte",
      teacher: "Prof. Elena Rodríguez",
      course: "1ro Bachillerato A",
      classroom: "Salón de Arte",
      startTime: "12:00",
      endTime: "13:00",
      day: "lunes",
    },
    {
      id: "11",
      subject: "Matemáticas",
      teacher: "Prof. Carlos Mendoza",
      course: "3ro Bachillerato A",
      classroom: "Aula 201",
      startTime: "08:00",
      endTime: "09:00",
      day: "martes",
    },
    {
      id: "12",
      subject: "Lengua Española",
      teacher: "Prof. María López",
      course: "2do Bachillerato A",
      classroom: "Aula 102",
      startTime: "08:00",
      endTime: "09:00",
      day: "martes",
    },
    {
      id: "13",
      subject: "Física",
      teacher: "Prof. Ana Gutiérrez",
      course: "4to Bachillerato B",
      classroom: "Laboratorio 1",
      startTime: "09:00",
      endTime: "10:00",
      day: "martes",
    },
    {
      id: "14",
      subject: "Historia",
      teacher: "Prof. Javier Ramírez",
      course: "5to Bachillerato C",
      classroom: "Aula 305",
      startTime: "09:00",
      endTime: "10:00",
      day: "martes",
    },
  ]

  // Actualizar la hora actual cada minuto
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date())
    }, 60000)

    return () => clearInterval(timer)
  }, [])

  // Filtrar las sesiones según los criterios
  useEffect(() => {
    let filtered = classSessions.filter((session) => {
      const matchesDay = session.day.toLowerCase() === selectedDay.toLowerCase()
      const matchesSearch =
        session.subject.toLowerCase().includes(searchTerm.toLowerCase()) ||
        session.teacher.toLowerCase().includes(searchTerm.toLowerCase()) ||
        session.course.toLowerCase().includes(searchTerm.toLowerCase()) ||
        session.classroom.toLowerCase().includes(searchTerm.toLowerCase())

      return matchesDay && matchesSearch
    })

    // Si está activado "Mostrar solo clases actuales", filtrar por hora actual
    if (showOnlyCurrent) {
      const currentHour = currentTime.getHours()
      const currentMinutes = currentTime.getMinutes()
      const currentTimeString = `${currentHour.toString().padStart(2, "0")}:${currentMinutes
        .toString()
        .padStart(2, "0")}`

      filtered = filtered.filter((session) => {
        return session.startTime <= currentTimeString && session.endTime > currentTimeString
      })
    }

    setFilteredSessions(filtered)
  }, [searchTerm, selectedDay, showOnlyCurrent, currentTime])

  // Función para verificar si una sesión está en curso
  const isSessionCurrent = (session: ClassSession) => {
    const currentHour = currentTime.getHours()
    const currentMinutes = currentTime.getMinutes()
    const currentTimeString = `${currentHour.toString().padStart(2, "0")}:${currentMinutes.toString().padStart(2, "0")}`

    return session.startTime <= currentTimeString && session.endTime > currentTimeString
  }

  // Obtener el día de la semana actual
  const getCurrentDayName = () => {
    return format(currentTime, "EEEE", { locale: es })
  }

  // Agrupar sesiones por hora
  const sessionsByHour = filteredSessions.reduce<Record<string, ClassSession[]>>((acc, session) => {
    const timeSlot = `${session.startTime} - ${session.endTime}`
    if (!acc[timeSlot]) {
      acc[timeSlot] = []
    }
    acc[timeSlot].push(session)
    return acc
  }, {})

  // Ordenar los bloques de tiempo
  const sortedTimeSlots = Object.keys(sessionsByHour).sort()

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle className="text-xl">Horario Diario</CardTitle>
          <p className="text-sm text-muted-foreground">
            {format(currentTime, "EEEE, d 'de' MMMM 'de' yyyy, HH:mm", { locale: es })}
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <Tabs value={selectedDay} onValueChange={setSelectedDay}>
            <TabsList>
              <TabsTrigger value="lunes">Lun</TabsTrigger>
              <TabsTrigger value="martes">Mar</TabsTrigger>
              <TabsTrigger value="miércoles">Mié</TabsTrigger>
              <TabsTrigger value="jueves">Jue</TabsTrigger>
              <TabsTrigger value="viernes">Vie</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Filtros */}
        <div className="flex flex-wrap gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Buscar por profesor, materia, curso o aula..."
              className="pl-8"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox
              id="showCurrent"
              checked={showOnlyCurrent}
              onCheckedChange={(checked) => setShowOnlyCurrent(checked as boolean)}
            />
            <Label htmlFor="showCurrent">Mostrar solo clases actuales</Label>
          </div>
        </div>

        {/* Horario */}
        <div className="space-y-4">
          {sortedTimeSlots.length > 0 ? (
            sortedTimeSlots.map((timeSlot) => (
              <div key={timeSlot} className="space-y-2">
                <div className="flex items-center space-x-2">
                  <Clock className="h-4 w-4 text-muted-foreground" />
                  <h3 className="font-medium">{timeSlot}</h3>
                  {sessionsByHour[timeSlot].some(isSessionCurrent) && <Badge className="bg-green-500">En curso</Badge>}
                </div>
                <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
                  {sessionsByHour[timeSlot].map((session) => (
                    <div
                      key={session.id}
                      className={`p-3 rounded-lg border ${
                        isSessionCurrent(session) ? "bg-green-50 border-green-200" : "bg-white border-gray-200"
                      }`}
                    >
                      <div className="flex justify-between items-start">
                        <div className="font-medium">{session.subject}</div>
                        {isSessionCurrent(session) && (
                          <Badge variant="outline" className="text-green-600 border-green-200 bg-green-50">
                            Ahora
                          </Badge>
                        )}
                      </div>
                      <div className="mt-2 space-y-1 text-sm">
                        <div className="flex items-center text-gray-600">
                          <User className="h-3.5 w-3.5 mr-1" />
                          {session.teacher}
                        </div>
                        <div className="flex items-center text-gray-600">
                          <BookOpen className="h-3.5 w-3.5 mr-1" />
                          {session.course}
                        </div>
                        <div className="flex items-center text-gray-600">
                          <MapPin className="h-3.5 w-3.5 mr-1" />
                          {session.classroom}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-8">
              <Calendar className="h-12 w-12 mx-auto text-gray-300" />
              <h3 className="mt-2 text-lg font-medium">No hay clases programadas</h3>
              <p className="text-sm text-gray-500">
                No se encontraron clases para {selectedDay} con los filtros actuales
              </p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
