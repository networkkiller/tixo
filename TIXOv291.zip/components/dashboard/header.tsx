"use client"

import { useAuth } from "@/contexts/auth-context"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Badge } from "@/components/ui/badge"
import { Bell, ChevronDown, LogOut, Settings, User, Zap, Brain } from "lucide-react"
import { useRouter } from "next/navigation"

export function Header({ title }: { title: string }) {
  const { user, logout } = useAuth()
  const router = useRouter()

  if (!user) return null

  const handleLogout = () => {
    logout()
    router.push("/login")
  }

  return (
    <header className="border-b border-futuristic-primary/10 bg-futuristic-surface/95 backdrop-blur-xl">
      <div className="flex h-16 items-center justify-between px-6">
        <div className="flex items-center space-x-4">
          <h1 className="text-2xl font-bold bg-gradient-to-r from-futuristic-text-primary to-futuristic-primary bg-clip-text text-transparent">
            {title}
          </h1>
          <Badge className="bg-futuristic-success/10 text-futuristic-success border-futuristic-success/20">
            <Zap className="w-3 h-3 mr-1" />
            Sistema Activo
          </Badge>
        </div>

        <div className="flex items-center space-x-4">
          {/* AI Status */}
          <div className="hidden md:flex items-center space-x-2 bg-futuristic-primary/5 px-3 py-2 rounded-xl border border-futuristic-primary/10">
            <Brain className="w-4 h-4 text-futuristic-primary animate-pulse" />
            <span className="text-sm text-futuristic-text-secondary">IA Activa</span>
          </div>

          {/* Notifications */}
          <Button
            variant="ghost"
            size="icon"
            className="relative text-futuristic-text-secondary hover:text-futuristic-primary hover:bg-futuristic-primary/5"
          >
            <Bell className="h-5 w-5" />
            <div className="absolute -top-1 -right-1 w-3 h-3 bg-futuristic-error rounded-full animate-pulse"></div>
          </Button>

          {/* User Menu */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                className="flex items-center space-x-3 text-futuristic-text-secondary hover:text-futuristic-primary hover:bg-futuristic-primary/5 px-3 py-2 h-auto"
              >
                <Avatar className="h-8 w-8">
                  <AvatarImage src={user.avatar || "/placeholder.svg"} alt={user.name} />
                  <AvatarFallback className="bg-gradient-to-br from-futuristic-primary to-futuristic-creative text-white text-sm">
                    {getInitials(user.name)}
                  </AvatarFallback>
                </Avatar>
                <div className="hidden md:flex flex-col items-start text-sm">
                  <span className="font-medium">{user.name}</span>
                  {user.schoolName && <span className="text-xs text-futuristic-text-tertiary">{user.schoolName}</span>}
                </div>
                <ChevronDown className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-56 bg-futuristic-surface border-futuristic-primary/20 shadow-xl">
              <DropdownMenuLabel className="text-futuristic-text-primary">Mi Cuenta</DropdownMenuLabel>
              <DropdownMenuSeparator className="bg-futuristic-primary/10" />
              <DropdownMenuItem className="hover:bg-futuristic-primary/5 hover:text-futuristic-primary cursor-pointer">
                <User className="mr-2 h-4 w-4" />
                <span>Perfil</span>
              </DropdownMenuItem>
              <DropdownMenuItem className="hover:bg-futuristic-primary/5 hover:text-futuristic-primary cursor-pointer">
                <Settings className="mr-2 h-4 w-4" />
                <span>Configuración</span>
              </DropdownMenuItem>
              <DropdownMenuSeparator className="bg-futuristic-primary/10" />
              <DropdownMenuItem
                className="hover:bg-futuristic-error/5 hover:text-futuristic-error cursor-pointer"
                onClick={handleLogout}
              >
                <LogOut className="mr-2 h-4 w-4" />
                <span>Cerrar Sesión</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  )
}

function getInitials(name: string): string {
  return name
    .split(" ")
    .map((part) => part[0])
    .join("")
    .toUpperCase()
    .substring(0, 2)
}
