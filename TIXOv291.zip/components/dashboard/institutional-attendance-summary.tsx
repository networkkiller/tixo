"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import {
  CheckCircle,
  XCircle,
  RefreshCw,
  AlertTriangle,
  Clock,
  FileText,
  BarChart3,
  Calendar,
  Users,
  Eye,
  Download,
  TrendingUp,
  School,
  BookOpen,
} from "lucide-react"
import { format } from "date-fns"
import { es } from "date-fns/locale"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"

interface InstitutionalAttendanceStats {
  present: number
  absentWithoutSubstitute: number
  absentWithSubstitute: number
  justified: number
  late: number
  total: number
}

interface TeacherDetail {
  id: string
  name: string
  courses: string[]
  shift: string
  level: string
  status: string
  observations?: string
  hasSubstitute?: boolean
}

interface WeeklyData {
  day: string
  percentage: number
}

export function InstitutionalAttendanceSummary() {
  const [selectedDate, setSelectedDate] = useState(format(new Date(), "yyyy-MM-dd"))
  const [selectedShift, setSelectedShift] = useState("all")
  const [selectedLevel, setSelectedLevel] = useState("all")
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [modalData, setModalData] = useState<{
    title: string
    teachers: TeacherDetail[]
    status: string
  }>({
    title: "",
    teachers: [],
    status: "",
  })

  // Datos de ejemplo - en producción vendrían de la API
  const [attendanceStats, setAttendanceStats] = useState<InstitutionalAttendanceStats>({
    present: 57,
    absentWithoutSubstitute: 6,
    absentWithSubstitute: 3,
    justified: 4,
    late: 5,
    total: 75,
  })

  // Datos semanales para el mini-gráfico
  const weeklyData: WeeklyData[] = [
    { day: "Lun", percentage: 92 },
    { day: "Mar", percentage: 88 },
    { day: "Mié", percentage: 94 },
    { day: "Jue", percentage: 90 },
    { day: "Vie", percentage: 85 },
  ]

  const teachersData: Record<string, TeacherDetail[]> = {
    present: [
      {
        id: "1",
        name: "María Pérez",
        courses: ["5to A", "6to B"],
        shift: "Mañana",
        level: "Primaria",
        status: "Presente",
      },
      { id: "2", name: "Carlos Mendoza", courses: ["3ro A"], shift: "Mañana", level: "Primaria", status: "Presente" },
      {
        id: "3",
        name: "Ana García",
        courses: ["1ro Bachillerato"],
        shift: "Tarde",
        level: "Secundaria",
        status: "Presente",
      },
    ],
    absentWithoutSubstitute: [
      {
        id: "4",
        name: "Juan Gómez",
        courses: ["3ro B"],
        shift: "Tarde",
        level: "Primaria",
        status: "Ausente",
        observations: "Sin justificación",
        hasSubstitute: false,
      },
      {
        id: "5",
        name: "Luis Martín",
        courses: ["2do A", "2do B"],
        shift: "Mañana",
        level: "Primaria",
        status: "Ausente",
        observations: "No se presentó",
        hasSubstitute: false,
      },
      {
        id: "6",
        name: "Elena Rodríguez",
        courses: ["Matemáticas 4to"],
        shift: "Tanda Extendida",
        level: "Secundaria",
        status: "Ausente",
        observations: "Sin contacto",
        hasSubstitute: false,
      },
    ],
    absentWithSubstitute: [
      {
        id: "7",
        name: "Roberto Silva",
        courses: ["4to A"],
        shift: "Mañana",
        level: "Primaria",
        status: "Ausente",
        observations: "Licencia médica",
        hasSubstitute: true,
      },
      {
        id: "8",
        name: "Laura Vega",
        courses: ["Ciencias 5to"],
        shift: "Tarde",
        level: "Secundaria",
        status: "Ausente",
        observations: "Permiso personal",
        hasSubstitute: true,
      },
    ],
    justified: [
      {
        id: "9",
        name: "Pedro Sánchez",
        courses: ["6to A"],
        shift: "Mañana",
        level: "Primaria",
        status: "Justificado",
        observations: "Cita médica autorizada",
      },
      {
        id: "10",
        name: "Carmen Torres",
        courses: ["Inicial 4 años"],
        shift: "Mañana",
        level: "Inicial",
        status: "Justificado",
        observations: "Licencia de maternidad",
      },
    ],
    late: [
      {
        id: "11",
        name: "Carmen López",
        courses: ["1ro A"],
        shift: "Mañana",
        level: "Primaria",
        status: "Tarde",
        observations: "Llegó 8:45 AM",
      },
      {
        id: "12",
        name: "Javier Ramírez",
        courses: ["Historia 3ro"],
        shift: "Tarde",
        level: "Secundaria",
        status: "Tarde",
        observations: "Llegó 13:20 PM",
      },
    ],
  }

  // Filtrar estadísticas por turno y nivel
  const getFilteredStats = () => {
    if (selectedShift === "all" && selectedLevel === "all") return attendanceStats
    // En producción, aquí se filtrarían los datos por turno y nivel
    return attendanceStats
  }

  const filteredStats = getFilteredStats()

  const handleStatClick = (status: string, title: string) => {
    const teachers = teachersData[status] || []
    setModalData({
      title,
      teachers,
      status,
    })
    setIsModalOpen(true)
  }

  const getAlertStatus = () => {
    if (filteredStats.absentWithoutSubstitute > 0) {
      return {
        type: "error",
        message: `¡Alerta! Hay ${filteredStats.absentWithoutSubstitute} docentes sin sustitución activa. Coordine con el equipo académico.`,
        icon: <AlertTriangle className="h-4 w-4 text-red-500" />,
        borderColor: "border-red-500",
        bgColor: "bg-red-50",
      }
    }

    return {
      type: "success",
      message: "Toda la planta docente está cubierta o justificada.",
      icon: <CheckCircle className="h-4 w-4 text-green-500" />,
      borderColor: "border-green-500",
      bgColor: "bg-green-50",
    }
  }

  const alertStatus = getAlertStatus()
  const attendancePercentage = Math.round((filteredStats.present / filteredStats.total) * 100)

  const statItems = [
    {
      key: "present",
      label: "Docentes Presentes",
      value: filteredStats.present,
      icon: <CheckCircle className="h-6 w-6 text-green-500" />,
      description: "Han asistido a su jornada según horario",
      bgColor: "bg-green-50",
      textColor: "text-green-700",
      hoverColor: "hover:bg-green-100",
      tooltip: "Docentes que se presentaron según su horario establecido",
    },
    {
      key: "absentWithoutSubstitute",
      label: "Ausentes SIN Sustitución",
      value: filteredStats.absentWithoutSubstitute,
      icon: <XCircle className="h-6 w-6 text-red-500" />,
      description: "Necesitan cobertura inmediata",
      bgColor: "bg-red-50",
      textColor: "text-red-700",
      hoverColor: "hover:bg-red-100",
      tooltip: "Docente ausente y sin cobertura asignada hasta el momento",
    },
    {
      key: "absentWithSubstitute",
      label: "Ausentes CON Sustitución",
      value: filteredStats.absentWithSubstitute,
      icon: <RefreshCw className="h-6 w-6 text-blue-500" />,
      description: "Sustitución ya registrada (interna o externa)",
      bgColor: "bg-blue-50",
      textColor: "text-blue-700",
      hoverColor: "hover:bg-blue-100",
      tooltip: "Docente ausente pero con sustituto asignado",
    },
    {
      key: "justified",
      label: "Ausencias Justificadas",
      value: filteredStats.justified,
      icon: <FileText className="h-6 w-6 text-yellow-500" />,
      description: "Médica, permiso especial, maternidad, etc.",
      bgColor: "bg-yellow-50",
      textColor: "text-yellow-700",
      hoverColor: "hover:bg-yellow-100",
      tooltip: "Ausencias con justificación médica, permiso o licencia autorizada",
    },
    {
      key: "late",
      label: "Llegadas Tardías",
      value: filteredStats.late,
      icon: <Clock className="h-6 w-6 text-orange-500" />,
      description: "Marcado después de la hora correspondiente",
      bgColor: "bg-orange-50",
      textColor: "text-orange-700",
      hoverColor: "hover:bg-orange-100",
      tooltip: "Docentes que llegaron después de su horario establecido",
    },
  ]

  const handleDownloadReport = () => {
    // En producción, aquí se generaría y descargaría el PDF
    console.log("Descargando reporte PDF del día...")
  }

  return (
    <>
      <Card className={`${alertStatus.borderColor} border-2 shadow-lg`}>
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-primary/10 rounded-lg">
                <BarChart3 className="h-6 w-6 text-primary" />
              </div>
              <div>
                <CardTitle className="text-xl">Estado General de Asistencia Docente</CardTitle>
                <p className="text-sm text-muted-foreground">
                  {format(new Date(selectedDate), "EEEE, d 'de' MMMM 'de' yyyy", { locale: es })}
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Badge variant="outline" className="text-lg px-3 py-1">
                <Users className="h-4 w-4 mr-1" />
                {attendancePercentage}% Asistencia
              </Badge>
            </div>
          </div>
        </CardHeader>

        <CardContent className="space-y-6">
          {/* Filtros */}
          <div className="flex flex-wrap items-center gap-3 p-4 bg-muted/30 rounded-lg">
            <div className="flex items-center space-x-2">
              <Calendar className="h-4 w-4 text-muted-foreground" />
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="px-3 py-1 text-sm border rounded-md bg-background"
              />
            </div>
            <Select value={selectedShift} onValueChange={setSelectedShift}>
              <SelectTrigger className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos los turnos</SelectItem>
                <SelectItem value="morning">Mañana</SelectItem>
                <SelectItem value="afternoon">Tarde</SelectItem>
                <SelectItem value="extended">Tanda Extendida</SelectItem>
              </SelectContent>
            </Select>
            <Select value={selectedLevel} onValueChange={setSelectedLevel}>
              <SelectTrigger className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos los niveles</SelectItem>
                <SelectItem value="inicial">Inicial</SelectItem>
                <SelectItem value="primaria">Primaria</SelectItem>
                <SelectItem value="secundaria">Secundaria</SelectItem>
                <SelectItem value="adultos">Adultos</SelectItem>
              </SelectContent>
            </Select>
            <div className="flex items-center space-x-2 ml-auto">
              <Button variant="outline" size="sm" onClick={handleDownloadReport}>
                <Download className="h-4 w-4 mr-1" />
                Descargar PDF
              </Button>
              <Button variant="outline" size="sm" asChild>
                <a href="/dashboard/coordinador-academico/attendance">
                  <BookOpen className="h-4 w-4 mr-1" />
                  Ver todos los cursos
                </a>
              </Button>
            </div>
          </div>

          {/* Alert Status */}
          <div className={`p-4 rounded-lg ${alertStatus.bgColor} flex items-center space-x-3`}>
            {alertStatus.icon}
            <span className="font-medium">{alertStatus.message}</span>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            {statItems.map((item) => (
              <div
                key={item.key}
                onClick={() => handleStatClick(item.key, item.label)}
                className={`${item.bgColor} ${item.hoverColor} p-5 rounded-lg cursor-pointer transition-all duration-200 group border border-transparent hover:border-current/20`}
                title={item.tooltip}
              >
                <div className="flex items-center justify-between mb-3">
                  {item.icon}
                  <span className={`text-3xl font-bold ${item.textColor}`}>{item.value}</span>
                </div>
                <div className="space-y-1">
                  <p className={`text-sm font-semibold ${item.textColor}`}>{item.label}</p>
                  <p className="text-xs text-muted-foreground leading-tight">{item.description}</p>
                </div>
              </div>
            ))}
          </div>

          {/* Mini gráfica semanal */}
          <div className="bg-muted/30 p-4 rounded-lg">
            <div className="flex items-center justify-between mb-4">
              <h4 className="font-semibold flex items-center">
                <TrendingUp className="h-4 w-4 mr-2" />
                Tendencia Semanal de Asistencia
              </h4>
              <Badge variant="outline">Promedio: 90%</Badge>
            </div>
            <div className="h-32">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={weeklyData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="day" />
                  <YAxis domain={[80, 100]} />
                  <Tooltip formatter={(value) => [`${value}%`, "Asistencia"]} />
                  <Line
                    type="monotone"
                    dataKey="percentage"
                    stroke="#3b82f6"
                    strokeWidth={3}
                    dot={{ fill: "#3b82f6", strokeWidth: 2, r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Resumen final */}
          <div className="flex items-center justify-between pt-4 border-t">
            <div className="flex items-center space-x-4">
              <Badge variant="outline" className="flex items-center space-x-1">
                <School className="h-3 w-3" />
                <span>Total Docentes: {filteredStats.total}</span>
              </Badge>
              <Badge
                variant={filteredStats.absentWithoutSubstitute > 0 ? "destructive" : "default"}
                className="flex items-center space-x-1"
              >
                <AlertTriangle className="h-3 w-3" />
                <span>Críticos: {filteredStats.absentWithoutSubstitute}</span>
              </Badge>
              <Badge variant="secondary" className="flex items-center space-x-1">
                <CheckCircle className="h-3 w-3" />
                <span>
                  Cobertura:{" "}
                  {Math.round(
                    ((filteredStats.total - filteredStats.absentWithoutSubstitute) / filteredStats.total) * 100,
                  )}
                  %
                </span>
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Detail Modal */}
      <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              <Users className="h-5 w-5" />
              <span>{modalData.title}</span>
              <Badge variant="outline">{modalData.teachers.length} docentes</Badge>
            </DialogTitle>
            <DialogDescription>
              Detalle institucional de docentes con estado: {modalData.title.toLowerCase()} -{" "}
              {format(new Date(selectedDate), "d 'de' MMMM 'de' yyyy", { locale: es })}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-3 max-h-96 overflow-y-auto">
            {modalData.teachers.length > 0 ? (
              modalData.teachers.map((teacher) => (
                <div key={teacher.id} className="p-4 border rounded-lg bg-muted/30 hover:bg-muted/50 transition-colors">
                  <div className="flex items-start justify-between">
                    <div className="space-y-2">
                      <h4 className="font-semibold text-lg">{teacher.name}</h4>
                      <div className="flex flex-wrap gap-2 text-sm text-muted-foreground">
                        <span className="flex items-center">
                          <BookOpen className="h-3 w-3 mr-1" />
                          Cursos: {teacher.courses.join(", ")}
                        </span>
                        <span className="flex items-center">
                          <Clock className="h-3 w-3 mr-1" />
                          Turno: {teacher.shift}
                        </span>
                        <span className="flex items-center">
                          <School className="h-3 w-3 mr-1" />
                          Nivel: {teacher.level}
                        </span>
                      </div>
                      {teacher.observations && (
                        <p className="text-sm bg-background p-2 rounded border-l-4 border-primary">
                          <strong>Observaciones:</strong> {teacher.observations}
                        </p>
                      )}
                    </div>
                    <div className="flex flex-col items-end space-y-2">
                      {teacher.hasSubstitute !== undefined && (
                        <Badge variant={teacher.hasSubstitute ? "default" : "destructive"}>
                          {teacher.hasSubstitute ? "Con sustituto" : "Sin sustituto"}
                        </Badge>
                      )}
                      {modalData.status === "absentWithoutSubstitute" && (
                        <Button size="sm" variant="outline" asChild>
                          <a href={`/dashboard/coordinador-academico/substitutions?teacher=${teacher.id}`}>
                            <RefreshCw className="h-3 w-3 mr-1" />
                            Coordinar Sustitución
                          </a>
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-12 text-muted-foreground">
                <Users className="h-16 w-16 mx-auto mb-4 opacity-50" />
                <p className="text-lg">No hay docentes con este estado</p>
                <p className="text-sm">Todos los docentes están en otros estados</p>
              </div>
            )}
          </div>

          <div className="flex justify-between items-center pt-4 border-t">
            <div className="flex space-x-2">
              <Button variant="outline" asChild>
                <a href="/dashboard/coordinador-academico/attendance">
                  <Eye className="h-4 w-4 mr-1" />
                  Ver registro completo
                </a>
              </Button>
              <Button variant="outline" asChild>
                <a href="/dashboard/coordinador-academico/substitutions">
                  <RefreshCw className="h-4 w-4 mr-1" />
                  Gestionar sustituciones
                </a>
              </Button>
            </div>
            <Button onClick={() => setIsModalOpen(false)}>Cerrar</Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  )
}
