"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Calendar, CalendarDays, Clock, Users, BookOpen, MapPin, AlertCircle, CheckCircle, User, GraduationCap, FileText, Bell, Filter, ChevronLeft, ChevronRight } from 'lucide-react'
import { format, addDays, startOfWeek, endOfWeek, isSameDay, parseISO } from "date-fns"
import { es } from "date-fns/locale"

interface CalendarActivity {
  id: string
  title: string
  description: string
  date: string
  startTime: string
  endTime: string
  type: "academic" | "administrative" | "evaluation" | "meeting" | "event"
  priority: "high" | "medium" | "low"
  status: "scheduled" | "in-progress" | "completed" | "cancelled"
  location: string
  participants: string[]
  organizer: string
  organizerRole: "coordinador-academico" | "coordinador-registro" | "director" | "profesor"
  relatedCourse?: string
  competencia?: string
  periodo?: string
  notes?: string
}

interface CalendarActivitiesProps {
  userRole: "profesor" | "coordinador-academico" | "coordinador-registro"
}

export function CalendarActivities({ userRole }: CalendarActivitiesProps) {
  const [selectedDate, setSelectedDate] = useState(new Date())
  const [selectedView, setSelectedView] = useState<"week" | "month">("week")
  const [selectedFilter, setSelectedFilter] = useState<string>("all")
  const [activities, setActivities] = useState<CalendarActivity[]>([])

  // Datos de ejemplo sincronizados entre perfiles
  const mockActivities: CalendarActivity[] = [
    {
      id: "1",
      title: "Evaluación Trimestral - Competencia Comunicativa",
      description: "Evaluación del primer trimestre para la competencia comunicativa en todos los cursos de primaria",
      date: "2024-01-22",
      startTime: "08:00",
      endTime: "12:00",
      type: "evaluation",
      priority: "high",
      status: "scheduled",
      location: "Aulas 101-105",
      participants: ["1° A", "1° B", "2° A", "2° B"],
      organizer: "Coordinación Académica",
      organizerRole: "coordinador-academico",
      relatedCourse: "Lengua Española",
      competencia: "Competencia Comunicativa",
      periodo: "P1",
      notes: "Evaluación obligatoria según calendario MINERD"
    },
    {
      id: "2",
      title: "Reunión de Coordinación Docente",
      description: "Revisión de planificación curricular y asignación de actividades del segundo período",
      date: "2024-01-18",
      startTime: "14:00",
      endTime: "16:00",
      type: "meeting",
      priority: "medium",
      status: "scheduled",
      location: "Sala de Reuniones",
      participants: ["Profesores de Primaria", "Coordinador Académico"],
      organizer: "Prof. María González",
      organizerRole: "coordinador-academico",
      notes: "Traer planificaciones del P2"
    },
    {
      id: "3",
      title: "Entrega de Boletines P1",
      description: "Distribución de calificaciones del primer período a padres y estudiantes",
      date: "2024-01-25",
      startTime: "09:00",
      endTime: "17:00",
      type: "administrative",
      priority: "high",
      status: "scheduled",
      location: "Oficina de Registro",
      participants: ["Padres", "Estudiantes", "Coordinador de Registro"],
      organizer: "Lic. Carlos Méndez",
      organizerRole: "coordinador-registro",
      notes: "Horario extendido para atención a padres"
    },
    {
      id: "4",
      title: "Capacitación: Nuevas Metodologías",
      description: "Taller sobre metodologías activas para el desarrollo de competencias",
      date: "2024-01-29",
      startTime: "08:00",
      endTime: "12:00",
      type: "academic",
      priority: "medium",
      status: "scheduled",
      location: "Auditorio Principal",
      participants: ["Cuerpo Docente"],
      organizer: "Dirección Académica",
      organizerRole: "coordinador-academico",
      notes: "Certificación de 4 horas académicas"
    },
    {
      id: "5",
      title: "Evaluación Competencia Científica - 2° Grado",
      description: "Actividad evaluativa para la competencia científica y tecnológica",
      date: "2024-01-24",
      startTime: "10:00",
      endTime: "11:30",
      type: "evaluation",
      priority: "high",
      status: "scheduled",
      location: "Aulas 201-202",
      participants: ["2° A", "2° B"],
      organizer: "Prof. Ana Rodríguez",
      organizerRole: "profesor",
      relatedCourse: "Ciencias Naturales",
      competencia: "Científica y Tecnológica",
      periodo: "P1",
      notes: "Evaluación práctica con experimentos"
    },
    {
      id: "6",
      title: "Inscripciones Período 2024-2",
      description: "Proceso de inscripción para el segundo período académico",
      date: "2024-01-30",
      startTime: "08:00",
      endTime: "16:00",
      type: "administrative",
      priority: "high",
      status: "scheduled",
      location: "Secretaría Académica",
      participants: ["Estudiantes Nuevos", "Padres"],
      organizer: "Secretaría Académica",
      organizerRole: "coordinador-registro",
      notes: "Documentación completa requerida"
    },
    {
      id: "7",
      title: "Reunión de Padres - 1° Grado",
      description: "Reunión informativa sobre el progreso académico del primer trimestre",
      date: "2024-01-26",
      startTime: "18:00",
      endTime: "20:00",
      type: "meeting",
      priority: "medium",
      status: "scheduled",
      location: "Aula Magna",
      participants: ["Padres 1° A y 1° B"],
      organizer: "Prof. Luis Fernández",
      organizerRole: "profesor",
      relatedCourse: "1° Grado",
      notes: "Presentación de resultados por competencias"
    }
  ]

  useEffect(() => {
    // Simular carga de actividades desde API
    setActivities(mockActivities)
  }, [])

  const getActivityTypeIcon = (type: string) => {
    switch (type) {
      case "academic":
        return <BookOpen className="h-4 w-4" />
      case "administrative":
        return <FileText className="h-4 w-4" />
      case "evaluation":
        return <GraduationCap className="h-4 w-4" />
      case "meeting":
        return <Users className="h-4 w-4" />
      case "event":
        return <Calendar className="h-4 w-4" />
      default:
        return <CalendarDays className="h-4 w-4" />
    }
  }

  const getActivityTypeColor = (type: string) => {
    switch (type) {
      case "academic":
        return "bg-blue-100 text-blue-800 border-blue-200"
      case "administrative":
        return "bg-gray-100 text-gray-800 border-gray-200"
      case "evaluation":
        return "bg-purple-100 text-purple-800 border-purple-200"
      case "meeting":
        return "bg-green-100 text-green-800 border-green-200"
      case "event":
        return "bg-orange-100 text-orange-800 border-orange-200"
      default:
        return "bg-gray-100 text-gray-800 border-gray-200"
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "bg-red-100 text-red-800"
      case "medium":
        return "bg-yellow-100 text-yellow-800"
      case "low":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <CheckCircle className="h-4 w-4 text-green-600" />
      case "in-progress":
        return <Clock className="h-4 w-4 text-blue-600" />
      case "cancelled":
        return <AlertCircle className="h-4 w-4 text-red-600" />
      default:
        return <Calendar className="h-4 w-4 text-gray-600" />
    }
  }

  const getOrganizerIcon = (role: string) => {
    switch (role) {
      case "coordinador-academico":
        return <GraduationCap className="h-3 w-3" />
      case "coordinador-registro":
        return <FileText className="h-3 w-3" />
      case "profesor":
        return <User className="h-3 w-3" />
      default:
        return <Users className="h-3 w-3" />
    }
  }

  const filteredActivities = activities.filter(activity => {
    if (selectedFilter === "all") return true
    return activity.type === selectedFilter
  })

  const getWeekDays = () => {
    const start = startOfWeek(selectedDate, { weekStartsOn: 1 })
    const end = endOfWeek(selectedDate, { weekStartsOn: 1 })
    const days = []
    let current = start

    while (current <= end) {
      days.push(current)
      current = addDays(current, 1)
    }
    return days
  }

  const getActivitiesForDate = (date: Date) => {
    return filteredActivities.filter(activity => 
      isSameDay(parseISO(activity.date), date)
    )
  }

  const upcomingActivities = filteredActivities
    .filter(activity => new Date(activity.date) >= new Date())
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
    .slice(0, 5)

  const todayActivities = getActivitiesForDate(new Date())

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5" />
              Calendario de Actividades Sincronizado
            </CardTitle>
            <CardDescription>
              Actividades coordinadas entre Coordinación Académica, Registro y Profesores
            </CardDescription>
          </div>
          <div className="flex items-center gap-2">
            <Select value={selectedFilter} onValueChange={setSelectedFilter}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Filtrar por tipo" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas las actividades</SelectItem>
                <SelectItem value="academic">Académicas</SelectItem>
                <SelectItem value="administrative">Administrativas</SelectItem>
                <SelectItem value="evaluation">Evaluaciones</SelectItem>
                <SelectItem value="meeting">Reuniones</SelectItem>
                <SelectItem value="event">Eventos</SelectItem>
              </SelectContent>
            </Select>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setSelectedView(selectedView === "week" ? "month" : "week")}
            >
              {selectedView === "week" ? "Vista Mensual" : "Vista Semanal"}
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="calendar" className="space-y-4">
          <TabsList>
            <TabsTrigger value="calendar">Calendario</TabsTrigger>
            <TabsTrigger value="today">Hoy ({todayActivities.length})</TabsTrigger>
            <TabsTrigger value="upcoming">Próximas</TabsTrigger>
            <TabsTrigger value="list">Lista Completa</TabsTrigger>
          </TabsList>

          <TabsContent value="calendar" className="space-y-4">
            {/* Navegación del calendario */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setSelectedDate(addDays(selectedDate, -7))}
                >
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <h3 className="text-lg font-semibold">
                  {format(selectedDate, "MMMM yyyy", { locale: es })}
                </h3>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setSelectedDate(addDays(selectedDate, 7))}
                >
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setSelectedDate(new Date())}
              >
                Hoy
              </Button>
            </div>

            {/* Vista semanal */}
            {selectedView === "week" && (
              <div className="grid grid-cols-7 gap-2">
                {["Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom"].map((day) => (
                  <div key={day} className="p-2 text-center font-medium text-sm text-gray-600 bg-gray-50 rounded">
                    {day}
                  </div>
                ))}
                
                {getWeekDays().map((day) => {
                  const dayActivities = getActivitiesForDate(day)
                  const isToday = isSameDay(day, new Date())
                  
                  return (
                    <div
                      key={day.toISOString()}
                      className={`min-h-[120px] p-2 border rounded-lg ${
                        isToday ? "bg-blue-50 border-blue-200" : "bg-white border-gray-200"
                      }`}
                    >
                      <div className={`text-sm font-medium mb-2 ${isToday ? "text-blue-800" : "text-gray-900"}`}>
                        {format(day, "d")}
                      </div>
                      <div className="space-y-1">
                        {dayActivities.slice(0, 3).map((activity) => (
                          <div
                            key={activity.id}
                            className={`text-xs p-1 rounded border ${getActivityTypeColor(activity.type)}`}
                          >
                            <div className="flex items-center gap-1">
                              {getActivityTypeIcon(activity.type)}
                              <span className="truncate">{activity.title}</span>
                            </div>
                            <div className="text-xs opacity-75">
                              {activity.startTime}
                            </div>
                          </div>
                        ))}
                        {dayActivities.length > 3 && (
                          <div className="text-xs text-gray-500 text-center">
                            +{dayActivities.length - 3} más
                          </div>
                        )}
                      </div>
                    </div>
                  )
                })}
              </div>
            )}
          </TabsContent>

          <TabsContent value="today" className="space-y-4">
            <div className="space-y-3">
              {todayActivities.length > 0 ? (
                todayActivities.map((activity) => (
                  <Card key={activity.id} className="border-l-4 border-l-blue-500">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            {getActivityTypeIcon(activity.type)}
                            <h4 className="font-medium">{activity.title}</h4>
                            <Badge className={getActivityTypeColor(activity.type)}>
                              {activity.type}
                            </Badge>
                            <Badge className={getPriorityColor(activity.priority)}>
                              {activity.priority}
                            </Badge>
                          </div>
                          <p className="text-sm text-gray-600 mb-3">{activity.description}</p>
                          
                          <div className="grid grid-cols-2 gap-4 text-sm">
                            <div className="flex items-center gap-2">
                              <Clock className="h-4 w-4 text-gray-400" />
                              <span>{activity.startTime} - {activity.endTime}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <MapPin className="h-4 w-4 text-gray-400" />
                              <span>{activity.location}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              {getOrganizerIcon(activity.organizerRole)}
                              <span>{activity.organizer}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Users className="h-4 w-4 text-gray-400" />
                              <span>{activity.participants.length} participantes</span>
                            </div>
                          </div>

                          {activity.competencia && (
                            <div className="mt-3 p-2 bg-purple-50 rounded border border-purple-200">
                              <div className="text-xs font-medium text-purple-800">
                                {activity.competencia} - {activity.periodo}
                              </div>
                              {activity.relatedCourse && (
                                <div className="text-xs text-purple-600">
                                  Curso: {activity.relatedCourse}
                                </div>
                              )}
                            </div>
                          )}

                          {activity.notes && (
                            <div className="mt-2 p-2 bg-gray-50 rounded text-xs text-gray-600">
                              <strong>Notas:</strong> {activity.notes}
                            </div>
                          )}
                        </div>
                        <div className="flex items-center gap-2 ml-4">
                          {getStatusIcon(activity.status)}
                          <Button variant="outline" size="sm">
                            Ver Detalle
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              ) : (
                <div className="text-center py-8">
                  <Calendar className="h-12 w-12 mx-auto text-gray-300 mb-2" />
                  <h3 className="text-lg font-medium text-gray-900">No hay actividades hoy</h3>
                  <p className="text-gray-500">Disfruta de tu día libre de actividades programadas</p>
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="upcoming" className="space-y-4">
            <div className="space-y-3">
              {upcomingActivities.map((activity) => (
                <div key={activity.id} className="flex items-center gap-4 p-4 border rounded-lg hover:bg-gray-50">
                  <div className="flex-shrink-0">
                    <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${getActivityTypeColor(activity.type)}`}>
                      {getActivityTypeIcon(activity.type)}
                    </div>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h4 className="font-medium">{activity.title}</h4>
                      <Badge className={getPriorityColor(activity.priority)} variant="outline">
                        {activity.priority}
                      </Badge>
                    </div>
                    <p className="text-sm text-gray-600 mb-2">{activity.description}</p>
                    <div className="flex items-center gap-4 text-xs text-gray-500">
                      <span>{format(parseISO(activity.date), "dd/MM/yyyy", { locale: es })}</span>
                      <span>{activity.startTime} - {activity.endTime}</span>
                      <span>{activity.location}</span>
                      <div className="flex items-center gap-1">
                        {getOrganizerIcon(activity.organizerRole)}
                        <span>{activity.organizer}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex-shrink-0">
                    {getStatusIcon(activity.status)}
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="list" className="space-y-4">
            <div className="space-y-2">
              {filteredActivities.map((activity) => (
                <div key={activity.id} className="flex items-center justify-between p-3 border rounded-lg hover:bg-gray-50">
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded flex items-center justify-center ${getActivityTypeColor(activity.type)}`}>
                      {getActivityTypeIcon(activity.type)}
                    </div>
                    <div>
                      <div className="font-medium">{activity.title}</div>
                      <div className="text-sm text-gray-600">
                        {format(parseISO(activity.date), "dd/MM/yyyy", { locale: es })} • {activity.startTime} - {activity.endTime}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge className={getPriorityColor(activity.priority)} variant="outline">
                      {activity.priority}
                    </Badge>
                    <div className="flex items-center gap-1 text-xs text-gray-500">
                      {getOrganizerIcon(activity.organizerRole)}
                      <span>{activity.organizer}</span>
                    </div>
                    {getStatusIcon(activity.status)}
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}
