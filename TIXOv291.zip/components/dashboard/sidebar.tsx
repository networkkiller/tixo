"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { useAuth } from "@/contexts/auth-context"
import { roleModules } from "@/lib/modules"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import {
  BarChart3,
  Building,
  Users,
  CreditCard,
  FileText,
  Settings,
  LifeBuoy,
  BookOpen,
  ClipboardCheck,
  MessageSquare,
  Calendar,
  GraduationCap,
  UserPlus,
  FolderArchive,
  PieChart,
  TrendingDown,
  TrendingUp,
  UserCheck,
  CalendarDays,
  UserX,
  LogOut,
  Menu,
  X,
  Sparkles,
  Home,
  Clock,
  School,
  Database,
  DollarSign,
  Receipt,
  Calculator,
  UserCog,
  UserSearch,
  CheckSquare,
  RefreshCw,
} from "lucide-react"

const icons = {
  BarChart3,
  Building,
  Users,
  CreditCard,
  FileText,
  Settings,
  LifeBuoy,
  BookOpen,
  ClipboardCheck,
  MessageSquare,
  Calendar,
  GraduationCap,
  UserPlus,
  FolderArchive,
  PieChart,
  TrendingDown,
  TrendingUp,
  UserCheck,
  CalendarDays,
  UserX,
  Home,
  Clock,
  School,
  Database,
  DollarSign,
  Receipt,
  Calculator,
  UserCog,
  UserSearch,
  CheckSquare,
  RefreshCw,
}

function getRoleName(role: string): string {
  const roleNames = {
    "super-admin": "Super Administrador",
    director: "Director",
    profesor: "Profesor",
    padre: "Padre de Familia",
    contable: "Contable",
    coordinador: "Coordinador de Registro y Control Académico",
    "coordinador-academico": "Coordinador Académico",
    secretario: "Secretario",
  }
  return roleNames[role as keyof typeof roleNames] || role
}

export function Sidebar() {
  const [isCollapsed, setIsCollapsed] = useState(false)
  const { user, logout } = useAuth()
  const pathname = usePathname()

  if (!user) return null

  const userModules = roleModules[user.role] || []
  console.log("🔍 User role:", user.role)
  console.log("🔍 Available modules:", userModules)

  const handleLogout = () => {
    logout()
  }

  return (
    <>
      {/* Mobile overlay */}
      {!isCollapsed && (
        <div className="fixed inset-0 bg-black/50 z-40 lg:hidden" onClick={() => setIsCollapsed(true)} />
      )}

      {/* Sidebar */}
      <div
        className={`fixed left-0 top-0 h-full bg-white border-r border-gray-200 z-50 transition-all duration-300 ${
          isCollapsed ? "-translate-x-full lg:translate-x-0 lg:w-20" : "w-80 lg:w-80"
        }`}
      >
        {/* Header */}
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <div className={`flex items-center space-x-3 ${isCollapsed ? "lg:justify-center" : ""}`}>
              <div className="w-10 h-10 bg-gradient-to-br from-purple-600 to-blue-600 rounded-xl flex items-center justify-center">
                <GraduationCap className="w-6 h-6 text-white" />
              </div>
              {!isCollapsed && (
                <div>
                  <h1 className="text-xl font-bold text-gray-900">EduGestión360</h1>
                  <p className="text-xs text-gray-500">Gestión Educativa Integral</p>
                </div>
              )}
            </div>
            <Button variant="ghost" size="sm" onClick={() => setIsCollapsed(!isCollapsed)} className="lg:hidden">
              <X className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* User Panel */}
        <div className="p-4 border-b border-gray-200">
          <div className={`bg-purple-50 rounded-xl p-4 ${isCollapsed ? "lg:p-2" : ""}`}>
            <div className={`flex items-center space-x-3 ${isCollapsed ? "lg:justify-center" : ""}`}>
              <div className="w-8 h-8 bg-purple-600 rounded-lg flex items-center justify-center">
                <Sparkles className="w-4 h-4 text-white" />
              </div>
              {!isCollapsed && (
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-gray-900 truncate">
                    Panel de{" "}
                    {user.role === "coordinador"
                      ? "Coordinador de Registro y Control Académico"
                      : user.role === "coordinador-academico"
                        ? "Coordinador Académico"
                        : getRoleName(user.role)}
                  </p>
                  <p className="text-xs text-purple-600 flex items-center space-x-1">
                    <Sparkles className="w-3 h-3" />
                    <span>IA Activa</span>
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Navigation */}
        <div className="flex-1 overflow-y-auto p-4">
          <nav className="space-y-2">
            {userModules.length > 0 ? (
              userModules.map((module) => {
                const IconComponent = icons[module.icon as keyof typeof icons] || FileText
                const isActive = pathname === module.path

                return (
                  <Link key={module.id} href={module.path}>
                    <div
                      className={`flex items-center space-x-3 px-3 py-3 rounded-lg transition-all duration-200 group ${
                        isActive ? "bg-purple-600 text-white shadow-lg" : "text-gray-700 hover:bg-gray-100"
                      } ${isCollapsed ? "lg:justify-center lg:px-2" : ""}`}
                    >
                      <IconComponent
                        className={`w-5 h-5 flex-shrink-0 ${
                          isActive ? "text-white" : "text-gray-500 group-hover:text-gray-700"
                        }`}
                      />
                      {!isCollapsed && <span className="font-medium truncate">{module.name}</span>}
                      {isActive && !isCollapsed && <div className="w-2 h-2 bg-white rounded-full ml-auto" />}
                    </div>
                  </Link>
                )
              })
            ) : (
              <div className="text-center py-8">
                <p className="text-gray-500 text-sm">
                  No hay módulos disponibles para este rol: {user.role || "desconocido"}
                </p>
              </div>
            )}
          </nav>
        </div>

        {/* User Info & Logout */}
        <div className="p-4 border-t border-gray-200">
          <div className={`flex items-center space-x-3 mb-4 ${isCollapsed ? "lg:justify-center" : ""}`}>
            <Avatar className="w-10 h-10">
              <AvatarFallback className="bg-purple-600 text-white font-semibold">
                {user.name
                  ? user.name
                      .split(" ")
                      .map((n) => n[0])
                      .join("")
                      .toUpperCase()
                  : "U"}
              </AvatarFallback>
            </Avatar>
            {!isCollapsed && (
              <div className="flex-1 min-w-0">
                <p className="font-medium text-gray-900 truncate">{user.name || "Usuario"}</p>
                <p className="text-sm text-gray-500 truncate">{user.email || "Sin email"}</p>
                {user.school && <p className="text-xs text-gray-400 truncate">{user.school}</p>}
              </div>
            )}
          </div>

          <Button
            onClick={handleLogout}
            variant="outline"
            className={`w-full justify-start text-gray-700 hover:text-red-600 hover:border-red-200 ${
              isCollapsed ? "lg:justify-center lg:px-2" : ""
            }`}
          >
            <LogOut className="w-4 h-4 flex-shrink-0" />
            {!isCollapsed && <span className="ml-2">Cerrar Sesión</span>}
          </Button>
        </div>
      </div>

      {/* Mobile menu button */}
      <Button
        variant="outline"
        size="sm"
        onClick={() => setIsCollapsed(false)}
        className="fixed top-4 left-4 z-40 lg:hidden"
      >
        <Menu className="w-4 h-4" />
      </Button>

      {/* Desktop toggle button */}
      <Button
        variant="outline"
        size="sm"
        onClick={() => setIsCollapsed(!isCollapsed)}
        className={`hidden lg:block fixed top-4 z-40 transition-all duration-300 ${
          isCollapsed ? "left-24" : "left-84"
        }`}
      >
        <Menu className="w-4 h-4" />
      </Button>
    </>
  )
}
