"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/contexts/auth-context"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { GraduationCap, Eye, EyeOff, Fingerprint, BookOpen, Users, Award } from "lucide-react"

const testCredentials = [
  {
    role: "Super Admin",
    email: "admin@edugestion360.com",
    password: "super-admin123",
    color: "bg-red-500",
  },
  {
    role: "Director",
    email: "director@edugestion360.com",
    password: "director123",
    color: "bg-blue-500",
  },
  {
    role: "Profesor",
    email: "profesor@edugestion360.com",
    password: "profesor123",
    color: "bg-green-500",
  },
  {
    role: "Padre",
    email: "padre@edugestion360.com",
    password: "padre123",
    color: "bg-orange-500",
  },
  {
    role: "Contable",
    email: "contable@edugestion360.com",
    password: "contable123",
    color: "bg-purple-500",
  },
  {
    role: "Coordinador de Registro",
    email: "coordinador@edugestion360.com",
    password: "coordinador123",
    color: "bg-teal-500",
  },
  {
    role: "Coordinador Académico",
    email: "coordinador-academico@edugestion360.com",
    password: "coordinador-academico123",
    color: "bg-indigo-500",
  },
]

export function LoginForm() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [error, setError] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const { login } = useAuth()
  const router = useRouter()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setIsLoading(true)

    try {
      const success = await login(email, password)
      if (success) {
        router.push("/dashboard")
      } else {
        setError("Credenciales incorrectas. Por favor intente nuevamente.")
      }
    } catch (error) {
      console.error("Login error:", error)
      setError("Error de conexión. Por favor intente nuevamente.")
    } finally {
      setIsLoading(false)
    }
  }

  const fillCredentials = (testEmail: string, testPassword: string) => {
    setEmail(testEmail)
    setPassword(testPassword)
    setError("")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#2D1B69] via-[#3B2F7A] to-[#4A3C8C] flex items-center justify-center p-4 relative overflow-hidden">
      {/* Elementos decorativos de fondo inspirados en redes de conexión */}
      <div className="absolute inset-0 overflow-hidden">
        {/* Nodos de conexión decorativos */}
        <div className="absolute top-20 left-20 w-4 h-4 bg-white/30 rounded-full"></div>
        <div className="absolute top-32 left-32 w-3 h-3 bg-blue-400/40 rounded-full"></div>
        <div className="absolute top-40 left-24 w-2 h-2 bg-white/50 rounded-full"></div>

        <div className="absolute top-24 right-28 w-3 h-3 bg-white/40 rounded-full"></div>
        <div className="absolute top-36 right-20 w-4 h-4 bg-blue-300/30 rounded-full"></div>
        <div className="absolute top-48 right-32 w-2 h-2 bg-white/60 rounded-full"></div>

        <div className="absolute bottom-32 left-24 w-3 h-3 bg-white/35 rounded-full"></div>
        <div className="absolute bottom-20 left-36 w-4 h-4 bg-blue-400/25 rounded-full"></div>
        <div className="absolute bottom-40 left-20 w-2 h-2 bg-white/45 rounded-full"></div>

        <div className="absolute bottom-28 right-24 w-4 h-4 bg-white/30 rounded-full"></div>
        <div className="absolute bottom-36 right-32 w-3 h-3 bg-blue-300/40 rounded-full"></div>
        <div className="absolute bottom-44 right-20 w-2 h-2 bg-white/50 rounded-full"></div>

        {/* Líneas de conexión sutiles */}
        <svg className="absolute inset-0 w-full h-full" style={{ zIndex: 1 }}>
          <defs>
            <linearGradient id="connectionGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="rgba(255,255,255,0.1)" />
              <stop offset="100%" stopColor="rgba(96,165,250,0.2)" />
            </linearGradient>
          </defs>
          <line x1="5%" y1="15%" x2="15%" y2="25%" stroke="url(#connectionGradient)" strokeWidth="1" />
          <line x1="85%" y1="20%" x2="95%" y2="30%" stroke="url(#connectionGradient)" strokeWidth="1" />
          <line x1="10%" y1="75%" x2="20%" y2="85%" stroke="url(#connectionGradient)" strokeWidth="1" />
          <line x1="80%" y1="70%" x2="90%" y2="80%" stroke="url(#connectionGradient)" strokeWidth="1" />
          <line x1="20%" y1="40%" x2="30%" y2="50%" stroke="url(#connectionGradient)" strokeWidth="1" />
          <line x1="70%" y1="45%" x2="80%" y2="55%" stroke="url(#connectionGradient)" strokeWidth="1" />
        </svg>

        {/* Efectos de luz difusa */}
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-400/5 rounded-full blur-3xl"></div>
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-purple-400/8 rounded-full blur-3xl"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[32rem] h-[32rem] bg-indigo-400/3 rounded-full blur-3xl"></div>
      </div>

      {/* Contenedor principal */}
      <div className="relative z-10 w-full max-w-6xl mx-auto grid lg:grid-cols-2 gap-8 items-center">
        {/* Panel izquierdo - Información */}
        <div className="hidden lg:block text-white space-y-8">
          <div className="space-y-6">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-gradient-to-br from-white/20 to-blue-400/30 rounded-xl flex items-center justify-center backdrop-blur-sm border border-white/20">
                <GraduationCap className="w-7 h-7 text-white" />
              </div>
              <div>
                <h1 className="text-4xl font-bold bg-gradient-to-r from-white to-blue-200 bg-clip-text text-transparent">
                  EduGestión360
                </h1>
                <p className="text-blue-200 text-lg">Sistema Integral de Gestión Educativa</p>
              </div>
            </div>

            <p className="text-xl text-blue-100 leading-relaxed">
              Transformamos la administración educativa con tecnología avanzada, conectando estudiantes, profesores,
              padres y administradores en una plataforma unificada.
            </p>
          </div>

          {/* Características */}
          <div className="space-y-4">
            <div className="flex items-center space-x-4 p-4 bg-white/10 backdrop-blur-sm rounded-xl border border-white/20">
              <div className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center">
                <BookOpen className="w-5 h-5 text-blue-200" />
              </div>
              <div>
                <h3 className="font-semibold text-white">Gestión Académica</h3>
                <p className="text-blue-200 text-sm">Control completo de cursos, calificaciones y evaluaciones</p>
              </div>
            </div>

            <div className="flex items-center space-x-4 p-4 bg-white/10 backdrop-blur-sm rounded-xl border border-white/20">
              <div className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center">
                <Users className="w-5 h-5 text-blue-200" />
              </div>
              <div>
                <h3 className="font-semibold text-white">Comunicación Integrada</h3>
                <p className="text-blue-200 text-sm">Conecta toda la comunidad educativa en tiempo real</p>
              </div>
            </div>

            <div className="flex items-center space-x-4 p-4 bg-white/10 backdrop-blur-sm rounded-xl border border-white/20">
              <div className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center">
                <Award className="w-5 h-5 text-blue-200" />
              </div>
              <div>
                <h3 className="font-semibold text-white">Reportes Avanzados</h3>
                <p className="text-blue-200 text-sm">Análisis detallado del rendimiento y progreso</p>
              </div>
            </div>
          </div>
        </div>

        {/* Panel derecho - Formulario de login */}
        <div className="w-full max-w-md mx-auto lg:mx-0">
          <Card className="bg-white/95 backdrop-blur-xl shadow-2xl border-0 rounded-2xl overflow-hidden">
            <CardHeader className="text-center space-y-4 bg-gradient-to-br from-slate-50 to-blue-50 pb-8">
              <div className="mx-auto w-16 h-16 bg-gradient-to-br from-[#2D1B69] to-[#4A3C8C] rounded-2xl flex items-center justify-center shadow-lg">
                <GraduationCap className="w-8 h-8 text-white" />
              </div>
              <div>
                <CardTitle className="text-2xl font-bold text-gray-900">Iniciar Sesión</CardTitle>
                <CardDescription className="text-gray-600">Accede a tu cuenta de EduGestión360</CardDescription>
              </div>
            </CardHeader>

            <CardContent className="space-y-6 p-8">
              {error && (
                <Alert className="border-red-200 bg-red-50 rounded-xl">
                  <AlertDescription className="text-red-800">{error}</AlertDescription>
                </Alert>
              )}

              <form onSubmit={handleSubmit} className="space-y-5">
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-gray-700 font-medium text-sm">
                    Correo Electrónico
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="usuario@edugestion360.com"
                    required
                    className="h-12 border-gray-200 focus:border-[#4A3C8C] focus:ring-[#4A3C8C] rounded-xl bg-gray-50/50"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password" className="text-gray-700 font-medium text-sm">
                    Contraseña
                  </Label>
                  <div className="relative">
                    <Input
                      id="password"
                      type={showPassword ? "text" : "password"}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••••••"
                      required
                      className="h-12 pr-12 border-gray-200 focus:border-[#4A3C8C] focus:ring-[#4A3C8C] rounded-xl bg-gray-50/50"
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="absolute right-0 top-0 h-12 px-3 hover:bg-transparent rounded-xl"
                      onClick={() => setShowPassword(!showPassword)}
                    >
                      {showPassword ? (
                        <EyeOff className="w-4 h-4 text-gray-500" />
                      ) : (
                        <Eye className="w-4 h-4 text-gray-500" />
                      )}
                    </Button>
                  </div>
                </div>

                <Button
                  type="submit"
                  disabled={isLoading}
                  className="w-full h-12 bg-gradient-to-r from-[#2D1B69] to-[#4A3C8C] hover:from-[#3B2F7A] hover:to-[#5A4D9C] text-white font-medium shadow-lg transition-all duration-200 rounded-xl"
                >
                  {isLoading ? (
                    <div className="flex items-center space-x-2">
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      <span>Verificando...</span>
                    </div>
                  ) : (
                    <div className="flex items-center space-x-2">
                      <Fingerprint className="w-5 h-5" />
                      <span>Iniciar Sesión</span>
                    </div>
                  )}
                </Button>
              </form>

              <div className="space-y-4">
                <div className="relative">
                  <div className="absolute inset-0 flex items-center">
                    <span className="w-full border-t border-gray-200" />
                  </div>
                  <div className="relative flex justify-center text-xs uppercase">
                    <span className="bg-white px-2 text-gray-500 font-medium">Credenciales de prueba</span>
                  </div>
                </div>

                <div className="grid gap-2 max-h-64 overflow-y-auto">
                  {testCredentials.map((cred, index) => (
                    <Button
                      key={index}
                      variant="outline"
                      size="sm"
                      onClick={() => fillCredentials(cred.email, cred.password)}
                      className="justify-start h-auto p-3 border-gray-200 hover:bg-[#4A3C8C]/5 hover:border-[#4A3C8C]/30 transition-colors rounded-xl"
                    >
                      <div className="flex items-center space-x-3 w-full">
                        <div className={`w-3 h-3 rounded-full ${cred.color} shadow-sm`} />
                        <div className="text-left flex-1">
                          <div className="font-medium text-gray-900 text-sm">{cred.role}</div>
                          <div className="text-xs text-gray-500 truncate">{cred.email}</div>
                        </div>
                      </div>
                    </Button>
                  ))}
                </div>
                <p className="text-xs text-gray-500 text-center">
                  Selecciona cualquier rol para llenar automáticamente las credenciales
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
