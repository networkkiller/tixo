"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Checkbox } from "@/components/ui/checkbox"
import { Progress } from "@/components/ui/progress"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  BookOpen,
  Plus,
  Edit,
  Trash2,
  Save,
  Copy,
  ArrowUp,
  ArrowDown,
  CheckCircle,
  Clock,
  Search,
  FileText,
  GripVertical,
} from "lucide-react"
import { SubjectsManagementService, type Subject, type CourseSubject, type Course } from "@/lib/subjects-management"
import { CourseInteroperabilityService } from "@/lib/course-interoperability"

interface CourseSubjectsConfiguratorProps {
  course: Course
  onSubjectsConfigured?: (courseId: string, subjects: CourseSubject[]) => void
  onCancel?: () => void
}

export function CourseSubjectsConfigurator({
  course,
  onSubjectsConfigured,
  onCancel,
}: CourseSubjectsConfiguratorProps) {
  const [courseSubjects, setCourseSubjects] = useState<CourseSubject[]>([])
  const [availableSubjects, setAvailableSubjects] = useState<Subject[]>([])
  const [selectedSubjects, setSelectedSubjects] = useState<string[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [filterArea, setFilterArea] = useState("all")
  const [filterType, setFilterType] = useState("all")
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isCloneDialogOpen, setIsCloneDialogOpen] = useState(false)
  const [isSaving, setIsSaving] = useState(false)
  const [compliance, setCompliance] = useState({
    totalRequired: 0,
    assignedRequired: 0,
    totalOptional: 0,
    assignedOptional: 0,
    compliancePercentage: 0,
    missingSubjects: [] as Subject[],
  })

  // Cargar datos iniciales
  useEffect(() => {
    loadCourseSubjects()
    loadAvailableSubjects()
  }, [course])

  // Calcular cumplimiento curricular
  useEffect(() => {
    const newCompliance = SubjectsManagementService.calculateCurricularCompliance(courseSubjects, course.level)
    setCompliance(newCompliance)
  }, [courseSubjects, course.level])

  const loadCourseSubjects = async () => {
    try {
      const subjects = await SubjectsManagementService.getCourseSubjects(course.id)
      setCourseSubjects(subjects)
    } catch (error) {
      console.error("Error cargando materias del curso:", error)
    }
  }

  const loadAvailableSubjects = () => {
    const subjects = SubjectsManagementService.getSubjectsByLevel(course.level)
    setAvailableSubjects(subjects)
  }

  const handleAddSubjects = async () => {
    if (selectedSubjects.length === 0) return

    try {
      setIsSaving(true)
      const newCourseSubjects = await SubjectsManagementService.assignSubjectsToCourse(course.id, selectedSubjects)
      setCourseSubjects((prev) => [...prev, ...newCourseSubjects])
      setSelectedSubjects([])
      setIsAddDialogOpen(false)
    } catch (error) {
      console.error("Error asignando materias:", error)
    } finally {
      setIsSaving(false)
    }
  }

  const handleRemoveSubject = async (courseSubjectId: string) => {
    const courseSubject = courseSubjects.find((cs) => cs.id === courseSubjectId)
    if (!courseSubject) return

    const validation = SubjectsManagementService.canRemoveSubjectFromCourse(courseSubject)
    if (!validation.canRemove) {
      alert(validation.reason)
      return
    }

    try {
      await SubjectsManagementService.removeSubjectFromCourse(courseSubjectId)
      setCourseSubjects((prev) => prev.filter((cs) => cs.id !== courseSubjectId))
    } catch (error) {
      console.error("Error eliminando materia:", error)
    }
  }

  const handleReorderSubject = async (courseSubjectId: string, direction: "up" | "down") => {
    const currentIndex = courseSubjects.findIndex((cs) => cs.id === courseSubjectId)
    if (currentIndex === -1) return

    const newIndex = direction === "up" ? currentIndex - 1 : currentIndex + 1
    if (newIndex < 0 || newIndex >= courseSubjects.length) return

    const newOrder = [...courseSubjects]
    const [movedItem] = newOrder.splice(currentIndex, 1)
    newOrder.splice(newIndex, 0, movedItem)

    // Actualizar órdenes
    const updatedOrder = newOrder.map((cs, index) => ({
      ...cs,
      order: index + 1,
    }))

    setCourseSubjects(updatedOrder)

    // Guardar en backend
    try {
      await SubjectsManagementService.reorderCourseSubjects(
        course.id,
        updatedOrder.map((cs) => ({ id: cs.id, order: cs.order })),
      )
    } catch (error) {
      console.error("Error reordenando materias:", error)
    }
  }

  const handleLoadTemplate = async () => {
    const template = SubjectsManagementService.getSuggestedTemplate(course.level, course.grade)
    const subjectIds = template.map((s) => s.id)

    try {
      setIsSaving(true)
      const newCourseSubjects = await SubjectsManagementService.assignSubjectsToCourse(course.id, subjectIds)
      setCourseSubjects(newCourseSubjects)
    } catch (error) {
      console.error("Error cargando plantilla:", error)
    } finally {
      setIsSaving(false)
    }
  }

  const handleSaveConfiguration = async () => {
    if (courseSubjects.length === 0) {
      alert("Debe asignar al menos una materia al curso")
      return
    }

    const missingHours = courseSubjects.some((cs) => !cs.subject.weeklyHours || cs.subject.weeklyHours <= 0)
    if (missingHours) {
      alert("Todas las materias deben tener carga horaria definida")
      return
    }

    try {
      setIsSaving(true)

      // Actualizar estado del curso en el sistema de interoperabilidad
      await CourseInteroperabilityService.updateCourseConfiguration(
        course.id,
        { hasSubjects: true },
        "coordinador-academico",
      )

      // Notificar al componente padre
      onSubjectsConfigured?.(course.id, courseSubjects)

      alert("✅ Configuración de materias guardada exitosamente")
    } catch (error) {
      console.error("Error guardando configuración:", error)
      alert("❌ Error al guardar la configuración")
    } finally {
      setIsSaving(false)
    }
  }

  // Filtrar materias disponibles
  const filteredAvailableSubjects = availableSubjects.filter((subject) => {
    const matchesSearch =
      subject.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      subject.code.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesArea = filterArea === "all" || subject.area === filterArea
    const matchesType = filterType === "all" || subject.type === filterType
    const notAlreadyAssigned = !courseSubjects.some((cs) => cs.subjectId === subject.id)

    return matchesSearch && matchesArea && matchesType && notAlreadyAssigned
  })

  // Obtener áreas únicas
  const uniqueAreas = Array.from(new Set(availableSubjects.map((s) => s.area)))

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Configurar Materias</h2>
          <p className="text-gray-600">
            Curso: <span className="font-medium">{course.name}</span> - {course.turn} - Capacidad: {course.capacity}
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={onCancel} className="border-gray-300 text-gray-600 bg-transparent">
            Cancelar
          </Button>
          <Button
            onClick={handleSaveConfiguration}
            disabled={isSaving || courseSubjects.length === 0}
            className="bg-green-600 hover:bg-green-700 text-white"
          >
            <Save className="mr-2 h-4 w-4" />
            {isSaving ? "Guardando..." : "Guardar Configuración"}
          </Button>
        </div>
      </div>

      {/* Cumplimiento Curricular */}
      <Card className="bg-blue-50 border-blue-200">
        <CardHeader>
          <CardTitle className="text-blue-800 flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Cumplimiento Curricular MINERD
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
            <div className="text-center">
              <p className="text-sm text-blue-600">Materias Obligatorias</p>
              <p className="text-2xl font-bold text-blue-800">
                {compliance.assignedRequired}/{compliance.totalRequired}
              </p>
            </div>
            <div className="text-center">
              <p className="text-sm text-blue-600">Materias Optativas</p>
              <p className="text-2xl font-bold text-blue-800">
                {compliance.assignedOptional}/{compliance.totalOptional}
              </p>
            </div>
            <div className="text-center">
              <p className="text-sm text-blue-600">Cumplimiento</p>
              <p className="text-2xl font-bold text-blue-800">{compliance.compliancePercentage}%</p>
            </div>
            <div className="text-center">
              <p className="text-sm text-blue-600">Total Asignadas</p>
              <p className="text-2xl font-bold text-blue-800">{courseSubjects.length}</p>
            </div>
          </div>
          <Progress value={compliance.compliancePercentage} className="h-3" />
          {compliance.missingSubjects.length > 0 && (
            <div className="mt-4">
              <p className="text-sm font-medium text-blue-800 mb-2">Materias Obligatorias Faltantes:</p>
              <div className="flex flex-wrap gap-1">
                {compliance.missingSubjects.map((subject) => (
                  <Badge key={subject.id} variant="outline" className="border-red-300 text-red-700">
                    {subject.name}
                  </Badge>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Acciones Rápidas */}
      <div className="flex flex-wrap gap-2">
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-purple-600 hover:bg-purple-700 text-white">
              <Plus className="mr-2 h-4 w-4" />
              Agregar Materias
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Agregar Materias al Curso</DialogTitle>
              <DialogDescription>
                Selecciona las materias del catálogo MINERD para asignar al curso {course.name}
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4">
              {/* Filtros */}
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                    <Input
                      placeholder="Buscar materias..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>
                <Select value={filterArea} onValueChange={setFilterArea}>
                  <SelectTrigger className="w-[200px]">
                    <SelectValue placeholder="Área" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todas las áreas</SelectItem>
                    {uniqueAreas.map((area) => (
                      <SelectItem key={area} value={area}>
                        {area}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select value={filterType} onValueChange={setFilterType}>
                  <SelectTrigger className="w-[150px]">
                    <SelectValue placeholder="Tipo" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos</SelectItem>
                    <SelectItem value="obligatoria">Obligatorias</SelectItem>
                    <SelectItem value="optativa">Optativas</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Lista de materias */}
              <div className="max-h-96 overflow-y-auto border rounded-lg">
                <div className="space-y-2 p-4">
                  {filteredAvailableSubjects.map((subject) => (
                    <div
                      key={subject.id}
                      className="flex items-center space-x-3 p-3 border rounded-lg hover:bg-gray-50"
                    >
                      <Checkbox
                        checked={selectedSubjects.includes(subject.id)}
                        onCheckedChange={(checked) => {
                          if (checked) {
                            setSelectedSubjects((prev) => [...prev, subject.id])
                          } else {
                            setSelectedSubjects((prev) => prev.filter((id) => id !== subject.id))
                          }
                        }}
                      />
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <h4 className="font-medium">{subject.name}</h4>
                          <Badge
                            className={
                              subject.type === "obligatoria" ? "bg-red-100 text-red-800" : "bg-blue-100 text-blue-800"
                            }
                          >
                            {subject.type === "obligatoria" ? "Obligatoria" : "Optativa"}
                          </Badge>
                        </div>
                        <p className="text-sm text-gray-600">{subject.description}</p>
                        <div className="flex items-center gap-4 text-xs text-gray-500 mt-1">
                          <span>Área: {subject.area}</span>
                          <span>Código: {subject.code}</span>
                          <span>Horas: {subject.weeklyHours}/semana</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {selectedSubjects.length > 0 && (
                <Alert>
                  <CheckCircle className="h-4 w-4" />
                  <AlertDescription>
                    {selectedSubjects.length} materia(s) seleccionada(s) para agregar al curso
                  </AlertDescription>
                </Alert>
              )}
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                Cancelar
              </Button>
              <Button
                onClick={handleAddSubjects}
                disabled={selectedSubjects.length === 0 || isSaving}
                className="bg-purple-600 hover:bg-purple-700 text-white"
              >
                {isSaving ? "Agregando..." : `Agregar ${selectedSubjects.length} Materia(s)`}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        <Button variant="outline" onClick={handleLoadTemplate} disabled={isSaving}>
          <FileText className="mr-2 h-4 w-4" />
          Cargar Plantilla MINERD
        </Button>

        <Dialog open={isCloneDialogOpen} onOpenChange={setIsCloneDialogOpen}>
          <DialogTrigger asChild>
            <Button variant="outline">
              <Copy className="mr-2 h-4 w-4" />
              Clonar de Otro Curso
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Clonar Materias</DialogTitle>
              <DialogDescription>
                Selecciona un curso existente para copiar su configuración de materias
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Seleccionar curso origen" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="course_1">5to A - Primaria</SelectItem>
                  <SelectItem value="course_2">5to B - Primaria</SelectItem>
                  <SelectItem value="course_3">6to A - Primaria</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsCloneDialogOpen(false)}>
                Cancelar
              </Button>
              <Button className="bg-blue-600 hover:bg-blue-700 text-white">Clonar Materias</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Lista de Materias Asignadas */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BookOpen className="h-5 w-5" />
            Materias Asignadas ({courseSubjects.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {courseSubjects.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <BookOpen className="h-12 w-12 mx-auto mb-4 text-gray-300" />
              <p>No hay materias asignadas a este curso</p>
              <p className="text-sm">Usa el botón "Agregar Materias" para comenzar</p>
            </div>
          ) : (
            <div className="space-y-3">
              {courseSubjects
                .sort((a, b) => a.order - b.order)
                .map((courseSubject, index) => (
                  <div
                    key={courseSubject.id}
                    className="flex items-center gap-4 p-4 border rounded-lg hover:bg-gray-50"
                  >
                    <div className="flex items-center gap-2">
                      <GripVertical className="h-4 w-4 text-gray-400" />
                      <span className="text-sm font-medium text-gray-500 w-8">{courseSubject.order}</span>
                    </div>

                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className="font-medium">{courseSubject.subject.name}</h4>
                        <Badge
                          className={
                            courseSubject.subject.type === "obligatoria"
                              ? "bg-red-100 text-red-800"
                              : "bg-blue-100 text-blue-800"
                          }
                        >
                          {courseSubject.subject.type === "obligatoria" ? "Obligatoria" : "Optativa"}
                        </Badge>
                        {courseSubject.isAssigned && (
                          <Badge className="bg-green-100 text-green-800">
                            <CheckCircle className="h-3 w-3 mr-1" />
                            Docente Asignado
                          </Badge>
                        )}
                        {courseSubject.hasGrades && (
                          <Badge className="bg-yellow-100 text-yellow-800">
                            <Clock className="h-3 w-3 mr-1" />
                            Con Calificaciones
                          </Badge>
                        )}
                      </div>
                      <div className="flex items-center gap-4 text-sm text-gray-600">
                        <span>Área: {courseSubject.subject.area}</span>
                        <span>Código: {courseSubject.subject.code}</span>
                        <span>Horas: {courseSubject.subject.weeklyHours}/semana</span>
                        {courseSubject.teacherName && <span>Docente: {courseSubject.teacherName}</span>}
                      </div>
                    </div>

                    <div className="flex items-center gap-1">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleReorderSubject(courseSubject.id, "up")}
                        disabled={index === 0}
                        title="Subir"
                      >
                        <ArrowUp className="h-4 w-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleReorderSubject(courseSubject.id, "down")}
                        disabled={index === courseSubjects.length - 1}
                        title="Bajar"
                      >
                        <ArrowDown className="h-4 w-4" />
                      </Button>
                      <Button size="sm" variant="ghost" title="Editar">
                        <Edit className="h-4 w-4" />
                      </Button>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button size="sm" variant="ghost" title="Eliminar">
                            <Trash2 className="h-4 w-4 text-red-600" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>¿Eliminar materia?</AlertDialogTitle>
                            <AlertDialogDescription>
                              ¿Estás seguro de que deseas eliminar "{courseSubject.subject.name}" del curso? Esta acción
                              no se puede deshacer.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancelar</AlertDialogCancel>
                            <AlertDialogAction
                              onClick={() => handleRemoveSubject(courseSubject.id)}
                              className="bg-red-600 hover:bg-red-700"
                            >
                              Eliminar
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </div>
                ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Resumen Final */}
      {courseSubjects.length > 0 && (
        <Card className="bg-green-50 border-green-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-medium text-green-800">Configuración Lista</h4>
                <p className="text-sm text-green-600">
                  {courseSubjects.length} materias configuradas - Total:{" "}
                  {courseSubjects.reduce((sum, cs) => sum + cs.subject.weeklyHours, 0)} horas semanales
                </p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
