"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Progress } from "@/components/ui/progress"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  BookOpen,
  Plus,
  Trash2,
  Save,
  Download,
  AlertTriangle,
  CheckCircle,
  User,
  ArrowLeft,
  RefreshCw,
  Settings,
} from "lucide-react"
import type { Course } from "@/lib/course-interoperability"

interface Teacher {
  id: string
  name: string
  cedula: string
  email: string
  phone: string
  specialization: string[]
  turn: string
  assignedCourses: number
  maxCourses: number
  status: "active" | "inactive"
  subjects: string[]
}

interface Subject {
  id: string
  name: string
  code: string
  area: string
  isOptional: boolean
  weeklyHours: number
  assignedTeacher?: string
  isCore: boolean
  minerdRequired: boolean
}

interface CourseConfigurationFormProps {
  course: Course
  onConfigurationComplete: (courseId: string, config: { subjects: Subject[]; teacher: Teacher }) => void
  onCancel: () => void
}

export function CourseConfigurationForm({ course, onConfigurationComplete, onCancel }: CourseConfigurationFormProps) {
  const [currentStep, setCurrentStep] = useState(1)
  const [selectedSubjects, setSelectedSubjects] = useState<Subject[]>([])
  const [selectedTeacher, setSelectedTeacher] = useState<Teacher | null>(null)
  const [suggestedTeacher, setSuggestedTeacher] = useState<Teacher | null>(null)
  const [availableSubjects, setAvailableSubjects] = useState<Subject[]>([])
  const [availableTeachers, setAvailableTeachers] = useState<Teacher[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [validationErrors, setValidationErrors] = useState<string[]>([])
  const [courseNotes, setCourseNotes] = useState("")
  const [showTeacherDetails, setShowTeacherDetails] = useState(false)

  // Datos de ejemplo para materias MINERD
  useEffect(() => {
    const mockSubjects: Subject[] = [
      {
        id: "math_1",
        name: "Matemáticas",
        code: "MAT-001",
        area: "Ciencias Exactas",
        isOptional: false,
        weeklyHours: 5,
        isCore: true,
        minerdRequired: true,
        subjects: ["Aritmética", "Álgebra", "Geometría"],
      },
      {
        id: "spanish_1",
        name: "Lengua Española",
        code: "ESP-001",
        area: "Humanidades",
        isOptional: false,
        weeklyHours: 4,
        isCore: true,
        minerdRequired: true,
        subjects: ["Gramática", "Literatura", "Redacción"],
      },
      {
        id: "science_1",
        name: "Ciencias Naturales",
        code: "CIE-001",
        area: "Ciencias Naturales",
        isOptional: false,
        weeklyHours: 3,
        isCore: true,
        minerdRequired: true,
        subjects: ["Biología", "Física", "Química"],
      },
      {
        id: "social_1",
        name: "Ciencias Sociales",
        code: "SOC-001",
        area: "Ciencias Sociales",
        isOptional: false,
        weeklyHours: 3,
        isCore: true,
        minerdRequired: true,
        subjects: ["Historia", "Geografía", "Cívica"],
      },
      {
        id: "english_1",
        name: "Inglés",
        code: "ING-001",
        area: "Idiomas",
        isOptional: false,
        weeklyHours: 3,
        isCore: true,
        minerdRequired: true,
        subjects: ["Conversación", "Gramática", "Comprensión"],
      },
      {
        id: "pe_1",
        name: "Educación Física",
        code: "EDF-001",
        area: "Deportes",
        isOptional: false,
        weeklyHours: 2,
        isCore: true,
        minerdRequired: true,
        subjects: ["Deportes", "Recreación", "Salud"],
      },
      {
        id: "art_1",
        name: "Educación Artística",
        code: "ART-001",
        area: "Artes",
        isOptional: true,
        weeklyHours: 2,
        isCore: false,
        minerdRequired: false,
        subjects: ["Música", "Pintura", "Teatro"],
      },
      {
        id: "religion_1",
        name: "Educación Moral y Religiosa",
        code: "REL-001",
        area: "Humanidades",
        isOptional: true,
        weeklyHours: 1,
        isCore: false,
        minerdRequired: false,
        subjects: ["Valores", "Ética", "Religión"],
      },
    ]

    setAvailableSubjects(mockSubjects)
  }, [])

  // Datos de ejemplo para profesores
  useEffect(() => {
    const mockTeachers: Teacher[] = [
      {
        id: "teacher_1",
        name: "Ana María Rodríguez",
        cedula: "001-1234567-8",
        email: "ana.rodriguez@escuela.edu.do",
        phone: "(809) 555-0101",
        specialization: ["Matemáticas", "Física"],
        turn: "Mañana",
        assignedCourses: 2,
        maxCourses: 3,
        status: "active",
        subjects: ["Matemáticas", "Álgebra", "Geometría", "Física"],
      },
      {
        id: "teacher_2",
        name: "Carlos Eduardo Mendoza",
        cedula: "001-2345678-9",
        email: "carlos.mendoza@escuela.edu.do",
        phone: "(809) 555-0102",
        specialization: ["Lengua Española", "Literatura"],
        turn: "Tarde",
        assignedCourses: 1,
        maxCourses: 3,
        status: "active",
        subjects: ["Lengua Española", "Literatura", "Redacción", "Gramática"],
      },
      {
        id: "teacher_3",
        name: "María Elena González",
        cedula: "001-3456789-0",
        email: "maria.gonzalez@escuela.edu.do",
        phone: "(809) 555-0103",
        specialization: ["Ciencias Naturales", "Biología"],
        turn: "Mañana",
        assignedCourses: 3,
        maxCourses: 3,
        status: "active",
        subjects: ["Ciencias Naturales", "Biología", "Química", "Física"],
      },
      {
        id: "teacher_4",
        name: "Luis Alberto Pérez",
        cedula: "001-4567890-1",
        email: "luis.perez@escuela.edu.do",
        phone: "(809) 555-0104",
        specialization: ["Ciencias Sociales", "Historia"],
        turn: "Mañana",
        assignedCourses: 1,
        maxCourses: 3,
        status: "active",
        subjects: ["Ciencias Sociales", "Historia", "Geografía", "Cívica"],
      },
      {
        id: "teacher_5",
        name: "Elena Victoria Vásquez",
        cedula: "001-5678901-2",
        email: "elena.vasquez@escuela.edu.do",
        phone: "(809) 555-0105",
        specialization: ["Inglés", "Idiomas"],
        turn: "Mañana",
        assignedCourses: 2,
        maxCourses: 4,
        status: "active",
        subjects: ["Inglés", "Francés", "Conversación"],
      },
      {
        id: "teacher_6",
        name: "Pedro Antonio Sánchez",
        cedula: "001-6789012-3",
        email: "pedro.sanchez@escuela.edu.do",
        phone: "(809) 555-0106",
        specialization: ["Educación Física", "Deportes"],
        turn: "Extendida",
        assignedCourses: 0,
        maxCourses: 5,
        status: "active",
        subjects: ["Educación Física", "Deportes", "Recreación"],
      },
    ]

    setAvailableTeachers(mockTeachers)
  }, [])

  // Sugerir profesor automáticamente
  useEffect(() => {
    if (selectedSubjects.length > 0 && availableTeachers.length > 0) {
      const suggestion = findBestTeacher()
      setSuggestedTeacher(suggestion)
    }
  }, [selectedSubjects, availableTeachers])

  const findBestTeacher = (): Teacher | null => {
    const subjectNames = selectedSubjects.map((s) => s.name)
    const subjectAreas = [...new Set(selectedSubjects.map((s) => s.area))]

    // Filtrar profesores por turno
    const suitableTeachers = availableTeachers.filter((teacher) => {
      // Verificar turno compatible
      const turnCompatible = teacher.turn === course.turn || teacher.turn === "Extendida"

      // Verificar disponibilidad (no exceder máximo de cursos)
      const hasCapacity = teacher.assignedCourses < teacher.maxCourses

      // Verificar si puede enseñar al menos una materia
      const canTeachSubjects = teacher.subjects.some((subject) => subjectNames.includes(subject))

      return turnCompatible && hasCapacity && canTeachSubjects
    })

    if (suitableTeachers.length === 0) return null

    // Calcular puntuación para cada profesor
    const scoredTeachers = suitableTeachers.map((teacher) => {
      let score = 0

      // Puntos por materias que puede enseñar
      const matchingSubjects = teacher.subjects.filter((subject) => subjectNames.includes(subject))
      score += matchingSubjects.length * 10

      // Puntos por especialización
      const matchingSpecializations = teacher.specialization.filter((spec) =>
        subjectAreas.some((area) => area.includes(spec) || spec.includes(area)),
      )
      score += matchingSpecializations.length * 15

      // Penalización por alta carga de trabajo
      const workloadPenalty = (teacher.assignedCourses / teacher.maxCourses) * 5
      score -= workloadPenalty

      // Bonus por turno exacto
      if (teacher.turn === course.turn) score += 5

      return { teacher, score }
    })

    // Ordenar por puntuación y devolver el mejor
    scoredTeachers.sort((a, b) => b.score - a.score)
    return scoredTeachers[0]?.teacher || null
  }

  const addSubject = (subject: Subject) => {
    if (selectedSubjects.find((s) => s.id === subject.id)) return

    setSelectedSubjects([...selectedSubjects, { ...subject }])
    setValidationErrors([])
  }

  const removeSubject = (subjectId: string) => {
    setSelectedSubjects(selectedSubjects.filter((s) => s.id !== subjectId))
  }

  const updateSubjectHours = (subjectId: string, hours: number) => {
    setSelectedSubjects(
      selectedSubjects.map((s) => (s.id === subjectId ? { ...s, weeklyHours: Math.max(1, Math.min(10, hours)) } : s)),
    )
  }

  const validateConfiguration = (): boolean => {
    const errors: string[] = []

    // Validar materias mínimas
    if (selectedSubjects.length === 0) {
      errors.push("Debe seleccionar al menos una materia")
    }

    // Validar materias obligatorias MINERD
    const requiredSubjects = availableSubjects.filter((s) => s.minerdRequired && s.isCore)
    const selectedRequiredSubjects = selectedSubjects.filter((s) => s.minerdRequired && s.isCore)

    if (selectedRequiredSubjects.length < requiredSubjects.length) {
      const missing = requiredSubjects
        .filter((req) => !selectedSubjects.find((sel) => sel.id === req.id))
        .map((s) => s.name)
      errors.push(`Faltan materias obligatorias MINERD: ${missing.join(", ")}`)
    }

    // Validar carga horaria total
    const totalHours = selectedSubjects.reduce((sum, s) => sum + s.weeklyHours, 0)
    const maxHours = course.turn === "Extendida" ? 45 : 30

    if (totalHours > maxHours) {
      errors.push(`La carga horaria total (${totalHours}h) excede el máximo permitido (${maxHours}h)`)
    }

    if (totalHours < 20) {
      errors.push(`La carga horaria total (${totalHours}h) es insuficiente (mínimo 20h)`)
    }

    // Validar profesor seleccionado
    if (!selectedTeacher) {
      errors.push("Debe seleccionar un profesor encargado")
    } else {
      // Validar turno del profesor
      if (selectedTeacher.turn !== course.turn && selectedTeacher.turn !== "Extendida") {
        errors.push(
          `El profesor seleccionado trabaja en turno ${selectedTeacher.turn}, pero el curso es de turno ${course.turn}`,
        )
      }

      // Validar capacidad del profesor
      if (selectedTeacher.assignedCourses >= selectedTeacher.maxCourses) {
        errors.push(
          `El profesor ya tiene la carga máxima de cursos (${selectedTeacher.assignedCourses}/${selectedTeacher.maxCourses})`,
        )
      }
    }

    setValidationErrors(errors)
    return errors.length === 0
  }

  const handleSaveConfiguration = async () => {
    if (!validateConfiguration()) return

    setIsLoading(true)

    try {
      // Simular guardado
      await new Promise((resolve) => setTimeout(resolve, 1500))

      // Llamar callback con la configuración completa
      onConfigurationComplete(course.id, {
        subjects: selectedSubjects,
        teacher: selectedTeacher!,
      })
    } catch (error) {
      console.error("Error guardando configuración:", error)
      setValidationErrors(["Error al guardar la configuración. Intente nuevamente."])
    } finally {
      setIsLoading(false)
    }
  }

  const handleDownloadSummary = () => {
    const summary = {
      curso: course.name,
      nivel: course.level,
      turno: course.turn,
      profesor_encargado: selectedTeacher?.name || "No asignado",
      materias: selectedSubjects.map((s) => ({
        nombre: s.name,
        codigo: s.code,
        area: s.area,
        horas_semanales: s.weeklyHours,
        obligatoria: s.minerdRequired,
      })),
      carga_horaria_total: selectedSubjects.reduce((sum, s) => sum + s.weeklyHours, 0),
      fecha_configuracion: new Date().toLocaleDateString(),
    }

    const blob = new Blob([JSON.stringify(summary, null, 2)], { type: "application/json" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `configuracion_${course.name.replace(/\s+/g, "_")}.json`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  const getTeacherStatusBadge = (teacher: Teacher) => {
    const workloadPercentage = (teacher.assignedCourses / teacher.maxCourses) * 100

    if (workloadPercentage >= 100) {
      return <Badge className="bg-red-100 text-red-800">🔴 Carga Completa</Badge>
    } else if (workloadPercentage >= 75) {
      return <Badge className="bg-yellow-100 text-yellow-800">🟡 Alta Carga</Badge>
    } else {
      return <Badge className="bg-green-100 text-green-800">🟢 Disponible</Badge>
    }
  }

  const getTurnCompatibilityBadge = (teacher: Teacher) => {
    if (teacher.turn === course.turn) {
      return <Badge className="bg-green-100 text-green-800">✅ Turno Compatible</Badge>
    } else if (teacher.turn === "Extendida") {
      return <Badge className="bg-blue-100 text-blue-800">🔄 Turno Flexible</Badge>
    } else {
      return <Badge className="bg-orange-100 text-orange-800">⚠️ Turno Diferente</Badge>
    }
  }

  const totalHours = selectedSubjects.reduce((sum, s) => sum + s.weeklyHours, 0)
  const maxHours = course.turn === "Extendida" ? 45 : 30
  const progressPercentage = Math.min((totalHours / maxHours) * 100, 100)

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="outline" onClick={onCancel}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Volver
          </Button>
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Configurar Curso: {course.name}</h1>
            <p className="text-muted-foreground">
              {course.level} • {course.turn} • Capacidad: {course.capacity} estudiantes
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={handleDownloadSummary} disabled={selectedSubjects.length === 0}>
            <Download className="h-4 w-4 mr-2" />
            Descargar Resumen
          </Button>
          <Button onClick={handleSaveConfiguration} disabled={isLoading} className="bg-green-600 hover:bg-green-700">
            {isLoading ? <RefreshCw className="h-4 w-4 mr-2 animate-spin" /> : <Save className="h-4 w-4 mr-2" />}
            Guardar Configuración
          </Button>
        </div>
      </div>

      {/* Progreso */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5" />
            Progreso de Configuración
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span>Materias Seleccionadas</span>
                <span className="font-medium">{selectedSubjects.length}</span>
              </div>
              <Progress value={selectedSubjects.length > 0 ? 100 : 0} />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span>Carga Horaria</span>
                <span className="font-medium">
                  {totalHours}/{maxHours}h
                </span>
              </div>
              <Progress value={progressPercentage} />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span>Profesor Encargado</span>
                <span className="font-medium">{selectedTeacher ? "✅" : "❌"}</span>
              </div>
              <Progress value={selectedTeacher ? 100 : 0} />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Errores de validación */}
      {validationErrors.length > 0 && (
        <Alert className="border-red-200 bg-red-50">
          <AlertTriangle className="h-4 w-4 text-red-600" />
          <AlertDescription>
            <div className="space-y-1">
              {validationErrors.map((error, index) => (
                <div key={index} className="text-red-700">
                  • {error}
                </div>
              ))}
            </div>
          </AlertDescription>
        </Alert>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Sección A: Configurar Materias */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BookOpen className="h-5 w-5" />📚 Sección A: Configurar Materias
              </CardTitle>
              <CardDescription>Selecciona las materias según el currículo MINERD para {course.level}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Materias disponibles */}
              <div>
                <h4 className="font-medium mb-3">Catálogo de Materias MINERD</h4>
                <div className="grid gap-2 max-h-60 overflow-y-auto">
                  {availableSubjects.map((subject) => (
                    <div
                      key={subject.id}
                      className={`flex items-center justify-between p-3 border rounded-lg ${
                        selectedSubjects.find((s) => s.id === subject.id)
                          ? "border-green-200 bg-green-50"
                          : "border-gray-200 hover:border-blue-300"
                      }`}
                    >
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{subject.name}</span>
                          {subject.minerdRequired && (
                            <Badge className="bg-blue-100 text-blue-800 text-xs">MINERD</Badge>
                          )}
                          {subject.isCore && (
                            <Badge className="bg-purple-100 text-purple-800 text-xs">Obligatoria</Badge>
                          )}
                        </div>
                        <div className="text-sm text-gray-600">
                          {subject.area} • {subject.weeklyHours}h semanales
                        </div>
                      </div>
                      <Button
                        size="sm"
                        onClick={() => addSubject(subject)}
                        disabled={!!selectedSubjects.find((s) => s.id === subject.id)}
                        className="bg-blue-600 hover:bg-blue-700"
                      >
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Materias seleccionadas */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Materias del Curso ({selectedSubjects.length})</span>
                <span className="text-sm font-normal">
                  Total: {totalHours}h / {maxHours}h
                </span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {selectedSubjects.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <BookOpen className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                  <p>No hay materias seleccionadas</p>
                  <p className="text-sm">Selecciona materias del catálogo MINERD</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {selectedSubjects.map((subject) => (
                    <div key={subject.id} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{subject.name}</span>
                          <Badge className="bg-gray-100 text-gray-800 text-xs">{subject.code}</Badge>
                          {subject.minerdRequired && (
                            <Badge className="bg-blue-100 text-blue-800 text-xs">MINERD</Badge>
                          )}
                        </div>
                        <div className="text-sm text-gray-600">{subject.area}</div>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="flex items-center gap-1">
                          <Input
                            type="number"
                            min="1"
                            max="10"
                            value={subject.weeklyHours}
                            onChange={(e) => updateSubjectHours(subject.id, Number.parseInt(e.target.value) || 1)}
                            className="w-16 text-center"
                          />
                          <span className="text-sm text-gray-600">h</span>
                        </div>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => removeSubject(subject.id)}
                          className="text-red-600 hover:text-red-700"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Sección B: Asignar Profesor Encargado */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="h-5 w-5" />
                👨‍🏫 Sección B: Asignar Profesor Encargado
              </CardTitle>
              <CardDescription>Selecciona el docente que será responsable de este curso</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Sugerencia automática */}
              {suggestedTeacher && !selectedTeacher && (
                <Alert className="border-blue-200 bg-blue-50">
                  <CheckCircle className="h-4 w-4 text-blue-600" />
                  <AlertDescription>
                    <div className="space-y-2">
                      <div className="font-medium text-blue-800">🤖 Sugerencia Automática</div>
                      <div className="text-blue-700">
                        Recomendamos a <strong>{suggestedTeacher.name}</strong> basado en:
                        <ul className="list-disc list-inside mt-1 text-sm">
                          <li>Especialización compatible</li>
                          <li>Turno adecuado ({suggestedTeacher.turn})</li>
                          <li>Carga de trabajo disponible</li>
                        </ul>
                      </div>
                      <Button
                        size="sm"
                        onClick={() => setSelectedTeacher(suggestedTeacher)}
                        className="bg-blue-600 hover:bg-blue-700"
                      >
                        ✅ Aceptar Sugerencia
                      </Button>
                    </div>
                  </AlertDescription>
                </Alert>
              )}

              {/* Selector de profesor */}
              <div>
                <label className="text-sm font-medium mb-2 block">Profesor Encargado</label>
                <Select
                  value={selectedTeacher?.id || ""}
                  onValueChange={(value) => {
                    const teacher = availableTeachers.find((t) => t.id === value)
                    setSelectedTeacher(teacher || null)
                  }}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Seleccionar profesor..." />
                  </SelectTrigger>
                  <SelectContent>
                    {availableTeachers
                      .filter((teacher) => teacher.status === "active")
                      .map((teacher) => (
                        <SelectItem key={teacher.id} value={teacher.id}>
                          <div className="flex items-center justify-between w-full">
                            <div>
                              <div className="font-medium">{teacher.name}</div>
                              <div className="text-xs text-gray-600">
                                {teacher.specialization.join(", ")} • {teacher.turn}
                              </div>
                            </div>
                            <div className="text-xs">
                              {teacher.assignedCourses}/{teacher.maxCourses} cursos
                            </div>
                          </div>
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Información del profesor seleccionado */}
              {selectedTeacher && (
                <Card className="border-green-200 bg-green-50">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg flex items-center justify-between">
                      <span>{selectedTeacher.name}</span>
                      <Button size="sm" variant="outline" onClick={() => setShowTeacherDetails(!showTeacherDetails)}>
                        {showTeacherDetails ? "Ocultar" : "Ver Detalles"}
                      </Button>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex flex-wrap gap-2">
                      {getTeacherStatusBadge(selectedTeacher)}
                      {getTurnCompatibilityBadge(selectedTeacher)}
                    </div>

                    {showTeacherDetails && (
                      <div className="space-y-3 pt-3 border-t border-green-200">
                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div>
                            <span className="font-medium">Cédula:</span>
                            <p>{selectedTeacher.cedula}</p>
                          </div>
                          <div>
                            <span className="font-medium">Email:</span>
                            <p>{selectedTeacher.email}</p>
                          </div>
                          <div>
                            <span className="font-medium">Teléfono:</span>
                            <p>{selectedTeacher.phone}</p>
                          </div>
                          <div>
                            <span className="font-medium">Turno:</span>
                            <p>{selectedTeacher.turn}</p>
                          </div>
                        </div>

                        <div>
                          <span className="font-medium text-sm">Especialización:</span>
                          <div className="flex flex-wrap gap-1 mt-1">
                            {selectedTeacher.specialization.map((spec, index) => (
                              <Badge key={index} className="bg-purple-100 text-purple-800 text-xs">
                                {spec}
                              </Badge>
                            ))}
                          </div>
                        </div>

                        <div>
                          <span className="font-medium text-sm">Materias que imparte:</span>
                          <div className="flex flex-wrap gap-1 mt-1">
                            {selectedTeacher.subjects.map((subject, index) => (
                              <Badge key={index} className="bg-blue-100 text-blue-800 text-xs">
                                {subject}
                              </Badge>
                            ))}
                          </div>
                        </div>

                        <div>
                          <span className="font-medium text-sm">Carga de trabajo:</span>
                          <div className="flex items-center gap-2 mt-1">
                            <Progress
                              value={(selectedTeacher.assignedCourses / selectedTeacher.maxCourses) * 100}
                              className="flex-1"
                            />
                            <span className="text-sm">
                              {selectedTeacher.assignedCourses}/{selectedTeacher.maxCourses}
                            </span>
                          </div>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              )}
            </CardContent>
          </Card>

          {/* Notas adicionales */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Notas Administrativas</CardTitle>
            </CardHeader>
            <CardContent>
              <Textarea
                placeholder="Agregar notas sobre la configuración del curso..."
                value={courseNotes}
                onChange={(e) => setCourseNotes(e.target.value)}
                rows={4}
              />
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Resumen final */}
      <Card className="border-blue-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CheckCircle className="h-5 w-5 text-blue-600" />
            Resumen de Configuración
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <h4 className="font-medium mb-2">Información del Curso</h4>
              <div className="space-y-1 text-sm">
                <p>
                  <strong>Curso:</strong> {course.name}
                </p>
                <p>
                  <strong>Nivel:</strong> {course.level}
                </p>
                <p>
                  <strong>Turno:</strong> {course.turn}
                </p>
                <p>
                  <strong>Capacidad:</strong> {course.capacity} estudiantes
                </p>
              </div>
            </div>
            <div>
              <h4 className="font-medium mb-2">Configuración Académica</h4>
              <div className="space-y-1 text-sm">
                <p>
                  <strong>Materias:</strong> {selectedSubjects.length}
                </p>
                <p>
                  <strong>Carga horaria:</strong> {totalHours}h semanales
                </p>
                <p>
                  <strong>Materias MINERD:</strong> {selectedSubjects.filter((s) => s.minerdRequired).length}/
                  {availableSubjects.filter((s) => s.minerdRequired).length}
                </p>
                <p>
                  <strong>Estado:</strong>{" "}
                  {validateConfiguration() ? (
                    <span className="text-green-600">✅ Válida</span>
                  ) : (
                    <span className="text-red-600">❌ Requiere ajustes</span>
                  )}
                </p>
              </div>
            </div>
            <div>
              <h4 className="font-medium mb-2">Profesor Encargado</h4>
              <div className="space-y-1 text-sm">
                <p>
                  <strong>Nombre:</strong> {selectedTeacher?.name || "No asignado"}
                </p>
                {selectedTeacher && (
                  <>
                    <p>
                      <strong>Especialización:</strong> {selectedTeacher.specialization.join(", ")}
                    </p>
                    <p>
                      <strong>Turno:</strong> {selectedTeacher.turn}
                    </p>
                    <p>
                      <strong>Carga:</strong> {selectedTeacher.assignedCourses + 1}/{selectedTeacher.maxCourses} cursos
                    </p>
                  </>
                )}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
