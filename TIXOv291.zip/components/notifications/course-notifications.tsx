"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Bell, X, Eye, CheckCircle, AlertTriangle, Clock, MessageSquare } from "lucide-react"
import type { CourseNotification } from "@/lib/course-interoperability"

interface CourseNotificationsProps {
  userRole: "director" | "coordinador-academico" | "coordinador"
}

export function CourseNotifications({ userRole }: CourseNotificationsProps) {
  const [notifications, setNotifications] = useState<CourseNotification[]>([])
  const [isOpen, setIsOpen] = useState(false)

  // Simular notificaciones por rol
  useEffect(() => {
    const mockNotifications: CourseNotification[] = []

    if (userRole === "coordinador-academico") {
      mockNotifications.push(
        {
          id: "notif_1",
          type: "course_created",
          courseId: "course_new_1",
          courseName: "6to B",
          targetRole: "coordinador-academico",
          message: "Se ha creado el curso 6to B. Debes configurar materias y docentes.",
          isRead: false,
          createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(), // 2 horas atrás
          priority: "high",
        },
        {
          id: "notif_2",
          type: "course_created",
          courseId: "course_new_2",
          courseName: "5to C",
          targetRole: "coordinador-academico",
          message: "Se ha creado el curso 5to C. Debes configurar materias y docentes.",
          isRead: false,
          createdAt: new Date(Date.now() - 4 * 60 * 60 * 1000).toISOString(), // 4 horas atrás
          priority: "high",
        },
        {
          id: "notif_3",
          type: "configuration_pending",
          courseId: "course_partial_1",
          courseName: "4to A",
          targetRole: "coordinador-academico",
          message: "El curso 4to A requiere completar la configuración de horarios.",
          isRead: true,
          createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(), // 1 día atrás
          priority: "medium",
        },
      )
    } else if (userRole === "coordinador") {
      mockNotifications.push(
        {
          id: "notif_4",
          type: "course_created",
          courseId: "course_new_1",
          courseName: "6to B",
          targetRole: "coordinador",
          message: "El curso 6to B ha sido creado. Puedes proceder a asignar estudiantes reinscritos.",
          isRead: false,
          createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
          priority: "medium",
        },
        {
          id: "notif_5",
          type: "course_updated",
          courseId: "course_partial_1",
          courseName: "4to A",
          targetRole: "coordinador",
          message: "El curso 4to A ha sido actualizado con nuevas materias. Ya puedes asignar estudiantes.",
          isRead: false,
          createdAt: new Date(Date.now() - 6 * 60 * 60 * 1000).toISOString(),
          priority: "low",
        },
      )
    } else if (userRole === "director") {
      mockNotifications.push(
        {
          id: "notif_6",
          type: "course_updated",
          courseId: "course_complete_1",
          courseName: "3ro A",
          targetRole: "director",
          message: "El curso 3ro A ha sido completamente configurado y está listo.",
          isRead: false,
          createdAt: new Date(Date.now() - 1 * 60 * 60 * 1000).toISOString(),
          priority: "low",
        },
        {
          id: "notif_7",
          type: "capacity_full",
          courseId: "course_full_1",
          courseName: "2do A",
          targetRole: "director",
          message: "El curso 2do A ha alcanzado su capacidad máxima (30 estudiantes).",
          isRead: true,
          createdAt: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString(),
          priority: "medium",
        },
      )
    }

    setNotifications(mockNotifications)
  }, [userRole])

  const unreadCount = notifications.filter((n) => !n.isRead).length

  const handleMarkAsRead = (notificationId: string) => {
    setNotifications((prev) => prev.map((n) => (n.id === notificationId ? { ...n, isRead: true } : n)))
  }

  const handleRemoveNotification = (notificationId: string) => {
    setNotifications((prev) => prev.filter((n) => n.id !== notificationId))
  }

  const handleViewCourse = (courseId: string) => {
    // Redirigir al curso específico según el rol
    const baseUrl = `/dashboard/${userRole}`
    if (userRole === "coordinador-academico") {
      window.location.href = `${baseUrl}/curriculum`
    } else if (userRole === "coordinador") {
      window.location.href = `${baseUrl}/students`
    } else {
      window.location.href = `${baseUrl}/academic/courses/${courseId}`
    }
    setIsOpen(false)
  }

  const getNotificationIcon = (type: string, priority: string) => {
    switch (type) {
      case "course_created":
        return <AlertTriangle className="h-4 w-4 text-blue-600" />
      case "course_updated":
        return <CheckCircle className="h-4 w-4 text-green-600" />
      case "configuration_pending":
        return <Clock className="h-4 w-4 text-yellow-600" />
      case "capacity_full":
        return <AlertTriangle className="h-4 w-4 text-red-600" />
      default:
        return <MessageSquare className="h-4 w-4 text-gray-600" />
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "bg-red-100 text-red-800 border-red-200"
      case "medium":
        return "bg-yellow-100 text-yellow-800 border-yellow-200"
      case "low":
        return "bg-green-100 text-green-800 border-green-200"
      default:
        return "bg-gray-100 text-gray-800 border-gray-200"
    }
  }

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString)
    const now = new Date()
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60))

    if (diffInHours < 1) return "Hace menos de 1 hora"
    if (diffInHours < 24) return `Hace ${diffInHours} hora${diffInHours > 1 ? "s" : ""}`
    const diffInDays = Math.floor(diffInHours / 24)
    return `Hace ${diffInDays} día${diffInDays > 1 ? "s" : ""}`
  }

  return (
    <DropdownMenu open={isOpen} onOpenChange={setIsOpen}>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="sm" className="relative bg-transparent">
          <Bell className="h-4 w-4" />
          {unreadCount > 0 && (
            <Badge className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0 flex items-center justify-center bg-red-600 text-white text-xs">
              {unreadCount > 9 ? "9+" : unreadCount}
            </Badge>
          )}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-80 max-h-96 overflow-y-auto">
        <DropdownMenuLabel className="flex items-center justify-between">
          <span>Notificaciones</span>
          {unreadCount > 0 && (
            <Badge variant="secondary" className="text-xs">
              {unreadCount} nueva{unreadCount > 1 ? "s" : ""}
            </Badge>
          )}
        </DropdownMenuLabel>
        <DropdownMenuSeparator />

        {notifications.length === 0 ? (
          <div className="p-4 text-center text-gray-500">
            <Bell className="h-8 w-8 mx-auto mb-2 text-gray-300" />
            <p className="text-sm">No hay notificaciones</p>
          </div>
        ) : (
          notifications.map((notification) => (
            <DropdownMenuItem
              key={notification.id}
              className={`p-3 cursor-pointer ${!notification.isRead ? "bg-blue-50" : ""}`}
              onSelect={(e) => e.preventDefault()}
            >
              <div className="flex items-start space-x-3 w-full">
                <div className="flex-shrink-0 mt-1">
                  {getNotificationIcon(notification.type, notification.priority)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <p className="text-sm font-medium text-gray-900 truncate">{notification.courseName}</p>
                    <Badge className={`text-xs ${getPriorityColor(notification.priority)}`}>
                      {notification.priority === "high"
                        ? "Alta"
                        : notification.priority === "medium"
                          ? "Media"
                          : "Baja"}
                    </Badge>
                  </div>
                  <p className="text-xs text-gray-600 mb-2 line-clamp-2">{notification.message}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-gray-500">{formatTimeAgo(notification.createdAt)}</span>
                    <div className="flex items-center space-x-1">
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-6 w-6 p-0"
                        onClick={() => handleViewCourse(notification.courseId)}
                        title="Ver curso"
                      >
                        <Eye className="h-3 w-3" />
                      </Button>
                      {!notification.isRead && (
                        <Button
                          size="sm"
                          variant="ghost"
                          className="h-6 w-6 p-0"
                          onClick={() => handleMarkAsRead(notification.id)}
                          title="Marcar como leído"
                        >
                          <CheckCircle className="h-3 w-3" />
                        </Button>
                      )}
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-6 w-6 p-0"
                        onClick={() => handleRemoveNotification(notification.id)}
                        title="Eliminar"
                      >
                        <X className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </DropdownMenuItem>
          ))
        )}

        {notifications.length > 0 && (
          <>
            <DropdownMenuSeparator />
            <DropdownMenuItem className="text-center text-sm text-gray-500 cursor-pointer">
              Ver todas las notificaciones
            </DropdownMenuItem>
          </>
        )}
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
