/**
 * EduGestión360 v63 - Script principal
 * Sistema completo de gestión educativa
 * Autor: EduGestión360 Team
 * Versión: 63.0.0
 * Fecha: 2024
 */

// ======================================
// VARIABLES GLOBALES
// ======================================
let currentUser = null
let currentPage = "landing"
const sidebarCollapsed = false

// ======================================
// INICIALIZACIÓN
// ======================================

/**
 * Esperar a que el DOM esté completamente cargado
 */
document.addEventListener("DOMContentLoaded", () => {
  console.log("🎓 Inicializando EduGestión360 v63...")
  initApp()
})

/**
 * Inicializa la aplicación
 */
function initApp() {
  try {
    // Verificar si hay una sesión activa
    const isLoggedIn = checkSession()

    // Mostrar la página correspondiente según el estado de la sesión
    if (isLoggedIn) {
      console.log("✅ Sesión activa encontrada, cargando dashboard...")
      showDashboard()
    } else {
      console.log("ℹ️ No hay sesión activa, mostrando página de inicio...")
      showLanding()
    }

    // Inicializar los eventos globales
    initGlobalEvents()

    // Ocultar el overlay de carga después de la inicialización
    setTimeout(hideLoading, 1000)

    console.log("✅ EduGestión360 v63 inicializado correctamente")
  } catch (error) {
    console.error("❌ Error al inicializar la aplicación:", error)
    showNotification("Error al inicializar la aplicación", "error")
  }
}

/**
 * Verifica si hay una sesión activa
 * @returns {boolean} - Verdadero si hay una sesión activa, falso en caso contrario
 */
function checkSession() {
  try {
    // Verificar si hay un token de sesión en localStorage
    const token = localStorage.getItem("eduGestion360_token")
    const userData = localStorage.getItem("eduGestion360_userData")

    // Si hay token y datos de usuario, considerar que hay una sesión activa
    if (token && userData) {
      currentUser = JSON.parse(userData)
      return true
    }

    return false
  } catch (error) {
    console.error("❌ Error al verificar la sesión:", error)
    return false
  }
}

/**
 * Inicializa los eventos globales de la aplicación
 */
function initGlobalEvents() {
  console.log("🔧 Inicializando eventos globales...")

  // Manejar clics en enlaces con hash para navegación suave
  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener("click", function (e) {
      const targetId = this.getAttribute("href")

      // Si es un enlace de navegación interna, hacer scroll suave
      if (targetId !== "#" && document.querySelector(targetId)) {
        e.preventDefault()
        document.querySelector(targetId).scrollIntoView({
          behavior: "smooth",
          block: "start",
        })
      }
    })
  })

  // Inicializar tooltips
  initTooltips()

  // Inicializar dropdowns
  initDropdowns()

  // Detectar cambios de tamaño de ventana para ajustes responsivos
  window.addEventListener("resize", handleWindowResize)

  // Manejar teclas de acceso rápido
  document.addEventListener("keydown", handleKeyboardShortcuts)

  // Llamar a la función de redimensionamiento una vez para configuración inicial
  handleWindowResize()

  console.log("✅ Eventos globales inicializados")
}

/**
 * Maneja los atajos de teclado
 * @param {KeyboardEvent} event - Evento de teclado
 */
function handleKeyboardShortcuts(event) {
  // Ctrl/Cmd + K para abrir búsqueda
  if ((event.ctrlKey || event.metaKey) && event.key === "k") {
    event.preventDefault()
    const searchInput = document.querySelector(".search-box input")
    if (searchInput) {
      searchInput.focus()
    }
  }

  // Escape para cerrar modales y dropdowns
  if (event.key === "Escape") {
    // Cerrar modales
    const modals = document.querySelectorAll(".modal-backdrop")
    modals.forEach((modal) => closeModal(modal))

    // Cerrar dropdowns
    document.querySelectorAll(".dropdown-menu.active, .user-menu-dropdown.active").forEach((dropdown) => {
      dropdown.classList.remove("active")
    })
  }
}

/**
 * Maneja los cambios de tamaño de la ventana
 */
function handleWindowResize() {
  // Ajustar elementos responsivos según el tamaño de la ventana
  const isMobile = window.innerWidth < 768

  // Ajustar el sidebar en modo móvil
  if (isMobile) {
    const sidebar = document.querySelector(".sidebar")
    if (sidebar && sidebar.classList.contains("active")) {
      sidebar.classList.remove("active")
      document.body.style.overflow = ""
    }
  }

  // Actualizar variables CSS personalizadas para dimensiones responsivas
  document.documentElement.style.setProperty("--viewport-height", `${window.innerHeight}px`)
  document.documentElement.style.setProperty("--viewport-width", `${window.innerWidth}px`)
}

/**
 * Inicializa los tooltips
 */
function initTooltips() {
  document.querySelectorAll("[data-tooltip]").forEach((element) => {
    const tooltipText = element.getAttribute("data-tooltip")
    if (tooltipText) {
      element.addEventListener("mouseenter", function () {
        showTooltip(this, tooltipText)
      })

      element.addEventListener("mouseleave", () => {
        hideTooltip()
      })
    }
  })
}

/**
 * Muestra un tooltip
 * @param {HTMLElement} element - Elemento que activa el tooltip
 * @param {string} text - Texto del tooltip
 */
function showTooltip(element, text) {
  // Implementación básica de tooltip
  const tooltip = document.createElement("div")
  tooltip.className = "tooltip-popup"
  tooltip.textContent = text
  tooltip.style.cssText = `
    position: absolute;
    background: var(--gray-900);
    color: white;
    padding: 0.5rem;
    border-radius: 0.375rem;
    font-size: 0.875rem;
    z-index: 9999;
    pointer-events: none;
  `

  document.body.appendChild(tooltip)

  const rect = element.getBoundingClientRect()
  tooltip.style.top = `${rect.top - tooltip.offsetHeight - 8}px`
  tooltip.style.left = `${rect.left + (rect.width - tooltip.offsetWidth) / 2}px`
}

/**
 * Oculta el tooltip activo
 */
function hideTooltip() {
  const tooltip = document.querySelector(".tooltip-popup")
  if (tooltip) {
    tooltip.remove()
  }
}

/**
 * Inicializa los dropdowns
 */
function initDropdowns() {
  document.querySelectorAll(".dropdown-toggle").forEach((toggle) => {
    toggle.addEventListener("click", function (e) {
      e.stopPropagation()

      // Cerrar todos los otros dropdowns
      document.querySelectorAll(".dropdown-menu.active").forEach((menu) => {
        if (!menu.parentElement.contains(toggle)) {
          menu.classList.remove("active")
        }
      })

      // Alternar el dropdown actual
      const dropdownMenu = this.nextElementSibling
      if (dropdownMenu && dropdownMenu.classList.contains("dropdown-menu")) {
        dropdownMenu.classList.toggle("active")
      }
    })
  })

  // Cerrar dropdowns al hacer clic fuera de ellos
  document.addEventListener("click", () => {
    document.querySelectorAll(".dropdown-menu.active").forEach((menu) => {
      menu.classList.remove("active")
    })
  })
}

// ======================================
// GESTIÓN DE PÁGINAS
// ======================================

/**
 * Muestra la página de inicio (landing)
 */
function showLanding() {
  console.log("📄 Mostrando página de inicio...")

  try {
    // Ocultar todas las páginas
    hideAllPages()

    // Mostrar la página de inicio
    const landingPage = document.getElementById("landing-page")
    if (landingPage) {
      landingPage.classList.add("active")
      currentPage = "landing"
    }

    // Actualizar el título de la página
    document.title = "EduGestión360 v63 - Sistema de Gestión Educativa"

    console.log("✅ Página de inicio mostrada")
  } catch (error) {
    console.error("❌ Error al mostrar la página de inicio:", error)
  }
}

/**
 * Muestra la página de inicio de sesión
 */
function showLogin() {
  console.log("🔐 Mostrando página de inicio de sesión...")

  try {
    // Ocultar todas las páginas
    hideAllPages()

    // Mostrar la página de inicio de sesión
    const loginPage = document.getElementById("login-page")
    if (loginPage) {
      loginPage.classList.add("active")
      currentPage = "login"
    }

    // Actualizar el título de la página
    document.title = "Iniciar Sesión - EduGestión360 v63"

    // Enfocar el campo de email después de un breve delay
    setTimeout(() => {
      const emailInput = document.getElementById("email")
      if (emailInput) {
        emailInput.focus()
      }
    }, 100)

    console.log("✅ Página de inicio de sesión mostrada")
  } catch (error) {
    console.error("❌ Error al mostrar la página de inicio de sesión:", error)
  }
}

/**
 * Muestra la página de dashboard
 */
function showDashboard() {
  console.log("📊 Mostrando dashboard...")

  try {
    // Mostrar overlay de carga
    showLoading()

    // Ocultar todas las páginas
    hideAllPages()

    // Mostrar la página de dashboard
    const dashboardPage = document.getElementById("dashboard")
    if (dashboardPage) {
      dashboardPage.classList.add("active")
      currentPage = "dashboard"
    }

    // Cargar los datos del usuario
    loadUserData()

    // Cargar la navegación del sidebar según el rol del usuario
    loadSidebarNavigation()

    // Cargar el contenido inicial del dashboard
    loadDashboardContent()

    // Actualizar el título de la página
    document.title = "Dashboard - EduGestión360 v63"

    // Ocultar overlay de carga después de cargar todo
    setTimeout(() => {
      hideLoading()
      console.log("✅ Dashboard mostrado correctamente")
    }, 800)
  } catch (error) {
    console.error("❌ Error al mostrar el dashboard:", error)
    hideLoading()
    showNotification("Error al cargar el dashboard", "error")
  }
}

/**
 * Oculta todas las páginas
 */
function hideAllPages() {
  document.querySelectorAll(".page").forEach((page) => {
    page.classList.remove("active")
  })
}

// ======================================
// AUTENTICACIÓN
// ======================================

/**
 * Maneja el envío del formulario de inicio de sesión
 * @param {Event} event - Evento de envío del formulario
 */
function handleLoginForm(event) {
  event.preventDefault()

  console.log("🔐 Procesando inicio de sesión...")

  try {
    // Mostrar overlay de carga
    showLoading()

    // Obtener los valores del formulario
    const formData = new FormData(event.target)
    const email = formData.get("email")
    const password = formData.get("password")
    const role = formData.get("role")
    const remember = formData.get("remember")

    // Validar que se hayan ingresado todos los campos
    if (!email || !password || !role) {
      hideLoading()
      showNotification("Por favor completa todos los campos requeridos", "error")
      return
    }

    // Simular una petición de inicio de sesión con delay realista
    setTimeout(() => {
      const loginResult = validateCredentials(email, password, role)

      if (loginResult.success) {
        // Guardar datos de sesión
        const token = generateSessionToken()

        localStorage.setItem("eduGestion360_token", token)
        localStorage.setItem("eduGestion360_userData", JSON.stringify(loginResult.userData))

        // Si se seleccionó "Recordarme", establecer una fecha de expiración más larga
        if (remember) {
          localStorage.setItem("eduGestion360_remember", "true")
          localStorage.setItem("eduGestion360_expires", Date.now() + 30 * 24 * 60 * 60 * 1000) // 30 días
        } else {
          localStorage.removeItem("eduGestion360_remember")
          localStorage.setItem("eduGestion360_expires", Date.now() + 24 * 60 * 60 * 1000) // 24 horas
        }

        // Actualizar usuario actual
        currentUser = loginResult.userData

        // Mostrar notificación de éxito
        showNotification(`¡Bienvenido, ${loginResult.userData.name}!`, "success")

        // Mostrar el dashboard
        showDashboard()

        console.log("✅ Inicio de sesión exitoso para:", loginResult.userData.name)
      } else {
        // Mostrar notificación de error
        showNotification(loginResult.message || "Credenciales incorrectas", "error")

        console.log("❌ Credenciales incorrectas para:", email)
      }

      // Ocultar overlay de carga
      hideLoading()
    }, 1500)
  } catch (error) {
    console.error("❌ Error durante el inicio de sesión:", error)
    hideLoading()
    showNotification("Error interno del sistema", "error")
  }
}

/**
 * Valida las credenciales de inicio de sesión
 * @param {string} email - Correo electrónico
 * @param {string} password - Contraseña
 * @param {string} role - Rol del usuario
 * @returns {Object} - Resultado de la validación
 */
function validateCredentials(email, password, role) {
  // Credenciales de demostración
  const demoCredentials = {
    "super-admin": {
      email: "admin@edugestión360.com",
      password: "admin123",
      userData: {
        id: 1,
        name: "Administrador Principal",
        email: email,
        role: role,
        avatar: null,
        permissions: ["all"],
      },
    },
    director: {
      email: "director@colegio.com",
      password: "director123",
      userData: {
        id: 2,
        name: "Director Académico",
        email: email,
        role: role,
        avatar: null,
        institution: "Colegio San José",
        permissions: ["academic", "users", "reports"],
      },
    },
    profesor: {
      email: "profesor@colegio.com",
      password: "profesor123",
      userData: {
        id: 3,
        name: "Profesor García",
        email: email,
        role: role,
        avatar: null,
        institution: "Colegio San José",
        department: "Matemáticas",
        permissions: ["courses", "grades", "communication"],
      },
    },
    padre: {
      email: "padre@familia.com",
      password: "padre123",
      userData: {
        id: 4,
        name: "Padre de Familia",
        email: email,
        role: role,
        avatar: null,
        children: ["Juan Pérez", "María Pérez"],
        permissions: ["view_grades", "communication", "payments"],
      },
    },
    contable: {
      email: "contable@colegio.com",
      password: "contable123",
      userData: {
        id: 5,
        name: "Contador Principal",
        email: email,
        role: role,
        avatar: null,
        institution: "Colegio San José",
        permissions: ["billing", "payroll", "reports"],
      },
    },
    secretario: {
      email: "secretario@colegio.com",
      password: "secretario123",
      userData: {
        id: 6,
        name: "Secretario Administrativo",
        email: email,
        role: role,
        avatar: null,
        institution: "Colegio San José",
        permissions: ["students", "documents", "calendar"],
      },
    },
  }

  const credentials = demoCredentials[role]

  if (credentials && credentials.email === email && credentials.password === password) {
    return {
      success: true,
      userData: credentials.userData,
    }
  }

  return {
    success: false,
    message: "Credenciales incorrectas. Verifica tu email, contraseña y rol.",
  }
}

/**
 * Genera un token de sesión único
 * @returns {string} - Token de sesión
 */
function generateSessionToken() {
  return "edugest360_" + Math.random().toString(36).substring(2) + Date.now().toString(36)
}

/**
 * Cierra la sesión del usuario
 */
function logout() {
  console.log("🚪 Cerrando sesión...")

  try {
    // Mostrar overlay de carga
    showLoading()

    // Simular cierre de sesión
    setTimeout(() => {
      // Eliminar datos de sesión
      localStorage.removeItem("eduGestion360_token")
      localStorage.removeItem("eduGestion360_userData")
      localStorage.removeItem("eduGestion360_remember")
      localStorage.removeItem("eduGestion360_expires")

      // Limpiar usuario actual
      currentUser = null

      // Mostrar notificación de éxito
      showNotification("Sesión cerrada correctamente", "success")

      // Mostrar la página de inicio
      showLanding()

      // Ocultar overlay de carga
      hideLoading()

      console.log("✅ Sesión cerrada correctamente")
    }, 1000)
  } catch (error) {
    console.error("❌ Error al cerrar sesión:", error)
    hideLoading()
    showNotification("Error al cerrar sesión", "error")
  }
}

// ======================================
// GESTIÓN DEL DASHBOARD
// ======================================

/**
 * Carga los datos del usuario en la interfaz
 */
function loadUserData() {
  console.log("👤 Cargando datos del usuario...")

  try {
    if (!currentUser) {
      console.warn("⚠️ No hay usuario actual para cargar datos")
      return
    }

    // Actualizar nombre de usuario en el header
    const userNameElements = document.querySelectorAll("#user-name, .user-name-dropdown")
    userNameElements.forEach((element) => {
      if (element) element.textContent = currentUser.name
    })

    // Actualizar email en el dropdown
    const userEmailElement = document.querySelector(".user-email-dropdown")
    if (userEmailElement) {
      userEmailElement.textContent = currentUser.email
    }

    // Actualizar rol en el header
    const userRoleElements = document.querySelectorAll("#user-role-header")
    userRoleElements.forEach((element) => {
      if (element) element.textContent = capitalizeFirstLetter(currentUser.role.replace("-", " "))
    })

    // Actualizar nombre y rol en el sidebar
    const sidebarUserName = document.getElementById("sidebar-user-name")
    const sidebarUserRole = document.getElementById("sidebar-user-role")

    if (sidebarUserName) sidebarUserName.textContent = currentUser.name
    if (sidebarUserRole) sidebarUserRole.textContent = capitalizeFirstLetter(currentUser.role.replace("-", " "))

    console.log("✅ Datos del usuario cargados correctamente")
  } catch (error) {
    console.error("❌ Error al cargar datos del usuario:", error)
  }
}

/**
 * Carga la navegación del sidebar según el rol del usuario
 */
function loadSidebarNavigation() {
  console.log("🧭 Cargando navegación del sidebar...")

  try {
    if (!currentUser) {
      console.warn("⚠️ No hay usuario actual para cargar navegación")
      return
    }

    const sidebarNav = document.getElementById("sidebar-nav")
    if (!sidebarNav) {
      console.warn("⚠️ No se encontró el elemento de navegación del sidebar")
      return
    }

    // Limpiar el contenido actual del sidebar
    sidebarNav.innerHTML = ""

    // Crear elementos de navegación según el rol
    const navItems = getNavigationItems(currentUser.role)

    navItems.forEach((item) => {
      const navItem = document.createElement("a")
      navItem.href = "javascript:void(0)"
      navItem.className = "nav-item"
      if (item.active) {
        navItem.classList.add("active")
      }
      navItem.innerHTML = `<i class="fas ${item.icon}"></i> ${item.text}`
      navItem.setAttribute("onclick", item.onClick)
      navItem.setAttribute("data-tooltip", item.description || item.text)
      sidebarNav.appendChild(navItem)
    })

    console.log("✅ Navegación del sidebar cargada correctamente")
  } catch (error) {
    console.error("❌ Error al cargar navegación del sidebar:", error)
  }
}

/**
 * Obtiene los elementos de navegación según el rol
 * @param {string} role - Rol del usuario
 * @returns {Array} - Array de elementos de navegación
 */
function getNavigationItems(role) {
  const navigationMap = {
    "super-admin": [
      {
        icon: "fa-tachometer-alt",
        text: "Dashboard",
        active: true,
        onClick: "loadDashboardContent()",
        description: "Panel principal de administración",
      },
      {
        icon: "fa-school",
        text: "Colegios",
        onClick: "loadSchoolsContent()",
        description: "Gestión de instituciones educativas",
      },
      {
        icon: "fa-users",
        text: "Usuarios",
        onClick: "loadUsersContent()",
        description: "Administración de usuarios del sistema",
      },
      {
        icon: "fa-credit-card",
        text: "Suscripciones",
        onClick: "loadSubscriptionsContent()",
        description: "Gestión de planes y suscripciones",
      },
      {
        icon: "fa-chart-bar",
        text: "Análisis",
        onClick: "loadAnalyticsContent()",
        description: "Análisis y métricas del sistema",
      },
      {
        icon: "fa-history",
        text: "Logs del Sistema",
        onClick: "loadLogsContent()",
        description: "Registros de actividad del sistema",
      },
      {
        icon: "fa-cog",
        text: "Configuración",
        onClick: "loadSettingsContent()",
        description: "Configuración global del sistema",
      },
      {
        icon: "fa-headset",
        text: "Soporte",
        onClick: "loadSupportContent()",
        description: "Centro de soporte técnico",
      },
    ],
    director: [
      {
        icon: "fa-tachometer-alt",
        text: "Dashboard",
        active: true,
        onClick: "loadDashboardContent()",
        description: "Panel principal del director",
      },
      {
        icon: "fa-graduation-cap",
        text: "Académico",
        onClick: "loadAcademicContent()",
        description: "Gestión académica institucional",
      },
      {
        icon: "fa-users",
        text: "Usuarios",
        onClick: "loadUsersContent()",
        description: "Gestión de profesores y personal",
      },
      {
        icon: "fa-user-graduate",
        text: "Estudiantes",
        onClick: "loadStudentsContent()",
        description: "Administración de estudiantes",
      },
      {
        icon: "fa-credit-card",
        text: "Facturación",
        onClick: "loadBillingContent()",
        description: "Gestión financiera institucional",
      },
      {
        icon: "fa-comments",
        text: "Comunicación",
        onClick: "loadCommunicationContent()",
        description: "Centro de comunicaciones",
      },
      {
        icon: "fa-calendar-alt",
        text: "Planificación",
        onClick: "loadPlanningContent()",
        description: "Planificación académica",
      },
      {
        icon: "fa-chart-bar",
        text: "Reportes",
        onClick: "loadReportsContent()",
        description: "Reportes institucionales",
      },
      {
        icon: "fa-cog",
        text: "Configuración",
        onClick: "loadSettingsContent()",
        description: "Configuración institucional",
      },
    ],
    profesor: [
      {
        icon: "fa-tachometer-alt",
        text: "Dashboard",
        active: true,
        onClick: "loadDashboardContent()",
        description: "Panel principal del profesor",
      },
      {
        icon: "fa-book",
        text: "Mis Cursos",
        onClick: "loadCoursesContent()",
        description: "Gestión de cursos asignados",
      },
      {
        icon: "fa-star",
        text: "Calificaciones",
        onClick: "loadGradesContent()",
        description: "Registro de calificaciones",
      },
      { icon: "fa-tasks", text: "Tareas", onClick: "loadTasksContent()", description: "Gestión de tareas y proyectos" },
      {
        icon: "fa-calendar-check",
        text: "Asistencia",
        onClick: "loadAttendanceContent()",
        description: "Control de asistencia",
      },
      {
        icon: "fa-comments",
        text: "Comunicación",
        onClick: "loadCommunicationContent()",
        description: "Comunicación con padres y estudiantes",
      },
      {
        icon: "fa-calendar-alt",
        text: "Planificación",
        onClick: "loadPlanningContent()",
        description: "Planificación de clases",
      },
      {
        icon: "fa-chart-line",
        text: "Progreso",
        onClick: "loadProgressContent()",
        description: "Seguimiento del progreso estudiantil",
      },
      { icon: "fa-history", text: "Historial", onClick: "loadHistoryContent()", description: "Historial académico" },
    ],
    padre: [
      {
        icon: "fa-tachometer-alt",
        text: "Dashboard",
        active: true,
        onClick: "loadDashboardContent()",
        description: "Panel principal familiar",
      },
      {
        icon: "fa-user-graduate",
        text: "Mis Hijos",
        onClick: "loadChildrenContent()",
        description: "Información de mis hijos",
      },
      {
        icon: "fa-star",
        text: "Calificaciones",
        onClick: "loadGradesContent()",
        description: "Calificaciones de mis hijos",
      },
      {
        icon: "fa-calendar-check",
        text: "Asistencia",
        onClick: "loadAttendanceContent()",
        description: "Control de asistencia",
      },
      { icon: "fa-tasks", text: "Tareas", onClick: "loadTasksContent()", description: "Tareas y proyectos pendientes" },
      {
        icon: "fa-comments",
        text: "Comunicación",
        onClick: "loadCommunicationContent()",
        description: "Comunicación con profesores",
      },
      {
        icon: "fa-money-bill-wave",
        text: "Pagos",
        onClick: "loadPaymentsContent()",
        description: "Gestión de pagos y facturas",
      },
      {
        icon: "fa-calendar-alt",
        text: "Eventos",
        onClick: "loadEventsContent()",
        description: "Calendario de eventos escolares",
      },
      {
        icon: "fa-history",
        text: "Historial",
        onClick: "loadHistoryContent()",
        description: "Historial académico familiar",
      },
    ],
    contable: [
      {
        icon: "fa-tachometer-alt",
        text: "Dashboard",
        active: true,
        onClick: "loadDashboardContent()",
        description: "Panel financiero principal",
      },
      {
        icon: "fa-file-invoice-dollar",
        text: "Facturación",
        onClick: "loadBillingContent()",
        description: "Gestión de facturación",
      },
      {
        icon: "fa-hand-holding-usd",
        text: "Cuentas por Cobrar",
        onClick: "loadReceivablesContent()",
        description: "Gestión de cobros",
      },
      {
        icon: "fa-money-bill-wave",
        text: "Gastos",
        onClick: "loadExpensesContent()",
        description: "Control de gastos institucionales",
      },
      {
        icon: "fa-users",
        text: "Nómina",
        onClick: "loadPayrollContent()",
        description: "Gestión de nómina y salarios",
      },
      {
        icon: "fa-user-graduate",
        text: "Perfil Estudiante",
        onClick: "loadStudentProfileContent()",
        description: "Perfiles financieros de estudiantes",
      },
      { icon: "fa-chart-bar", text: "Reportes", onClick: "loadReportsContent()", description: "Reportes financieros" },
      {
        icon: "fa-calculator",
        text: "Contabilidad",
        onClick: "loadAccountingContent()",
        description: "Módulo contable avanzado",
      },
      {
        icon: "fa-cog",
        text: "Configuración",
        onClick: "loadSettingsContent()",
        description: "Configuración financiera",
      },
    ],
    secretario: [
      {
        icon: "fa-tachometer-alt",
        text: "Dashboard",
        active: true,
        onClick: "loadDashboardContent()",
        description: "Panel administrativo principal",
      },
      {
        icon: "fa-user-graduate",
        text: "Estudiantes",
        onClick: "loadStudentsContent()",
        description: "Gestión de estudiantes",
      },
      {
        icon: "fa-calendar-alt",
        text: "Calendario",
        onClick: "loadCalendarContent()",
        description: "Gestión de calendario y citas",
      },
      {
        icon: "fa-file-alt",
        text: "Documentos",
        onClick: "loadDocumentsContent()",
        description: "Gestión de documentos",
      },
      {
        icon: "fa-comments",
        text: "Comunicación",
        onClick: "loadCommunicationContent()",
        description: "Centro de comunicaciones",
      },
      {
        icon: "fa-clipboard-list",
        text: "Registros",
        onClick: "loadRegistrationsContent()",
        description: "Inscripciones y registros",
      },
      {
        icon: "fa-phone",
        text: "Atención",
        onClick: "loadCustomerServiceContent()",
        description: "Atención al cliente",
      },
      { icon: "fa-archive", text: "Archivo", onClick: "loadArchiveContent()", description: "Archivo de documentos" },
    ],
  }

  return navigationMap[role] || []
}

/**
 * Carga el contenido inicial del dashboard
 */
function loadDashboardContent() {
  console.log("📊 Cargando contenido del dashboard...")

  try {
    if (!currentUser) {
      console.warn("⚠️ No hay usuario actual para cargar contenido")
      return
    }

    const contentArea = document.getElementById("content-area")
    const pageTitle = document.getElementById("page-title")
    const breadcrumbNav = document.getElementById("breadcrumb-nav")

    if (!contentArea) {
      console.warn("⚠️ No se encontró el área de contenido")
      return
    }

    // Actualizar título de la página
    if (pageTitle) {
      pageTitle.textContent = "Dashboard"
    }

    // Actualizar migas de pan
    if (breadcrumbNav) {
      breadcrumbNav.innerHTML = `
        <a href="javascript:void(0)" onclick="loadDashboardContent()">Inicio</a>
        <span>/</span>
        <span>Dashboard</span>
      `
    }

    // Actualizar elementos de navegación activos
    updateActiveNavigation("Dashboard")

    // Generar contenido según el rol
    let dashboardContent = ""

    switch (currentUser.role) {
      case "super-admin":
        dashboardContent = generateSuperAdminDashboard()
        break
      case "director":
        dashboardContent = generateDirectorDashboard()
        break
      case "profesor":
        dashboardContent = generateProfesorDashboard()
        break
      case "padre":
        dashboardContent = generatePadreDashboard()
        break
      case "contable":
        dashboardContent = generateContableDashboard()
        break
      case "secretario":
        dashboardContent = generateSecretarioDashboard()
        break
      default:
        dashboardContent = generateDefaultDashboard()
    }

    // Actualizar el contenido con animación
    contentArea.style.opacity = "0"
    setTimeout(() => {
      contentArea.innerHTML = dashboardContent
      contentArea.style.opacity = "1"

      // Inicializar componentes específicos del dashboard
      initDashboardComponents()

      console.log("✅ Contenido del dashboard cargado correctamente")
    }, 150)
  } catch (error) {
    console.error("❌ Error al cargar contenido del dashboard:", error)
    showNotification("Error al cargar el dashboard", "error")
  }
}

/**
 * Actualiza la navegación activa
 * @param {string} activeItem - Elemento activo
 */
function updateActiveNavigation(activeItem) {
  document.querySelectorAll(".nav-item").forEach((item) => {
    item.classList.remove("active")
    if (item.textContent.trim().includes(activeItem)) {
      item.classList.add("active")
    }
  })
}

/**
 * Inicializa componentes específicos del dashboard
 */
function initDashboardComponents() {
  // Inicializar gráficos simulados
  initSimulatedCharts()

  // Inicializar contadores animados
  initAnimatedCounters()

  // Inicializar tooltips en las tarjetas
  initTooltips()
}

/**
 * Inicializa gráficos simulados
 */
function initSimulatedCharts() {
  // Simular la inicialización de gráficos
  const chartContainers = document.querySelectorAll(".chart-container")
  chartContainers.forEach((container) => {
    if (!container.querySelector(".chart-placeholder")) {
      const placeholder = document.createElement("div")
      placeholder.className = "chart-placeholder"
      placeholder.style.cssText = `
        width: 100%;
        height: 100%;
        background: linear-gradient(45deg, var(--gray-100) 25%, transparent 25%),
                    linear-gradient(-45deg, var(--gray-100) 25%, transparent 25%),
                    linear-gradient(45deg, transparent 75%, var(--gray-100) 75%),
                    linear-gradient(-45deg, transparent 75%, var(--gray-100) 75%);
        background-size: 20px 20px;
        background-position: 0 0, 0 10px, 10px -10px, -10px 0px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--gray-500);
        font-size: 0.875rem;
        border-radius: var(--radius-md);
      `
      placeholder.textContent = "Gráfico de datos"
      container.appendChild(placeholder)
    }
  })
}

/**
 * Inicializa contadores animados
 */
function initAnimatedCounters() {
  const counters = document.querySelectorAll(".stat-number")
  counters.forEach((counter) => {
    const target = Number.parseInt(counter.textContent.replace(/[^\d]/g, ""))
    if (target && !isNaN(target)) {
      animateCounter(counter, target)
    }
  })
}

/**
 * Anima un contador
 * @param {HTMLElement} element - Elemento contador
 * @param {number} target - Valor objetivo
 */
function animateCounter(element, target) {
  const duration = 2000 // 2 segundos
  const start = 0
  const increment = target / (duration / 16) // 60 FPS
  let current = start

  const timer = setInterval(() => {
    current += increment
    if (current >= target) {
      current = target
      clearInterval(timer)
    }

    // Mantener formato original (con + o % si los tenía)
    const originalText = element.textContent
    let formattedValue = Math.floor(current).toString()

    if (originalText.includes("+")) {
      formattedValue = "+" + formattedValue
    }
    if (originalText.includes("%")) {
      formattedValue = formattedValue + "%"
    }
    if (originalText.includes("K")) {
      formattedValue = Math.floor(current / 1000) + "K+"
    }
    if (originalText.includes("$")) {
      formattedValue = "$" + formattedValue.replace(/\B(?=(\d{3})+(?!\d))/g, ",")
    }

    element.textContent = formattedValue
  }, 16)
}

// ======================================
// GENERADORES DE CONTENIDO DEL DASHBOARD
// ======================================

/**
 * Genera el contenido del dashboard para el Super Administrador
 * @returns {string} - HTML del dashboard
 */
function generateSuperAdminDashboard() {
  return `
    <div class="dashboard-welcome">
      <h2>Bienvenido, ${currentUser.name}</h2>
      <p>Gestiona todos los aspectos del sistema EduGestión360 desde este panel de control centralizado.</p>
    </div>
    
    <div class="dashboard-stats">
      <div class="stat-card">
        <div class="stat-icon" style="background: var(--primary);">
          <i class="fas fa-school"></i>
        </div>
        <div class="stat-content">
          <h3>Colegios Activos</h3>
          <p class="stat-value">524</p>
          <p class="stat-change positive">+12 este mes</p>
        </div>
      </div>
      
      <div class="stat-card">
        <div class="stat-icon" style="background: var(--info);">
          <i class="fas fa-users"></i>
        </div>
        <div class="stat-content">
          <h3>Usuarios Totales</h3>
          <p class="stat-value">52,348</p>
          <p class="stat-change positive">+1,256 este mes</p>
        </div>
      </div>
      
      <div class="stat-card">
        <div class="stat-icon" style="background: var(--success);">
          <i class="fas fa-credit-card"></i>
        </div>
        <div class="stat-content">
          <h3>Ingresos Mensuales</h3>
          <p class="stat-value">$124,580</p>
          <p class="stat-change positive">+8.3% este mes</p>
        </div>
      </div>
      
      <div class="stat-card">
        <div class="stat-icon" style="background: var(--warning);">
          <i class="fas fa-ticket-alt"></i>
        </div>
        <div class="stat-content">
          <h3>Tickets Soporte</h3>
          <p class="stat-value">18</p>
          <p class="stat-change negative">+5 sin resolver</p>
        </div>
      </div>
    </div>
    
    <div class="dashboard-grid">
      <div class="dashboard-card">
        <div class="card-header">
          <h3>Colegios Recientes</h3>
          <a href="javascript:void(0)" onclick="loadSchoolsContent()">Ver todos</a>
        </div>
        <div class="card-content">
          <div class="table-responsive">
            <table class="data-table">
              <thead>
                <tr>
                  <th>Institución</th>
                  <th>Ciudad</th>
                  <th>Estudiantes</th>
                  <th>Plan</th>
                  <th>Estado</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>
                    <div class="table-cell-content">
                      <div class="institution-info">
                        <strong>Colegio San José</strong>
                        <small>Fundado en 1985</small>
                      </div>
                    </div>
                  </td>
                  <td>Santo Domingo</td>
                  <td>450</td>
                  <td><span class="badge badge-primary">Profesional</span></td>
                  <td><span class="badge badge-success">Activo</span></td>
                </tr>
                <tr>
                  <td>
                    <div class="table-cell-content">
                      <div class="institution-info">
                        <strong>Instituto Tecnológico</strong>
                        <small>Fundado en 1992</small>
                      </div>
                    </div>
                  </td>
                  <td>Santiago</td>
                  <td>320</td>
                  <td><span class="badge badge-primary">Profesional</span></td>
                  <td><span class="badge badge-success">Activo</span></td>
                </tr>
                <tr>
                  <td>
                    <div class="table-cell-content">
                      <div class="institution-info">
                        <strong>Colegio Montessori</strong>
                        <small>Fundado en 2001</small>
                      </div>
                    </div>
                  </td>
                  <td>La Romana</td>
                  <td>180</td>
                  <td><span class="badge badge-warning">Básico</span></td>
                  <td><span class="badge badge-warning">Pendiente</span></td>
                </tr>
                <tr>
                  <td>
                    <div class="table-cell-content">
                      <div class="institution-info">
                        <strong>Liceo Francés</strong>
                        <small>Fundado en 1978</small>
                      </div>
                    </div>
                  </td>
                  <td>Puerto Plata</td>
                  <td>210</td>
                  <td><span class="badge badge-accent">Enterprise</span></td>
                  <td><span class="badge badge-success">Activo</span></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
      
      <div class="dashboard-card">
        <div class="card-header">
          <h3>Actividad del Sistema</h3>
          <a href="javascript:void(0)" onclick="loadLogsContent()">Ver logs completos</a>
        </div>
        <div class="card-content">
          <div class="activity-timeline">
            <div class="activity-item">
              <div class="activity-icon success">
                <i class="fas fa-user-plus"></i>
              </div>
              <div class="activity-content">
                <div class="activity-header">
                  <strong>Nuevo colegio registrado</strong>
                  <span class="activity-time">Hace 2 horas</span>
                </div>
                <p>Colegio Montessori se registró en el plan Básico</p>
              </div>
            </div>
            
            <div class="activity-item">
              <div class="activity-icon info">
                <i class="fas fa-credit-card"></i>
              </div>
              <div class="activity-content">
                <div class="activity-header">
                  <strong>Pago procesado</strong>
                  <span class="activity-time">Hace 4 horas</span>
                </div>
                <p>$1,200 recibidos de Colegio San José</p>
              </div>
            </div>
            
            <div class="activity-item">
              <div class="activity-icon warning">
                <i class="fas fa-exclamation-triangle"></i>
              </div>
              <div class="activity-content">
                <div class="activity-header">
                  <strong>Ticket de soporte</strong>
                  <span class="activity-time">Hace 6 horas</span>
                </div>
                <p>Nuevo ticket #1234 de Instituto Tecnológico</p>
              </div>
            </div>
            
            <div class="activity-item">
              <div class="activity-icon primary">
                <i class="fas fa-arrow-up"></i>
              </div>
              <div class="activity-content">
                <div class="activity-header">
                  <strong>Actualización de plan</strong>
                  <span class="activity-time">Hace 1 día</span>
                </div>
                <p>Liceo Francés actualizó a plan Enterprise</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <div class="dashboard-grid">
      <div class="dashboard-card">
        <div class="card-header">
          <h3>Distribución de Usuarios</h3>
          <div class="card-actions">
            <button class="btn-icon" onclick="refreshChart('users')">
              <i class="fas fa-sync-alt"></i>
            </button>
          </div>
        </div>
        <div class="card-content">
          <div class="chart-container" id="usersChart">
            <!-- Gráfico se inicializará con JavaScript -->
          </div>
          <div class="chart-legend">
            <div class="legend-item">
              <span class="legend-color" style="background: var(--primary);"></span>
              <span>Directores (524)</span>
            </div>
            <div class="legend-item">
              <span class="legend-color" style="background: var(--success);"></span>
              <span>Profesores (12,450)</span>
            </div>
            <div class="legend-item">
              <span class="legend-color" style="background: var(--warning);"></span>
              <span>Padres (35,200)</span>
            </div>
            <div class="legend-item">
              <span class="legend-color" style="background: var(--info);"></span>
              <span>Otros (4,174)</span>
            </div>
          </div>
        </div>
      </div>
      
      <div class="dashboard-card">
        <div class="card-header">
          <h3>Ingresos vs Gastos</h3>
          <div class="card-actions">
            <select class="select-sm">
              <option>Últimos 6 meses</option>
              <option>Último año</option>
              <option>Últimos 2 años</option>
            </select>
          </div>
        </div>
        <div class="card-content">
          <div class="chart-container" id="revenueChart">
            <!-- Gráfico se inicializará con JavaScript -->
          </div>
          <div class="chart-summary">
            <div class="summary-item">
              <span class="summary-label">Ingresos totales:</span>
              <span class="summary-value positive">$1,247,580</span>
            </div>
            <div class="summary-item">
              <span class="summary-label">Gastos operativos:</span>
              <span class="summary-value negative">$456,230</span>
            </div>
            <div class="summary-item">
              <span class="summary-label">Ganancia neta:</span>
              <span class="summary-value positive">$791,350</span>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <style>
      .table-responsive {
        overflow-x: auto;
      }
      
      .data-table {
        width: 100%;
        border-collapse: collapse;
        font-size: 0.875rem;
      }
      
      .data-table th {
        text-align: left;
        padding: 0.75rem 1rem;
        font-size: 0.75rem;
        font-weight: 600;
        color: var(--gray-600);
        text-transform: uppercase;
        border-bottom: 1px solid var(--gray-200);
        background: var(--gray-50);
      }
      
      .data-table td {
        padding: 1rem;
        border-bottom: 1px solid var(--gray-200);
        vertical-align: middle;
      }
      
      .data-table tr:hover {
        background: var(--gray-50);
      }
      
      .table-cell-content {
        display: flex;
        align-items: center;
        gap: 0.75rem;
      }
      
      .institution-info strong {
        display: block;
        color: var(--gray-900);
        font-weight: 600;
      }
      
      .institution-info small {
        color: var(--gray-500);
        font-size: 0.75rem;
      }
      
      .badge {
        display: inline-block;
        padding: 0.25rem 0.5rem;
        border-radius: var(--radius-full);
        font-size: 0.75rem;
        font-weight: 500;
        text-transform: uppercase;
        letter-spacing: 0.025em;
      }
      
      .badge-success {
        background: var(--success);
        color: white;
      }
      
      .badge-warning {
        background: var(--warning);
        color: white;
      }
      
      .badge-primary {
        background: var(--primary);
        color: white;
      }
      
      .badge-accent {
        background: var(--accent);
        color: white;
      }
      
      .activity-timeline {
        display: flex;
        flex-direction: column;
        gap: 1.25rem;
      }
      
      .activity-item {
        display: flex;
        gap: 1rem;
        position: relative;
      }
      
      .activity-item:not(:last-child)::after {
        content: '';
        position: absolute;
        left: 1.25rem;
        top: 2.5rem;
        bottom: -1.25rem;
        width: 2px;
        background: var(--gray-200);
      }
      
      .activity-icon {
        width: 2.5rem;
        height: 2.5rem;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-size: 0.875rem;
        flex-shrink: 0;
      }
      
      .activity-icon.success {
        background: var(--success);
      }
      
      .activity-icon.info {
        background: var(--info);
      }
      
      .activity-icon.warning {
        background: var(--warning);
      }
      
      .activity-icon.primary {
        background: var(--primary);
      }
      
      .activity-content {
        flex: 1;
        min-width: 0;
      }
      
      .activity-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 0.25rem;
      }
      
      .activity-header strong {
        color: var(--gray-900);
        font-weight: 600;
      }
      
      .activity-time {
        font-size: 0.75rem;
        color: var(--gray-500);
        white-space: nowrap;
      }
      
      .activity-content p {
        color: var(--gray-600);
        font-size: 0.875rem;
        margin: 0;
      }
      
      .card-actions {
        display: flex;
        align-items: center;
        gap: 0.5rem;
      }
      
      .btn-icon {
        background: none;
        border: none;
        color: var(--gray-500);
        cursor: pointer;
        padding: 0.5rem;
        border-radius: var(--radius-md);
        transition: var(--transition);
      }
      
      .btn-icon:hover {
        background: var(--gray-100);
        color: var(--gray-700);
      }
      
      .select-sm {
        padding: 0.375rem 0.75rem;
        border: 1px solid var(--gray-300);
        border-radius: var(--radius-md);
        font-size: 0.875rem;
        background: white;
      }
      
      .chart-legend {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 0.75rem;
        margin-top: 1rem;
        padding-top: 1rem;
        border-top: 1px solid var(--gray-200);
      }
      
      .legend-item {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        font-size: 0.875rem;
      }
      
      .legend-color {
        width: 12px;
        height: 12px;
        border-radius: 2px;
        flex-shrink: 0;
      }
      
      .chart-summary {
        margin-top: 1rem;
        padding-top: 1rem;
        border-top: 1px solid var(--gray-200);
      }
      
      .summary-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 0.5rem;
        font-size: 0.875rem;
      }
      
      .summary-label {
        color: var(--gray-600);
      }
      
      .summary-value {
        font-weight: 600;
      }
      
      .summary-value.positive {
        color: var(--success);
      }
      
      .summary-value.negative {
        color: var(--error);
      }
      
      @media (max-width: 768px) {
        .dashboard-grid {
          grid-template-columns: 1fr;
        }
        
        .chart-legend {
          grid-template-columns: 1fr;
        }
        
        .activity-header {
          flex-direction: column;
          align-items: flex-start;
          gap: 0.25rem;
        }
      }
    </style>
  `
}

/**
 * Genera el contenido del dashboard para el Director
 * @returns {string} - HTML del dashboard
 */
function generateDirectorDashboard() {
  return `
    <div class="dashboard-welcome">
      <h2>Bienvenido, ${currentUser.name}</h2>
      <p>Gestiona tu institución educativa ${currentUser.institution || "desde este panel de control integral"}.</p>
    </div>
    
    <div class="dashboard-stats">
      <div class="stat-card">
        <div class="stat-icon" style="background: var(--info);">
          <i class="fas fa-user-graduate"></i>
        </div>
        <div class="stat-content">
          <h3>Estudiantes</h3>
          <p class="stat-value">450</p>
          <p class="stat-change positive">+12 este mes</p>
        </div>
      </div>
      
      <div class="stat-card">
        <div class="stat-icon" style="background: var(--success);">
          <i class="fas fa-chalkboard-teacher"></i>
        </div>
        <div class="stat-content">
          <h3>Profesores</h3>
          <p class="stat-value">32</p>
          <p class="stat-change positive">+2 este mes</p>
        </div>
      </div>
      
      <div class="stat-card">
        <div class="stat-icon" style="background: var(--warning);">
          <i class="fas fa-book"></i>
        </div>
        <div class="stat-content">
          <h3>Cursos Activos</h3>
          <p class="stat-value">24</p>
          <p class="stat-change neutral">Sin cambios</p>
        </div>
      </div>
      
      <div class="stat-card">
        <div class="stat-icon" style="background: var(--accent);">
          <i class="fas fa-calendar-check"></i>
        </div>
        <div class="stat-content">
          <h3>Asistencia Promedio</h3>
          <p class="stat-value">95%</p>
          <p class="stat-change positive">+2% este mes</p>
        </div>
      </div>
    </div>
    
    <div class="dashboard-grid">
      <div class="dashboard-card">
        <div class="card-header">
          <h3>Rendimiento Académico por Grado</h3>
          <a href="javascript:void(0)" onclick="loadAcademicContent()">Ver detalles</a>
        </div>
        <div class="card-content">
          <div class="performance-grid">
            <div class="performance-item">
              <div class="performance-header">
                <span class="grade-label">1° Grado</span>
                <span class="performance-score excellent">92%</span>
              </div>
              <div class="performance-bar">
                <div class="performance-fill" style="width: 92%; background: var(--success);"></div>
              </div>
              <div class="performance-details">
                <span>45 estudiantes</span>
                <span class="trend positive">+3%</span>
              </div>
            </div>
            
            <div class="performance-item">
              <div class="performance-header">
                <span class="grade-label">2° Grado</span>
                <span class="performance-score good">87%</span>
              </div>
              <div class="performance-bar">
                <div class="performance-fill" style="width: 87%; background: var(--info);"></div>
              </div>
              <div class="performance-details">
                <span>42 estudiantes</span>
                <span class="trend positive">+1%</span>
              </div>
            </div>
            
            <div class="performance-item">
              <div class="performance-header">
                <span class="grade-label">3° Grado</span>
                <span class="performance-score good">89%</span>
              </div>
              <div class="performance-bar">
                <div class="performance-fill" style="width: 89%; background: var(--info);"></div>
              </div>
              <div class="performance-details">
                <span>38 estudiantes</span>
                <span class="trend positive">+5%</span>
              </div>
            </div>
            
            <div class="performance-item">
              <div class="performance-header">
                <span class="grade-label">4° Grado</span>
                <span class="performance-score warning">78%</span>
              </div>
              <div class="performance-bar">
                <div class="performance-fill" style="width: 78%; background: var(--warning);"></div>
              </div>
              <div class="performance-details">
                <span>40 estudiantes</span>
                <span class="trend negative">-2%</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div class="dashboard-card">
        <div class="card-header">
          <h3>Próximos Eventos</h3>
          <a href="javascript:void(0)" onclick="loadPlanningContent()">Ver calendario completo</a>
        </div>
        <div class="card-content">
          <div class="events-list">
            <div class="event-item">
              <div class="event-date">
                <span class="event-day">15</span>
                <span class="event-month">Jun</span>
              </div>
              <div class="event-content">
                <h4>Reunión de Padres</h4>
                <p>Salón de Actos • 4:00 PM - 6:00 PM</p>
                <div class="event-attendees">
                  <span class="attendee-count">
                    <i class="fas fa-users"></i>
                    120 confirmados
                  </span>
                </div>
              </div>
              <div class="event-status">
                <span class="badge badge-info">Confirmado</span>
              </div>
            </div>
            
            <div class="event-item">
              <div class="event-date">
                <span class="event-day">22</span>
                <span class="event-month">Jun</span>
              </div>
              <div class="event-content">
                <h4>Fin de Trimestre</h4>
                <p>Entrega de calificaciones</p>
                <div class="event-attendees">
                  <span class="attendee-count">
                    <i class="fas fa-clipboard-list"></i>
                    450 estudiantes
                  </span>
                </div>
              </div>
              <div class="event-status">
                <span class="badge badge-warning">Pendiente</span>
              </div>
            </div>
            
            <div class="event-item">
              <div class="event-date">
                <span class="event-day">30</span>
                <span class="event-month">Jun</span>
              </div>
              <div class="event-content">
                <h4>Acto de Graduación</h4>
                <p>Auditorio Principal • 10:00 AM</p>
                <div class="event-attendees">
                  <span class="attendee-count">
                    <i class="fas fa-graduation-cap"></i>
                    45 graduandos
                  </span>
                </div>
              </div>
              <div class="event-status">
                <span class="badge badge-success">Planificado</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <div class="dashboard-grid">
      <div class="dashboard-card">
        <div class="card-header">
          <h3>Profesores Destacados del Mes</h3>
          <a href="javascript:void(0)" onclick="loadUsersContent()">Ver todos los profesores</a>
        </div>
        <div class="card-content">
          <div class="teachers-grid">
            <div class="teacher-card">
              <div class="teacher-avatar">
                <i class="fas fa-user"></i>
              </div>
              <div class="teacher-info">
                <h4>María Rodríguez</h4>
                <p>Matemáticas • 5° y 6° Grado</p>
                <div class="teacher-stats">
                  <div class="teacher-stat">
                    <span class="stat-value">98%</span>
                    <span class="stat-label">Asistencia</span>
                  </div>
                  <div class="teacher-stat">
                    <span class="stat-value">4.9/5</span>
                    <span class="stat-label">Evaluación</span>
                  </div>
                </div>
                <div class="teacher-achievements">
                  <span class="achievement-badge">
                    <i class="fas fa-star"></i>
                    Profesor del Mes
                  </span>
                </div>
              </div>
            </div>
            
            <div class="teacher-card">
              <div class="teacher-avatar">
                <i class="fas fa-user"></i>
              </div>
              <div class="teacher-info">
                <h4>Juan Pérez</h4>
                <p>Ciencias • 3° y 4° Grado</p>
                <div class="teacher-stats">
                  <div class="teacher-stat">
                    <span class="stat-value">95%</span>
                    <span class="stat-label">Asistencia</span>
                  </div>
                  <div class="teacher-stat">
                    <span class="stat-value">4.8/5</span>
                    <span class="stat-label">Evaluación</span>
                  </div>
                </div>
                <div class="teacher-achievements">
                  <span class="achievement-badge innovation">
                    <i class="fas fa-lightbulb"></i>
                    Innovación
                  </span>
                </div>
              </div>
            </div>
            
            <div class="teacher-card">
              <div class="teacher-avatar">
                <i class="fas fa-user"></i>
              </div>
              <div class="teacher-info">
                <h4>Ana Gómez</h4>
                <p>Literatura • 1° y 2° Grado</p>
                <div class="teacher-stats">
                  <div class="teacher-stat">
                    <span class="stat-value">97%</span>
                    <span class="stat-label">Asistencia</span>
                  </div>
                  <div class="teacher-stat">
                    <span class="stat-value">4.7/5</span>
                    <span class="stat-label">Evaluación</span>
                  </div>
                </div>
                <div class="teacher-achievements">
                  <span class="achievement-badge excellence">
                    <i class="fas fa-medal"></i>
                    Excelencia
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div class="dashboard-card">
        <div class="card-header">
          <h3>Comunicaciones Recientes</h3>
          <a href="javascript:void(0)" onclick="loadCommunicationContent()">Ver todas</a>
        </div>
        <div class="card-content">
          <div class="communications-list">
            <div class="communication-item urgent">
              <div class="communication-icon">
                <i class="fas fa-exclamation-circle"></i>
              </div>
              <div class="communication-content">
                <div class="communication-header">
                  <h4>Solicitud Urgente - Prof. Carlos Mendoza</h4>
                  <span class="communication-time">Hace 30 min</span>
                </div>
                <p>Solicita reunión urgente para discutir el rendimiento del grupo 4-B. Requiere atención inmediata.</p>
                <div class="communication-actions">
                  <button class="btn-sm btn-primary">Responder</button>
                  <button class="btn-sm btn-outline">Programar reunión</button>
                </div>
              </div>
            </div>
            
            <div class="communication-item">
              <div class="communication-icon">
                <i class="fas fa-file-alt"></i>
              </div>
              <div class="communication-content">
                <div class="communication-header">
                  <h4>Informe Mensual - Prof. Laura Sánchez</h4>
                  <span class="communication-time">Hace 2 horas</span>
                </div>
                <p>Informe mensual de asistencia del departamento de Ciencias. Incluye estadísticas detalladas.</p>
                <div class="communication-actions">
                  <button class="btn-sm btn-outline">Ver informe</button>
                  <button class="btn-sm btn-outline">Descargar PDF</button>
                </div>
              </div>
            </div>
            
            <div class="communication-item">
              <div class="communication-icon">
                <i class="fas fa-question-circle"></i>
              </div>
              <div class="communication-content">
                <div class="communication-header">
                  <h4>Consulta - Prof. Roberto Díaz</h4>
                  <span class="communication-time">Hace 5 horas</span>
                </div>
                <p>Solicita autorización para materiales adicionales del laboratorio de Química para el próximo trimestre.</p>
                <div class="communication-actions">
                  <button class="btn-sm btn-success">Aprobar</button>
                  <button class="btn-sm btn-outline">Revisar presupuesto</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <style>
      .performance-grid {
        display: flex;
        flex-direction: column;
        gap: 1rem;
      }
      
      .performance-item {
        padding: 1rem;
        background: var(--gray-50);
        border-radius: var(--radius-lg);
        border: 1px solid var(--gray-200);
      }
      
      .performance-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 0.75rem;
      }
      
      .grade-label {
        font-weight: 600;
        color: var(--gray-900);
      }
      
      .performance-score {
        font-weight: 700;
        font-size: 1.125rem;
      }
      
      .performance-score.excellent {
        color: var(--success);
      }
      
      .performance-score.good {
        color: var(--info);
      }
      
      .performance-score.warning {
        color: var(--warning);
      }
      
      .performance-bar {
        height: 8px;
        background: var(--gray-200);
        border-radius: var(--radius-full);
        overflow: hidden;
        margin-bottom: 0.75rem;
      }
      
      .performance-fill {
        height: 100%;
        border-radius: var(--radius-full);
        transition: width 1s ease-out;
      }
      
      .performance-details {
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-size: 0.875rem;
      }
      
      .performance-details span:first-child {
        color: var(--gray-600);
      }
      
      .trend {
        font-weight: 600;
        font-size: 0.75rem;
      }
      
      .trend.positive {
        color: var(--success);
      }
      
      .trend.negative {
        color: var(--error);
      }
      
      .events-list {
        display: flex;
        flex-direction: column;
        gap: 1.25rem;
      }
      
      .event-item {
        display: flex;
        gap: 1rem;
        padding: 1rem;
        background: var(--gray-50);
        border-radius: var(--radius-lg);
        border: 1px solid var(--gray-200);
        transition: var(--transition);
      }
      
      .event-item:hover {
        box-shadow: var(--shadow-md);
        transform: translateY(-1px);
      }
      
      .event-date {
        width: 60px;
        height: 60px;
        background: var(--primary);
        color: white;
        border-radius: var(--radius-lg);
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
      }
      
      .event-day {
        font-size: 1.25rem;
        font-weight: 700;
        line-height: 1;
      }
      
      .event-month {
        font-size: 0.75rem;
        text-transform: uppercase;
        opacity: 0.9;
      }
      
      .event-content {
        flex: 1;
        min-width: 0;
      }
      
      .event-content h4 {
        font-size: 1rem;
        font-weight: 600;
        color: var(--gray-900);
        margin-bottom: 0.25rem;
      }
      
      .event-content p {
        font-size: 0.875rem;
        color: var(--gray-600);
        margin-bottom: 0.5rem;
      }
      
      .event-attendees {
        margin-bottom: 0.5rem;
      }
      
      .attendee-count {
        display: inline-flex;
        align-items: center;
        gap: 0.375rem;
        font-size: 0.75rem;
        color: var(--gray-500);
        background: white;
        padding: 0.25rem 0.5rem;
        border-radius: var(--radius-md);
      }
      
      .event-status {
        align-self: flex-start;
      }
      
      .teachers-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
        gap: 1.5rem;
      }
      
      .teacher-card {
        background: var(--gray-50);
        border-radius: var(--radius-lg);
        padding: 1.5rem;
        border: 1px solid var(--gray-200);
        transition: var(--transition);
      }
      
      .teacher-card:hover {
        box-shadow: var(--shadow-md);
        transform: translateY(-2px);
      }
      
      .teacher-avatar {
        width: 60px;
        height: 60px;
        background: var(--primary);
        color: white;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.5rem;
        margin: 0 auto 1rem;
      }
      
      .teacher-info {
        text-align: center;
      }
      
      .teacher-info h4 {
        font-size: 1.125rem;
        font-weight: 600;
        color: var(--gray-900);
        margin-bottom: 0.25rem;
      }
      
      .teacher-info p {
        font-size: 0.875rem;
        color: var(--gray-600);
        margin-bottom: 1rem;
      }
      
      .teacher-stats {
        display: flex;
        justify-content: center;
        gap: 1.5rem;
        margin-bottom: 1rem;
      }
      
      .teacher-stat {
        display: flex;
        flex-direction: column;
        align-items: center;
      }
      
      .teacher-stat .stat-value {
        font-size: 1rem;
        font-weight: 700;
        color: var(--gray-900);
      }
      
      .teacher-stat .stat-label {
        font-size: 0.75rem;
        color: var(--gray-500);
        text-transform: uppercase;
      }
      
      .teacher-achievements {
        display: flex;
        justify-content: center;
      }
      
      .achievement-badge {
        display: inline-flex;
        align-items: center;
        gap: 0.375rem;
        padding: 0.375rem 0.75rem;
        background: var(--success);
        color: white;
        border-radius: var(--radius-full);
        font-size: 0.75rem;
        font-weight: 500;
      }
      
      .achievement-badge.innovation {
        background: var(--warning);
      }
      
      .achievement-badge.excellence {
        background: var(--accent);
      }
      
      .communications-list {
        display: flex;
        flex-direction: column;
        gap: 1.25rem;
      }
      
      .communication-item {
        display: flex;
        gap: 1rem;
        padding: 1.25rem;
        background: var(--gray-50);
        border-radius: var(--radius-lg);
        border: 1px solid var(--gray-200);
        transition: var(--transition);
      }
      
      .communication-item.urgent {
        border-left: 4px solid var(--error);
        background: rgba(239, 68, 68, 0.05);
      }
      
      .communication-item:hover {
        box-shadow: var(--shadow-md);
      }
      
      .communication-icon {
        width: 40px;
        height: 40px;
        background: var(--primary);
        color: white;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
      }
      
      .communication-item.urgent .communication-icon {
        background: var(--error);
      }
      
      .communication-content {
        flex: 1;
        min-width: 0;
      }
      
      .communication-header {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        margin-bottom: 0.5rem;
        gap: 1rem;
      }
      
      .communication-header h4 {
        font-size: 1rem;
        font-weight: 600;
        color: var(--gray-900);
        margin: 0;
      }
      
      .communication-time {
        font-size: 0.75rem;
        color: var(--gray-500);
        white-space: nowrap;
      }
      
      .communication-content p {
        font-size: 0.875rem;
        color: var(--gray-600);
        line-height: 1.5;
        margin-bottom: 1rem;
      }
      
      .communication-actions {
        display: flex;
        gap: 0.5rem;
        flex-wrap: wrap;
      }
      
      .btn-sm {
        padding: 0.375rem 0.75rem;
        font-size: 0.75rem;
        border-radius: var(--radius-md);
        border: none;
        cursor: pointer;
        transition: var(--transition);
        font-weight: 500;
      }
      
      .btn-sm.btn-primary {
        background: var(--primary);
        color: white;
      }
      
      .btn-sm.btn-primary:hover {
        background: var(--primary-dark);
      }
      
      .btn-sm.btn-success {
        background: var(--success);
        color: white;
      }
      
      .btn-sm.btn-success:hover {
        background: var(--success-dark);
      }
      
      .btn-sm.btn-outline {
        background: transparent;
        border: 1px solid var(--gray-300);
        color: var(--gray-700);
      }
      
      .btn-sm.btn-outline:hover {
        background: var(--gray-100);
        border-color: var(--gray-400);
      }
      
      @media (max-width: 768px) {
        .teachers-grid {
          grid-template-columns: 1fr;
        }
        
        .communication-header {
          flex-direction: column;
          align-items: flex-start;
          gap: 0.25rem;
        }
        
        .communication-actions {
          flex-direction: column;
        }
        
        .btn-sm {
          width: 100%;
          text-align: center;
        }
      }
    </style>
  `
}

/**
 * Genera el contenido del dashboard para el Profesor
 * @returns {string} - HTML del dashboard
 */
function generateProfesorDashboard() {
  return `
    <div class="dashboard-welcome">
      <h2>Bienvenido, ${currentUser.name}</h2>
      <p>Gestiona tus cursos y estudiantes del departamento de ${currentUser.department || "tu área académica"}.</p>
    </div>
    
    <div class="dashboard-stats">
      <div class="stat-card">
        <div class="stat-icon" style="background: var(--primary);">
          <i class="fas fa-book"></i>
        </div>
        <div class="stat-content">
          <h3>Mis Cursos</h3>
          <p class="stat-value">6</p>
          <p class="stat-change neutral">Activos</p>
        </div>
      </div>
      
      <div class="stat-card">
        <div class="stat-icon" style="background: var(--info);">
          <i class="fas fa-user-graduate"></i>
        </div>
        <div class="stat-content">
          <h3>Estudiantes</h3>
          <p class="stat-value">142</p>
          <p class="stat-change positive">+3 este mes</p>
        </div>
      </div>
      
      <div class="stat-card">
        <div class="stat-icon" style="background: var(--warning);">
          <i class="fas fa-tasks"></i>
        </div>
        <div class="stat-content">
          <h3>Tareas Pendientes</h3>
          <p class="stat-value">8</p>
          <p class="stat-change negative">Por revisar</p>
        </div>
      </div>
      
      <div class="stat-card">
        <div class="stat-icon" style="background: var(--success);">
          <i class="fas fa-calendar-check"></i>
        </div>
        <div class="stat-content">
          <h3>Asistencia Promedio</h3>
          <p class="stat-value">94%</p>
          <p class="stat-change positive">+1% esta semana</p>
        </div>
      </div>
    </div>
    
    <div class="dashboard-grid">
      <div class="dashboard-card">
        <div class="card-header">
          <h3>Mis Cursos Activos</h3>
          <a href="javascript:void(0)" onclick="loadCoursesContent()">Ver todos los cursos</a>
        </div>
        <div class="card-content">
          <div class="courses-grid">
            <div class="course-card">
              <div class="course-header">
                <div class="course-icon">
                  <i class="fas fa-calculator"></i>
                </div>
                <div class="course-info">
                  <h4>Matemáticas 5°A</h4>
                  <p>24 estudiantes • Lun, Mié, Vie</p>
                </div>
                <div class="course-status">
                  <span class="status-indicator active"></span>
                </div>
              </div>
              <div class="course-stats">
                <div class="course-stat">
                  <span class="stat-label">Promedio</span>
                  <span class="stat-value">87%</span>
                </div>
                <div class="course-stat">
                  <span class="stat-label">Asistencia</span>
                  <span class="stat-value">95%</span>
                </div>
                <div class="course-stat">
                  <span class="stat-label">Tareas</span>
                  <span class="stat-value pending">3 pendientes</span>
                </div>
              </div>
              <div class="course-actions">
                <button class="btn-sm btn-primary">Ver curso</button>
                <button class="btn-sm btn-outline">Calificar</button>
              </div>
            </div>
            
            <div class="course-card">
              <div class="course-header">
                <div class="course-icon">
                  <i class="fas fa-calculator"></i>
                </div>
                <div class="course-info">
                  <h4>Matemáticas 5°B</h4>
                  <p>22 estudiantes • Mar, Jue</p>
                </div>
                <div class="course-status">
                  <span class="status-indicator active"></span>
                </div>
              </div>
              <div class="course-stats">
                <div class="course-stat">
                  <span class="stat-label">Promedio</span>
                  <span class="stat-value">82%</span>
                </div>
                <div class="course-stat">
                  <span class="stat-label">Asistencia</span>
                  <span class="stat-value">92%</span>
                </div>
                <div class="course-stat">
                  <span class="stat-label">Tareas</span>
                  <span class="stat-value completed">Al día</span>
                </div>
              </div>
              <div class="course-actions">
                <button class="btn-sm btn-primary">Ver curso</button>
                <button class="btn-sm btn-outline">Calificar</button>
              </div>
            </div>
            
            <div class="course-card">
              <div class="course-header">
                <div class="course-icon">
                  <i class="fas fa-calculator"></i>
                </div>
                <div class="course-info">
                  <h4>Matemáticas 6°A</h4>
                  <p>26 estudiantes • Lun, Mié, Vie</p>
                </div>
                <div class="course-status">
                  <span class="status-indicator active"></span>
                </div>
              </div>
              <div class="course-stats">
                <div class="course-stat">
                  <span class="stat-label">Promedio</span>
                  <span class="stat-value">90%</span>
                </div>
                <div class="course-stat">
                  <span class="stat-label">Asistencia</span>
                  <span class="stat-value">97%</span>
                </div>
                <div class="course-stat">
                  <span class="stat-label">Tareas</span>
                  <span class="stat-value pending">2 pendientes</span>
                </div>
              </div>
              <div class="course-actions">
                <button class="btn-sm btn-primary">Ver curso</button>
                <button class="btn-sm btn-outline">Calificar</button>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div class="dashboard-card">
        <div class="card-header">
          <h3>Horario de Hoy</h3>
          <div class="current-date">
            <i class="fas fa-calendar"></i>
            <span>Lunes, 15 de Junio</span>
          </div>
        </div>
        <div class="card-content">
          <div class="schedule-timeline">
            <div class="schedule-item current">
              <div class="schedule-time">
                <span class="time-start">8:00</span>
                <span class="time-end">9:30</span>
              </div>
              <div class="schedule-content">
                <h4>Matemáticas 5°A</h4>
                <p>Aula 201 • Álgebra básica</p>
                <div class="schedule-status">
                  <span class="status-badge current">En curso</span>
                </div>
              </div>
              <div class="schedule-actions">
                <button class="btn-icon" title="Tomar asistencia">
                  <i class="fas fa-check"></i>
                </button>
                <button class="btn-icon" title="Ver detalles">
                  <i class="fas fa-eye"></i>
                </button>
              </div>
            </div>
            
            <div class="schedule-item upcoming">
              <div class="schedule-time">
                <span class="time-start">10:00</span>
                <span class="time-end">11:30</span>
              </div>
              <div class="schedule-content">
                <h4>Matemáticas 6°A</h4>
                <p>Aula 203 • Geometría</p>
                <div class="schedule-status">
                  <span class="status-badge upcoming">Próxima</span>
                </div>
              </div>
              <div class="schedule-actions">
                <button class="btn-icon" title="Preparar clase">
                  <i class="fas fa-edit"></i>
                </button>
                <button class="btn-icon" title="Ver detalles">
                  <i class="fas fa-eye"></i>
                </button>
              </div>
            </div>
            
            <div class="schedule-item">
              <div class="schedule-time">
                <span class="time-start">14:00</span>
                <span class="time-end">15:30</span>
              </div>
              <div class="schedule-content">
                <h4>Matemáticas 5°B</h4>
                <p>Aula 201 • Fracciones</p>
                <div class="schedule-status">
                  <span class="status-badge scheduled">Programada</span>
                </div>
              </div>
              <div class="schedule-actions">
                <button class="btn-icon" title="Preparar clase">
                  <i class="fas fa-edit"></i>
                </button>
                <button class="btn-icon" title="Ver detalles">
                  <i class="fas fa-eye"></i>
                </button>
              </div>
            </div>
            
            <div class="schedule-item">
              <div class="schedule-time">
                <span class="time-start">16:00</span>
                <span class="time-end">17:00</span>
              </div>
              <div class="schedule-content">
                <h4>Reunión de Departamento</h4>
                <p>Sala de Profesores • Planificación</p>
                <div class="schedule-status">
                  <span class="status-badge meeting">Reunión</span>
                </div>
              </div>
              <div class="schedule-actions">
                <button class="btn-icon" title="Ver agenda">
                  <i class="fas fa-list"></i>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <div class="dashboard-grid">
      <div class="dashboard-card">
        <div class="card-header">
          <h3>Tareas por Revisar</h3>
          <a href="javascript:void(0)" onclick="loadTasksContent()">Ver todas las tareas</a>
        </div>
        <div class="card-content">
          <div class="tasks-list">
            <div class="task-item urgent">
              <div class="task-header">
                <div class="task-info">
                  <h4>Examen de Álgebra - 5°A</h4>
                  <p>24 estudiantes • Entregado hace 2 días</p>
                </div>
                <div class="task-priority">
                  <span class="priority-badge urgent">Urgente</span>
                </div>
              </div>
              <div class="task-progress">
                <div class="progress-info">
                  <span>Revisado: 8/24</span>
                  <span>33%</span>
                </div>
                <div class="progress-bar">
                  <div class="progress-fill" style="width: 33%; background: var(--error);"></div>
                </div>
              </div>
              <div class="task-actions">
                <button class="btn-sm btn-primary">Continuar revisión</button>
                <button class="btn-sm btn-outline">Ver detalles</button>
              </div>
            </div>
            
            <div class="task-item">
              <div class="task-header">
                <div class="task-info">
                  <h4>Tarea de Geometría - 6°A</h4>
                  <p>26 estudiantes • Entregado ayer</p>
                </div>
                <div class="task-priority">
                  <span class="priority-badge normal">Normal</span>
                </div>
              </div>
              <div class="task-progress">
                <div class="progress-info">
                  <span>Revisado: 15/26</span>
                  <span>58%</span>
                </div>
                <div class="progress-bar">
                  <div class="progress-fill" style="width: 58%; background: var(--warning);"></div>
                </div>
              </div>
              <div class="task-actions">
                <button class="btn-sm btn-primary">Continuar revisión</button>
                <button class="btn-sm btn-outline">Ver detalles</button>
              </div>
            </div>
            
            <div class="task-item">
              <div class="task-header">
                <div class="task-info">
                  <h4>Proyecto de Fracciones - 5°B</h4>
                  <p>22 estudiantes • Entregado hoy</p>
                </div>
                <div class="task-priority">
                  <span class="priority-badge low">Baja</span>
                </div>
              </div>
              <div class="task-progress">
                <div class="progress-info">
                  <span>Revisado: 0/22</span>
                  <span>0%</span>
                </div>
                <div class="progress-bar">
                  <div class="progress-fill" style="width: 0%; background: var(--gray-300);"></div>
                </div>
              </div>
              <div class="task-actions">
                <button class="btn-sm btn-primary">Iniciar revisión</button>
                <button class="btn-sm btn-outline">Ver detalles</button>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div class="dashboard-card">
        <div class="card-header">
          <h3>Estudiantes que Requieren Atención</h3>
          <a href="javascript:void(0)" onclick="loadProgressContent()">Ver progreso completo</a>
        </div>
        <div class="card-content">
          <div class="students-attention-list">
            <div class="student-attention-item">
              <div class="student-avatar">
                <i class="fas fa-user"></i>
              </div>
              <div class="student-info">
                <h4>Carlos Mendoza</h4>
                <p>5°A • Matemáticas</p>
                <div class="attention-reasons">
                  <span class="reason-tag attendance">Asistencia: 78%</span>
                  <span class="reason-tag grades">Promedio: 65%</span>
                </div>
              </div>
              <div class="student-actions">
                <button class="btn-sm btn-warning">Contactar padre</button>
                <button class="btn-sm btn-outline">Ver historial</button>
              </div>
            </div>
            
            <div class="student-attention-item">
              <div class="student-avatar">
                <i class="fas fa-user"></i>
              </div>
              <div class="student-info">
                <h4>María González</h4>
                <p>6°A • Matemáticas</p>
                <div class="attention-reasons">
                  <span class="reason-tag behavior">Comportamiento</span>
                  <span class="reason-tag participation">Baja participación</span>
                </div>
              </div>
              <div class="student-actions">
                <button class="btn-sm btn-info">Programar tutoría</button>
                <button class="btn-sm btn-outline">Ver historial</button>
              </div>
            </div>
            
            <div class="student-attention-item">
              <div class="student-avatar">
                <i class="fas fa-user"></i>
              </div>
              <div class="student-info">
                <h4>Luis Rodríguez</h4>
                <p>5°B • Matemáticas</p>
                <div class="attention-reasons">
                  <span class="reason-tag homework">Tareas atrasadas: 3</span>
                </div>
              </div>
              <div class="student-actions">
                <button class="btn-sm btn-primary">Revisar tareas</button>
                <button class="btn-sm btn-outline">Ver historial</button>
              </div>
            </div>
            
            <div class="student-attention-item positive">
              <div class="student-avatar">
                <i class="fas fa-user"></i>
              </div>
              <div class="student-info">
                <h4>Ana Pérez</h4>
                <p>6°A • Matemáticas</p>
                <div class="attention-reasons">
                  <span class="reason-tag excellence">Excelencia académica</span>
                  <span class="reason-tag leadership">Liderazgo</span>
                </div>
              </div>
              <div class="student-actions">
                <button class="btn-sm btn-success">Reconocimiento</button>
                <button class="btn-sm btn-outline">Ver historial</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <style>
      .current-date {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        font-size: 0.875rem;
        color: var(--gray-600);
      }
      
      .courses-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 1.5rem;
      }
      
      .course-card {
        background: var(--gray-50);
        border-radius: var(--radius-lg);
        padding: 1.5rem;
        border: 1px solid var(--gray-200);
        transition: var(--transition);
      }
      
      .course-card:hover {
        box-shadow: var(--shadow-md);
        transform: translateY(-2px);
      }
      
      .course-header {
        display: flex;
        align-items: flex-start;
        gap: 1rem;
        margin-bottom: 1rem;
      }
      
      .course-icon {
        width: 50px;
        height: 50px;
        background: var(--primary);
        color: white;
        border-radius: var(--radius-lg);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.25rem;
        flex-shrink: 0;
      }
      
      .course-info {
        flex: 1;
        min-width: 0;
      }
      
      .course-info h4 {
        font-size: 1.125rem;
        font-weight: 600;
        color: var(--gray-900);
        margin-bottom: 0.25rem;
      }
      
      .course-info p {
        font-size: 0.875rem;
        color: var(--gray-600);
      }
      
      .course-status {
        flex-shrink: 0;
      }
      
      .status-indicator {
        width: 12px;
        height: 12px;
        border-radius: 50%;
        background: var(--success);
        box-shadow: 0 0 0 2px white, 0 0 0 4px rgba(16, 185, 129, 0.3);
      }
      
      .status-indicator.active {
        background: var(--success);
        box-shadow: 0 0 0 2px white, 0 0 0 4px rgba(16, 185, 129, 0.3);
      }
      
      .course-stats {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 1rem;
        margin-bottom: 1.5rem;
        padding: 1rem;
        background: white;
        border-radius: var(--radius-md);
        border: 1px solid var(--gray-200);
      }
      
      .course-stat {
        text-align: center;
      }
      
      .course-stat .stat-label {
        display: block;
        font-size: 0.75rem;
        color: var(--gray-500);
        text-transform: uppercase;
        margin-bottom: 0.25rem;
      }
      
      .course-stat .stat-value {
        font-size: 1rem;
        font-weight: 600;
        color: var(--gray-900);
      }
      
      .course-stat .stat-value.pending {
        color: var(--warning);
      }
      
      .course-stat .stat-value.completed {
        color: var(--success);
      }
      
      .course-actions {
        display: flex;
        gap: 0.75rem;
      }
      
      .course-actions .btn-sm {
        flex: 1;
      }
      
      .schedule-timeline {
        display: flex;
        flex-direction: column;
        gap: 1rem;
      }
      
      .schedule-item {
        display: flex;
        gap: 1rem;
        padding: 1.25rem;
        background: var(--gray-50);
        border-radius: var(--radius-lg);
        border: 1px solid var(--gray-200);
        transition: var(--transition);
      }
      
      .schedule-item.current {
        background: rgba(67, 56, 202, 0.05);
        border-color: var(--primary);
        box-shadow: 0 0 0 1px rgba(67, 56, 202, 0.1);
      }
      
      .schedule-item.upcoming {
        background: rgba(6, 182, 212, 0.05);
        border-color: var(--secondary);
      }
      
      .schedule-item:hover {
        box-shadow: var(--shadow-md);
      }
      
      .schedule-time {
        display: flex;
        flex-direction: column;
        align-items: center;
        min-width: 60px;
        flex-shrink: 0;
      }
      
      .time-start {
        font-size: 1.125rem;
        font-weight: 700;
        color: var(--gray-900);
        line-height: 1;
      }
      
      .time-end {
        font-size: 0.75rem;
        color: var(--gray-500);
      }
      
      .schedule-content {
        flex: 1;
        min-width: 0;
      }
      
      .schedule-content h4 {
        font-size: 1rem;
        font-weight: 600;
        color: var(--gray-900);
        margin-bottom: 0.25rem;
      }
      
      .schedule-content p {
        font-size: 0.875rem;
        color: var(--gray-600);
        margin-bottom: 0.5rem;
      }
      
      .schedule-status {
        margin-bottom: 0.5rem;
      }
      
      .status-badge {
        display: inline-block;
        padding: 0.25rem 0.5rem;
        border-radius: var(--radius-full);
        font-size: 0.75rem;
        font-weight: 500;
        text-transform: uppercase;
      }
      
      .status-badge.current {
        background: var(--primary);
        color: white;
      }
      
      .status-badge.upcoming {
        background: var(--secondary);
        color: white;
      }
      
      .status-badge.scheduled {
        background: var(--gray-200);
        color: var(--gray-700);
      }
      
      .status-badge.meeting {
        background: var(--accent);
        color: white;
      }
      
      .schedule-actions {
        display: flex;
        flex-direction: column;
        gap: 0.5rem;
        align-self: flex-start;
      }
      
      .tasks-list {
        display: flex;
        flex-direction: column;
        gap: 1.25rem;
      }
      
      .task-item {
        padding: 1.25rem;
        background: var(--gray-50);
        border-radius: var(--radius-lg);
        border: 1px solid var(--gray-200);
        transition: var(--transition);
      }
      
      .task-item.urgent {
        border-left: 4px solid var(--error);
        background: rgba(239, 68, 68, 0.05);
      }
      
      .task-item:hover {
        box-shadow: var(--shadow-md);
      }
      
      .task-header {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        margin-bottom: 1rem;
        gap: 1rem;
      }
      
      .task-info h4 {
        font-size: 1rem;
        font-weight: 600;
        color: var(--gray-900);
        margin-bottom: 0.25rem;
      }
      
      .task-info p {
        font-size: 0.875rem;
        color: var(--gray-600);
      }
      
      .task-priority {
        flex-shrink: 0;
      }
      
      .priority-badge {
        display: inline-block;
        padding: 0.25rem 0.5rem;
        border-radius: var(--radius-full);
        font-size: 0.75rem;
        font-weight: 500;
        text-transform: uppercase;
      }
      
      .priority-badge.urgent {
        background: var(--error);
        color: white;
      }
      
      .priority-badge.normal {
        background: var(--warning);
        color: white;
      }
      
      .priority-badge.low {
        background: var(--gray-300);
        color: var(--gray-700);
      }
      
      .task-progress {
        margin-bottom: 1rem;
      }
      
      .progress-info {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 0.5rem;
        font-size: 0.875rem;
        color: var(--gray-600);
      }
      
      .progress-bar {
        height: 8px;
        background: var(--gray-200);
        border-radius: var(--radius-full);
        overflow: hidden;
      }
      
      .progress-fill {
        height: 100%;
        border-radius: var(--radius-full);
        transition: width 1s ease-out;
      }
      
      .task-actions {
        display: flex;
        gap: 0.75rem;
        flex-wrap: wrap;
      }
      
      .students-attention-list {
        display: flex;
        flex-direction: column;
        gap: 1.25rem;
      }
      
      .student-attention-item {
        display: flex;
        gap: 1rem;
        padding: 1.25rem;
        background: var(--gray-50);
        border-radius: var(--radius-lg);
        border: 1px solid var(--gray-200);
        transition: var(--transition);
      }
      
      .student-attention-item.positive {
        background: rgba(16, 185, 129, 0.05);
        border-color: var(--success);
      }
      
      .student-attention-item:hover {
        box-shadow: var(--shadow-md);
      }
      
      .student-avatar {
        width: 50px;
        height: 50px;
        background: var(--primary);
        color: white;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.25rem;
        flex-shrink: 0;
      }
      
      .student-attention-item.positive .student-avatar {
        background: var(--success);
      }
      
      .student-info {
        flex: 1;
        min-width: 0;
      }
      
      .student-info h4 {
        font-size: 1rem;
        font-weight: 600;
        color: var(--gray-900);
        margin-bottom: 0.25rem;
      }
      
      .student-info p {
        font-size: 0.875rem;
        color: var(--gray-600);
        margin-bottom: 0.75rem;
      }
      
      .attention-reasons {
        display: flex;
        flex-wrap: wrap;
        gap: 0.5rem;
      }
      
      .reason-tag {
        display: inline-block;
        padding: 0.25rem 0.5rem;
        border-radius: var(--radius-md);
        font-size: 0.75rem;
        font-weight: 500;
      }
      
      .reason-tag.attendance {
        background: rgba(239, 68, 68, 0.1);
        color: var(--error);
      }
      
      .reason-tag.grades {
        background: rgba(245, 158, 11, 0.1);
        color: var(--warning);
      }
      
      .reason-tag.behavior {
        background: rgba(139, 92, 246, 0.1);
        color: var(--accent);
      }
      
      .reason-tag.participation {
        background: rgba(59, 130, 246, 0.1);
        color: var(--info);
      }
      
      .reason-tag.homework {
        background: rgba(245, 158, 11, 0.1);
        color: var(--warning);
      }
      
      .reason-tag.excellence {
        background: rgba(16, 185, 129, 0.1);
        color: var(--success);
      }
      
      .reason-tag.leadership {
        background: rgba(6, 182, 212, 0.1);
        color: var(--secondary);
      }
      
      .student-actions {
        display: flex;
        flex-direction: column;
        gap: 0.5rem;
        align-self: flex-start;
      }
      
      @media (max-width: 768px) {
        .courses-grid {
          grid-template-columns: 1fr;
        }
        
        .course-stats {
          grid-template-columns: 1fr;
          gap: 0.75rem;
        }
        
        .course-actions {
          flex-direction: column;
        }
        
        .task-header {
          flex-direction: column;
          align-items: flex-start;
          gap: 0.5rem;
        }
        
        .task-actions {
          flex-direction: column;
        }
        
        .student-attention-item {
          flex-direction: column;
          align-items: flex-start;
        }
        
        .student-actions {
          flex-direction: row;
          width: 100%;
        }
        
        .student-actions .btn-sm {
          flex: 1;
        }
        
        .schedule-item {
          flex-direction: column;
          gap: 0.75rem;
        }
        
        .schedule-time {
          flex-direction: row;
          justify-content: space-between;
          min-width: auto;
          width: 100%;
        }
        
        .schedule-actions {
          flex-direction: row;
          align-self: stretch;
        }
        
        .schedule-actions .btn-icon {
          flex: 1;
        }
      }
    </style>
  `
}

/**
 * Genera el contenido del dashboard para el Padre de Familia
 * @returns {string} - HTML del dashboard
 */
function generatePadreDashboard() {
  const children = currentUser.children || ["Hijo/a"]

  return `
    <div class="dashboard-welcome">
      <h2>Bienvenido, ${currentUser.name}</h2>
      <p>Mantente al día con el progreso académico de ${children.length > 1 ? "tus hijos" : "tu hijo/a"}.</p>
    </div>
    
    <div class="dashboard-stats">
      <div class="stat-card">
        <div class="stat-icon" style="background: var(--info);">
          <i class="fas fa-user-graduate"></i>
        </div>
        <div class="stat-content">
          <h3>Mis Hijos</h3>
          <p class="stat-value">${children.length}</p>
          <p class="stat-change neutral">Estudiantes</p>
        </div>
      </div>
      
      <div class="stat-card">
        <div class="stat-icon" style="background: var(--success);">
          <i class="fas fa-star"></i>
        </div>
        <div class="stat-content">
          <h3>Promedio General</h3>
          <p class="stat-value">88%</p>
          <p class="stat-change positive">+3% este mes</p>
        </div>
      </div>
      
      <div class="stat-card">
        <div class="stat-icon" style="background: var(--warning);">
          <i class="fas fa-calendar-check"></i>
        </div>
        <div class="stat-content">
          <h3>Asistencia</h3>
          <p class="stat-value">96%</p>
          <p class="stat-change positive">Excelente</p>
        </div>
      </div>
      
      <div class="stat-card">
        <div class="stat-icon" style="background: var(--accent);">
          <i class="fas fa-money-bill-wave"></i>
        </div>
        <div class="stat-content">
          <h3>Pagos Pendientes</h3>
          <p class="stat-value">$0</p>
          <p class="stat-change positive">Al día</p>
        </div>
      </div>
    </div>
    
    <div class="dashboard-grid">
      <div class="dashboard-card">
        <div class="card-header">
          <h3>Mis Hijos</h3>
          <a href="javascript:void(0)" onclick="loadChildrenContent()">Ver detalles completos</a>
        </div>
        <div class="card-content">
          <div class="children-grid">
            <div class="child-card">
              <div class="child-header">
                <div class="child-avatar">
                  <i class="fas fa-user"></i>
                </div>
                <div class="child-info">
                  <h4>${children[0] || "Juan Pérez"}</h4>
                  <p>5° Grado • Sección A</p>
                  <div class="child-status">
                    <span class="status-badge active">Activo</span>
                  </div>
                </div>
              </div>
              
              <div class="child-stats">
                <div class="child-stat">
                  <div class="stat-icon-small" style="background: var(--success);">
                    <i class="fas fa-star"></i>
                  </div>
                  <div class="stat-info">
                    <span class="stat-label">Promedio</span>
                    <span class="stat-value">92%</span>
                  </div>
                </div>
                
                <div class="child-stat">
                  <div class="stat-icon-small" style="background: var(--info);">
                    <i class="fas fa-calendar-check"></i>
                  </div>
                  <div class="stat-info">
                    <span class="stat-label">Asistencia</span>
                    <span class="stat-value">98%</span>
                  </div>
                </div>
                
                <div class="child-stat">
                  <div class="stat-icon-small" style="background: var(--warning);">
                    <i class="fas fa-tasks"></i>
                  </div>
                  <div class="stat-info">
                    <span class="stat-label">Tareas</span>
                    <span class="stat-value">2 pendientes</span>
                  </div>
                </div>
              </div>
              
              <div class="child-recent-grades">
                <h5>Calificaciones Recientes</h5>
                <div class="grades-list">
                  <div class="grade-item">
                    <span class="subject">Matemáticas</span>
                    <span class="grade excellent">95</span>
                  </div>
                  <div class="grade-item">
                    <span class="subject">Ciencias</span>
                    <span class="grade good">88</span>
                  </div>
                  <div class="grade-item">
                    <span class="subject">Literatura</span>
                    <span class="grade excellent">94</span>
                  </div>
                </div>
              </div>
              
              <div class="child-actions">
                <button class="btn-sm btn-primary">Ver calificaciones</button>
                <button class="btn-sm btn-outline">Contactar profesor</button>
              </div>
            </div>
            
            ${
              children.length > 1
                ? `
            <div class="child-card">
              <div class="child-header">
                <div class="child-avatar">
                  <i class="fas fa-user"></i>
                </div>
                <div class="child-info">
                  <h4>${children[1] || "María Pérez"}</h4>
                  <p>3° Grado • Sección B</p>
                  <div class="child-status">
                    <span class="status-badge active">Activa</span>
                  </div>
                </div>
              </div>
              
              <div class="child-stats">
                <div class="child-stat">
                  <div class="stat-icon-small" style="background: var(--success);">
                    <i class="fas fa-star"></i>
                  </div>
                  <div class="stat-info">
                    <span class="stat-label">Promedio</span>
                    <span class="stat-value">85%</span>
                  </div>
                </div>
                
                <div class="child-stat">
                  <div class="stat-icon-small" style="background: var(--info);">
                    <i class="fas fa-calendar-check"></i>
                  </div>
                  <div class="stat-info">
                    <span class="stat-label">Asistencia</span>
                    <span class="stat-value">94%</span>
                  </div>
                </div>
                
                <div class="child-stat">
                  <div class="stat-icon-small" style="background: var(--success);">
                    <i class="fas fa-tasks"></i>
                  </div>
                  <div class="stat-info">
                    <span class="stat-label">Tareas</span>
                    <span class="stat-value">Al día</span>
                  </div>
                </div>
              </div>
              
              <div class="child-recent-grades">
                <h5>Calificaciones Recientes</h5>
                <div class="grades-list">
                  <div class="grade-item">
                    <span class="subject">Matemáticas</span>
                    <span class="grade good">82</span>
                  </div>
                  <div class="grade-item">
                    <span class="subject">Ciencias</span>
                    <span class="grade excellent">90</span>
                  </div>
                  <div class="grade-item">
                    <span class="subject">Arte</span>
                    <span class="grade good">83</span>
                  </div>
                </div>
              </div>
              
              <div class="child-actions">
                <button class="btn-sm btn-primary">Ver calificaciones</button>
                <button class="btn-sm btn-outline">Contactar profesor</button>
              </div>
            </div>
            `
                : ""
            }
          </div>
        </div>
      </div>
      
      <div class="dashboard-card">
        <div class="card-header">
          <h3>Próximos Eventos y Tareas</h3>
          <a href="javascript:void(0)" onclick="loadEventsContent()">Ver calendario completo</a>
        </div>
        <div class="card-content">
          <div class="upcoming-events">
            <div class="event-item urgent">
              <div class="event-date">
                <span class="event-day">16</span>
                <span class="event-month">Jun</span>
              </div>
              <div class="event-content">
                <div class="event-header">
                  <h4>Examen de Matemáticas</h4>
                  <span class="event-type">Juan Pérez • 5°A</span>
                </div>
                <p>Álgebra básica y fracciones</p>
                <div class="event-status">
                  <span class="priority-badge urgent">Mañana</span>
                </div>
              </div>
              <div class="event-actions">
                <button class="btn-icon" title="Recordar a Juan">
                  <i class="fas fa-bell"></i>
                </button>
              </div>
            </div>
            
            <div class="event-item">
              <div class="event-date">
                <span class="event-day">18</span>
                <span class="event-month">Jun</span>
              </div>
              <div class="event-content">
                <div class="event-header">
                  <h4>Entrega de Proyecto</h4>
                  <span class="event-type">Juan Pérez • Ciencias</span>
                </div>
                <p>Sistema Solar - Maqueta</p>
                <div class="event-status">
                  <span class="priority-badge normal">En 3 días</span>
                </div>
              </div>
              <div class="event-actions">
                <button class="btn-icon" title="Ver detalles">
                  <i class="fas fa-eye"></i>
                </button>
              </div>
            </div>
            
            <div class="event-item">
              <div class="event-date">
                <span class="event-day">20</span>
                <span class="event-month">Jun</span>
              </div>
              <div class="event-content">
                <div class="event-header">
                  <h4>Reunión de Padres</h4>
                  <span class="event-type">5° Grado • Salón de Actos</span>
                </div>
                <p>Evaluación del trimestre</p>
                <div class="event-status">
                  <span class="priority-badge normal">En 5 días</span>
                </div>
              </div>
              <div class="event-actions">
                <button class="btn-icon" title="Confirmar asistencia">
                  <i class="fas fa-check"></i>
                </button>
              </div>
            </div>
            
            ${
              children.length > 1
                ? `
            <div class="event-item">
              <div class="event-date">
                <span class="event-day">22</span>
                <span class="event-month">Jun</span>
              </div>
              <div class="event-content">
                <div class="event-header">
                  <h4>Presentación de Arte</h4>
                  <span class="event-type">María Pérez • 3°B</span>
                </div>
                <p>Exposición de trabajos del trimestre</p>
                <div class="event-status">
                  <span class="priority-badge low">En 1 semana</span>
                </div>
              </div>
              <div class="event-actions">
                <button class="btn-icon" title="Ver detalles">
                  <i class="fas fa-eye"></i>
                </button>
              </div>
            </div>
            `
                : ""
            }
          </div>
        </div>
      </div>
    </div>
    
    <div class="dashboard-grid">
      <div class="dashboard-card">
        <div class="card-header">
          <h3>Comunicaciones Recientes</h3>
          <a href="javascript:void(0)" onclick="loadCommunicationContent()">Ver todas</a>
        </div>
        <div class="card-content">
          <div class="communications-list">
            <div class="communication-item unread">
              <div class="communication-icon">
                <i class="fas fa-user-tie"></i>
              </div>
              <div class="communication-content">
                <div class="communication-header">
                  <h4>Prof. María Rodríguez</h4>
                  <span class="communication-time">Hace 2 horas</span>
                </div>
                <div class="communication-subject">
                  <strong>Excelente progreso en Matemáticas</strong>
                </div>
                <p>Juan ha mostrado una mejora significativa en álgebra. Felicitaciones por el apoyo en casa.</p>
                <div class="communication-actions">
                  <button class="btn-sm btn-primary">Responder</button>
                  <button class="btn-sm btn-outline">Marcar como leído</button>
                </div>
              </div>
            </div>
            
            <div class="communication-item">
              <div class="communication-icon">
                <i class="fas fa-school"></i>
              </div>
              <div class="communication-content">
                <div class="communication-header">
                  <h4>Dirección Académica</h4>
                  <span class="communication-time">Ayer</span>
                </div>
                <div class="communication-subject">
                  <strong>Recordatorio: Reunión de Padres</strong>
                </div>
                <p>Les recordamos la reunión del 20 de junio a las 4:00 PM para evaluar el progreso del trimestre.</p>
                <div class="communication-actions">
                  <button class="btn-sm btn-success">Confirmar asistencia</button>
                  <button class="btn-sm btn-outline">Ver detalles</button>
                </div>
              </div>
            </div>
            
            <div class="communication-item">
              <div class="communication-icon">
                <i class="fas fa-money-bill-wave"></i>
              </div>
              <div class="communication-content">
                <div class="communication-header">
                  <h4>Departamento de Finanzas</h4>
                  <span class="communication-time">Hace 3 días</span>
                </div>
                <div class="communication-subject">
                  <strong>Pago procesado correctamente</strong>
                </div>
                <p>Hemos recibido su pago de $1,200 correspondiente a la mensualidad de junio. Gracias.</p>
                <div class="communication-actions">
                  <button class="btn-sm btn-outline">Ver recibo</button>
                  <button class="btn-sm btn-outline">Descargar PDF</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div class="dashboard-card">
        <div class="card-header">
          <h3>Estado Financiero</h3>
          <a href="javascript:void(0)" onclick="loadPaymentsContent()">Ver historial completo</a>
        </div>
        <div class="card-content">
          <div class="financial-summary">
            <div class="financial-item">
              <div class="financial-icon" style="background: var(--success);">
                <i class="fas fa-check-circle"></i>
              </div>
              <div class="financial-info">
                <h4>Último Pago</h4>
                <p>$1,200 • 1 de Junio, 2024</p>
                <span class="status-badge success">Procesado</span>
              </div>
            </div>
            
            <div class="financial-item">
              <div class="financial-icon" style="background: var(--info);">
                <i class="fas fa-calendar-alt"></i>
              </div>
              <div class="financial-info">
                <h4>Próximo Pago</h4>
                <p>$1,200 • 1 de Julio, 2024</p>
                <span class="status-badge upcoming">Próximo</span>
              </div>
            </div>
            
            <div class="financial-item">
              <div class="financial-icon" style="background: var(--success);">
                <i class="fas fa-shield-alt"></i>
              </div>
              <div class="financial-info">
                <h4>Estado de Cuenta</h4>
                <p>Sin pagos pendientes</p>
                <span class="status-badge success">Al día</span>
              </div>
            </div>
          </div>
          
          <div class="payment-methods">
            <h5>Métodos de Pago Disponibles</h5>
            <div class="payment-options">
              <div class="payment-option">
                <div class="payment-icon">
                  <i class="fas fa-credit-card"></i>
                </div>
                <span>Tarjeta de Crédito</span>
              </div>
              <div class="payment-option">
                <div class="payment-icon">
                  <i class="fas fa-university"></i>
                </div>
                <span>Transferencia Bancaria</span>
              </div>
              <div class="payment-option">
                <div class="payment-icon">
                  <i class="fas fa-mobile-alt"></i>
                </div>
                <span>Pago Móvil</span>
              </div>
            </div>
          </div>
          
          <div class="quick-actions">
            <button class="btn btn-primary btn-full">
              <i class="fas fa-credit-card"></i>
              Realizar Pago
            </button>
            <button class="btn btn-outline btn-full">
              <i class="fas fa-download"></i>
              Descargar Estado de Cuenta
            </button>
          </div>
        </div>
      </div>
    </div>
    
    <style>
      .children-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
        gap: 1.5rem;
      }
      
      .child-card {
        background: var(--gray-50);
        border-radius: var(--radius-xl);
        padding: 1.5rem;
        border: 1px solid var(--gray-200);
        transition: var(--transition);
      }
      
      .child-card:hover {
        box-shadow: var(--shadow-lg);
        transform: translateY(-2px);
      }
      
      .child-header {
        display: flex;
        align-items: center;
        gap: 1rem;
        margin-bottom: 1.5rem;
      }
      
      .child-avatar {
        width: 60px;
        height: 60px;
        background: var(--primary);
        color: white;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.5rem;
        flex-shrink: 0;
      }
      
      .child-info {
        flex: 1;
      }
      
      .child-info h4 {
        font-size: 1.25rem;
        font-weight: 600;
        color: var(--gray-900);
        margin-bottom: 0.25rem;
      }
      
      .child-info p {
        font-size: 0.875rem;
        color: var(--gray-600);
        margin-bottom: 0.5rem;
      }
      
      .child-status .status-badge {
        background: var(--success);
        color: white;
        padding: 0.25rem 0.5rem;
        border-radius: var(--radius-full);
        font-size: 0.75rem;
        font-weight: 500;
      }
      
      .child-stats {
        display: flex;
        flex-direction: column;
        gap: 1rem;
        margin-bottom: 1.5rem;
        padding: 1rem;
        background: white;
        border-radius: var(--radius-lg);
        border: 1px solid var(--gray-200);
      }
      
      .child-stat {
        display: flex;
        align-items: center;
        gap: 0.75rem;
      }
      
      .stat-icon-small {
        width: 35px;
        height: 35px;
        border-radius: var(--radius-md);
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-size: 0.875rem;
        flex-shrink: 0;
      }
      
      .stat-info {
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex: 1;
      }
      
      .stat-info .stat-label {
        font-size: 0.875rem;
        color: var(--gray-600);
      }
      
      .stat-info .stat-value {
        font-size: 0.875rem;
        font-weight: 600;
        color: var(--gray-900);
      }
      
      .child-recent-grades {
        margin-bottom: 1.5rem;
      }
      
      .child-recent-grades h5 {
        font-size: 1rem;
        font-weight: 600;
        color: var(--gray-900);
        margin-bottom: 0.75rem;
      }
      
      .grades-list {
        display: flex;
        flex-direction: column;
        gap: 0.5rem;
      }
      
      .grade-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 0.5rem 0.75rem;
        background: white;
        border-radius: var(--radius-md);
        border: 1px solid var(--gray-200);
      }
      
      .grade-item .subject {
        font-size: 0.875rem;
        color: var(--gray-700);
      }
      
      .grade-item .grade {
        font-size: 0.875rem;
        font-weight: 600;
        padding: 0.25rem 0.5rem;
        border-radius: var(--radius-md);
      }
      
      .grade.excellent {
        background: var(--success);
        color: white;
      }
      
      .grade.good {
        background: var(--info);
        color: white;
      }
      
      .grade.average {
        background: var(--warning);
        color: white;
      }
      
      .grade.poor {
        background: var(--error);
        color: white;
      }
      
      .child-actions {
        display: flex;
        gap: 0.75rem;
      }
      
      .child-actions .btn-sm {
        flex: 1;
      }
      
      .upcoming-events {
        display: flex;
        flex-direction: column;
        gap: 1rem;
      }
      
      .event-item {
        display: flex;
        gap: 1rem;
        padding: 1rem;
        background: var(--gray-50);
        border-radius: var(--radius-lg);
        border: 1px solid var(--gray-200);
        transition: var(--transition);
      }
      
      .event-item.urgent {
        border-left: 4px solid var(--error);
        background: rgba(239, 68, 68, 0.05);
      }
      
      .event-item:hover {
        box-shadow: var(--shadow-md);
      }
      
      .event-date {
        width: 50px;
        height: 50px;
        background: var(--primary);
        color: white;
        border-radius: var(--radius-lg);
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
      }
      
      .event-day {
        font-size: 1rem;
        font-weight: 700;
        line-height: 1;
      }
      
      .event-month {
        font-size: 0.625rem;
        text-transform: uppercase;
        opacity: 0.9;
      }
      
      .event-content {
        flex: 1;
        min-width: 0;
      }
      
      .event-header {
        margin-bottom: 0.25rem;
      }
      
      .event-header h4 {
        font-size: 1rem;
        font-weight: 600;
        color: var(--gray-900);
        margin-bottom: 0.125rem;
      }
      
      .event-type {
        font-size: 0.75rem;
        color: var(--gray-500);
        text-transform: uppercase;
        font-weight: 500;
      }
      
      .event-content p {
        font-size: 0.875rem;
        color: var(--gray-600);
        margin-bottom: 0.5rem;
      }
      
      .event-actions {
        display: flex;
        align-items: flex-start;
      }
      
      .communication-item.unread {
        background: rgba(67, 56, 202, 0.05);
        border-left: 4px solid var(--primary);
      }
      
      .communication-subject {
        margin-bottom: 0.5rem;
      }
      
      .communication-subject strong {
        font-size: 0.875rem;
        color: var(--gray-900);
      }
      
      .financial-summary {
        display: flex;
        flex-direction: column;
        gap: 1rem;
        margin-bottom: 1.5rem;
      }
      
      .financial-item {
        display: flex;
        align-items: center;
        gap: 1rem;
        padding: 1rem;
        background: var(--gray-50);
        border-radius: var(--radius-lg);
        border: 1px solid var(--gray-200);
      }
      
      .financial-icon {
        width: 45px;
        height: 45px;
        border-radius: var(--radius-lg);
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-size: 1.125rem;
        flex-shrink: 0;
      }
      
      .financial-info {
        flex: 1;
      }
      
      .financial-info h4 {
        font-size: 1rem;
        font-weight: 600;
        color: var(--gray-900);
        margin-bottom: 0.25rem;
      }
      
      .financial-info p {
        font-size: 0.875rem;
        color: var(--gray-600);
        margin-bottom: 0.5rem;
      }
      
      .status-badge.success {
        background: var(--success);
        color: white;
      }
      
      .status-badge.upcoming {
        background: var(--info);
        color: white;
      }
      
      .payment-methods {
        margin-bottom: 1.5rem;
      }
      
      .payment-methods h5 {
        font-size: 1rem;
        font-weight: 600;
        color: var(--gray-900);
        margin-bottom: 0.75rem;
      }
      
      .payment-options {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 0.75rem;
      }
      
      .payment-option {
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 0.5rem;
        padding: 1rem;
        background: var(--gray-50);
        border-radius: var(--radius-lg);
        border: 1px solid var(--gray-200);
        transition: var(--transition);
        cursor: pointer;
      }
      
      .payment-option:hover {
        background: var(--gray-100);
        border-color: var(--primary);
      }
      
      .payment-icon {
        width: 35px;
        height: 35px;
        background: var(--primary);
        color: white;
        border-radius: var(--radius-md);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1rem;
      }
      
      .payment-option span {
        font-size: 0.75rem;
        color: var(--gray-700);
        text-align: center;
        font-weight: 500;
      }
      
      .quick-actions {
        display: flex;
        flex-direction: column;
        gap: 0.75rem;
      }
      
      @media (max-width: 768px) {
        .children-grid {
          grid-template-columns: 1fr;
        }
        
        .child-actions {
          flex-direction: column;
        }
        
        .payment-options {
          grid-template-columns: 1fr;
        }
        
        .event-item {
          flex-direction: column;
          gap: 0.75rem;
        }
        
        .event-date {
          align-self: flex-start;
        }
        
        .event-actions {
          align-self: stretch;
        }
        
        .event-actions .btn-icon {
          flex: 1;
        }
      }
    </style>
  `
}

/**
 * Genera el contenido del dashboard para el Contable
 * @returns {string} - HTML del dashboard
 */
function generateContableDashboard() {
  return `
    <div class="dashboard-welcome">
      <h2>Bienvenido, ${currentUser.name}</h2>
      <p>Gestiona las finanzas de ${currentUser.institution || 'la institución'} con herramientas contables avanzadas.</p>
    </div>
    
    <div class="dashboard-stats">
      <div class="stat-card">
        <div class="stat-icon" style="background: var(--success);">
          <i class="fas fa-dollar-sign"></i>
        </div>
        <div class="stat-content">
          <h3>Ingresos del Mes</h3>
          <p class="stat-value">$54,200</p>
          <p class="stat-change positive">+8.5% vs mes anterior</p>
        </div>
      </div>
      
      <div class="stat-card">
        <div class="stat-icon" style="background: var(--error);">
          <i class="fas fa-credit-card"></i>
        </div>
        <div class="stat-content">
          <h3>Gastos del Mes</h3>
          <p class="stat-value">$18,750</p>
          <p class="stat-change negative">+12% vs mes anterior</p>
        </div>
      </div>
      
      <div class="stat-card">
        <div class="stat-icon" style="background: var(--warning);">
          <i class="fas fa-hand-holding-usd"></i>
        </div>
        <div class="stat-content">
          <h3>Cuentas por Cobrar</h3>
          <p class="stat-value">$12,400</p>
          <p class="stat-change neutral">23 facturas pendientes</p>
        </div>
      </div>
      
      <div class="stat-card">
        <div class="stat-icon" style="background: var(--info);">
          <i class="fas fa-users"></i>
        </div>
        <div class="stat-content">
          <h3>Nómina Mensual</h3>
          <p class="stat-value">$28,500</p>
          <p class="stat-change neutral">32 empleados</p>
        </div>
      </div>
    </div>
    
    <div class="dashboard-grid">
      <div class="dashboard-card">
        <div class="card-header">
          <h3>Flujo de Caja</h3>
          <div class="card-actions">
            <select class="select-sm">
              <option>Últimos 6 meses</option>
              <option>Último año</option>
              <option>Últimos 2 años</option>
            </select>
          </div>
        </div>
        <div class="card-content">
          <div class="chart-container" id="cashFlowChart">
            <!-- Gráfico se inicializará con JavaScript -->
          </div>
          <div class="cash-flow-summary">
            <div class="flow-item positive">
              <div class="flow-icon">
                <i class="fas fa-arrow-up"></i>
              </div>
              <div class="flow-info">
                <span class="flow-label">Ingresos</span>
                <span class="flow-amount">$54,200</span>
              </div>
            </div>
            <div class="flow-item negative">
              <div class="flow-icon">
                <i class="fas fa-arrow-down"></i>
              </div>
              <div class="flow-info">
                <span class="flow-label">Gastos</span>
                <span class="flow-amount">$18,750</span>
              </div>
            </div>
            <div class="flow-item neutral">
              <div class="flow-icon">
                <i class="fas fa-equals"></i>
              </div>
              <div class="flow-info">
                <span class="flow-label">Flujo Neto</span>
                <span class="flow-amount">$35,450</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div class="dashboard-card">
        <div class="card-header">
          <h3>Facturas Pendientes de Cobro</h3>
          <a href="javascript:void(0)" onclick="loadReceivablesContent()">Ver todas</a>
        </div>
        <div class="card-content">
          <div class="pending-invoices">
            <div class="invoice-item urgent">
              <div class="invoice-info">
                <div class="invoice-header">
                  <h4>Factura #2024-156</h4>
                  <span class="invoice-amount">$2,400</span>
                </div>
                <p>Juan Pérez • Mensualidad Mayo</p>
                <div class="invoice-status">
                  <span class="status-badge overdue">Vencida - 15 días</span>
                </div>
              </div>
              <div class="invoice-actions">
                <button class="btn-sm btn-warning">Enviar recordatorio</button>
                <button class="btn-sm btn-outline">Ver detalles</button>
              </div>
            </div>
            
            <div class="invoice-item urgent">
              <div class="invoice-info">
                <div class="invoice-header">
                  <h4>Factura #2024-162</h4>
                  <span class="invoice-amount">$1,800</span>
                </div>
                <p>María González • Mensualidad Mayo</p>
                <div class="invoice-status">
                  <span class="status-badge overdue">Vencida - 8 días</span>
                </div>
              </div>
              <div class="invoice-actions">
                <button class="btn-sm btn-warning">Enviar recordatorio</button>
                <button class="btn-sm btn-outline">Ver detalles</button>
              </div>
            </div>
            
            <div class="invoice-item">
              <div class="invoice-info">
                <div class="invoice-header">
                  <h4>Factura #2024-178</h4>
                  <span class="invoice-amount">$2,200</span>
                </div>
                <p>Carlos Mendoza • Mensualidad Junio</p>
                <div class="invoice-status">
                  <span class="status-badge due-soon">Vence en 3 días</span>
                </div>
              </div>
              <div class="invoice-actions">
                <button class="btn-sm btn-info">Recordatorio preventivo</button>
                <button class="btn-sm btn-outline">Ver detalles</button>
              </div>
            </div>
            
            <div class="invoice-item">
              <div class="invoice-info">
                <div class="invoice-header">
                  <h4>Factura #2024-185</h4>
                  <span class="invoice-amount">$1,950</span>
                </div>
                <p>Ana Rodríguez • Mensualidad Junio</p>
                <div class="invoice-status">
                  <span class="status-badge current">Vence en 10 días</span>
                </div>
              </div>
              <div class="invoice-actions">
                <button class="btn-sm btn-outline">Ver detalles</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <div class="dashboard-grid">
      <div class="dashboard-card">
        <div class="card-header">
          <h3>Gastos por Categoría</h3>
          <a href="javascript:void(0)" onclick="loadExpensesContent()">Ver desglose completo</a>
        </div>
        <div class="card-content">
          <div class="expenses-breakdown">
            <div class="expense-category">
              <div class="category-header">
                <div class="category-info">
                  <div class="category-icon" style="background: var(--primary);">
                    <i class="fas fa-users"></i>
                  </div>
                  <div class="category-details">
                    <h4>Nómina</h4>
                    <p>32 empleados</p>
                  </div>
                </div>
                <div class="category-amount">
                  <span class="amount">$28,500</span>
                  <span class="percentage">60.8%</span>
                </div>
              </div>
              <div class="category-bar">
                <div class="category-fill" style="width: 60.8%; background: var(--primary);"></div>
              </div>
            </div>
            
            <div class="expense-category">
              <div class="category-header">
                <div class="category-info">
                  <div class="category-icon" style="background: var(--warning);">
                    <i class="fas fa-tools"></i>
                  </div>
                  <div class="category-details">
                    <h4>Mantenimiento</h4>
                    <p>Instalaciones y equipos</p>
                  </div>
                </div>
                <div class="category-amount">
                  <span class="amount">$8,200</span>
                  <span class="percentage">17.5%</span>
                </div>
              </div>
              <div class="category-bar">
                <div class="category-fill" style="width: 17.5%; background: var(--warning);"></div>
              </div>
            </div>
            
            <div class="expense-category">
              <div class="category-header">
                <div class="category-info">
                  <div class="category-icon" style="background: var(--info);">
                    <i class="fas fa-lightbulb"></i>
                  </div>
                  <div class="category-details">
                    <h4>Servicios</h4>
                    <p>Electricidad, agua, internet</p>
                  </div>
                </div>
                <div class="category-amount">
                  <span class="amount">$4,800</span>
                  <span class="percentage">10.2%</span>
                </div>
              </div>
              <div class="category-bar">
                <div class="category-fill" style="width: 10.2%; background: var(--info);"></div>
              </div>
            </div>
            
            <div class="expense-category">
              <div class="category-header">
                <div class="category-info">
                  <div class="category-icon" style="background: var(--success);">
                    <i class="fas fa-book"></i>
                  </div>
                  <div class="category-details">
                    <h4>Material Educativo</h4>
                    <p>Libros, suministros</p>
                  </div>
                </div>
                <div class="category-amount">
                  <span class="amount">$3,200</span>
                  <span class="percentage">6.8%</span>
                </div>
              </div>
              <div class="category-bar">
                <div class="category-fill" style="width: 6.8%; background: var(--success);"></div>
              </div>
            </div>
            
            <div class="expense-category">
              <div class="category-header">
                <div class="category-info">
                  <div class="category-icon" style="background: var(--accent);">
                    <i class="fas fa-ellipsis-h"></i>
                  </div>
                  <div class="category-details">
                    <h4>Otros</h4>
                    <p>Gastos varios</p>
                  </div>
                </div>
                <div class="category-amount">
                  <span class="amount">$2,250</span>
                  <span class="percentage">4.7%</span>
                </div>
              </div>
              <div class="category-bar">
                <div class="category-fill" style="width: 4.7%; background: var(--accent);"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div class="dashboard-card">
        <div class="card-header">
          <h3>Resumen de Nómina</h3>
          <a href="javascript:void(0)" onclick="loadPayrollContent()">Gestionar nómina</a>
        </div>
        <div class="card-content">
          <div class="payroll-summary">
            <div class="payroll-overview">
              <div class="payroll-stat">
                <div class="stat-icon" style="background: var(--primary);">
                  <i class="fas fa-users"></i>
                </div>
                <div class="stat-info">
                  <span class="stat-value">32</span>
                  <span class="stat-label">Empleados</span>
                </div>
              </div>
              
              <div class="payroll-stat">
                <div class="stat-icon" style="background: var(--success);">
                  <i class="fas fa-dollar-sign"></i>
                </div>
                <div class="stat-info">
                  <span class="stat-value">$28,500</span>
                  <span class="stat-label">Total Nómina</span>
                </div>
              </div>
              
              <div class="payroll-stat">
                <div class="stat-icon" style="background: var(--warning);">
                  <i class="fas fa-calendar"></i>
                </div>
                <div class="stat-info">
                  <span class="stat-value">30</span>
                  <span class="stat-label">Junio</span>
                </div>
              </div>
            </div>
            
            <div class="payroll-breakdown">
              <h5>Desglose por Departamento</h5>
              <div class="department-list">
                <div class="department-item">
                  <div class="department-info">
                    <span class="department-name">Docentes</span>
                    <span class="employee-count">18 empleados</span>
                  </div>
                  <span class="department-amount">$18,200</span>
                </div>
                
                <div class="department-item">
                  <div class="department-info">
                    <span class="department-name">Administrativo</span>
                    <span class="employee-count">8 empleados</span>
                  </div>
                  <span class="department-amount">$6,800</span>
                </div>
                
                <div class="department-item">
                  <div class="department-info">
                    <span class="department-name">Servicios</span>
                    <span class="employee-count">4 empleados</span>
                  </div>
                  <span class="department-amount">$2,200</span>
                </div>
                
                <div class="department-item">
                  <div class="department-info">
                    <span class="department-name">Dirección</span>
                    <span class="employee-count">2 empleados</span>
                  </div>
                  <span class="department-amount">$1,300</span>
                </div>
              </div>
            </div>
            
            <div class="payroll-actions">
              <button class="btn btn-primary btn-full">
                <i class="fas fa-calculator"></i>
                Procesar Nómina de Julio
              </button>
              <div class="action-buttons">
                <button class="btn-sm btn-outline">
                  <i class="fas fa-download"></i>
                  Exportar Reporte
                </button>
                <button class="btn-sm btn-outline">
                  <i class="fas fa-print"></i>
                  Imprimir Recibos
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <div class="dashboard-grid">
      <div class="dashboard-card">
        <div class="card-header">
          <h3>Transacciones Recientes</h3>
          <a href="javascript:void(0)" onclick="loadAccountingContent()">Ver libro mayor</a>
        </div>
        <div class="card-content">
          <div class="transactions-list">
            <div class="transaction-item income">
              <div class="transaction-icon">
                <i class="fas fa-arrow-up"></i>
              </div>
              <div class="transaction-info">
                <h4>Pago de Mensualidad</h4>
                <p>Juan Pérez • Factura #2024-189</p>
                <span class="transaction-date">Hoy, 2:30 PM</span>
              </div>
              <div class="transaction-amount positive">
                +$2,400
              </div>
            </div>
            
            <div class="transaction-item income">
              <div class="transaction-icon">
                <i class="fas fa-arrow-up"></i>
              </div>
              <div class="transaction-info">
                <h4>Pago de Mensualidad</h4>
                <p>María González • Factura #2024-187</p>
                <span class="transaction-date">Hoy, 11:15 AM</span>
              </div>
              <div class="transaction-amount positive">
                +$1,800
              </div>
            </div>
            
            <div class="transaction-item expense">
              <div class="transaction-icon">
                <i class="fas fa-arrow-down"></i>
              </div>
              <div class="transaction-info">
                <h4>Pago de Servicios</h4>
                <p>Electricidad • Factura Mayo</p>
                <span class="transaction-date">Ayer, 4:45 PM</span>
              </div>
              <div class="transaction-amount negative">
                -$1,200
              </div>
            </div>
            
            <div class="transaction-item expense">
              <div class="transaction-icon">
                <i class="fas fa-arrow-down"></i>
              </div>
              <div class="transaction-info">
                <h4>Compra de Material</h4>
                <p>Suministros de oficina</p>
                <span class="transaction-date">Ayer, 10:20 AM</span>
              </div>
              <div class="transaction-amount negative">
                -$450
              </div>
            </div>
            
            <div class="transaction-item income">
              <div class="transaction-icon">
                <i class="fas fa-arrow-up"></i>
              </div>
              <div class="transaction-info">
                <h4>Pago de Inscripción</h4>
                <p>Carlos Mendoza • Nuevo estudiante</p>
                <span class="transaction-date">Hace 2 días</span>
              </div>
              <div class="transaction-amount positive">
                +$500
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div class="dashboard-card">
        <div class="card-header">
          <h3>Indicadores Financieros</h3>
          <div class="card-actions">
            <button class="btn-icon" onclick="refreshFinancialIndicators()">
              <i class="fas fa-sync-alt"></i>
            </button>
          </div>
        </div>
        <div class="card-content">
          <div class="financial-indicators">
            <div class="indicator-item">
              <div class="indicator-header">
                <h4>Liquidez Corriente</h4>
                <span class="indicator-value good">2.4</span>
              </div>
              <div class="indicator-description">
                <p>Capacidad para cubrir obligaciones a corto plazo</p>
                <span class="indicator-status good">Excelente</span>
              </div>
            </div>
            
            <div class="indicator-item">
              <div class="indicator-header">
                <h4>Margen de Ganancia</h4>
                <span class="indicator-value good">65.4%</span>
              </div>
              <div class="indicator-description">
                <p>Porcentaje de ingresos que se convierte en ganancia</p>
                <span class="indicator-status good">Muy bueno</span>
              </div>
            </div>
            
            <div class="indicator-item">
              <div class="indicator-header">
                <h4>Días de Cobro</h4>
                <span class="indicator-value warning">18</span>
              </div>
              <div class="indicator-description">
                <p>Tiempo promedio para cobrar facturas</p>
                <span class="indicator-status warning">Mejorable</span>
              </div>
            </div>
            
            <div class="indicator-item">
              <div class="indicator-header">
                <h4>Crecimiento Mensual</h4>
                <span class="indicator-value good">+8.5%</span>
              </div>
              <div class="indicator-description">
                <p>Crecimiento de ingresos vs mes anterior</p>
                <span class="indicator-status good">En crecimiento</span>
              </div>
            </div>
          </div>
          
          <div class="quick-reports">
            <h5>Reportes Rápidos</h5>
            <div class="report-buttons">
              <button class="btn-sm btn-outline">
                <i class="fas fa-chart-bar"></i>
                Estado de Resultados
              </button>
              <button class="btn-sm btn-outline">
                <i class="fas fa-balance-scale"></i>
                Balance General
              </button>
              <button class="btn-sm btn-outline">
                <i class="fas fa-money-bill-wave"></i>
                Flujo de Efectivo
              </button>
              <button class="btn-sm btn-outline">
                <i class="fas fa-file-invoice"></i>
                Cuentas por Cobrar
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <style>
      .cash-flow-summary {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 1rem;
        margin-top: 1rem;
        padding-top: 1rem;
        border-top: 1px solid var(--gray-200);
      }
      
      .flow-item {
        display: flex;
        align-items: center;
        gap: 0.75rem;
        padding: 1rem;
        border-radius: var(--radius-lg);
        border: 1px solid var(--gray-200);
      }
      
      .flow-item.positive {
        background: rgba(16, 185, 129, 0.05);
        border-color: var(--success);
      }
      
      .flow-item.negative {
        background: rgba(239, 68, 68, 0.05);
        border-color: var(--error);
      }
      
      .flow-item.neutral {
        background: var(--gray-50);
      }
      
      .flow-icon {
        width: 35px;
        height: 35px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-size: 0.875rem;
      }
      
      .flow-item.positive .flow-icon {
        background: var(--success);
      }
      
      .flow-item.negative .flow-icon {
        background: var(--error);
      }
      
      .flow-item.neutral .flow-icon {
        background: var(--gray-500);
      }
      
      .flow-info {
        display: flex;
        flex-direction: column;
      }
      
      .flow-label {
        font-size: 0.75rem;
        color: var(--gray-600);
        text-transform: uppercase;
        font-weight: 500;
      }
      
      .flow-amount {
        font-size: 1rem;
        font-weight: 700;
        color: var(--gray-900);
      }
      
      .pending-invoices {
        display: flex;
        flex-direction: column;
        gap: 1rem;
      }
      
      .invoice-item {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        gap: 1rem;
        padding: 1.25rem;
        background: var(--gray-50);
        border-radius: var(--radius-lg);
        border: 1px solid var(--gray-200);
        transition: var(--transition);
      }
      
      .invoice-item.urgent {
        border-left: 4px solid var(--error);
        background: rgba(239, 68, 68, 0.05);
      }
      
      .invoice-item:hover {
        box-shadow: var(--shadow-md);
      }
      
      .invoice-info {
        flex: 1;
        min-width: 0;
      }
      
      .invoice-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 0.25rem;
      }
      
      .invoice-header h4 {
        font-size: 1rem;
        font-weight: 600;
        color: var(--gray-900);
      }
      
      .invoice-amount {
        font-size: 1.125rem;
        font-weight: 700;
        color: var(--gray-900);
      }
      
      .invoice-info p {
        font-size: 0.875rem;
        color: var(--gray-600);
        margin-bottom: 0.5rem;
      }
      
      .invoice-status {
        margin-bottom: 0.5rem;
      }
      
      .status-badge.overdue {
        background: var(--error);
        color: white;
      }
      
      .status-badge.due-soon {
        background: var(--warning);
        color: white;
      }
      
      .status-badge.current {
        background: var(--info);
        color: white;
      }
      
      .invoice-actions {
        display: flex;
        flex-direction: column;
        gap: 0.5rem;
        flex-shrink: 0;
      }
      
      .expenses-breakdown {
        display: flex;
        flex-direction: column;
        gap: 1.25rem;
      }
      
      .expense-category {
        padding: 1rem;
        background: var(--gray-50);
        border-radius: var(--radius-lg);
        border: 1px solid var(--gray-200);
      }
      
      .category-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 0.75rem;
      }
      
      .category-info {
        display: flex;
        align-items: center;
        gap: 0.75rem;
      }
      
      .category-icon {
        width: 40px;
        height: 40px;
        border-radius: var(--radius-md);
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-size: 1rem;
      }
      
      .category-details h4 {
        font-size: 1rem;
        font-weight: 600;
        color: var(--gray-900);
        margin-bottom: 0.125rem;
      }
      
      .category-details p {
        font-size: 0.75rem;
        color: var(--gray-600);
      }
      
      .category-amount {
        display: flex;
        flex-direction: column;
        align-items: flex-end;
      }
      
      .category-amount .amount {
        font-size: 1.125rem;
        font-weight: 700;
        color: var(--gray-900);
      }
      
      .category-amount .percentage {
        font-size: 0.75rem;
        color: var(--gray-500);
      }
      
      .category-bar {
        height: 6px;
        background: var(--gray-200);
        border-radius: var(--radius-full);
        overflow: hidden;
      }
      
      .category-fill {
        height: 100%;
        border-radius: var(--radius-full);
        transition: width 1s ease-out;
      }
      
      .payroll-summary {
        display: flex;
        flex-direction: column;
        gap: 1.5rem;
      }
      
      .payroll-overview {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 1rem;
      }
      
      .payroll-stat {
        display: flex;
        align-items: center;
        gap: 0.75rem;
        padding:
