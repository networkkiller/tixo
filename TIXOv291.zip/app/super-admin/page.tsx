import Link from "next/link"

export default function SuperAdminPage() {
  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-800">Panel Super Admin</h1>
            <p className="text-gray-600">Administración completa del sistema TIXO</p>
          </div>
          <Link href="/" className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700">
            Volver al inicio
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div className="bg-white p-6 rounded-lg shadow-md border border-gray-200">
            <h2 className="text-xl font-bold mb-4">Colegios</h2>
            <p className="text-gray-600 mb-4">Administración de instituciones educativas</p>
            <div className="bg-gray-100 h-40 rounded-lg flex items-center justify-center text-gray-400">
              Contenido del módulo
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-md border border-gray-200">
            <h2 className="text-xl font-bold mb-4">Usuarios</h2>
            <p className="text-gray-600 mb-4">Gestión de usuarios del sistema</p>
            <div className="bg-gray-100 h-40 rounded-lg flex items-center justify-center text-gray-400">
              Contenido del módulo
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-md border border-gray-200">
            <h2 className="text-xl font-bold mb-4">Suscripciones</h2>
            <p className="text-gray-600 mb-4">Control de planes y pagos</p>
            <div className="bg-gray-100 h-40 rounded-lg flex items-center justify-center text-gray-400">
              Contenido del módulo
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
