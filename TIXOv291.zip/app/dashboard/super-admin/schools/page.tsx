"use client"

import { useState } from "react"
import { Header } from "@/components/dashboard/header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import {
  Building,
  Plus,
  Search,
  Filter,
  Download,
  Edit,
  Eye,
  Trash2,
  Users,
  GraduationCap,
  Calendar,
  MapPin,
  Phone,
  Mail,
  Upload,
  BarChart3,
  DollarSign,
  AlertTriangle,
  CheckCircle,
  Globe,
  Shield,
  CreditCard,
  UserCheck,
  Settings,
  TrendingUp,
  Activity,
  Map,
  Crown,
  Star,
  Calculator,
  Clock,
  PieChart,
} from "lucide-react"

// Datos de ejemplo para colegios del MINERD
const minerdSchools = [
  {
    id: "001",
    name: "Colegio San Patricio",
    code: "SP-001-2024",
    address: "Av. Principal 123, Santo Domingo Este",
    district: "Distrito Educativo 15-03",
    municipality: "Santo Domingo Este",
    province: "Santo Domingo",
    region: "Región Metropolitana",
  },
  {
    id: "002",
    name: "Instituto Tecnológico Avanzado",
    code: "ITA-002-2024",
    address: "Calle Tecnología 456, Santiago",
    district: "Distrito Educativo 08-01",
    municipality: "Santiago",
    province: "Santiago",
    region: "Región Norte",
  },
  {
    id: "003",
    name: "Escuela Nueva Era",
    code: "ENE-003-2024",
    address: "Plaza Central 789, La Vega",
    district: "Distrito Educativo 06-02",
    municipality: "La Vega",
    province: "La Vega",
    region: "Región Central",
  },
]

// Datos de ejemplo de colegios registrados
const schoolsData = [
  {
    id: 1,
    name: "Colegio San Patricio",
    code: "SP-001-2024",
    status: "Activo",
    subscriptionType: "Premium",
    expirationDate: "2024-12-15",
    paymentStatus: "Al día",
    totalStudents: 487,
    totalStaff: 32,
    estimatedUsers: 519,
    activeUsers: 498,
    monthlyPayment: 2595, // 519 * 5
    costPerUser: 5,
    director: { name: "Carlos Rodríguez", phone: "+1 234-567-8900" },
    address: "Av. Principal 123, Santo Domingo Este",
    province: "Santo Domingo",
    region: "Región Metropolitana",
    district: "Distrito Educativo 15-03",
    municipality: "Santo Domingo Este",
    activationDate: "2024-01-15",
    email: "admin@sanpatricio.edu",
    logo: "/placeholder.svg?height=60&width=60",
  },
  {
    id: 2,
    name: "Instituto Tecnológico Avanzado",
    code: "ITA-002-2024",
    status: "Activo",
    subscriptionType: "Básica",
    expirationDate: "2024-07-15",
    paymentStatus: "Vencido",
    totalStudents: 312,
    totalStaff: 28,
    estimatedUsers: 340,
    activeUsers: 325,
    monthlyPayment: 1020, // 340 * 3
    costPerUser: 3,
    director: { name: "Ana Martínez", phone: "+1 234-567-8901" },
    address: "Calle Tecnología 456, Santiago",
    province: "Santiago",
    region: "Región Norte",
    district: "Distrito Educativo 08-01",
    municipality: "Santiago",
    activationDate: "2024-02-20",
    email: "admin@tecnoavanzado.edu",
    logo: "/placeholder.svg?height=60&width=60",
  },
  {
    id: 3,
    name: "Escuela Nueva Era",
    code: "ENE-003-2024",
    status: "Inactivo",
    subscriptionType: "Gratuita",
    expirationDate: "2024-08-30",
    paymentStatus: "Al día",
    totalStudents: 156,
    totalStaff: 18,
    estimatedUsers: 174,
    activeUsers: 0,
    monthlyPayment: 0,
    costPerUser: 0,
    director: { name: "Roberto Sánchez", phone: "+1 234-567-8902" },
    address: "Plaza Central 789, La Vega",
    province: "La Vega",
    region: "Región Central",
    district: "Distrito Educativo 06-02",
    municipality: "La Vega",
    activationDate: "2024-03-10",
    email: "admin@nuevaera.edu",
    logo: "/placeholder.svg?height=60&width=60",
  },
]

// Planes de suscripción
const subscriptionPlans = [
  {
    id: "free",
    name: "Gratuita",
    maxUsers: 50,
    costPerUser: 0,
    features: ["Gestión básica", "Hasta 50 usuarios", "Soporte por email"],
  },
  {
    id: "basic",
    name: "Básica",
    maxUsers: 500,
    costPerUser: 3,
    features: ["Todas las funciones básicas", "Hasta 500 usuarios", "Soporte prioritario", "Reportes básicos"],
  },
  {
    id: "premium",
    name: "Premium",
    maxUsers: 2000,
    costPerUser: 5,
    features: ["Funciones avanzadas", "Hasta 2000 usuarios", "Soporte 24/7", "Analytics avanzados", "API access"],
  },
]

export default function SchoolsPage() {
  const [selectedSchool, setSelectedSchool] = useState(null)
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [isDetailDialogOpen, setIsDetailDialogOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedMinerdSchool, setSelectedMinerdSchool] = useState(null)
  const [formData, setFormData] = useState({
    // Datos del MINERD (autocompletados)
    name: "",
    code: "",
    address: "",
    district: "",
    municipality: "",
    province: "",
    region: "",
    // Datos manuales
    directorName: "",
    directorPhone: "",
    estimatedStudents: "",
    estimatedStaff: "",
    subscriptionType: "",
    costPerUser: 0,
    logo: null,
  })
  const [filters, setFilters] = useState({
    status: "Todos",
    subscriptionType: "Todas",
    paymentStatus: "Todos",
    region: "Todas",
    search: "",
  })

  const [editFormData, setEditFormData] = useState({
    name: "",
    code: "",
    address: "",
    district: "",
    municipality: "",
    province: "",
    region: "",
    directorName: "",
    directorPhone: "",
    email: "",
    totalStudents: "",
    totalStaff: "",
    subscriptionType: "",
    status: "",
    paymentStatus: "",
  })

  // Filtrar colegios del MINERD para autocompletado
  const filteredMinerdSchools = minerdSchools.filter(
    (school) =>
      school.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      school.code.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  // Filtrar colegios registrados
  const filteredSchools = schoolsData.filter((school) => {
    return (
      (filters.status === "Todos" || school.status === filters.status) &&
      (filters.subscriptionType === "Todas" || school.subscriptionType === filters.subscriptionType) &&
      (filters.paymentStatus === "Todos" || school.paymentStatus === filters.paymentStatus) &&
      (filters.region === "Todas" || school.region === filters.region) &&
      (filters.search === "" || school.name.toLowerCase().includes(filters.search.toLowerCase()))
    )
  })

  // Calcular costo total
  const calculateTotalCost = () => {
    const students = Number.parseInt(formData.estimatedStudents) || 0
    const staff = Number.parseInt(formData.estimatedStaff) || 0
    const totalUsers = students + staff
    const selectedPlan = subscriptionPlans.find((plan) => plan.id === formData.subscriptionType)

    if (selectedPlan) {
      return totalUsers * selectedPlan.costPerUser
    }
    return 0
  }

  const handleEditSchool = (school) => {
    setSelectedSchool(school)
    setEditFormData({
      name: school.name,
      code: school.code,
      address: school.address,
      district: school.district || "",
      municipality: school.municipality || "",
      province: school.province,
      region: school.region,
      directorName: school.director.name,
      directorPhone: school.director.phone,
      email: school.email,
      totalStudents: school.totalStudents.toString(),
      totalStaff: school.totalStaff.toString(),
      subscriptionType: school.subscriptionType,
      status: school.status,
      paymentStatus: school.paymentStatus,
    })
    setIsEditDialogOpen(true)
  }

  // Manejar selección de colegio del MINERD
  const handleMinerdSchoolSelect = (school) => {
    setSelectedMinerdSchool(school)
    setFormData({
      ...formData,
      name: school.name,
      code: school.code,
      address: school.address,
      district: school.district,
      municipality: school.municipality,
      province: school.province,
      region: school.region,
    })
    setSearchQuery(school.name)
  }

  // Manejar cambio de plan de suscripción
  const handleSubscriptionChange = (planId) => {
    const selectedPlan = subscriptionPlans.find((plan) => plan.id === planId)
    setFormData({
      ...formData,
      subscriptionType: planId,
      costPerUser: selectedPlan ? selectedPlan.costPerUser : 0,
    })
  }

  const getStatusColor = (status) => {
    switch (status) {
      case "Activo":
        return "bg-futuristic-success/10 text-futuristic-success border-futuristic-success/20"
      case "Inactivo":
        return "bg-futuristic-error/10 text-futuristic-error border-futuristic-error/20"
      default:
        return "bg-futuristic-info/10 text-futuristic-info border-futuristic-info/20"
    }
  }

  const getPaymentStatusColor = (status) => {
    switch (status) {
      case "Al día":
        return "bg-futuristic-success/10 text-futuristic-success border-futuristic-success/20"
      case "Vencido":
        return "bg-futuristic-error/10 text-futuristic-error border-futuristic-error/20"
      default:
        return "bg-futuristic-warning/10 text-futuristic-warning border-futuristic-warning/20"
    }
  }

  const getSubscriptionColor = (type) => {
    switch (type) {
      case "Premium":
        return "bg-gradient-to-r from-futuristic-primary to-futuristic-creative text-white"
      case "Básica":
        return "bg-futuristic-info/10 text-futuristic-info border-futuristic-info/20"
      case "Gratuita":
        return "bg-futuristic-text-tertiary/10 text-futuristic-text-tertiary border-futuristic-text-tertiary/20"
      default:
        return "bg-futuristic-info/10 text-futuristic-info border-futuristic-info/20"
    }
  }

  return (
    <div className="flex-1 flex flex-col">
      <Header title="Gestión de Colegios" />

      <main className="flex-1 overflow-y-auto p-6 bg-futuristic-background">
        <Tabs defaultValue="list" className="space-y-6">
          <div className="flex items-center justify-between">
            <TabsList className="bg-futuristic-surface border border-futuristic-primary/10">
              <TabsTrigger value="list" className="flex items-center gap-2">
                <Building className="w-4 h-4" />
                Listado de Colegios
              </TabsTrigger>
              <TabsTrigger value="analytics" className="flex items-center gap-2">
                <BarChart3 className="w-4 h-4" />
                Analítica
              </TabsTrigger>
            </TabsList>

            <div className="flex gap-2">
              <Button
                variant="outline"
                className="border-futuristic-info/30 text-futuristic-info hover:bg-futuristic-info/5 bg-transparent"
              >
                <Upload className="w-4 h-4 mr-2" />
                Importar
              </Button>
              <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-gradient-to-r from-futuristic-primary to-futuristic-primary-light hover:from-futuristic-primary-dark hover:to-futuristic-primary">
                    <Plus className="w-4 h-4 mr-2" />
                    Nuevo Colegio
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto bg-futuristic-surface border-futuristic-primary/20">
                  <DialogHeader>
                    <DialogTitle className="text-futuristic-text-primary flex items-center gap-2">
                      <Building className="w-5 h-5" />
                      Registrar Nuevo Colegio
                    </DialogTitle>
                    <DialogDescription className="text-futuristic-text-secondary">
                      Complete la información del nuevo centro educativo
                    </DialogDescription>
                  </DialogHeader>

                  <div className="space-y-6 py-4">
                    {/* Búsqueda inteligente MINERD */}
                    <Card className="bg-futuristic-background/50 border-futuristic-primary/10">
                      <CardHeader>
                        <CardTitle className="text-futuristic-text-primary text-lg flex items-center gap-2">
                          <Globe className="w-5 h-5" />
                          Búsqueda en Base de Datos MINERD
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="relative">
                          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-futuristic-text-tertiary w-4 h-4" />
                          <Input
                            placeholder="Buscar colegio oficial por nombre o código..."
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            className="pl-10 bg-futuristic-surface border-futuristic-primary/20"
                          />
                        </div>

                        {searchQuery && filteredMinerdSchools.length > 0 && (
                          <div className="max-h-40 overflow-y-auto border border-futuristic-primary/20 rounded-lg bg-futuristic-surface">
                            {filteredMinerdSchools.map((school) => (
                              <div
                                key={school.id}
                                className="p-3 hover:bg-futuristic-primary/5 cursor-pointer border-b border-futuristic-primary/10 last:border-b-0"
                                onClick={() => handleMinerdSchoolSelect(school)}
                              >
                                <div className="font-medium text-futuristic-text-primary">{school.name}</div>
                                <div className="text-sm text-futuristic-text-secondary">{school.code}</div>
                                <div className="text-xs text-futuristic-text-tertiary">{school.address}</div>
                              </div>
                            ))}
                          </div>
                        )}
                      </CardContent>
                    </Card>

                    {/* Datos autocompletados */}
                    {selectedMinerdSchool && (
                      <Card className="bg-futuristic-success/5 border-futuristic-success/20">
                        <CardHeader>
                          <CardTitle className="text-futuristic-success text-lg flex items-center gap-2">
                            <CheckCircle className="w-5 h-5" />
                            Datos Oficiales Cargados
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="grid grid-cols-2 gap-4">
                          <div>
                            <Label className="text-futuristic-text-primary">Nombre del Colegio</Label>
                            <Input value={formData.name} disabled className="bg-futuristic-background/30" />
                          </div>
                          <div>
                            <Label className="text-futuristic-text-primary">Código del Centro</Label>
                            <Input value={formData.code} disabled className="bg-futuristic-background/30" />
                          </div>
                          <div className="col-span-2">
                            <Label className="text-futuristic-text-primary">Dirección</Label>
                            <Input value={formData.address} disabled className="bg-futuristic-background/30" />
                          </div>
                          <div>
                            <Label className="text-futuristic-text-primary">Distrito Educativo</Label>
                            <Input value={formData.district} disabled className="bg-futuristic-background/30" />
                          </div>
                          <div>
                            <Label className="text-futuristic-text-primary">Municipio</Label>
                            <Input value={formData.municipality} disabled className="bg-futuristic-background/30" />
                          </div>
                          <div>
                            <Label className="text-futuristic-text-primary">Provincia</Label>
                            <Input value={formData.province} disabled className="bg-futuristic-background/30" />
                          </div>
                          <div>
                            <Label className="text-futuristic-text-primary">Región</Label>
                            <Input value={formData.region} disabled className="bg-futuristic-background/30" />
                          </div>
                        </CardContent>
                      </Card>
                    )}

                    {/* Datos manuales obligatorios */}
                    <Card className="bg-futuristic-background/50 border-futuristic-primary/10">
                      <CardHeader>
                        <CardTitle className="text-futuristic-text-primary text-lg flex items-center gap-2">
                          <UserCheck className="w-5 h-5" />
                          Información del Director
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="directorName" className="text-futuristic-text-primary">
                            Nombre del Director *
                          </Label>
                          <Input
                            id="directorName"
                            placeholder="Nombre completo del director"
                            value={formData.directorName}
                            onChange={(e) => setFormData({ ...formData, directorName: e.target.value })}
                            className="bg-futuristic-surface border-futuristic-primary/20"
                          />
                        </div>
                        <div>
                          <Label htmlFor="directorPhone" className="text-futuristic-text-primary">
                            Teléfono de Contacto *
                          </Label>
                          <Input
                            id="directorPhone"
                            placeholder="+1 234-567-8900"
                            value={formData.directorPhone}
                            onChange={(e) => setFormData({ ...formData, directorPhone: e.target.value })}
                            className="bg-futuristic-surface border-futuristic-primary/20"
                          />
                        </div>
                      </CardContent>
                    </Card>

                    {/* Configuración del colegio */}
                    <Card className="bg-futuristic-background/50 border-futuristic-primary/10">
                      <CardHeader>
                        <CardTitle className="text-futuristic-text-primary text-lg flex items-center gap-2">
                          <Settings className="w-5 h-5" />
                          Configuración Institucional
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="estimatedStudents" className="text-futuristic-text-primary">
                              Cantidad Estimada de Estudiantes *
                            </Label>
                            <Input
                              id="estimatedStudents"
                              type="number"
                              placeholder="500"
                              value={formData.estimatedStudents}
                              onChange={(e) => setFormData({ ...formData, estimatedStudents: e.target.value })}
                              className="bg-futuristic-surface border-futuristic-primary/20"
                            />
                          </div>
                          <div>
                            <Label htmlFor="estimatedStaff" className="text-futuristic-text-primary">
                              Personal Administrativo/Docente *
                            </Label>
                            <Input
                              id="estimatedStaff"
                              type="number"
                              placeholder="50"
                              value={formData.estimatedStaff}
                              onChange={(e) => setFormData({ ...formData, estimatedStaff: e.target.value })}
                              className="bg-futuristic-surface border-futuristic-primary/20"
                            />
                          </div>
                        </div>

                        {/* Logo upload */}
                        <div>
                          <Label className="text-futuristic-text-primary">Logo Institucional</Label>
                          <div className="flex items-center justify-center p-6 border-2 border-dashed border-futuristic-primary/30 rounded-lg bg-futuristic-background/30 hover:bg-futuristic-primary/5 transition-colors">
                            <div className="text-center">
                              <Upload className="w-8 h-8 text-futuristic-text-secondary mx-auto mb-2" />
                              <p className="text-sm text-futuristic-text-secondary">
                                Arrastra el logo aquí o haz clic para seleccionar
                              </p>
                              <p className="text-xs text-futuristic-text-tertiary mt-1">
                                Formatos: PNG, JPG, SVG (máx. 2MB)
                              </p>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Tipo de suscripción */}
                    <Card className="bg-futuristic-background/50 border-futuristic-primary/10">
                      <CardHeader>
                        <CardTitle className="text-futuristic-text-primary text-lg flex items-center gap-2">
                          <CreditCard className="w-5 h-5" />
                          Plan de Suscripción
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          {subscriptionPlans.map((plan) => (
                            <div
                              key={plan.id}
                              className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                                formData.subscriptionType === plan.id
                                  ? "border-futuristic-primary bg-futuristic-primary/10"
                                  : "border-futuristic-primary/20 hover:border-futuristic-primary/40"
                              }`}
                              onClick={() => handleSubscriptionChange(plan.id)}
                            >
                              <div className="flex items-center justify-between mb-2">
                                <h3 className="font-semibold text-futuristic-text-primary">{plan.name}</h3>
                                {plan.id === "premium" && <Crown className="w-4 h-4 text-futuristic-primary" />}
                              </div>
                              <div className="text-2xl font-bold text-futuristic-primary mb-2">
                                ${plan.costPerUser}
                                <span className="text-sm text-futuristic-text-secondary">/usuario/mes</span>
                              </div>
                              <div className="text-sm text-futuristic-text-secondary mb-3">
                                Hasta {plan.maxUsers} usuarios
                              </div>
                              <ul className="text-xs text-futuristic-text-tertiary space-y-1">
                                {plan.features.map((feature, index) => (
                                  <li key={index} className="flex items-center gap-1">
                                    <CheckCircle className="w-3 h-3 text-futuristic-success" />
                                    {feature}
                                  </li>
                                ))}
                              </ul>
                            </div>
                          ))}
                        </div>

                        {/* Cálculo de costo */}
                        {formData.subscriptionType && (formData.estimatedStudents || formData.estimatedStaff) && (
                          <Card className="bg-futuristic-primary/5 border-futuristic-primary/20">
                            <CardContent className="p-4">
                              <div className="flex items-center justify-between">
                                <div>
                                  <h4 className="font-semibold text-futuristic-text-primary flex items-center gap-2">
                                    <Calculator className="w-4 h-4" />
                                    Cálculo de Costo
                                  </h4>
                                  <div className="text-sm text-futuristic-text-secondary mt-1">
                                    {Number.parseInt(formData.estimatedStudents) || 0} estudiantes +{" "}
                                    {Number.parseInt(formData.estimatedStaff) || 0} personal ={" "}
                                    {(Number.parseInt(formData.estimatedStudents) || 0) +
                                      (Number.parseInt(formData.estimatedStaff) || 0)}{" "}
                                    usuarios totales
                                  </div>
                                </div>
                                <div className="text-right">
                                  <div className="text-2xl font-bold text-futuristic-primary">
                                    ${calculateTotalCost()}
                                  </div>
                                  <div className="text-sm text-futuristic-text-secondary">por mes</div>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        )}
                      </CardContent>
                    </Card>
                  </div>

                  <DialogFooter>
                    <Button
                      variant="outline"
                      onClick={() => setIsCreateDialogOpen(false)}
                      className="border-futuristic-primary/30 text-futuristic-text-secondary"
                    >
                      Cancelar
                    </Button>
                    <Button
                      className="bg-gradient-to-r from-futuristic-primary to-futuristic-primary-light"
                      disabled={
                        !formData.name ||
                        !formData.directorName ||
                        !formData.directorPhone ||
                        !formData.subscriptionType
                      }
                    >
                      <CheckCircle className="w-4 h-4 mr-2" />
                      Registrar Colegio
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
          </div>

          <TabsContent value="list" className="space-y-6">
            {/* Filtros */}
            <Card className="bg-futuristic-surface border-futuristic-primary/10">
              <CardHeader>
                <CardTitle className="text-futuristic-text-primary flex items-center gap-2">
                  <Filter className="w-5 h-5" />
                  Filtros de Búsqueda
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-6 gap-4">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-futuristic-text-tertiary w-4 h-4" />
                    <Input
                      placeholder="Buscar colegio..."
                      value={filters.search}
                      onChange={(e) => setFilters({ ...filters, search: e.target.value })}
                      className="pl-10 bg-futuristic-background/50 border-futuristic-primary/20"
                    />
                  </div>
                  <Select value={filters.status} onValueChange={(value) => setFilters({ ...filters, status: value })}>
                    <SelectTrigger className="bg-futuristic-background/50 border-futuristic-primary/20">
                      <SelectValue placeholder="Estado" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Todos">Todos</SelectItem>
                      <SelectItem value="Activo">Activo</SelectItem>
                      <SelectItem value="Inactivo">Inactivo</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select
                    value={filters.subscriptionType}
                    onValueChange={(value) => setFilters({ ...filters, subscriptionType: value })}
                  >
                    <SelectTrigger className="bg-futuristic-background/50 border-futuristic-primary/20">
                      <SelectValue placeholder="Plan" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Todas">Todos los Planes</SelectItem>
                      <SelectItem value="Gratuita">Gratuita</SelectItem>
                      <SelectItem value="Básica">Básica</SelectItem>
                      <SelectItem value="Premium">Premium</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select
                    value={filters.paymentStatus}
                    onValueChange={(value) => setFilters({ ...filters, paymentStatus: value })}
                  >
                    <SelectTrigger className="bg-futuristic-background/50 border-futuristic-primary/20">
                      <SelectValue placeholder="Estado de Pago" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Todos">Todos</SelectItem>
                      <SelectItem value="Al día">Al día</SelectItem>
                      <SelectItem value="Vencido">Vencido</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select value={filters.region} onValueChange={(value) => setFilters({ ...filters, region: value })}>
                    <SelectTrigger className="bg-futuristic-background/50 border-futuristic-primary/20">
                      <SelectValue placeholder="Región" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Todas">Todas las Regiones</SelectItem>
                      <SelectItem value="Región Metropolitana">Región Metropolitana</SelectItem>
                      <SelectItem value="Región Norte">Región Norte</SelectItem>
                      <SelectItem value="Región Central">Región Central</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button
                    variant="outline"
                    className="border-futuristic-primary/30 text-futuristic-primary hover:bg-futuristic-primary/5 bg-transparent"
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Exportar
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Tabla de Colegios */}
            <Card className="bg-futuristic-surface border-futuristic-primary/10">
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-futuristic-primary/10">
                        <th className="text-left p-4 text-futuristic-text-secondary font-medium">Colegio</th>
                        <th className="text-left p-4 text-futuristic-text-secondary font-medium">Estado</th>
                        <th className="text-left p-4 text-futuristic-text-secondary font-medium">Plan</th>
                        <th className="text-left p-4 text-futuristic-text-secondary font-medium">Usuarios</th>
                        <th className="text-left p-4 text-futuristic-text-secondary font-medium">Pago</th>
                        <th className="text-left p-4 text-futuristic-text-secondary font-medium">Ingresos</th>
                        <th className="text-left p-4 text-futuristic-text-secondary font-medium">Director</th>
                        <th className="text-left p-4 text-futuristic-text-secondary font-medium">Región</th>
                        <th className="text-right p-4 text-futuristic-text-secondary font-medium">Acciones</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredSchools.map((school) => (
                        <tr
                          key={school.id}
                          className="border-b border-futuristic-primary/5 hover:bg-futuristic-primary/5 transition-colors"
                        >
                          <td className="p-4">
                            <div className="flex items-center space-x-3">
                              <img
                                src={school.logo || "/placeholder.svg"}
                                alt={school.name}
                                className="w-10 h-10 rounded-lg object-cover"
                              />
                              <div>
                                <div className="text-futuristic-text-primary font-medium">{school.name}</div>
                                <div className="text-sm text-futuristic-text-secondary">{school.code}</div>
                              </div>
                            </div>
                          </td>
                          <td className="p-4">
                            <Badge className={getStatusColor(school.status)}>{school.status}</Badge>
                          </td>
                          <td className="p-4">
                            <Badge className={getSubscriptionColor(school.subscriptionType)}>
                              {school.subscriptionType}
                            </Badge>
                          </td>
                          <td className="p-4">
                            <div className="text-futuristic-text-primary">
                              <div className="font-medium">
                                {school.activeUsers}/{school.estimatedUsers}
                              </div>
                              <div className="text-xs text-futuristic-text-secondary">
                                {Math.round((school.activeUsers / school.estimatedUsers) * 100)}% activos
                              </div>
                            </div>
                          </td>
                          <td className="p-4">
                            <Badge className={getPaymentStatusColor(school.paymentStatus)}>
                              {school.paymentStatus}
                            </Badge>
                          </td>
                          <td className="p-4">
                            <div className="flex items-center gap-1 text-futuristic-text-primary">
                              <DollarSign className="w-4 h-4 text-futuristic-success" />
                              <span className="font-medium">${school.monthlyPayment}</span>
                              <span className="text-xs text-futuristic-text-secondary">/mes</span>
                            </div>
                          </td>
                          <td className="p-4">
                            <div>
                              <div className="text-futuristic-text-primary font-medium">{school.director.name}</div>
                              <div className="text-sm text-futuristic-text-secondary flex items-center gap-1">
                                <Phone className="w-3 h-3" />
                                {school.director.phone}
                              </div>
                            </div>
                          </td>
                          <td className="p-4">
                            <div className="text-futuristic-text-primary text-sm">
                              <div>{school.province}</div>
                              <div className="text-xs text-futuristic-text-secondary">{school.region}</div>
                            </div>
                          </td>
                          <td className="p-4 text-right">
                            <div className="flex justify-end gap-2">
                              <Button
                                size="sm"
                                variant="ghost"
                                className="h-8 w-8 p-0 hover:bg-futuristic-info/10"
                                onClick={() => {
                                  setSelectedSchool(school)
                                  setIsDetailDialogOpen(true)
                                }}
                              >
                                <Eye className="h-4 w-4 text-futuristic-info" />
                              </Button>
                              <Button
                                size="sm"
                                variant="ghost"
                                className="h-8 w-8 p-0 hover:bg-futuristic-primary/10"
                                onClick={() => handleEditSchool(school)}
                              >
                                <Edit className="h-4 w-4 text-futuristic-primary" />
                              </Button>
                              <AlertDialog>
                                <AlertDialogTrigger asChild>
                                  <Button
                                    size="sm"
                                    variant="ghost"
                                    className="h-8 w-8 p-0 hover:bg-futuristic-error/10"
                                  >
                                    <Trash2 className="h-4 w-4 text-futuristic-error" />
                                  </Button>
                                </AlertDialogTrigger>
                                <AlertDialogContent className="bg-futuristic-surface border-futuristic-primary/20">
                                  <AlertDialogHeader>
                                    <AlertDialogTitle className="text-futuristic-text-primary">
                                      ¿Eliminar Colegio?
                                    </AlertDialogTitle>
                                    <AlertDialogDescription className="text-futuristic-text-secondary">
                                      Esta acción eliminará permanentemente el colegio "{school.name}" y todos sus datos
                                      asociados. Esta acción no se puede deshacer.
                                    </AlertDialogDescription>
                                  </AlertDialogHeader>
                                  <AlertDialogFooter>
                                    <AlertDialogCancel className="border-futuristic-primary/30">
                                      Cancelar
                                    </AlertDialogCancel>
                                    <AlertDialogAction className="bg-futuristic-error hover:bg-futuristic-error/80">
                                      Eliminar Permanentemente
                                    </AlertDialogAction>
                                  </AlertDialogFooter>
                                </AlertDialogContent>
                              </AlertDialog>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            {/* Métricas principales */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="bg-futuristic-surface border-futuristic-primary/10">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-futuristic-text-secondary text-sm font-medium">Total Colegios</CardTitle>
                  <Building className="h-4 w-4 text-futuristic-primary" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-futuristic-text-primary">42</div>
                  <p className="text-xs text-futuristic-success">+3 este mes</p>
                </CardContent>
              </Card>

              <Card className="bg-futuristic-surface border-futuristic-primary/10">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-futuristic-text-secondary text-sm font-medium">
                    Estudiantes Activos
                  </CardTitle>
                  <GraduationCap className="h-4 w-4 text-futuristic-success" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-futuristic-text-primary">12,847</div>
                  <p className="text-xs text-futuristic-success">+5.2% vs mes anterior</p>
                </CardContent>
              </Card>

              <Card className="bg-futuristic-surface border-futuristic-primary/10">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-futuristic-text-secondary text-sm font-medium">Personal Docente</CardTitle>
                  <Users className="h-4 w-4 text-futuristic-info" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-futuristic-text-primary">1,284</div>
                  <p className="text-xs text-futuristic-info">+2.1% vs mes anterior</p>
                </CardContent>
              </Card>

              <Card className="bg-futuristic-surface border-futuristic-primary/10">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-futuristic-text-secondary text-sm font-medium">
                    Ingresos Mensuales
                  </CardTitle>
                  <DollarSign className="h-4 w-4 text-futuristic-success" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-futuristic-text-primary">$68,450</div>
                  <p className="text-xs text-futuristic-success">+12.3% vs mes anterior</p>
                </CardContent>
              </Card>
            </div>

            {/* Distribución por planes */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-futuristic-surface border-futuristic-primary/10">
                <CardHeader>
                  <CardTitle className="text-futuristic-text-primary flex items-center gap-2">
                    <PieChart className="w-5 h-5" />
                    Distribución por Planes
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full bg-gradient-to-r from-futuristic-primary to-futuristic-creative"></div>
                        <span className="text-futuristic-text-primary">Premium</span>
                      </div>
                      <div className="text-right">
                        <div className="text-futuristic-text-primary font-medium">18 colegios</div>
                        <div className="text-xs text-futuristic-text-secondary">42.9%</div>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full bg-futuristic-info"></div>
                        <span className="text-futuristic-text-primary">Básica</span>
                      </div>
                      <div className="text-right">
                        <div className="text-futuristic-text-primary font-medium">16 colegios</div>
                        <div className="text-xs text-futuristic-text-secondary">38.1%</div>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full bg-futuristic-text-tertiary"></div>
                        <span className="text-futuristic-text-primary">Gratuita</span>
                      </div>
                      <div className="text-right">
                        <div className="text-futuristic-text-primary font-medium">8 colegios</div>
                        <div className="text-xs text-futuristic-text-secondary">19.0%</div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-futuristic-surface border-futuristic-primary/10">
                <CardHeader>
                  <CardTitle className="text-futuristic-text-primary flex items-center gap-2">
                    <Map className="w-5 h-5" />
                    Distribución por Región
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-futuristic-text-primary">Región Metropolitana</span>
                      <div className="text-right">
                        <div className="text-futuristic-text-primary font-medium">18 colegios</div>
                        <div className="text-xs text-futuristic-text-secondary">42.9%</div>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-futuristic-text-primary">Región Norte</span>
                      <div className="text-right">
                        <div className="text-futuristic-text-primary font-medium">12 colegios</div>
                        <div className="text-xs text-futuristic-text-secondary">28.6%</div>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-futuristic-text-primary">Región Central</span>
                      <div className="text-right">
                        <div className="text-futuristic-text-primary font-medium">8 colegios</div>
                        <div className="text-xs text-futuristic-text-secondary">19.0%</div>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-futuristic-text-primary">Región Este</span>
                      <div className="text-right">
                        <div className="text-futuristic-text-primary font-medium">4 colegios</div>
                        <div className="text-xs text-futuristic-text-secondary">9.5%</div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Ranking y alertas */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-futuristic-surface border-futuristic-primary/10">
                <CardHeader>
                  <CardTitle className="text-futuristic-text-primary flex items-center gap-2">
                    <Star className="w-5 h-5" />
                    Top 5 Colegios Más Activos
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {schoolsData.slice(0, 3).map((school, index) => (
                      <div
                        key={school.id}
                        className="flex items-center justify-between p-3 bg-futuristic-background/30 rounded-lg"
                      >
                        <div className="flex items-center gap-3">
                          <div
                            className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                              index === 0
                                ? "bg-yellow-500 text-white"
                                : index === 1
                                  ? "bg-gray-400 text-white"
                                  : "bg-orange-500 text-white"
                            }`}
                          >
                            {index + 1}
                          </div>
                          <div>
                            <div className="text-futuristic-text-primary font-medium">{school.name}</div>
                            <div className="text-xs text-futuristic-text-secondary">
                              {school.activeUsers} usuarios activos
                            </div>
                          </div>
                        </div>
                        <Badge className={getSubscriptionColor(school.subscriptionType)}>
                          {school.subscriptionType}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-futuristic-surface border-futuristic-primary/10">
                <CardHeader>
                  <CardTitle className="text-futuristic-text-primary flex items-center gap-2">
                    <AlertTriangle className="w-5 h-5" />
                    Alertas y Notificaciones
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-start gap-3 p-3 bg-futuristic-error/5 border border-futuristic-error/20 rounded-lg">
                      <AlertTriangle className="w-4 h-4 text-futuristic-error mt-0.5" />
                      <div>
                        <div className="text-futuristic-text-primary font-medium">Pagos Vencidos</div>
                        <div className="text-xs text-futuristic-text-secondary">
                          1 colegio con pago vencido requiere atención
                        </div>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 p-3 bg-futuristic-warning/5 border border-futuristic-warning/20 rounded-lg">
                      <Clock className="w-4 h-4 text-futuristic-warning mt-0.5" />
                      <div>
                        <div className="text-futuristic-text-primary font-medium">Renovaciones Próximas</div>
                        <div className="text-xs text-futuristic-text-secondary">
                          3 colegios vencen en los próximos 30 días
                        </div>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 p-3 bg-futuristic-info/5 border border-futuristic-info/20 rounded-lg">
                      <TrendingUp className="w-4 h-4 text-futuristic-info mt-0.5" />
                      <div>
                        <div className="text-futuristic-text-primary font-medium">Crecimiento</div>
                        <div className="text-xs text-futuristic-text-secondary">
                          5 colegios han superado su límite de usuarios
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        {/* Modal de Detalle del Colegio */}
        {selectedSchool && isDetailDialogOpen && (
          <Dialog open={isDetailDialogOpen} onOpenChange={setIsDetailDialogOpen}>
            <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto bg-futuristic-surface border-futuristic-primary/20">
              <DialogHeader>
                <DialogTitle className="text-futuristic-text-primary flex items-center gap-3">
                  <img
                    src={selectedSchool.logo || "/placeholder.svg"}
                    alt={selectedSchool.name}
                    className="w-12 h-12 rounded-lg object-cover"
                  />
                  <div>
                    <div>{selectedSchool.name}</div>
                    <div className="text-sm text-futuristic-text-secondary font-normal">{selectedSchool.code}</div>
                  </div>
                </DialogTitle>
                <DialogDescription className="text-futuristic-text-secondary">
                  Información detallada del centro educativo
                </DialogDescription>
              </DialogHeader>

              <div className="space-y-6 py-4">
                {/* Información básica */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Card className="bg-futuristic-background/50 border-futuristic-primary/10">
                    <CardHeader>
                      <CardTitle className="text-futuristic-text-primary text-lg flex items-center gap-2">
                        <Building className="w-5 h-5" />
                        Información Institucional
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="flex items-center gap-2">
                        <MapPin className="w-4 h-4 text-futuristic-info" />
                        <span className="text-futuristic-text-primary">{selectedSchool.address}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Globe className="w-4 h-4 text-futuristic-info" />
                        <span className="text-futuristic-text-primary">{selectedSchool.district}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Map className="w-4 h-4 text-futuristic-info" />
                        <span className="text-futuristic-text-primary">
                          {selectedSchool.province}, {selectedSchool.region}
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4 text-futuristic-success" />
                        <span className="text-futuristic-text-primary">Activado: {selectedSchool.activationDate}</span>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="bg-futuristic-background/50 border-futuristic-primary/10">
                    <CardHeader>
                      <CardTitle className="text-futuristic-text-primary text-lg flex items-center gap-2">
                        <UserCheck className="w-5 h-5" />
                        Director Responsable
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="flex items-center gap-2">
                        <Users className="w-4 h-4 text-futuristic-primary" />
                        <span className="text-futuristic-text-primary font-medium">{selectedSchool.director.name}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Phone className="w-4 h-4 text-futuristic-info" />
                        <span className="text-futuristic-text-primary">{selectedSchool.director.phone}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Mail className="w-4 h-4 text-futuristic-info" />
                        <span className="text-futuristic-text-primary">{selectedSchool.email}</span>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Estadísticas */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <Card className="bg-futuristic-background/50 border-futuristic-primary/10">
                    <CardContent className="p-4 text-center">
                      <div className="text-2xl font-bold text-futuristic-primary">{selectedSchool.totalStudents}</div>
                      <div className="text-sm text-futuristic-text-secondary">Estudiantes</div>
                    </CardContent>
                  </Card>
                  <Card className="bg-futuristic-background/50 border-futuristic-primary/10">
                    <CardContent className="p-4 text-center">
                      <div className="text-2xl font-bold text-futuristic-success">{selectedSchool.totalStaff}</div>
                      <div className="text-sm text-futuristic-text-secondary">Personal</div>
                    </CardContent>
                  </Card>
                  <Card className="bg-futuristic-background/50 border-futuristic-primary/10">
                    <CardContent className="p-4 text-center">
                      <div className="text-2xl font-bold text-futuristic-info">{selectedSchool.activeUsers}</div>
                      <div className="text-sm text-futuristic-text-secondary">Usuarios Activos</div>
                    </CardContent>
                  </Card>
                  <Card className="bg-futuristic-background/50 border-futuristic-primary/10">
                    <CardContent className="p-4 text-center">
                      <div className="text-2xl font-bold text-futuristic-creative">
                        ${selectedSchool.monthlyPayment}
                      </div>
                      <div className="text-sm text-futuristic-text-secondary">Pago Mensual</div>
                    </CardContent>
                  </Card>
                </div>

                {/* Estado y suscripción */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Card className="bg-futuristic-background/50 border-futuristic-primary/10">
                    <CardHeader>
                      <CardTitle className="text-futuristic-text-primary text-lg flex items-center gap-2">
                        <Activity className="w-5 h-5" />
                        Estado del Colegio
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-futuristic-text-secondary">Estado:</span>
                        <Badge className={getStatusColor(selectedSchool.status)}>{selectedSchool.status}</Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-futuristic-text-secondary">Estado de Pago:</span>
                        <Badge className={getPaymentStatusColor(selectedSchool.paymentStatus)}>
                          {selectedSchool.paymentStatus}
                        </Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-futuristic-text-secondary">Vencimiento:</span>
                        <span className="text-futuristic-text-primary">{selectedSchool.expirationDate}</span>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="bg-futuristic-background/50 border-futuristic-primary/10">
                    <CardHeader>
                      <CardTitle className="text-futuristic-text-primary text-lg flex items-center gap-2">
                        <CreditCard className="w-5 h-5" />
                        Plan de Suscripción
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-futuristic-text-secondary">Plan:</span>
                        <Badge className={getSubscriptionColor(selectedSchool.subscriptionType)}>
                          {selectedSchool.subscriptionType}
                        </Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-futuristic-text-secondary">Costo por Usuario:</span>
                        <span className="text-futuristic-text-primary">${selectedSchool.costPerUser}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-futuristic-text-secondary">Capacidad:</span>
                        <span className="text-futuristic-text-primary">{selectedSchool.estimatedUsers} usuarios</span>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Acciones */}
                <Card className="bg-futuristic-background/50 border-futuristic-primary/10">
                  <CardHeader>
                    <CardTitle className="text-futuristic-text-primary text-lg flex items-center gap-2">
                      <Settings className="w-5 h-5" />
                      Acciones Disponibles
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-wrap gap-3">
                      <Button
                        variant="outline"
                        className="border-futuristic-primary/30 text-futuristic-primary hover:bg-futuristic-primary/5 bg-transparent"
                      >
                        <Edit className="w-4 h-4 mr-2" />
                        Editar Información
                      </Button>
                      <Button
                        variant="outline"
                        className="border-futuristic-info/30 text-futuristic-info hover:bg-futuristic-info/5 bg-transparent"
                      >
                        <Users className="w-4 h-4 mr-2" />
                        Ver Usuarios
                      </Button>
                      <Button
                        variant="outline"
                        className="border-futuristic-creative/30 text-futuristic-creative hover:bg-futuristic-creative/5 bg-transparent"
                      >
                        <CreditCard className="w-4 h-4 mr-2" />
                        Cambiar Plan
                      </Button>
                      {selectedSchool.status === "Activo" ? (
                        <Button
                          variant="outline"
                          className="border-futuristic-warning/30 text-futuristic-warning hover:bg-futuristic-warning/5 bg-transparent"
                        >
                          <Shield className="w-4 h-4 mr-2" />
                          Desactivar
                        </Button>
                      ) : (
                        <Button
                          variant="outline"
                          className="border-futuristic-success/30 text-futuristic-success hover:bg-futuristic-success/5 bg-transparent"
                        >
                          <CheckCircle className="w-4 h-4 mr-2" />
                          Activar
                        </Button>
                      )}
                      <Button
                        variant="outline"
                        className="border-futuristic-error/30 text-futuristic-error hover:bg-futuristic-error/5 bg-transparent"
                      >
                        <Trash2 className="w-4 h-4 mr-2" />
                        Eliminar
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </DialogContent>
          </Dialog>
        )}

        {/* Modal de Edición del Colegio */}
        {selectedSchool && isEditDialogOpen && (
          <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
            <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto bg-futuristic-surface border-futuristic-primary/20">
              <DialogHeader>
                <DialogTitle className="text-futuristic-text-primary flex items-center gap-3">
                  <Edit className="w-6 h-6" />
                  <div>
                    <div>Editar Colegio</div>
                    <div className="text-sm text-futuristic-text-secondary font-normal">{selectedSchool.name}</div>
                  </div>
                </DialogTitle>
                <DialogDescription className="text-futuristic-text-secondary">
                  Modifica la información del centro educativo
                </DialogDescription>
              </DialogHeader>

              <div className="space-y-6 py-4">
                {/* Información básica */}
                <Card className="bg-futuristic-background/50 border-futuristic-primary/10">
                  <CardHeader>
                    <CardTitle className="text-futuristic-text-primary text-lg flex items-center gap-2">
                      <Building className="w-5 h-5" />
                      Información Institucional
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="edit-name" className="text-futuristic-text-primary">
                        Nombre del Colegio *
                      </Label>
                      <Input
                        id="edit-name"
                        value={editFormData.name}
                        onChange={(e) => setEditFormData({ ...editFormData, name: e.target.value })}
                        className="bg-futuristic-surface border-futuristic-primary/20"
                      />
                    </div>
                    <div>
                      <Label htmlFor="edit-code" className="text-futuristic-text-primary">
                        Código del Centro *
                      </Label>
                      <Input
                        id="edit-code"
                        value={editFormData.code}
                        onChange={(e) => setEditFormData({ ...editFormData, code: e.target.value })}
                        className="bg-futuristic-surface border-futuristic-primary/20"
                      />
                    </div>
                    <div className="col-span-2">
                      <Label htmlFor="edit-address" className="text-futuristic-text-primary">
                        Dirección *
                      </Label>
                      <Input
                        id="edit-address"
                        value={editFormData.address}
                        onChange={(e) => setEditFormData({ ...editFormData, address: e.target.value })}
                        className="bg-futuristic-surface border-futuristic-primary/20"
                      />
                    </div>
                    <div>
                      <Label htmlFor="edit-province" className="text-futuristic-text-primary">
                        Provincia *
                      </Label>
                      <Input
                        id="edit-province"
                        value={editFormData.province}
                        onChange={(e) => setEditFormData({ ...editFormData, province: e.target.value })}
                        className="bg-futuristic-surface border-futuristic-primary/20"
                      />
                    </div>
                    <div>
                      <Label htmlFor="edit-region" className="text-futuristic-text-primary">
                        Región *
                      </Label>
                      <Input
                        id="edit-region"
                        value={editFormData.region}
                        onChange={(e) => setEditFormData({ ...editFormData, region: e.target.value })}
                        className="bg-futuristic-surface border-futuristic-primary/20"
                      />
                    </div>
                  </CardContent>
                </Card>

                {/* Información del Director */}
                <Card className="bg-futuristic-background/50 border-futuristic-primary/10">
                  <CardHeader>
                    <CardTitle className="text-futuristic-text-primary text-lg flex items-center gap-2">
                      <UserCheck className="w-5 h-5" />
                      Director Responsable
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="edit-director-name" className="text-futuristic-text-primary">
                        Nombre del Director *
                      </Label>
                      <Input
                        id="edit-director-name"
                        value={editFormData.directorName}
                        onChange={(e) => setEditFormData({ ...editFormData, directorName: e.target.value })}
                        className="bg-futuristic-surface border-futuristic-primary/20"
                      />
                    </div>
                    <div>
                      <Label htmlFor="edit-director-phone" className="text-futuristic-text-primary">
                        Teléfono *
                      </Label>
                      <Input
                        id="edit-director-phone"
                        value={editFormData.directorPhone}
                        onChange={(e) => setEditFormData({ ...editFormData, directorPhone: e.target.value })}
                        className="bg-futuristic-surface border-futuristic-primary/20"
                      />
                    </div>
                    <div className="col-span-2">
                      <Label htmlFor="edit-email" className="text-futuristic-text-primary">
                        Email Institucional *
                      </Label>
                      <Input
                        id="edit-email"
                        type="email"
                        value={editFormData.email}
                        onChange={(e) => setEditFormData({ ...editFormData, email: e.target.value })}
                        className="bg-futuristic-surface border-futuristic-primary/20"
                      />
                    </div>
                  </CardContent>
                </Card>

                {/* Configuración */}
                <Card className="bg-futuristic-background/50 border-futuristic-primary/10">
                  <CardHeader>
                    <CardTitle className="text-futuristic-text-primary text-lg flex items-center gap-2">
                      <Settings className="w-5 h-5" />
                      Configuración
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="edit-students" className="text-futuristic-text-primary">
                        Total Estudiantes *
                      </Label>
                      <Input
                        id="edit-students"
                        type="number"
                        value={editFormData.totalStudents}
                        onChange={(e) => setEditFormData({ ...editFormData, totalStudents: e.target.value })}
                        className="bg-futuristic-surface border-futuristic-primary/20"
                      />
                    </div>
                    <div>
                      <Label htmlFor="edit-staff" className="text-futuristic-text-primary">
                        Total Personal *
                      </Label>
                      <Input
                        id="edit-staff"
                        type="number"
                        value={editFormData.totalStaff}
                        onChange={(e) =>
                          setEditFormData({
                            ...editFormData,
                            totalStaff: e.target.value,
                          })
                        }
                        className="bg-futuristic-surface border-futuristic-primary/20"
                      />
                    </div>
                    <div>
                      <Label className="text-futuristic-text-primary">Plan de Suscripción *</Label>
                      <Select
                        value={editFormData.subscriptionType}
                        onValueChange={(value) => setEditFormData({ ...editFormData, subscriptionType: value })}
                      >
                        <SelectTrigger className="bg-futuristic-surface border-futuristic-primary/20">
                          <SelectValue placeholder="Seleccionar plan" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Gratuita">Gratuita</SelectItem>
                          <SelectItem value="Básica">Básica</SelectItem>
                          <SelectItem value="Premium">Premium</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label className="text-futuristic-text-primary">Estado *</Label>
                      <Select
                        value={editFormData.status}
                        onValueChange={(value) => setEditFormData({ ...editFormData, status: value })}
                      >
                        <SelectTrigger className="bg-futuristic-surface border-futuristic-primary/20">
                          <SelectValue placeholder="Seleccionar estado" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Activo">Activo</SelectItem>
                          <SelectItem value="Inactivo">Inactivo</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label className="text-futuristic-text-primary">Estado de Pago *</Label>
                      <Select
                        value={editFormData.paymentStatus}
                        onValueChange={(value) => setEditFormData({ ...editFormData, paymentStatus: value })}
                      >
                        <SelectTrigger className="bg-futuristic-surface border-futuristic-primary/20">
                          <SelectValue placeholder="Estado de pago" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Al día">Al día</SelectItem>
                          <SelectItem value="Vencido">Vencido</SelectItem>
                          <SelectItem value="Pendiente">Pendiente</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </CardContent>
                </Card>

                {/* Acciones adicionales */}
                <Card className="bg-futuristic-background/50 border-futuristic-primary/10">
                  <CardHeader>
                    <CardTitle className="text-futuristic-text-primary text-lg flex items-center gap-2">
                      <Shield className="w-5 h-5" />
                      Acciones Administrativas
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-wrap gap-3">
                      <Button
                        variant="outline"
                        className="border-futuristic-warning/30 text-futuristic-warning hover:bg-futuristic-warning/5 bg-transparent"
                      >
                        <Shield className="w-4 h-4 mr-2" />
                        Resetear Contraseñas
                      </Button>
                      <Button
                        variant="outline"
                        className="border-futuristic-info/30 text-futuristic-info hover:bg-futuristic-info/5 bg-transparent"
                      >
                        <Activity className="w-4 h-4 mr-2" />
                        Ver Actividad
                      </Button>
                      <Button
                        variant="outline"
                        className="border-futuristic-creative/30 text-futuristic-creative hover:bg-futuristic-creative/5 bg-transparent"
                      >
                        <Download className="w-4 h-4 mr-2" />
                        Exportar Datos
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <DialogFooter>
                <Button
                  variant="outline"
                  onClick={() => {
                    setIsEditDialogOpen(false)
                    setEditFormData({
                      name: "",
                      code: "",
                      address: "",
                      district: "",
                      municipality: "",
                      province: "",
                      region: "",
                      directorName: "",
                      directorPhone: "",
                      email: "",
                      totalStudents: "",
                      totalStaff: "",
                      subscriptionType: "",
                      status: "",
                      paymentStatus: "",
                    })
                  }}
                  className="border-futuristic-primary/30 text-futuristic-text-secondary"
                >
                  Cancelar
                </Button>
                <Button
                  className="bg-gradient-to-r from-futuristic-primary to-futuristic-primary-light"
                  disabled={
                    !editFormData.name ||
                    !editFormData.code ||
                    !editFormData.address ||
                    !editFormData.directorName ||
                    !editFormData.directorPhone ||
                    !editFormData.email ||
                    !editFormData.subscriptionType ||
                    !editFormData.status
                  }
                >
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Guardar Cambios
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        )}
      </main>
    </div>
  )
}
