"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import {
  Search,
  Filter,
  Download,
  Eye,
  LogIn,
  Edit,
  Trash2,
  FileText,
  Plus,
  CalendarIcon,
  Monitor,
  MapPin,
  Clock,
  User,
  Building,
} from "lucide-react"

// Datos de ejemplo para logs
const logsData = [
  {
    id: "LOG-001",
    timestamp: "2024-01-15 14:30:25",
    user: {
      name: "María González",
      email: "maria.gonzalez@colegio1.edu",
      role: "Director",
    },
    action: "login",
    description: "Inició sesión en el sistema",
    details: "Acceso exitoso desde navegador Chrome",
    ip: "192.168.1.100",
    school: "Colegio San José",
    device: "Chrome 120.0 - Windows 10",
    location: "Bogotá, Colombia",
  },
  {
    id: "LOG-002",
    timestamp: "2024-01-15 14:25:10",
    user: {
      name: "Carlos Rodríguez",
      email: "carlos.rodriguez@colegio2.edu",
      role: "Profesor",
    },
    action: "edit",
    description: "Editó calificaciones del estudiante Ana Martínez",
    details: "Cambió nota de Matemáticas de 3.5 a 4.2",
    ip: "192.168.1.105",
    school: "Colegio Santa María",
    device: "Firefox 121.0 - macOS",
    location: "Medellín, Colombia",
  },
  {
    id: "LOG-003",
    timestamp: "2024-01-15 14:20:45",
    user: {
      name: "Ana Pérez",
      email: "ana.perez@parent.com",
      role: "Padre",
    },
    action: "export",
    description: "Generó boletín PDF del estudiante Luis Pérez",
    details: "Descargó boletín del primer período académico",
    ip: "192.168.1.110",
    school: "Colegio San José",
    device: "Safari 17.0 - iOS",
    location: "Cali, Colombia",
  },
  {
    id: "LOG-004",
    timestamp: "2024-01-15 14:15:30",
    user: {
      name: "Super Admin",
      email: "admin@edugestión360.com",
      role: "Super Admin",
    },
    action: "create",
    description: "Creó nuevo usuario profesor",
    details: "Agregó profesor Juan Ramírez al Colegio Santa María",
    ip: "192.168.1.1",
    school: "Sistema Global",
    device: "Chrome 120.0 - Windows 11",
    location: "Bogotá, Colombia",
  },
  {
    id: "LOG-005",
    timestamp: "2024-01-15 14:10:15",
    user: {
      name: "Laura Jiménez",
      email: "laura.jimenez@colegio3.edu",
      role: "Director",
    },
    action: "delete",
    description: "Eliminó registro de estudiante inactivo",
    details: "Eliminó estudiante Pedro Gómez (graduado 2023)",
    ip: "192.168.1.120",
    school: "Colegio Los Andes",
    device: "Edge 120.0 - Windows 10",
    location: "Barranquilla, Colombia",
  },
]

const actionIcons = {
  login: LogIn,
  edit: Edit,
  delete: Trash2,
  export: FileText,
  create: Plus,
}

const actionColors = {
  login: "bg-futuristic-success/10 text-futuristic-success border-futuristic-success/20",
  edit: "bg-futuristic-info/10 text-futuristic-info border-futuristic-info/20",
  delete: "bg-futuristic-error/10 text-futuristic-error border-futuristic-error/20",
  export: "bg-futuristic-creative/10 text-futuristic-creative border-futuristic-creative/20",
  create: "bg-futuristic-warning/10 text-futuristic-warning border-futuristic-warning/20",
}

const roleColors = {
  "Super Admin": "bg-futuristic-error/10 text-futuristic-error border-futuristic-error/20",
  Director: "bg-futuristic-info/10 text-futuristic-info border-futuristic-info/20",
  Profesor: "bg-futuristic-success/10 text-futuristic-success border-futuristic-success/20",
  Padre: "bg-futuristic-creative/10 text-futuristic-creative border-futuristic-creative/20",
}

export default function LogsPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedUser, setSelectedUser] = useState("")
  const [selectedRole, setSelectedRole] = useState("all")
  const [selectedAction, setSelectedAction] = useState("all")
  const [selectedSchool, setSelectedSchool] = useState("all")
  const [dateFrom, setDateFrom] = useState<Date>()
  const [dateTo, setDateTo] = useState<Date>()
  const [selectedLog, setSelectedLog] = useState<any>(null)

  const filteredLogs = logsData.filter((log) => {
    return (
      (log.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        log.user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        log.user.email.toLowerCase().includes(searchTerm.toLowerCase())) &&
      (selectedUser === "" || log.user.email === selectedUser) &&
      (selectedRole === "all" || log.user.role === selectedRole) &&
      (selectedAction === "all" || log.action === selectedAction) &&
      (selectedSchool === "all" || log.school === selectedSchool)
    )
  })

  const exportLogs = (format: "csv" | "pdf") => {
    console.log(`Exportando logs en formato ${format}`)
    // Aquí iría la lógica de exportación
  }

  return (
    <div className="space-y-6">
      {/* Header con estadísticas */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-futuristic-surface border-futuristic-primary/10 hover:border-futuristic-primary/30 transition-all duration-300 hover:shadow-lg hover:shadow-futuristic-primary/10">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-futuristic-text-secondary">Acciones Hoy</p>
                <p className="text-2xl font-bold text-futuristic-text-primary">1,247</p>
              </div>
              <div className="w-10 h-10 bg-gradient-to-br from-futuristic-primary to-futuristic-primary-light rounded-xl flex items-center justify-center">
                <Clock className="h-5 w-5 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-futuristic-surface border-futuristic-primary/10 hover:border-futuristic-primary/30 transition-all duration-300 hover:shadow-lg hover:shadow-futuristic-success/10">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-futuristic-text-secondary">Usuarios Activos</p>
                <p className="text-2xl font-bold text-futuristic-text-primary">89</p>
              </div>
              <div className="w-10 h-10 bg-gradient-to-br from-futuristic-success to-futuristic-amber rounded-xl flex items-center justify-center">
                <User className="h-5 w-5 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-futuristic-surface border-futuristic-primary/10 hover:border-futuristic-primary/30 transition-all duration-300 hover:shadow-lg hover:shadow-futuristic-info/10">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-futuristic-text-secondary">Colegios Activos</p>
                <p className="text-2xl font-bold text-futuristic-text-primary">12</p>
              </div>
              <div className="w-10 h-10 bg-gradient-to-br from-futuristic-info to-futuristic-creative rounded-xl flex items-center justify-center">
                <Building className="h-5 w-5 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-futuristic-surface border-futuristic-primary/10 hover:border-futuristic-primary/30 transition-all duration-300 hover:shadow-lg hover:shadow-futuristic-creative/10">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-futuristic-text-secondary">Logs Totales</p>
                <p className="text-2xl font-bold text-futuristic-text-primary">45,892</p>
              </div>
              <div className="w-10 h-10 bg-gradient-to-br from-futuristic-creative to-futuristic-warning rounded-xl flex items-center justify-center">
                <FileText className="h-5 w-5 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filtros */}
      <Card className="bg-futuristic-surface border-futuristic-primary/10">
        <CardHeader>
          <CardTitle className="text-futuristic-text-primary flex items-center gap-2">
            <Filter className="w-5 h-5" />
            Filtros Avanzados
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-futuristic-text-tertiary w-4 h-4" />
              <Input
                placeholder="Buscar logs..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-futuristic-background/50 border-futuristic-primary/20"
              />
            </div>

            <Select value={selectedRole} onValueChange={setSelectedRole}>
              <SelectTrigger className="bg-futuristic-background/50 border-futuristic-primary/20">
                <SelectValue placeholder="Rol" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos los roles</SelectItem>
                <SelectItem value="Super Admin">Super Admin</SelectItem>
                <SelectItem value="Director">Director</SelectItem>
                <SelectItem value="Profesor">Profesor</SelectItem>
                <SelectItem value="Padre">Padre</SelectItem>
              </SelectContent>
            </Select>

            <Select value={selectedAction} onValueChange={setSelectedAction}>
              <SelectTrigger className="bg-futuristic-background/50 border-futuristic-primary/20">
                <SelectValue placeholder="Acción" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas las acciones</SelectItem>
                <SelectItem value="login">Inicio de sesión</SelectItem>
                <SelectItem value="edit">Edición</SelectItem>
                <SelectItem value="delete">Eliminación</SelectItem>
                <SelectItem value="export">Exportación</SelectItem>
                <SelectItem value="create">Creación</SelectItem>
              </SelectContent>
            </Select>

            <Select value={selectedSchool} onValueChange={setSelectedSchool}>
              <SelectTrigger className="bg-futuristic-background/50 border-futuristic-primary/20">
                <SelectValue placeholder="Colegio" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos los colegios</SelectItem>
                <SelectItem value="Colegio San José">Colegio San José</SelectItem>
                <SelectItem value="Colegio Santa María">Colegio Santa María</SelectItem>
                <SelectItem value="Colegio Los Andes">Colegio Los Andes</SelectItem>
              </SelectContent>
            </Select>

            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" className="bg-futuristic-background/50 border-futuristic-primary/20">
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  Desde
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar mode="single" selected={dateFrom} onSelect={setDateFrom} initialFocus />
              </PopoverContent>
            </Popover>

            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" className="bg-futuristic-background/50 border-futuristic-primary/20">
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  Hasta
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar mode="single" selected={dateTo} onSelect={setDateTo} initialFocus />
              </PopoverContent>
            </Popover>
          </div>

          <div className="flex gap-2">
            <Button
              onClick={() => exportLogs("csv")}
              className="bg-gradient-to-r from-futuristic-primary to-futuristic-primary-light hover:from-futuristic-primary-dark hover:to-futuristic-primary"
            >
              <Download className="mr-2 h-4 w-4" />
              Exportar CSV
            </Button>
            <Button
              onClick={() => exportLogs("pdf")}
              variant="outline"
              className="border-futuristic-primary/30 text-futuristic-primary hover:bg-futuristic-primary/5"
            >
              <Download className="mr-2 h-4 w-4" />
              Exportar PDF
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Tabla de Logs */}
      <Card className="bg-futuristic-surface border-futuristic-primary/10">
        <CardHeader>
          <CardTitle className="text-futuristic-text-primary">Registro de Actividades</CardTitle>
          <CardDescription className="text-futuristic-text-secondary">
            Mostrando {filteredLogs.length} de {logsData.length} registros
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {filteredLogs.map((log) => {
              const ActionIcon = actionIcons[log.action as keyof typeof actionIcons]

              return (
                <div
                  key={log.id}
                  className="flex items-center justify-between p-4 rounded-lg bg-futuristic-background/30 border border-futuristic-primary/10 hover:border-futuristic-primary/30 transition-colors"
                >
                  <div className="flex items-center gap-4 flex-1">
                    <div className={`p-2 rounded-lg border ${actionColors[log.action as keyof typeof actionColors]}`}>
                      <ActionIcon className="h-4 w-4" />
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-sm text-futuristic-text-secondary">{log.timestamp}</span>
                        <Badge className={`text-xs ${roleColors[log.user.role as keyof typeof roleColors]}`}>
                          {log.user.role}
                        </Badge>
                        <Badge
                          variant="outline"
                          className="text-xs border-futuristic-primary/30 text-futuristic-text-secondary"
                        >
                          {log.school}
                        </Badge>
                      </div>

                      <p className="text-futuristic-text-primary font-medium">{log.description}</p>
                      <p className="text-sm text-futuristic-text-secondary">
                        {log.user.name} ({log.user.email})
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <Badge
                      variant="outline"
                      className="text-xs border-futuristic-primary/30 text-futuristic-text-tertiary"
                    >
                      {log.ip}
                    </Badge>

                    <Dialog>
                      <DialogTrigger asChild>
                        <Button
                          size="sm"
                          variant="outline"
                          className="border-futuristic-primary/30 text-futuristic-primary hover:bg-futuristic-primary/5"
                          onClick={() => setSelectedLog(log)}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-2xl bg-futuristic-surface border-futuristic-primary/20">
                        <DialogHeader>
                          <DialogTitle className="text-futuristic-text-primary">Detalle del Log</DialogTitle>
                          <DialogDescription className="text-futuristic-text-secondary">
                            Información completa del evento {selectedLog?.id}
                          </DialogDescription>
                        </DialogHeader>

                        {selectedLog && (
                          <div className="space-y-4">
                            <div className="grid grid-cols-2 gap-4">
                              <div>
                                <label className="text-sm font-medium text-futuristic-text-secondary">
                                  Fecha y Hora
                                </label>
                                <p className="text-futuristic-text-primary">{selectedLog.timestamp}</p>
                              </div>
                              <div>
                                <label className="text-sm font-medium text-futuristic-text-secondary">ID del Log</label>
                                <p className="text-futuristic-text-primary">{selectedLog.id}</p>
                              </div>
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                              <div>
                                <label className="text-sm font-medium text-futuristic-text-secondary">Usuario</label>
                                <p className="text-futuristic-text-primary">{selectedLog.user.name}</p>
                                <p className="text-sm text-futuristic-text-secondary">{selectedLog.user.email}</p>
                              </div>
                              <div>
                                <label className="text-sm font-medium text-futuristic-text-secondary">Rol</label>
                                <Badge className={`${roleColors[selectedLog.user.role as keyof typeof roleColors]}`}>
                                  {selectedLog.user.role}
                                </Badge>
                              </div>
                            </div>

                            <div>
                              <label className="text-sm font-medium text-futuristic-text-secondary">
                                Acción Realizada
                              </label>
                              <p className="text-futuristic-text-primary">{selectedLog.description}</p>
                            </div>

                            <div>
                              <label className="text-sm font-medium text-futuristic-text-secondary">
                                Detalles Adicionales
                              </label>
                              <p className="text-futuristic-text-secondary">{selectedLog.details}</p>
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                              <div>
                                <label className="text-sm font-medium text-futuristic-text-secondary">Colegio</label>
                                <p className="text-futuristic-text-primary">{selectedLog.school}</p>
                              </div>
                              <div>
                                <label className="text-sm font-medium text-futuristic-text-secondary">
                                  Dirección IP
                                </label>
                                <p className="text-futuristic-text-primary">{selectedLog.ip}</p>
                              </div>
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                              <div>
                                <label className="text-sm font-medium text-futuristic-text-secondary">
                                  Dispositivo
                                </label>
                                <p className="text-futuristic-text-primary flex items-center gap-2">
                                  <Monitor className="h-4 w-4" />
                                  {selectedLog.device}
                                </p>
                              </div>
                              <div>
                                <label className="text-sm font-medium text-futuristic-text-secondary">Ubicación</label>
                                <p className="text-futuristic-text-primary flex items-center gap-2">
                                  <MapPin className="h-4 w-4" />
                                  {selectedLog.location}
                                </p>
                              </div>
                            </div>
                          </div>
                        )}
                      </DialogContent>
                    </Dialog>
                  </div>
                </div>
              )
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
