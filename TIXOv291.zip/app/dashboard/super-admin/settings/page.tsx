"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import {
  MessageSquare,
  Mail,
  Shield,
  Globe,
  TestTube,
  Save,
  CheckCircle,
  AlertCircle,
  Upload,
  Eye,
  EyeOff,
} from "lucide-react"

export default function SettingsPage() {
  const [showPassword, setShowPassword] = useState(false)
  const [showApiKey, setShowApiKey] = useState(false)
  const [saved, setSaved] = useState(false)
  const [testingConnection, setTestingConnection] = useState(false)

  // Estados para configuraciones
  const [whatsappEnabled, setWhatsappEnabled] = useState(true)
  const [emailEnabled, setEmailEnabled] = useState(true)
  const [twoFactorEnabled, setTwoFactorEnabled] = useState(false)
  const [sessionBlockingEnabled, setSessionBlockingEnabled] = useState(false)

  const [settings, setSettings] = useState({
    // WhatsApp
    whatsappNumber: "+57 300 123 4567",
    whatsappToken: "EAABwzLixnjYBAOZCZCqZCZBXZC...",
    whatsappSid: "AC1234567890abcdef1234567890abcdef",
    whatsappSender: "EduGestión360",

    // Email
    smtpServer: "smtp.gmail.com",
    smtpPort: "587",
    emailSender: "noreply@edugestión360.com",
    emailPassword: "••••••••••••",
    emailSecurity: "TLS",

    // Sistema
    systemLanguage: "es",
    timezone: "America/Bogota",
    dateFormat: "DD/MM/YYYY",
    platformName: "EduGestión360",

    // Seguridad
    maxLoginAttempts: "5",
    lockoutDuration: "15",
    sessionTimeout: "60",
    require2FAForDirectors: false,
  })

  const handleSave = () => {
    setTestingConnection(true)
    setTimeout(() => {
      setTestingConnection(false)
      setSaved(true)
      setTimeout(() => setSaved(false), 3000)
    }, 2000)
  }

  const testWhatsApp = () => {
    setTestingConnection(true)
    setTimeout(() => {
      setTestingConnection(false)
      alert("Mensaje de prueba enviado exitosamente a WhatsApp")
    }, 2000)
  }

  const testEmail = () => {
    setTestingConnection(true)
    setTimeout(() => {
      setTestingConnection(false)
      alert("Correo de prueba enviado exitosamente")
    }, 2000)
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-futuristic-text-primary">Configuración del Sistema</h1>
          <p className="text-futuristic-text-secondary">Administra las configuraciones globales de la plataforma</p>
        </div>

        <Button
          onClick={handleSave}
          disabled={testingConnection}
          className="bg-gradient-to-r from-futuristic-primary to-futuristic-primary-light hover:from-futuristic-primary-dark hover:to-futuristic-primary"
        >
          {saved ? (
            <>
              <CheckCircle className="mr-2 h-4 w-4" />
              Guardado
            </>
          ) : (
            <>
              <Save className="mr-2 h-4 w-4" />
              Guardar Cambios
            </>
          )}
        </Button>
      </div>

      <Tabs defaultValue="integrations" className="space-y-6">
        <TabsList className="bg-futuristic-surface border border-futuristic-primary/10">
          <TabsTrigger value="integrations" className="data-[state=active]:bg-futuristic-primary/20">
            Integraciones
          </TabsTrigger>
          <TabsTrigger value="system" className="data-[state=active]:bg-futuristic-primary/20">
            Sistema
          </TabsTrigger>
          <TabsTrigger value="security" className="data-[state=active]:bg-futuristic-primary/20">
            Seguridad
          </TabsTrigger>
        </TabsList>

        {/* Integraciones */}
        <TabsContent value="integrations" className="space-y-6">
          {/* WhatsApp API */}
          <Card className="bg-futuristic-surface border-futuristic-primary/10">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <MessageSquare className="h-5 w-5 text-futuristic-primary" />
                  <CardTitle className="text-futuristic-text-primary">WhatsApp API</CardTitle>
                </div>
                <div className="flex items-center gap-2">
                  <Switch checked={whatsappEnabled} onCheckedChange={setWhatsappEnabled} />
                  <Badge
                    className={
                      whatsappEnabled
                        ? "bg-futuristic-success/10 text-futuristic-success border-futuristic-success/20"
                        : "bg-futuristic-error/10 text-futuristic-error border-futuristic-error/20"
                    }
                  >
                    {whatsappEnabled ? "Activo" : "Inactivo"}
                  </Badge>
                </div>
              </div>
              <CardDescription className="text-futuristic-text-secondary">
                Configuración para envío de mensajes automáticos vía WhatsApp
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="whatsapp-number" className="text-futuristic-text-primary">
                    Número Asociado
                  </Label>
                  <Input
                    id="whatsapp-number"
                    value={settings.whatsappNumber}
                    onChange={(e) => setSettings({ ...settings, whatsappNumber: e.target.value })}
                    className="bg-futuristic-background/50 border-futuristic-primary/20"
                    disabled={!whatsappEnabled}
                  />
                </div>
                <div>
                  <Label htmlFor="whatsapp-sender" className="text-futuristic-text-primary">
                    Nombre del Remitente
                  </Label>
                  <Input
                    id="whatsapp-sender"
                    value={settings.whatsappSender}
                    onChange={(e) => setSettings({ ...settings, whatsappSender: e.target.value })}
                    className="bg-futuristic-background/50 border-futuristic-primary/20"
                    disabled={!whatsappEnabled}
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="whatsapp-token" className="text-futuristic-text-primary">
                  Token de Autenticación
                </Label>
                <div className="relative">
                  <Input
                    id="whatsapp-token"
                    type={showApiKey ? "text" : "password"}
                    value={settings.whatsappToken}
                    onChange={(e) => setSettings({ ...settings, whatsappToken: e.target.value })}
                    className="bg-futuristic-background/50 border-futuristic-primary/20 pr-10"
                    disabled={!whatsappEnabled}
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                    onClick={() => setShowApiKey(!showApiKey)}
                  >
                    {showApiKey ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </Button>
                </div>
              </div>

              <div>
                <Label htmlFor="whatsapp-sid" className="text-futuristic-text-primary">
                  SID de Cuenta
                </Label>
                <Input
                  id="whatsapp-sid"
                  value={settings.whatsappSid}
                  onChange={(e) => setSettings({ ...settings, whatsappSid: e.target.value })}
                  className="bg-futuristic-background/50 border-futuristic-primary/20"
                  disabled={!whatsappEnabled}
                />
              </div>

              <Button
                onClick={testWhatsApp}
                disabled={!whatsappEnabled || testingConnection}
                variant="outline"
                className="border-futuristic-primary/30 text-futuristic-primary hover:bg-futuristic-primary/5"
              >
                <TestTube className="mr-2 h-4 w-4" />
                {testingConnection ? "Probando..." : "Probar Conexión"}
              </Button>
            </CardContent>
          </Card>

          {/* Email SMTP */}
          <Card className="bg-futuristic-surface border-futuristic-primary/10">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Mail className="h-5 w-5 text-futuristic-primary" />
                  <CardTitle className="text-futuristic-text-primary">Configuración SMTP</CardTitle>
                </div>
                <div className="flex items-center gap-2">
                  <Switch checked={emailEnabled} onCheckedChange={setEmailEnabled} />
                  <Badge
                    className={
                      emailEnabled
                        ? "bg-futuristic-success/10 text-futuristic-success border-futuristic-success/20"
                        : "bg-futuristic-error/10 text-futuristic-error border-futuristic-error/20"
                    }
                  >
                    {emailEnabled ? "Activo" : "Inactivo"}
                  </Badge>
                </div>
              </div>
              <CardDescription className="text-futuristic-text-secondary">
                Configuración para envío de correos electrónicos automáticos
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="smtp-server" className="text-futuristic-text-primary">
                    Servidor SMTP
                  </Label>
                  <Input
                    id="smtp-server"
                    value={settings.smtpServer}
                    onChange={(e) => setSettings({ ...settings, smtpServer: e.target.value })}
                    className="bg-futuristic-background/50 border-futuristic-primary/20"
                    disabled={!emailEnabled}
                  />
                </div>
                <div>
                  <Label htmlFor="smtp-port" className="text-futuristic-text-primary">
                    Puerto
                  </Label>
                  <Input
                    id="smtp-port"
                    value={settings.smtpPort}
                    onChange={(e) => setSettings({ ...settings, smtpPort: e.target.value })}
                    className="bg-futuristic-background/50 border-futuristic-primary/20"
                    disabled={!emailEnabled}
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="email-sender" className="text-futuristic-text-primary">
                  Correo Emisor
                </Label>
                <Input
                  id="email-sender"
                  type="email"
                  value={settings.emailSender}
                  onChange={(e) => setSettings({ ...settings, emailSender: e.target.value })}
                  className="bg-futuristic-background/50 border-futuristic-primary/20"
                  disabled={!emailEnabled}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="email-password" className="text-futuristic-text-primary">
                    Contraseña/API Key
                  </Label>
                  <div className="relative">
                    <Input
                      id="email-password"
                      type={showPassword ? "text" : "password"}
                      value={settings.emailPassword}
                      onChange={(e) => setSettings({ ...settings, emailPassword: e.target.value })}
                      className="bg-futuristic-background/50 border-futuristic-primary/20 pr-10"
                      disabled={!emailEnabled}
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                      onClick={() => setShowPassword(!showPassword)}
                    >
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </Button>
                  </div>
                </div>
                <div>
                  <Label htmlFor="email-security" className="text-futuristic-text-primary">
                    Seguridad
                  </Label>
                  <Select
                    value={settings.emailSecurity}
                    onValueChange={(value) => setSettings({ ...settings, emailSecurity: value })}
                  >
                    <SelectTrigger
                      className="bg-futuristic-background/50 border-futuristic-primary/20"
                      disabled={!emailEnabled}
                    >
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="SSL">SSL</SelectItem>
                      <SelectItem value="TLS">TLS</SelectItem>
                      <SelectItem value="none">Ninguna</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <Button
                onClick={testEmail}
                disabled={!emailEnabled || testingConnection}
                variant="outline"
                className="border-futuristic-primary/30 text-futuristic-primary hover:bg-futuristic-primary/5"
              >
                <TestTube className="mr-2 h-4 w-4" />
                {testingConnection ? "Enviando..." : "Enviar Correo de Prueba"}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Sistema */}
        <TabsContent value="system" className="space-y-6">
          <Card className="bg-futuristic-surface border-futuristic-primary/10">
            <CardHeader>
              <div className="flex items-center gap-2">
                <Globe className="h-5 w-5 text-futuristic-primary" />
                <CardTitle className="text-futuristic-text-primary">Parámetros Globales</CardTitle>
              </div>
              <CardDescription className="text-futuristic-text-secondary">
                Configuraciones generales de la plataforma
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="system-language" className="text-futuristic-text-primary">
                    Idioma del Sistema
                  </Label>
                  <Select
                    value={settings.systemLanguage}
                    onValueChange={(value) => setSettings({ ...settings, systemLanguage: value })}
                  >
                    <SelectTrigger className="bg-futuristic-background/50 border-futuristic-primary/20">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="es">Español</SelectItem>
                      <SelectItem value="en">Inglés</SelectItem>
                      <SelectItem value="pt">Portugués</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="timezone" className="text-futuristic-text-primary">
                    Zona Horaria
                  </Label>
                  <Select
                    value={settings.timezone}
                    onValueChange={(value) => setSettings({ ...settings, timezone: value })}
                  >
                    <SelectTrigger className="bg-futuristic-background/50 border-futuristic-primary/20">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="America/Bogota">Bogotá (UTC-5)</SelectItem>
                      <SelectItem value="America/Mexico_City">Ciudad de México (UTC-6)</SelectItem>
                      <SelectItem value="America/Lima">Lima (UTC-5)</SelectItem>
                      <SelectItem value="America/Buenos_Aires">Buenos Aires (UTC-3)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="date-format" className="text-futuristic-text-primary">
                    Formato de Fecha
                  </Label>
                  <Select
                    value={settings.dateFormat}
                    onValueChange={(value) => setSettings({ ...settings, dateFormat: value })}
                  >
                    <SelectTrigger className="bg-futuristic-background/50 border-futuristic-primary/20">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="DD/MM/YYYY">DD/MM/YYYY</SelectItem>
                      <SelectItem value="MM/DD/YYYY">MM/DD/YYYY</SelectItem>
                      <SelectItem value="YYYY-MM-DD">YYYY-MM-DD</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="platform-name" className="text-futuristic-text-primary">
                    Nombre de la Plataforma
                  </Label>
                  <Input
                    id="platform-name"
                    value={settings.platformName}
                    onChange={(e) => setSettings({ ...settings, platformName: e.target.value })}
                    className="bg-futuristic-background/50 border-futuristic-primary/20"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="logo-upload" className="text-futuristic-text-primary">
                  Logo Institucional
                </Label>
                <div className="flex items-center gap-4 mt-2">
                  <div className="w-16 h-16 bg-futuristic-primary/20 border border-futuristic-primary/30 rounded-lg flex items-center justify-center">
                    <Upload className="h-6 w-6 text-futuristic-primary" />
                  </div>
                  <Button
                    variant="outline"
                    className="border-futuristic-primary/30 text-futuristic-primary hover:bg-futuristic-primary/5"
                  >
                    <Upload className="mr-2 h-4 w-4" />
                    Subir Logo
                  </Button>
                </div>
                <p className="text-sm text-futuristic-text-secondary mt-2">
                  Formato recomendado: PNG o SVG, tamaño máximo 2MB
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Seguridad */}
        <TabsContent value="security" className="space-y-6">
          <Card className="bg-futuristic-surface border-futuristic-primary/10">
            <CardHeader>
              <div className="flex items-center gap-2">
                <Shield className="h-5 w-5 text-futuristic-primary" />
                <CardTitle className="text-futuristic-text-primary">Configuración de Seguridad</CardTitle>
              </div>
              <CardDescription className="text-futuristic-text-secondary">
                Ajustes de seguridad y autenticación para toda la plataforma
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Intentos de Login */}
              <div className="space-y-4">
                <h4 className="text-lg font-medium text-futuristic-text-primary">Control de Acceso</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="max-attempts" className="text-futuristic-text-primary">
                      Intentos Máximos de Login
                    </Label>
                    <Input
                      id="max-attempts"
                      type="number"
                      value={settings.maxLoginAttempts}
                      onChange={(e) => setSettings({ ...settings, maxLoginAttempts: e.target.value })}
                      className="bg-futuristic-background/50 border-futuristic-primary/20"
                    />
                    <p className="text-sm text-futuristic-text-secondary mt-1">
                      Número de intentos fallidos antes del bloqueo
                    </p>
                  </div>
                  <div>
                    <Label htmlFor="lockout-duration" className="text-futuristic-text-primary">
                      Duración del Bloqueo (minutos)
                    </Label>
                    <Input
                      id="lockout-duration"
                      type="number"
                      value={settings.lockoutDuration}
                      onChange={(e) => setSettings({ ...settings, lockoutDuration: e.target.value })}
                      className="bg-futuristic-background/50 border-futuristic-primary/20"
                    />
                    <p className="text-sm text-futuristic-text-secondary mt-1">Tiempo de bloqueo temporal</p>
                  </div>
                </div>
              </div>

              {/* Autenticación de Dos Factores */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-lg font-medium text-futuristic-text-primary">
                      Autenticación de Dos Factores (2FA)
                    </h4>
                    <p className="text-sm text-futuristic-text-secondary">Añade una capa extra de seguridad</p>
                  </div>
                  <Switch checked={twoFactorEnabled} onCheckedChange={setTwoFactorEnabled} />
                </div>

                {twoFactorEnabled && (
                  <div className="space-y-4 p-4 bg-futuristic-background/30 rounded-lg border border-futuristic-primary/20">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="require-2fa-directors" className="text-futuristic-text-primary">
                        Requerir 2FA para Directores
                      </Label>
                      <Switch
                        checked={settings.require2FAForDirectors}
                        onCheckedChange={(checked) => setSettings({ ...settings, require2FAForDirectors: checked })}
                      />
                    </div>
                    <div className="flex items-center gap-2 text-sm text-futuristic-warning">
                      <AlertCircle className="h-4 w-4" />
                      Los usuarios serán notificados cuando se active esta opción
                    </div>
                  </div>
                )}
              </div>

              {/* Control de Sesiones */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-lg font-medium text-futuristic-text-primary">Control de Sesiones</h4>
                    <p className="text-sm text-futuristic-text-secondary">Gestión de sesiones activas</p>
                  </div>
                  <Switch checked={sessionBlockingEnabled} onCheckedChange={setSessionBlockingEnabled} />
                </div>

                <div>
                  <Label htmlFor="session-timeout" className="text-futuristic-text-primary">
                    Tiempo de Expiración por Inactividad (minutos)
                  </Label>
                  <Input
                    id="session-timeout"
                    type="number"
                    value={settings.sessionTimeout}
                    onChange={(e) => setSettings({ ...settings, sessionTimeout: e.target.value })}
                    className="bg-futuristic-background/50 border-futuristic-primary/20"
                  />
                  <p className="text-sm text-futuristic-text-secondary mt-1">
                    Tiempo antes de cerrar sesión automáticamente
                  </p>
                </div>

                {sessionBlockingEnabled && (
                  <div className="p-4 bg-futuristic-background/30 rounded-lg border border-futuristic-primary/20">
                    <div className="flex items-center gap-2 text-sm text-futuristic-info">
                      <CheckCircle className="h-4 w-4" />
                      Se bloqueará el acceso simultáneo desde múltiples dispositivos
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
