import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"

export default function SupportLoading() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="space-y-2">
          <Skeleton className="h-8 w-64 bg-gray-700" />
          <Skeleton className="h-4 w-96 bg-gray-700" />
        </div>
        <Skeleton className="h-10 w-32 bg-gray-700" />
      </div>

      {/* Dashboard Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {[...Array(4)].map((_, i) => (
          <Card key={i} className="bg-cyber-dark/50 border-cyber-primary/30">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="space-y-2">
                  <Skeleton className="h-4 w-20 bg-gray-700" />
                  <Skeleton className="h-8 w-16 bg-gray-700" />
                </div>
                <Skeleton className="h-8 w-8 bg-gray-700" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Filtros */}
      <Card className="bg-cyber-dark/50 border-cyber-primary/30">
        <CardHeader>
          <Skeleton className="h-6 w-32 bg-gray-700" />
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {[...Array(4)].map((_, i) => (
              <Skeleton key={i} className="h-10 bg-gray-700" />
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Lista de Tickets */}
      <Card className="bg-cyber-dark/50 border-cyber-primary/30">
        <CardHeader>
          <Skeleton className="h-6 w-48 bg-gray-700" />
          <Skeleton className="h-4 w-64 bg-gray-700" />
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[...Array(5)].map((_, i) => (
              <div
                key={i}
                className="flex items-center justify-between p-4 rounded-lg bg-cyber-dark/30 border border-cyber-primary/20"
              >
                <div className="flex items-center gap-4 flex-1">
                  <div className="flex flex-col gap-1">
                    <Skeleton className="h-5 w-16 bg-gray-700" />
                    <Skeleton className="h-5 w-12 bg-gray-700" />
                  </div>
                  <div className="flex-1 space-y-2">
                    <div className="flex items-center gap-2">
                      <Skeleton className="h-4 w-20 bg-gray-700" />
                      <Skeleton className="h-4 w-32 bg-gray-700" />
                    </div>
                    <Skeleton className="h-5 w-64 bg-gray-700" />
                    <div className="flex items-center gap-4">
                      <Skeleton className="h-4 w-24 bg-gray-700" />
                      <Skeleton className="h-4 w-32 bg-gray-700" />
                    </div>
                  </div>
                </div>
                <Skeleton className="h-8 w-24 bg-gray-700" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
