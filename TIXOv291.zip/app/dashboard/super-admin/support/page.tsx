"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Search,
  Filter,
  MessageSquare,
  CheckCircle,
  AlertTriangle,
  User,
  Building,
  Calendar,
  Send,
  Paperclip,
  Eye,
  BarChart3,
  TrendingUp,
  Timer,
} from "lucide-react"

// Datos de ejemplo para tickets
const ticketsData = [
  {
    id: "TKT-001",
    school: "Colegio San José",
    director: "María González",
    email: "maria.gonzalez@colegio1.edu",
    subject: "Error al generar boletines PDF",
    message:
      "Buenos días, tengo problemas para generar los boletines en PDF. El sistema me muestra un error cuando intento descargar los reportes del primer período.",
    status: "open",
    priority: "high",
    createdAt: "2024-01-15 09:30:00",
    updatedAt: "2024-01-15 09:30:00",
    attachments: ["error-screenshot.png"],
    responses: [],
  },
  {
    id: "TKT-002",
    school: "Colegio Santa María",
    director: "Carlos Rodríguez",
    email: "carlos.rodriguez@colegio2.edu",
    subject: "Consulta sobre configuración de calificaciones",
    message:
      "Necesito ayuda para configurar el sistema de calificaciones. ¿Cómo puedo cambiar la escala de notas de 1-5 a 1-10?",
    status: "in-progress",
    priority: "medium",
    createdAt: "2024-01-14 14:20:00",
    updatedAt: "2024-01-15 08:45:00",
    attachments: [],
    responses: [
      {
        id: 1,
        author: "Soporte EduGestión360",
        message:
          "Hola Carlos, para cambiar la escala de calificaciones debes ir a Configuración > Académico > Escalas de Calificación.",
        timestamp: "2024-01-15 08:45:00",
        isInternal: false,
      },
    ],
  },
  {
    id: "TKT-003",
    school: "Colegio Los Andes",
    director: "Laura Jiménez",
    email: "laura.jimenez@colegio3.edu",
    subject: "Solicitud de capacitación para profesores",
    message:
      "Queremos programar una capacitación para nuestros profesores sobre el uso de la plataforma. ¿Qué opciones tienen disponibles?",
    status: "resolved",
    priority: "low",
    createdAt: "2024-01-12 16:15:00",
    updatedAt: "2024-01-13 10:30:00",
    attachments: [],
    responses: [
      {
        id: 1,
        author: "Soporte EduGestión360",
        message:
          "Hola Laura, ofrecemos capacitaciones virtuales y presenciales. Te envío por correo el cronograma disponible.",
        timestamp: "2024-01-13 10:30:00",
        isInternal: false,
      },
    ],
  },
]

const statusColors = {
  open: "bg-futuristic-error/10 text-futuristic-error border-futuristic-error/20",
  "in-progress": "bg-futuristic-warning/10 text-futuristic-warning border-futuristic-warning/20",
  resolved: "bg-futuristic-success/10 text-futuristic-success border-futuristic-success/20",
}

const priorityColors = {
  high: "bg-futuristic-error/10 text-futuristic-error border-futuristic-error/20",
  medium: "bg-futuristic-warning/10 text-futuristic-warning border-futuristic-warning/20",
  low: "bg-futuristic-success/10 text-futuristic-success border-futuristic-success/20",
}

const statusLabels = {
  open: "Abierto",
  "in-progress": "En Progreso",
  resolved: "Resuelto",
}

const priorityLabels = {
  high: "Alta",
  medium: "Media",
  low: "Baja",
}

export default function SupportPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedStatus, setSelectedStatus] = useState("all")
  const [selectedPriority, setSelectedPriority] = useState("all")
  const [selectedSchool, setSelectedSchool] = useState("all")
  const [selectedTicket, setSelectedTicket] = useState<any>(null)
  const [newResponse, setNewResponse] = useState("")
  const [newInternalNote, setNewInternalNote] = useState("")

  const filteredTickets = ticketsData.filter((ticket) => {
    return (
      (ticket.subject.toLowerCase().includes(searchTerm.toLowerCase()) ||
        ticket.school.toLowerCase().includes(searchTerm.toLowerCase()) ||
        ticket.director.toLowerCase().includes(searchTerm.toLowerCase())) &&
      (selectedStatus === "all" || ticket.status === selectedStatus) &&
      (selectedPriority === "all" || ticket.priority === selectedPriority) &&
      (selectedSchool === "all" || ticket.school === selectedSchool)
    )
  })

  const handleStatusChange = (ticketId: string, newStatus: string) => {
    console.log(`Cambiando estado del ticket ${ticketId} a ${newStatus}`)
    // Aquí iría la lógica para actualizar el estado
  }

  const handlePriorityChange = (ticketId: string, newPriority: string) => {
    console.log(`Cambiando prioridad del ticket ${ticketId} a ${newPriority}`)
    // Aquí iría la lógica para actualizar la prioridad
  }

  const sendResponse = () => {
    if (newResponse.trim()) {
      console.log("Enviando respuesta:", newResponse)
      setNewResponse("")
      // Aquí iría la lógica para enviar la respuesta
    }
  }

  const addInternalNote = () => {
    if (newInternalNote.trim()) {
      console.log("Agregando nota interna:", newInternalNote)
      setNewInternalNote("")
      // Aquí iría la lógica para agregar la nota interna
    }
  }

  return (
    <div className="space-y-6">
      <Tabs defaultValue="tickets" className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-futuristic-text-primary">Centro de Soporte</h1>
            <p className="text-futuristic-text-secondary">Gestiona las solicitudes de ayuda de los colegios</p>
          </div>

          <TabsList className="bg-futuristic-surface border border-futuristic-primary/10">
            <TabsTrigger value="tickets" className="data-[state=active]:bg-futuristic-primary/20">
              Tickets
            </TabsTrigger>
            <TabsTrigger value="dashboard" className="data-[state=active]:bg-futuristic-primary/20">
              Dashboard
            </TabsTrigger>
          </TabsList>
        </div>

        {/* Dashboard de Soporte */}
        <TabsContent value="dashboard" className="space-y-6">
          {/* Métricas principales */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card className="bg-futuristic-surface border-futuristic-primary/10 hover:border-futuristic-primary/30 transition-all duration-300 hover:shadow-lg hover:shadow-futuristic-primary/10">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-futuristic-text-secondary">Total Tickets</p>
                    <p className="text-2xl font-bold text-futuristic-text-primary">127</p>
                  </div>
                  <div className="w-10 h-10 bg-gradient-to-br from-futuristic-primary to-futuristic-primary-light rounded-xl flex items-center justify-center">
                    <MessageSquare className="h-5 w-5 text-white" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-futuristic-surface border-futuristic-primary/10 hover:border-futuristic-primary/30 transition-all duration-300 hover:shadow-lg hover:shadow-futuristic-error/10">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-futuristic-text-secondary">Tickets Activos</p>
                    <p className="text-2xl font-bold text-futuristic-text-primary">23</p>
                  </div>
                  <div className="w-10 h-10 bg-gradient-to-br from-futuristic-error to-futuristic-warning rounded-xl flex items-center justify-center">
                    <AlertTriangle className="h-5 w-5 text-white" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-futuristic-surface border-futuristic-primary/10 hover:border-futuristic-primary/30 transition-all duration-300 hover:shadow-lg hover:shadow-futuristic-success/10">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-futuristic-text-secondary">Resueltos Este Mes</p>
                    <p className="text-2xl font-bold text-futuristic-text-primary">89</p>
                  </div>
                  <div className="w-10 h-10 bg-gradient-to-br from-futuristic-success to-futuristic-amber rounded-xl flex items-center justify-center">
                    <CheckCircle className="h-5 w-5 text-white" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-futuristic-surface border-futuristic-primary/10 hover:border-futuristic-primary/30 transition-all duration-300 hover:shadow-lg hover:shadow-futuristic-info/10">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-futuristic-text-secondary">Tiempo Promedio</p>
                    <p className="text-2xl font-bold text-futuristic-text-primary">2.4h</p>
                  </div>
                  <div className="w-10 h-10 bg-gradient-to-br from-futuristic-info to-futuristic-creative rounded-xl flex items-center justify-center">
                    <Timer className="h-5 w-5 text-white" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Gráficas y estadísticas */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="bg-futuristic-surface border-futuristic-primary/10">
              <CardHeader>
                <CardTitle className="text-futuristic-text-primary flex items-center gap-2">
                  <BarChart3 className="h-5 w-5" />
                  Tickets por Estado
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 bg-futuristic-error rounded-full"></div>
                      <span className="text-futuristic-text-secondary">Abiertos</span>
                    </div>
                    <span className="text-futuristic-text-primary font-medium">15</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 bg-futuristic-warning rounded-full"></div>
                      <span className="text-futuristic-text-secondary">En Progreso</span>
                    </div>
                    <span className="text-futuristic-text-primary font-medium">8</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 bg-futuristic-success rounded-full"></div>
                      <span className="text-futuristic-text-secondary">Resueltos</span>
                    </div>
                    <span className="text-futuristic-text-primary font-medium">104</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-futuristic-surface border-futuristic-primary/10">
              <CardHeader>
                <CardTitle className="text-futuristic-text-primary flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  Colegios con Más Tickets
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-futuristic-text-secondary">Colegio San José</span>
                    <span className="text-futuristic-text-primary font-medium">12</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-futuristic-text-secondary">Colegio Santa María</span>
                    <span className="text-futuristic-text-primary font-medium">8</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-futuristic-text-secondary">Colegio Los Andes</span>
                    <span className="text-futuristic-text-primary font-medium">6</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-futuristic-text-secondary">Colegio La Esperanza</span>
                    <span className="text-futuristic-text-primary font-medium">4</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Bandeja de Tickets */}
        <TabsContent value="tickets" className="space-y-6">
          {/* Filtros */}
          <Card className="bg-futuristic-surface border-futuristic-primary/10">
            <CardHeader>
              <CardTitle className="text-futuristic-text-primary flex items-center gap-2">
                <Filter className="h-5 w-5" />
                Filtros
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-futuristic-text-tertiary" />
                  <Input
                    placeholder="Buscar tickets..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 bg-futuristic-background/50 border-futuristic-primary/20"
                  />
                </div>

                <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                  <SelectTrigger className="bg-futuristic-background/50 border-futuristic-primary/20">
                    <SelectValue placeholder="Estado" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos los estados</SelectItem>
                    <SelectItem value="open">Abierto</SelectItem>
                    <SelectItem value="in-progress">En Progreso</SelectItem>
                    <SelectItem value="resolved">Resuelto</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={selectedPriority} onValueChange={setSelectedPriority}>
                  <SelectTrigger className="bg-futuristic-background/50 border-futuristic-primary/20">
                    <SelectValue placeholder="Prioridad" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todas las prioridades</SelectItem>
                    <SelectItem value="high">Alta</SelectItem>
                    <SelectItem value="medium">Media</SelectItem>
                    <SelectItem value="low">Baja</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={selectedSchool} onValueChange={setSelectedSchool}>
                  <SelectTrigger className="bg-futuristic-background/50 border-futuristic-primary/20">
                    <SelectValue placeholder="Colegio" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos los colegios</SelectItem>
                    <SelectItem value="Colegio San José">Colegio San José</SelectItem>
                    <SelectItem value="Colegio Santa María">Colegio Santa María</SelectItem>
                    <SelectItem value="Colegio Los Andes">Colegio Los Andes</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Lista de Tickets */}
          <Card className="bg-futuristic-surface border-futuristic-primary/10">
            <CardHeader>
              <CardTitle className="text-futuristic-text-primary">Bandeja de Entrada</CardTitle>
              <CardDescription className="text-futuristic-text-secondary">
                Mostrando {filteredTickets.length} de {ticketsData.length} tickets
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {filteredTickets.map((ticket) => (
                  <div
                    key={ticket.id}
                    className="flex items-center justify-between p-4 rounded-lg bg-futuristic-background/30 border border-futuristic-primary/10 hover:border-futuristic-primary/30 transition-colors"
                  >
                    <div className="flex items-center gap-4 flex-1">
                      <div className="flex flex-col gap-1">
                        <Badge className={`text-xs ${statusColors[ticket.status as keyof typeof statusColors]}`}>
                          {statusLabels[ticket.status as keyof typeof statusLabels]}
                        </Badge>
                        <Badge className={`text-xs ${priorityColors[ticket.priority as keyof typeof priorityColors]}`}>
                          {priorityLabels[ticket.priority as keyof typeof priorityLabels]}
                        </Badge>
                      </div>

                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-sm font-medium text-futuristic-primary">{ticket.id}</span>
                          <span className="text-sm text-futuristic-text-secondary">{ticket.createdAt}</span>
                        </div>

                        <p className="text-futuristic-text-primary font-medium">{ticket.subject}</p>
                        <div className="flex items-center gap-4 text-sm text-futuristic-text-secondary">
                          <span className="flex items-center gap-1">
                            <Building className="h-3 w-3" />
                            {ticket.school}
                          </span>
                          <span className="flex items-center gap-1">
                            <User className="h-3 w-3" />
                            {ticket.director}
                          </span>
                          {ticket.attachments.length > 0 && (
                            <span className="flex items-center gap-1">
                              <Paperclip className="h-3 w-3" />
                              {ticket.attachments.length} archivo(s)
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    <Dialog>
                      <DialogTrigger asChild>
                        <Button
                          size="sm"
                          variant="outline"
                          className="border-futuristic-primary/30 text-futuristic-primary hover:bg-futuristic-primary/5"
                          onClick={() => setSelectedTicket(ticket)}
                        >
                          <Eye className="h-4 w-4 mr-2" />
                          Ver Detalle
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-4xl bg-futuristic-surface border-futuristic-primary/20">
                        <DialogHeader>
                          <DialogTitle className="text-futuristic-text-primary">
                            Ticket {selectedTicket?.id} - {selectedTicket?.subject}
                          </DialogTitle>
                          <DialogDescription className="text-futuristic-text-secondary">
                            {selectedTicket?.school} - {selectedTicket?.director}
                          </DialogDescription>
                        </DialogHeader>

                        {selectedTicket && (
                          <div className="space-y-6">
                            {/* Información del ticket */}
                            <div className="grid grid-cols-2 gap-4">
                              <div>
                                <label className="text-sm font-medium text-futuristic-text-secondary">Estado</label>
                                <Select
                                  value={selectedTicket.status}
                                  onValueChange={(value) => handleStatusChange(selectedTicket.id, value)}
                                >
                                  <SelectTrigger className="bg-futuristic-background/50 border-futuristic-primary/20">
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="open">Abierto</SelectItem>
                                    <SelectItem value="in-progress">En Progreso</SelectItem>
                                    <SelectItem value="resolved">Resuelto</SelectItem>
                                  </SelectContent>
                                </Select>
                              </div>
                              <div>
                                <label className="text-sm font-medium text-futuristic-text-secondary">Prioridad</label>
                                <Select
                                  value={selectedTicket.priority}
                                  onValueChange={(value) => handlePriorityChange(selectedTicket.id, value)}
                                >
                                  <SelectTrigger className="bg-futuristic-background/50 border-futuristic-primary/20">
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="high">Alta</SelectItem>
                                    <SelectItem value="medium">Media</SelectItem>
                                    <SelectItem value="low">Baja</SelectItem>
                                  </SelectContent>
                                </Select>
                              </div>
                            </div>

                            {/* Mensaje original */}
                            <div>
                              <label className="text-sm font-medium text-futuristic-text-secondary">
                                Mensaje Original
                              </label>
                              <div className="mt-2 p-4 bg-futuristic-background/30 rounded-lg border border-futuristic-primary/20">
                                <p className="text-futuristic-text-secondary">{selectedTicket.message}</p>
                                <div className="flex items-center gap-2 mt-2 text-sm text-futuristic-text-tertiary">
                                  <Calendar className="h-3 w-3" />
                                  {selectedTicket.createdAt}
                                </div>
                              </div>
                            </div>

                            {/* Historial de respuestas */}
                            {selectedTicket.responses.length > 0 && (
                              <div>
                                <label className="text-sm font-medium text-futuristic-text-secondary">
                                  Historial de Respuestas
                                </label>
                                <div className="mt-2 space-y-3">
                                  {selectedTicket.responses.map((response: any) => (
                                    <div
                                      key={response.id}
                                      className="p-4 bg-futuristic-background/30 rounded-lg border border-futuristic-primary/20"
                                    >
                                      <div className="flex items-center justify-between mb-2">
                                        <span className="text-sm font-medium text-futuristic-primary">
                                          {response.author}
                                        </span>
                                        <span className="text-sm text-futuristic-text-secondary">
                                          {response.timestamp}
                                        </span>
                                      </div>
                                      <p className="text-futuristic-text-secondary">{response.message}</p>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            )}

                            {/* Responder al ticket */}
                            <div>
                              <label className="text-sm font-medium text-futuristic-text-secondary">
                                Responder al Director
                              </label>
                              <div className="mt-2 space-y-3">
                                <Textarea
                                  placeholder="Escribe tu respuesta aquí..."
                                  value={newResponse}
                                  onChange={(e) => setNewResponse(e.target.value)}
                                  className="bg-futuristic-background/50 border-futuristic-primary/20"
                                  rows={4}
                                />
                                <Button
                                  onClick={sendResponse}
                                  className="bg-gradient-to-r from-futuristic-primary to-futuristic-primary-light hover:from-futuristic-primary-dark hover:to-futuristic-primary"
                                >
                                  <Send className="mr-2 h-4 w-4" />
                                  Enviar Respuesta
                                </Button>
                              </div>
                            </div>

                            {/* Nota interna */}
                            <div>
                              <label className="text-sm font-medium text-futuristic-text-secondary">
                                Agregar Nota Interna
                              </label>
                              <div className="mt-2 space-y-3">
                                <Textarea
                                  placeholder="Nota visible solo para el equipo de soporte..."
                                  value={newInternalNote}
                                  onChange={(e) => setNewInternalNote(e.target.value)}
                                  className="bg-futuristic-background/50 border-futuristic-primary/20"
                                  rows={3}
                                />
                                <Button
                                  onClick={addInternalNote}
                                  variant="outline"
                                  className="border-futuristic-primary/30 text-futuristic-primary hover:bg-futuristic-primary/5"
                                >
                                  Agregar Nota
                                </Button>
                              </div>
                            </div>
                          </div>
                        )}
                      </DialogContent>
                    </Dialog>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
