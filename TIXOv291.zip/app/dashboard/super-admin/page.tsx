"use client"

import { Header } from "@/components/dashboard/header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  Building,
  CreditCard,
  Users,
  TrendingUp,
  AlertTriangle,
  CheckCircle,
  Clock,
  Globe,
  Shield,
  Activity,
  DollarSign,
  UserCheck,
  Server,
} from "lucide-react"

export default function SuperAdminDashboard() {
  return (
    <div className="flex-1 flex flex-col">
      <Header title="Dashboard" />

      <main className="flex-1 overflow-y-auto p-6 bg-futuristic-background">
        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="bg-futuristic-surface border-futuristic-primary/10 hover:border-futuristic-primary/30 transition-all duration-300 hover:shadow-lg hover:shadow-futuristic-primary/10">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-futuristic-text-secondary text-sm font-medium">Total Colegios</CardTitle>
              <div className="w-10 h-10 bg-gradient-to-br from-futuristic-primary to-futuristic-primary-light rounded-xl flex items-center justify-center">
                <Building className="h-5 w-5 text-white" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-futuristic-text-primary">42</div>
              <div className="flex items-center space-x-2 mt-2">
                <TrendingUp className="h-4 w-4 text-futuristic-success" />
                <p className="text-xs text-futuristic-success">+3 este mes</p>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-futuristic-surface border-futuristic-primary/10 hover:border-futuristic-primary/30 transition-all duration-300 hover:shadow-lg hover:shadow-futuristic-info/10">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-futuristic-text-secondary text-sm font-medium">Usuarios Activos</CardTitle>
              <div className="w-10 h-10 bg-gradient-to-br from-futuristic-info to-futuristic-creative rounded-xl flex items-center justify-center">
                <Users className="h-5 w-5 text-white" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-futuristic-text-primary">8,392</div>
              <div className="flex items-center space-x-2 mt-2">
                <TrendingUp className="h-4 w-4 text-futuristic-success" />
                <p className="text-xs text-futuristic-success">+12% vs mes anterior</p>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-futuristic-surface border-futuristic-primary/10 hover:border-futuristic-primary/30 transition-all duration-300 hover:shadow-lg hover:shadow-futuristic-success/10">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-futuristic-text-secondary text-sm font-medium">Ingresos Mensuales</CardTitle>
              <div className="w-10 h-10 bg-gradient-to-br from-futuristic-success to-futuristic-amber rounded-xl flex items-center justify-center">
                <DollarSign className="h-5 w-5 text-white" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-futuristic-text-primary">$24,500</div>
              <div className="flex items-center space-x-2 mt-2">
                <TrendingUp className="h-4 w-4 text-futuristic-success" />
                <p className="text-xs text-futuristic-success">+8% vs mes anterior</p>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-futuristic-surface border-futuristic-primary/10 hover:border-futuristic-primary/30 transition-all duration-300 hover:shadow-lg hover:shadow-futuristic-warning/10">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-futuristic-text-secondary text-sm font-medium">
                Suscripciones Activas
              </CardTitle>
              <div className="w-10 h-10 bg-gradient-to-br from-futuristic-warning to-futuristic-amber rounded-xl flex items-center justify-center">
                <CreditCard className="h-5 w-5 text-white" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-futuristic-text-primary">38</div>
              <div className="flex items-center space-x-2 mt-2">
                <AlertTriangle className="h-4 w-4 text-futuristic-error" />
                <p className="text-xs text-futuristic-error">2 por vencer</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* System Status */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <Card className="bg-futuristic-surface border-futuristic-primary/10">
            <CardHeader>
              <CardTitle className="text-futuristic-text-primary flex items-center space-x-2">
                <Activity className="w-5 h-5 text-futuristic-success" />
                <span>Estado del Sistema</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {[
                { service: "API Principal", status: "Operativo", uptime: "99.9%", color: "success" },
                { service: "Base de Datos", status: "Operativo", uptime: "99.8%", color: "success" },
                { service: "CDN Global", status: "Operativo", uptime: "100%", color: "success" },
                { service: "Notificaciones", status: "Mantenimiento", uptime: "95.2%", color: "warning" },
              ].map((service, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div
                      className={`w-3 h-3 rounded-full bg-futuristic-${service.color} ${
                        service.color === "success" ? "animate-pulse" : ""
                      }`}
                    ></div>
                    <span className="text-futuristic-text-primary font-medium">{service.service}</span>
                  </div>
                  <div className="text-right">
                    <Badge
                      className={`bg-futuristic-${service.color}/10 text-futuristic-${service.color} border-futuristic-${service.color}/20`}
                    >
                      {service.status}
                    </Badge>
                    <div className="text-xs text-futuristic-text-secondary mt-1">{service.uptime}</div>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card className="bg-futuristic-surface border-futuristic-primary/10">
            <CardHeader>
              <CardTitle className="text-futuristic-text-primary flex items-center space-x-2">
                <Globe className="w-5 h-5 text-futuristic-info" />
                <span>Distribución Global</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {[
                { region: "América Latina", schools: 28, users: "5.2K", color: "primary" },
                { region: "España", schools: 8, users: "1.8K", color: "info" },
                { region: "Estados Unidos", schools: 4, users: "1.1K", color: "success" },
                { region: "Otros", schools: 2, users: "0.3K", color: "amber" },
              ].map((region, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div>
                    <div className="text-futuristic-text-primary font-medium">{region.region}</div>
                    <div className="text-xs text-futuristic-text-secondary">{region.schools} colegios</div>
                  </div>
                  <div className="text-right">
                    <div className="text-futuristic-text-primary font-bold">{region.users}</div>
                    <div className="text-xs text-futuristic-text-secondary">usuarios</div>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>

        {/* Recent Activity & Alerts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <Card className="bg-futuristic-surface border-futuristic-primary/10">
            <CardHeader>
              <CardTitle className="text-futuristic-text-primary flex items-center space-x-2">
                <Clock className="w-5 h-5 text-futuristic-primary" />
                <span>Actividad Reciente</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  {
                    action: "Nuevo colegio registrado",
                    details: "Instituto Tecnológico Avanzado",
                    time: "Hace 2 horas",
                    icon: Building,
                    color: "success",
                  },
                  {
                    action: "Suscripción renovada",
                    details: "Colegio San Patricio - Plan Premium",
                    time: "Hace 4 horas",
                    icon: CreditCard,
                    color: "primary",
                  },
                  {
                    action: "Usuario administrador creado",
                    details: "Ana Martínez - Director",
                    time: "Hace 6 horas",
                    icon: UserCheck,
                    color: "info",
                  },
                  {
                    action: "Backup automático completado",
                    details: "Base de datos principal",
                    time: "Hace 8 horas",
                    icon: Server,
                    color: "success",
                  },
                ].map((activity, index) => (
                  <div key={index} className="flex items-start space-x-4">
                    <div
                      className={`w-10 h-10 bg-gradient-to-br from-futuristic-${activity.color} to-futuristic-${activity.color}/70 rounded-xl flex items-center justify-center flex-shrink-0`}
                    >
                      <activity.icon className="w-5 h-5 text-white" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-futuristic-text-primary font-medium">{activity.action}</p>
                      <p className="text-sm text-futuristic-text-secondary">{activity.details}</p>
                      <p className="text-xs text-futuristic-text-tertiary mt-1">{activity.time}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="bg-futuristic-surface border-futuristic-primary/10">
            <CardHeader>
              <CardTitle className="text-futuristic-text-primary flex items-center space-x-2">
                <Shield className="w-5 h-5 text-futuristic-warning" />
                <span>Alertas del Sistema</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  {
                    title: "Suscripción por vencer",
                    description: "Colegio San Patricio - Vence en 3 días",
                    type: "warning",
                    priority: "Alta",
                  },
                  {
                    title: "Pago rechazado",
                    description: "Instituto Tecnológico Avanzado - Tarjeta expirada",
                    type: "error",
                    priority: "Crítica",
                  },
                  {
                    title: "Nuevo ticket de soporte",
                    description: "Escuela Nueva Era - Problema con calificaciones",
                    type: "info",
                    priority: "Media",
                  },
                  {
                    title: "Actualización disponible",
                    description: "Nueva versión 2.4.1 lista para implementar",
                    type: "success",
                    priority: "Baja",
                  },
                ].map((alert, index) => (
                  <div
                    key={index}
                    className={`p-4 rounded-xl border ${
                      alert.type === "warning"
                        ? "bg-futuristic-warning-light border-futuristic-warning/30"
                        : alert.type === "error"
                          ? "bg-futuristic-error-light border-futuristic-error/30"
                          : alert.type === "info"
                            ? "bg-futuristic-info-light border-futuristic-info/30"
                            : "bg-futuristic-success-light border-futuristic-success/30"
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <p
                          className={`font-medium ${
                            alert.type === "warning"
                              ? "text-futuristic-warning"
                              : alert.type === "error"
                                ? "text-futuristic-error"
                                : alert.type === "info"
                                  ? "text-futuristic-info"
                                  : "text-futuristic-success"
                          }`}
                        >
                          {alert.title}
                        </p>
                        <p className="text-sm text-futuristic-text-secondary mt-1">{alert.description}</p>
                      </div>
                      <Badge
                        className={`ml-4 ${
                          alert.priority === "Crítica"
                            ? "bg-futuristic-error/10 text-futuristic-error border-futuristic-error/20"
                            : alert.priority === "Alta"
                              ? "bg-futuristic-warning/10 text-futuristic-warning border-futuristic-warning/20"
                              : alert.priority === "Media"
                                ? "bg-futuristic-info/10 text-futuristic-info border-futuristic-info/20"
                                : "bg-futuristic-success/10 text-futuristic-success border-futuristic-success/20"
                        }`}
                      >
                        {alert.priority}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="mt-8">
          <h3 className="text-lg font-semibold text-futuristic-text-primary mb-4">Acciones Rápidas</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {[
              { name: "Nuevo Colegio", icon: Building, color: "primary" },
              { name: "Gestionar Usuarios", icon: Users, color: "info" },
              { name: "Ver Suscripciones", icon: CreditCard, color: "success" },
              { name: "Revisar Logs", icon: Activity, color: "warning" },
              { name: "Configuración", icon: Shield, color: "creative" },
              { name: "Centro de Soporte", icon: CheckCircle, color: "amber" },
            ].map((action, index) => (
              <Button
                key={index}
                variant="outline"
                className={`h-20 flex flex-col items-center justify-center space-y-2 border-futuristic-${action.color}/20 text-futuristic-${action.color} hover:bg-futuristic-${action.color}/5 transition-all duration-200`}
              >
                <action.icon className="w-6 h-6" />
                <span className="text-xs font-medium">{action.name}</span>
              </Button>
            ))}
          </div>
        </div>
      </main>
    </div>
  )
}
