"use client"

import { useState } from "react"
import { Header } from "@/components/dashboard/header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  CreditCard,
  Plus,
  Search,
  Filter,
  Download,
  Edit,
  Eye,
  Trash2,
  Calendar,
  DollarSign,
  AlertTriangle,
  CheckCircle,
  Clock,
  Building,
  FileText,
  Send,
  Settings,
  Bell,
  Zap,
  Shield,
  Users,
  BookOpen,
  BarChart3,
  MessageSquare,
  Percent,
  RefreshCw,
} from "lucide-react"

// Datos de ejemplo para suscripciones
const subscriptionsData = [
  {
    id: 1,
    schoolName: "Colegio San Patricio",
    planType: "Premium Anual",
    status: "Activa",
    startDate: "2024-01-15",
    endDate: "2025-01-15",
    amount: 10200,
    paymentStatus: "Pagado",
    lastPayment: "2024-01-15",
    nextPayment: "2025-01-15",
    discount: 15,
  },
  {
    id: 2,
    schoolName: "Instituto Tecnológico Avanzado",
    planType: "Básico Mensual",
    status: "Por vencer",
    startDate: "2024-06-01",
    endDate: "2024-07-01",
    amount: 650,
    paymentStatus: "Pendiente",
    lastPayment: "2024-06-01",
    nextPayment: "2024-07-01",
    discount: 0,
  },
  {
    id: 3,
    schoolName: "Escuela Nueva Era",
    planType: "Personalizado",
    status: "Vencida",
    startDate: "2024-03-01",
    endDate: "2024-06-01",
    amount: 1350,
    paymentStatus: "En mora",
    lastPayment: "2024-03-01",
    nextPayment: "2024-06-01",
    discount: 10,
  },
]

// Datos de ejemplo para planes
const plansData = [
  {
    id: 1,
    name: "Plan Básico",
    description: "Funcionalidades esenciales para colegios pequeños",
    price: 650,
    period: "Mensual",
    features: ["Gestión de estudiantes", "Calificaciones básicas", "Comunicación padres", "Reportes básicos"],
    trialDays: 30,
    isActive: true,
  },
  {
    id: 2,
    name: "Plan Premium",
    description: "Solución completa para instituciones medianas y grandes",
    price: 850,
    period: "Mensual",
    features: [
      "Todas las funciones básicas",
      "Analytics avanzados",
      "Integración WhatsApp",
      "Facturación automática",
      "Soporte prioritario",
    ],
    trialDays: 15,
    isActive: true,
  },
  {
    id: 3,
    name: "Plan Enterprise",
    description: "Solución personalizada para grandes instituciones",
    price: 1200,
    period: "Mensual",
    features: [
      "Todas las funciones premium",
      "API personalizada",
      "Integración ERP",
      "Soporte 24/7",
      "Capacitación incluida",
    ],
    trialDays: 0,
    isActive: true,
  },
]

export default function SubscriptionsPage() {
  const [selectedSubscription, setSelectedSubscription] = useState(null)
  const [selectedPlan, setSelectedPlan] = useState(null)
  const [isCreatePlanDialogOpen, setIsCreatePlanDialogOpen] = useState(false)
  const [isAssignPlanDialogOpen, setIsAssignPlanDialogOpen] = useState(false)
  const [isPaymentConfigOpen, setIsPaymentConfigOpen] = useState(false)
  const [isAlertsConfigOpen, setIsAlertsConfigOpen] = useState(false)
  const [isPaymentTrackingOpen, setIsPaymentTrackingOpen] = useState(false)
  const [selectedSubscriptionForTracking, setSelectedSubscriptionForTracking] = useState(null)
  const [filters, setFilters] = useState({
    status: "",
    planType: "",
    school: "",
    search: "",
  })

  const [paymentStatuses, setPaymentStatuses] = useState({})

  const filteredSubscriptions = subscriptionsData.filter((subscription) => {
    return (
      (filters.status === "" || subscription.status === filters.status) &&
      (filters.planType === "" || subscription.planType.includes(filters.planType)) &&
      (filters.school === "" || subscription.schoolName.toLowerCase().includes(filters.school.toLowerCase())) &&
      (filters.search === "" || subscription.schoolName.toLowerCase().includes(filters.search.toLowerCase()))
    )
  })

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Activa":
        return "bg-futuristic-success/10 text-futuristic-success border-futuristic-success/20"
      case "Por vencer":
        return "bg-futuristic-warning/10 text-futuristic-warning border-futuristic-warning/20"
      case "Vencida":
        return "bg-futuristic-error/10 text-futuristic-error border-futuristic-error/20"
      default:
        return "bg-futuristic-info/10 text-futuristic-info border-futuristic-info/20"
    }
  }

  const getPaymentStatusColor = (status: string) => {
    switch (status) {
      case "Pagado":
        return "bg-futuristic-success/10 text-futuristic-success border-futuristic-success/20"
      case "Pendiente":
        return "bg-futuristic-warning/10 text-futuristic-warning border-futuristic-warning/20"
      case "En mora":
        return "bg-futuristic-error/10 text-futuristic-error border-futuristic-error/20"
      default:
        return "bg-futuristic-info/10 text-futuristic-info border-futuristic-info/20"
    }
  }

  return (
    <div className="flex-1 flex flex-col">
      <Header title="Suscripciones" />

      <main className="flex-1 overflow-y-auto p-6 bg-futuristic-background">
        <Tabs defaultValue="subscriptions" className="space-y-6">
          <div className="flex items-center justify-between">
            <TabsList className="bg-futuristic-surface border border-futuristic-primary/10">
              <TabsTrigger value="subscriptions" className="flex items-center gap-2">
                <CreditCard className="w-4 h-4" />
                Suscripciones
              </TabsTrigger>
              <TabsTrigger value="plans" className="flex items-center gap-2">
                <Settings className="w-4 h-4" />
                Planes
              </TabsTrigger>
              <TabsTrigger value="payments" className="flex items-center gap-2">
                <DollarSign className="w-4 h-4" />
                Pagos
              </TabsTrigger>
              <TabsTrigger value="alerts" className="flex items-center gap-2">
                <Bell className="w-4 h-4" />
                Alertas
              </TabsTrigger>
            </TabsList>

            <div className="flex gap-2">
              <Dialog open={isAssignPlanDialogOpen} onOpenChange={setIsAssignPlanDialogOpen}>
                <DialogTrigger asChild>
                  <Button
                    variant="outline"
                    className="border-futuristic-primary/30 text-futuristic-primary hover:bg-futuristic-primary/5 bg-transparent"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Asignar Plan
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl bg-futuristic-surface border-futuristic-primary/20">
                  <DialogHeader>
                    <DialogTitle className="text-futuristic-text-primary">Asignar Plan a Colegio</DialogTitle>
                    <DialogDescription className="text-futuristic-text-secondary">
                      Seleccione el colegio y configure la suscripción
                    </DialogDescription>
                  </DialogHeader>
                  <div className="grid grid-cols-2 gap-4 py-4">
                    <div className="space-y-2">
                      <Label htmlFor="school-select" className="text-futuristic-text-primary">
                        Colegio
                      </Label>
                      <Input
                        id="school-select"
                        placeholder="Buscar colegio..."
                        className="bg-futuristic-background/50 border-futuristic-primary/20"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="plan-select" className="text-futuristic-text-primary">
                        Plan
                      </Label>
                      <Select>
                        <SelectTrigger className="bg-futuristic-background/50 border-futuristic-primary/20">
                          <SelectValue placeholder="Seleccionar plan" />
                        </SelectTrigger>
                        <SelectContent>
                          {plansData.map((plan) => (
                            <SelectItem key={plan.id} value={plan.id.toString()}>
                              {plan.name} - ${plan.price}/{plan.period}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="start-date" className="text-futuristic-text-primary">
                        Fecha de Inicio
                      </Label>
                      <Input
                        id="start-date"
                        type="date"
                        className="bg-futuristic-background/50 border-futuristic-primary/20"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="duration" className="text-futuristic-text-primary">
                        Duración (meses)
                      </Label>
                      <Input
                        id="duration"
                        type="number"
                        placeholder="12"
                        className="bg-futuristic-background/50 border-futuristic-primary/20"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="discount" className="text-futuristic-text-primary">
                        Descuento (%)
                      </Label>
                      <Input
                        id="discount"
                        type="number"
                        placeholder="0"
                        className="bg-futuristic-background/50 border-futuristic-primary/20"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="payment-method" className="text-futuristic-text-primary">
                        Método de Pago
                      </Label>
                      <Select>
                        <SelectTrigger className="bg-futuristic-background/50 border-futuristic-primary/20">
                          <SelectValue placeholder="Seleccionar método" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="manual">Manual</SelectItem>
                          <SelectItem value="stripe">Stripe</SelectItem>
                          <SelectItem value="paypal">PayPal</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="col-span-2 space-y-2">
                      <Label htmlFor="status" className="text-futuristic-text-primary">
                        Estado Inicial
                      </Label>
                      <Select>
                        <SelectTrigger className="bg-futuristic-background/50 border-futuristic-primary/20">
                          <SelectValue placeholder="Seleccionar estado" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="active">Activo</SelectItem>
                          <SelectItem value="pending">Pendiente</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <DialogFooter>
                    <Button
                      variant="outline"
                      onClick={() => setIsAssignPlanDialogOpen(false)}
                      className="border-futuristic-primary/30 text-futuristic-text-secondary"
                    >
                      Cancelar
                    </Button>
                    <Button className="bg-gradient-to-r from-futuristic-primary to-futuristic-primary-light">
                      Asignar Plan
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>

              <Dialog open={isCreatePlanDialogOpen} onOpenChange={setIsCreatePlanDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-gradient-to-r from-futuristic-primary to-futuristic-primary-light hover:from-futuristic-primary-dark hover:to-futuristic-primary">
                    <Plus className="w-4 h-4 mr-2" />
                    Nuevo Plan
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-3xl bg-futuristic-surface border-futuristic-primary/20">
                  <DialogHeader>
                    <DialogTitle className="text-futuristic-text-primary">Crear Nuevo Plan</DialogTitle>
                    <DialogDescription className="text-futuristic-text-secondary">
                      Configure los detalles del nuevo plan de suscripción
                    </DialogDescription>
                  </DialogHeader>
                  <div className="grid grid-cols-2 gap-4 py-4">
                    <div className="space-y-2">
                      <Label htmlFor="plan-name" className="text-futuristic-text-primary">
                        Nombre del Plan
                      </Label>
                      <Input
                        id="plan-name"
                        placeholder="Ej: Plan Premium"
                        className="bg-futuristic-background/50 border-futuristic-primary/20"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="plan-price" className="text-futuristic-text-primary">
                        Precio
                      </Label>
                      <Input
                        id="plan-price"
                        type="number"
                        placeholder="850"
                        className="bg-futuristic-background/50 border-futuristic-primary/20"
                      />
                    </div>
                    <div className="col-span-2 space-y-2">
                      <Label htmlFor="plan-description" className="text-futuristic-text-primary">
                        Descripción
                      </Label>
                      <Textarea
                        id="plan-description"
                        placeholder="Breve descripción del plan..."
                        className="bg-futuristic-background/50 border-futuristic-primary/20"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="plan-period" className="text-futuristic-text-primary">
                        Período
                      </Label>
                      <Select>
                        <SelectTrigger className="bg-futuristic-background/50 border-futuristic-primary/20">
                          <SelectValue placeholder="Seleccionar período" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="monthly">Mensual</SelectItem>
                          <SelectItem value="annual">Anual</SelectItem>
                          <SelectItem value="custom">Personalizado</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="trial-days" className="text-futuristic-text-primary">
                        Días de Prueba Gratuita
                      </Label>
                      <Input
                        id="trial-days"
                        type="number"
                        placeholder="30"
                        className="bg-futuristic-background/50 border-futuristic-primary/20"
                      />
                    </div>
                    <div className="col-span-2 space-y-4">
                      <Label className="text-futuristic-text-primary">Servicios Incluidos</Label>
                      <div className="grid grid-cols-2 gap-4">
                        {[
                          { id: "students", label: "Gestión de Estudiantes", icon: Users },
                          { id: "grades", label: "Sistema de Calificaciones", icon: BookOpen },
                          { id: "communication", label: "Comunicación Padres", icon: MessageSquare },
                          { id: "reports", label: "Reportes Avanzados", icon: BarChart3 },
                          { id: "analytics", label: "Analytics", icon: BarChart3 },
                          { id: "whatsapp", label: "Integración WhatsApp", icon: MessageSquare },
                          { id: "billing", label: "Facturación Automática", icon: CreditCard },
                          { id: "support", label: "Soporte Prioritario", icon: Shield },
                        ].map((service) => (
                          <div key={service.id} className="flex items-center space-x-2">
                            <Checkbox id={service.id} />
                            <label
                              htmlFor={service.id}
                              className="text-sm text-futuristic-text-primary flex items-center gap-2"
                            >
                              <service.icon className="w-4 h-4" />
                              {service.label}
                            </label>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                  <DialogFooter>
                    <Button
                      variant="outline"
                      onClick={() => setIsCreatePlanDialogOpen(false)}
                      className="border-futuristic-primary/30 text-futuristic-text-secondary"
                    >
                      Cancelar
                    </Button>
                    <Button className="bg-gradient-to-r from-futuristic-primary to-futuristic-primary-light">
                      Crear Plan
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
          </div>

          {/* Tab de Suscripciones */}
          <TabsContent value="subscriptions" className="space-y-6">
            {/* Estadísticas */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <Card className="bg-futuristic-surface border-futuristic-primary/10">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-futuristic-text-secondary text-sm font-medium">
                    Suscripciones Activas
                  </CardTitle>
                  <CheckCircle className="h-4 w-4 text-futuristic-success" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-futuristic-text-primary">38</div>
                  <p className="text-xs text-futuristic-success">90.5% del total</p>
                </CardContent>
              </Card>

              <Card className="bg-futuristic-surface border-futuristic-primary/10">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-futuristic-text-secondary text-sm font-medium">Por Vencer</CardTitle>
                  <Clock className="h-4 w-4 text-futuristic-warning" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-futuristic-text-primary">4</div>
                  <p className="text-xs text-futuristic-warning">Próximos 7 días</p>
                </CardContent>
              </Card>

              <Card className="bg-futuristic-surface border-futuristic-primary/10">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-futuristic-text-secondary text-sm font-medium">Vencidas</CardTitle>
                  <AlertTriangle className="h-4 w-4 text-futuristic-error" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-futuristic-text-primary">2</div>
                  <p className="text-xs text-futuristic-error">Requieren atención</p>
                </CardContent>
              </Card>

              <Card className="bg-futuristic-surface border-futuristic-primary/10">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-futuristic-text-secondary text-sm font-medium">Ingresos MRR</CardTitle>
                  <DollarSign className="h-4 w-4 text-futuristic-success" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-futuristic-text-primary">$32,150</div>
                  <p className="text-xs text-futuristic-success">+8% vs mes anterior</p>
                </CardContent>
              </Card>
            </div>

            {/* Filtros */}
            <Card className="bg-futuristic-surface border-futuristic-primary/10">
              <CardHeader>
                <CardTitle className="text-futuristic-text-primary flex items-center gap-2">
                  <Filter className="w-5 h-5" />
                  Filtros
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-futuristic-text-tertiary w-4 h-4" />
                    <Input
                      placeholder="Buscar colegio..."
                      value={filters.search}
                      onChange={(e) => setFilters({ ...filters, search: e.target.value })}
                      className="pl-10 bg-futuristic-background/50 border-futuristic-primary/20"
                    />
                  </div>
                  <Select value={filters.status} onValueChange={(value) => setFilters({ ...filters, status: value })}>
                    <SelectTrigger className="bg-futuristic-background/50 border-futuristic-primary/20">
                      <SelectValue placeholder="Estado" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos</SelectItem>
                      <SelectItem value="Activa">Activa</SelectItem>
                      <SelectItem value="Por vencer">Por vencer</SelectItem>
                      <SelectItem value="Vencida">Vencida</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select
                    value={filters.planType}
                    onValueChange={(value) => setFilters({ ...filters, planType: value })}
                  >
                    <SelectTrigger className="bg-futuristic-background/50 border-futuristic-primary/20">
                      <SelectValue placeholder="Tipo de Plan" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos</SelectItem>
                      <SelectItem value="Básico">Básico</SelectItem>
                      <SelectItem value="Premium">Premium</SelectItem>
                      <SelectItem value="Enterprise">Enterprise</SelectItem>
                      <SelectItem value="Personalizado">Personalizado</SelectItem>
                    </SelectContent>
                  </Select>
                  <Input
                    placeholder="Fecha inicio..."
                    type="date"
                    className="bg-futuristic-background/50 border-futuristic-primary/20"
                  />
                  <Button
                    variant="outline"
                    className="border-futuristic-primary/30 text-futuristic-primary hover:bg-futuristic-primary/5 bg-transparent"
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Exportar
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Tabla de Suscripciones */}
            <Card className="bg-futuristic-surface border-futuristic-primary/10">
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-futuristic-primary/10">
                        <th className="text-left p-4 text-futuristic-text-secondary font-medium">Colegio</th>
                        <th className="text-left p-4 text-futuristic-text-secondary font-medium">Plan</th>
                        <th className="text-left p-4 text-futuristic-text-secondary font-medium">Estado</th>
                        <th className="text-left p-4 text-futuristic-text-secondary font-medium">Inicio</th>
                        <th className="text-left p-4 text-futuristic-text-secondary font-medium">Vencimiento</th>
                        <th className="text-left p-4 text-futuristic-text-secondary font-medium">Monto</th>
                        <th className="text-left p-4 text-futuristic-text-secondary font-medium">Pago</th>
                        <th className="text-left p-4 text-futuristic-text-secondary font-medium">Último Pago</th>
                        <th className="text-right p-4 text-futuristic-text-secondary font-medium">Acciones</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredSubscriptions.map((subscription) => (
                        <tr
                          key={subscription.id}
                          className="border-b border-futuristic-primary/5 hover:bg-futuristic-primary/5 transition-colors"
                        >
                          <td className="p-4">
                            <div className="flex items-center space-x-3">
                              <Building className="w-8 h-8 text-futuristic-primary" />
                              <div>
                                <div className="text-futuristic-text-primary font-medium">
                                  {subscription.schoolName}
                                </div>
                              </div>
                            </div>
                          </td>
                          <td className="p-4">
                            <div className="text-futuristic-text-primary">{subscription.planType}</div>
                            {subscription.discount > 0 && (
                              <div className="flex items-center gap-1 text-xs text-futuristic-success">
                                <Percent className="w-3 h-3" />
                                {subscription.discount}% descuento
                              </div>
                            )}
                          </td>
                          <td className="p-4">
                            <Badge className={getStatusColor(subscription.status)}>{subscription.status}</Badge>
                          </td>
                          <td className="p-4">
                            <div className="text-futuristic-text-primary">{subscription.startDate}</div>
                          </td>
                          <td className="p-4">
                            <div className="flex items-center gap-1 text-futuristic-text-primary">
                              <Calendar className="w-4 h-4 text-futuristic-warning" />
                              {subscription.endDate}
                            </div>
                          </td>
                          <td className="p-4">
                            <div className="flex items-center gap-1 text-futuristic-text-primary font-medium">
                              <DollarSign className="w-4 h-4 text-futuristic-success" />
                              {subscription.amount.toLocaleString()}
                            </div>
                          </td>
                          <td className="p-4">
                            <Badge className={getPaymentStatusColor(subscription.paymentStatus)}>
                              {subscription.paymentStatus}
                            </Badge>
                          </td>
                          <td className="p-4">
                            <div className="text-futuristic-text-primary">{subscription.lastPayment}</div>
                          </td>
                          <td className="p-4 text-right">
                            <div className="flex justify-end gap-2">
                              <Button
                                size="sm"
                                variant="ghost"
                                className="h-8 w-8 p-0 hover:bg-futuristic-info/10"
                                onClick={() => setSelectedSubscription(subscription)}
                              >
                                <Eye className="h-4 w-4 text-futuristic-info" />
                              </Button>
                              <Button size="sm" variant="ghost" className="h-8 w-8 p-0 hover:bg-futuristic-success/10">
                                <RefreshCw className="h-4 w-4 text-futuristic-success" />
                              </Button>
                              <Button
                                size="sm"
                                variant="ghost"
                                className="h-8 w-8 p-0 hover:bg-futuristic-warning/10"
                                onClick={() => {
                                  setSelectedSubscriptionForTracking(subscription)
                                  setIsPaymentTrackingOpen(true)
                                }}
                              >
                                <DollarSign className="h-4 w-4 text-futuristic-warning" />
                              </Button>
                              <Button size="sm" variant="ghost" className="h-8 w-8 p-0 hover:bg-futuristic-warning/10">
                                <Send className="h-4 w-4 text-futuristic-warning" />
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Tab de Planes */}
          <TabsContent value="plans" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {plansData.map((plan) => (
                <Card
                  key={plan.id}
                  className="bg-futuristic-surface border-futuristic-primary/10 hover:border-futuristic-primary/30 transition-all duration-300"
                >
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-futuristic-text-primary">{plan.name}</CardTitle>
                      <Badge
                        className={
                          plan.isActive
                            ? "bg-futuristic-success/10 text-futuristic-success border-futuristic-success/20"
                            : "bg-futuristic-error/10 text-futuristic-error border-futuristic-error/20"
                        }
                      >
                        {plan.isActive ? "Activo" : "Inactivo"}
                      </Badge>
                    </div>
                    <p className="text-futuristic-text-secondary text-sm">{plan.description}</p>
                    <div className="flex items-baseline gap-2">
                      <span className="text-3xl font-bold text-futuristic-text-primary">${plan.price}</span>
                      <span className="text-futuristic-text-secondary">/{plan.period}</span>
                    </div>
                    {plan.trialDays > 0 && (
                      <div className="flex items-center gap-1 text-sm text-futuristic-info">
                        <Zap className="w-4 h-4" />
                        {plan.trialDays} días de prueba gratuita
                      </div>
                    )}
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <h4 className="font-medium text-futuristic-text-primary">Características incluidas:</h4>
                      <ul className="space-y-2">
                        {plan.features.map((feature, index) => (
                          <li key={index} className="flex items-center gap-2 text-sm text-futuristic-text-secondary">
                            <CheckCircle className="w-4 h-4 text-futuristic-success flex-shrink-0" />
                            {feature}
                          </li>
                        ))}
                      </ul>
                    </div>
                    <div className="flex gap-2 mt-6">
                      <Button
                        size="sm"
                        variant="outline"
                        className="flex-1 border-futuristic-primary/30 text-futuristic-primary hover:bg-futuristic-primary/5 bg-transparent"
                        onClick={() => setSelectedPlan(plan)}
                      >
                        <Edit className="w-4 h-4 mr-2" />
                        Editar
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="border-futuristic-error/30 text-futuristic-error hover:bg-futuristic-error/5 bg-transparent"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Tab de Pagos */}
          <TabsContent value="payments" className="space-y-6">
            <Card className="bg-futuristic-surface border-futuristic-primary/10">
              <CardHeader>
                <CardTitle className="text-futuristic-text-primary flex items-center gap-2">
                  <Settings className="w-5 h-5" />
                  Configuración de Pagos
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h3 className="font-medium text-futuristic-text-primary">Pasarelas de Pago</h3>
                    <div className="space-y-3">
                      {[
                        { name: "Stripe", enabled: true, icon: CreditCard },
                        { name: "PayPal", enabled: false, icon: DollarSign },
                        { name: "Mercado Pago", enabled: true, icon: CreditCard },
                      ].map((gateway) => (
                        <div
                          key={gateway.name}
                          className="flex items-center justify-between p-3 border border-futuristic-primary/10 rounded-lg"
                        >
                          <div className="flex items-center gap-3">
                            <gateway.icon className="w-5 h-5 text-futuristic-primary" />
                            <span className="text-futuristic-text-primary">{gateway.name}</span>
                          </div>
                          <Badge
                            className={
                              gateway.enabled
                                ? "bg-futuristic-success/10 text-futuristic-success border-futuristic-success/20"
                                : "bg-futuristic-error/10 text-futuristic-error border-futuristic-error/20"
                            }
                          >
                            {gateway.enabled ? "Activo" : "Inactivo"}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="space-y-4">
                    <h3 className="font-medium text-futuristic-text-primary">Logs de Pagos</h3>
                    <div className="space-y-2 max-h-48 overflow-y-auto">
                      {[
                        { date: "2024-06-06 14:30", school: "Colegio San Patricio", amount: "$850", status: "Exitoso" },
                        {
                          date: "2024-06-06 12:15",
                          school: "Instituto Tecnológico",
                          amount: "$650",
                          status: "Fallido",
                        },
                        { date: "2024-06-05 16:45", school: "Escuela Nueva Era", amount: "$450", status: "Exitoso" },
                      ].map((log, index) => (
                        <div key={index} className="p-2 bg-futuristic-background/30 rounded text-sm">
                          <div className="flex justify-between items-center">
                            <span className="text-futuristic-text-primary">{log.school}</span>
                            <Badge
                              className={
                                log.status === "Exitoso"
                                  ? "bg-futuristic-success/10 text-futuristic-success border-futuristic-success/20"
                                  : "bg-futuristic-error/10 text-futuristic-error border-futuristic-error/20"
                              }
                            >
                              {log.status}
                            </Badge>
                          </div>
                          <div className="text-futuristic-text-secondary text-xs">
                            {log.date} - {log.amount}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Tab de Alertas */}
          <TabsContent value="alerts" className="space-y-6">
            <Card className="bg-futuristic-surface border-futuristic-primary/10">
              <CardHeader>
                <CardTitle className="text-futuristic-text-primary flex items-center gap-2">
                  <Bell className="w-5 h-5" />
                  Configuración de Alertas
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h3 className="font-medium text-futuristic-text-primary">Reglas de Alerta</h3>
                    <div className="space-y-3">
                      <div className="p-4 border border-futuristic-primary/10 rounded-lg">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-futuristic-text-primary font-medium">Vencimiento próximo</span>
                          <Badge className="bg-futuristic-success/10 text-futuristic-success border-futuristic-success/20">
                            Activa
                          </Badge>
                        </div>
                        <p className="text-sm text-futuristic-text-secondary">Alertar 7 días antes del vencimiento</p>
                        <div className="flex gap-2 mt-3">
                          <Badge className="bg-futuristic-info/10 text-futuristic-info border-futuristic-info/20">
                            Email
                          </Badge>
                          <Badge className="bg-futuristic-success/10 text-futuristic-success border-futuristic-success/20">
                            WhatsApp
                          </Badge>
                        </div>
                      </div>
                      <div className="p-4 border border-futuristic-primary/10 rounded-lg">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-futuristic-text-primary font-medium">Pago vencido</span>
                          <Badge className="bg-futuristic-success/10 text-futuristic-success border-futuristic-success/20">
                            Activa
                          </Badge>
                        </div>
                        <p className="text-sm text-futuristic-text-secondary">Alertar inmediatamente al vencer</p>
                        <div className="flex gap-2 mt-3">
                          <Badge className="bg-futuristic-info/10 text-futuristic-info border-futuristic-info/20">
                            Email
                          </Badge>
                          <Badge className="bg-futuristic-warning/10 text-futuristic-warning border-futuristic-warning/20">
                            Sistema
                          </Badge>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-4">
                    <h3 className="font-medium text-futuristic-text-primary">Historial de Alertas</h3>
                    <div className="space-y-2 max-h-48 overflow-y-auto">
                      {[
                        {
                          date: "2024-06-06 09:00",
                          school: "Instituto Tecnológico",
                          type: "Vencimiento próximo",
                          channel: "Email + WhatsApp",
                        },
                        {
                          date: "2024-06-05 14:30",
                          school: "Escuela Nueva Era",
                          type: "Pago vencido",
                          channel: "Email",
                        },
                        {
                          date: "2024-06-04 10:15",
                          school: "Colegio San Patricio",
                          type: "Renovación exitosa",
                          channel: "Sistema",
                        },
                      ].map((alert, index) => (
                        <div key={index} className="p-3 bg-futuristic-background/30 rounded">
                          <div className="flex justify-between items-start">
                            <div>
                              <div className="text-futuristic-text-primary font-medium text-sm">{alert.school}</div>
                              <div className="text-futuristic-text-secondary text-xs">{alert.type}</div>
                            </div>
                            <div className="text-right">
                              <div className="text-futuristic-text-secondary text-xs">{alert.date}</div>
                              <div className="text-futuristic-info text-xs">{alert.channel}</div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Modal de Detalle de Suscripción */}
        {selectedSubscription && (
          <Dialog
            open={!!selectedSubscription}
            onOpenChange={() => {
              setSelectedSubscription(null)
              setSelectedSubscriptionForTracking(null)
              setIsPaymentTrackingOpen(false)
            }}
          >
            <DialogContent className="max-w-4xl bg-futuristic-surface border-futuristic-primary/20">
              <DialogHeader>
                <DialogTitle className="text-futuristic-text-primary flex items-center gap-3">
                  <Building className="w-8 h-8 text-futuristic-primary" />
                  {selectedSubscription.schoolName}
                </DialogTitle>
                <DialogDescription className="text-futuristic-text-secondary">
                  Detalle completo de la suscripción
                </DialogDescription>
              </DialogHeader>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 py-4">
                <div className="space-y-4">
                  <div>
                    <h4 className="font-medium text-futuristic-text-primary mb-2">Información del Plan</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-futuristic-text-secondary">Plan:</span>
                        <span className="text-futuristic-text-primary">{selectedSubscription.planType}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-futuristic-text-secondary">Estado:</span>
                        <Badge className={getStatusColor(selectedSubscription.status)}>
                          {selectedSubscription.status}
                        </Badge>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-futuristic-text-secondary">Monto:</span>
                        <span className="text-futuristic-text-primary font-medium">
                          ${selectedSubscription.amount.toLocaleString()}
                        </span>
                      </div>
                      {selectedSubscription.discount > 0 && (
                        <div className="flex justify-between">
                          <span className="text-futuristic-text-secondary">Descuento:</span>
                          <span className="text-futuristic-success">{selectedSubscription.discount}%</span>
                        </div>
                      )}
                    </div>
                  </div>
                  <div>
                    <h4 className="font-medium text-futuristic-text-primary mb-2">Fechas</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-futuristic-text-secondary">Inicio:</span>
                        <span className="text-futuristic-text-primary">{selectedSubscription.startDate}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-futuristic-text-secondary">Vencimiento:</span>
                        <span className="text-futuristic-text-primary">{selectedSubscription.endDate}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-futuristic-text-secondary">Último pago:</span>
                        <span className="text-futuristic-text-primary">{selectedSubscription.lastPayment}</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="space-y-4">
                  <div>
                    <h4 className="font-medium text-futuristic-text-primary mb-2">Historial de Pagos</h4>
                    <div className="space-y-2 max-h-32 overflow-y-auto">
                      {[
                        { date: "2024-01-15", amount: "$10,200", method: "Stripe", status: "Pagado" },
                        { date: "2023-01-15", amount: "$10,200", method: "Transferencia", status: "Pagado" },
                      ].map((payment, index) => (
                        <div key={index} className="p-2 bg-futuristic-background/30 rounded text-sm">
                          <div className="flex justify-between">
                            <span className="text-futuristic-text-primary">{payment.date}</span>
                            <span className="text-futuristic-text-primary font-medium">{payment.amount}</span>
                          </div>
                          <div className="flex justify-between text-xs text-futuristic-text-secondary">
                            <span>{payment.method}</span>
                            <Badge
                              className={
                                payment.status === "Pagado"
                                  ? "bg-futuristic-success/10 text-futuristic-success border-futuristic-success/20"
                                  : "bg-futuristic-error/10 text-futuristic-error border-futuristic-error/20"
                              }
                            >
                              {payment.status}
                            </Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div>
                    <h4 className="font-medium text-futuristic-text-primary mb-2">Alertas Enviadas</h4>
                    <div className="space-y-2 max-h-32 overflow-y-auto">
                      {[
                        { date: "2024-06-01", type: "Recordatorio renovación", channel: "Email" },
                        { date: "2024-05-25", type: "Vencimiento próximo", channel: "WhatsApp" },
                      ].map((alert, index) => (
                        <div key={index} className="p-2 bg-futuristic-background/30 rounded text-sm">
                          <div className="text-futuristic-text-primary">{alert.type}</div>
                          <div className="flex justify-between text-xs text-futuristic-text-secondary">
                            <span>{alert.date}</span>
                            <span>{alert.channel}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
              <DialogFooter className="flex gap-2">
                <Button
                  variant="outline"
                  className="border-futuristic-info/30 text-futuristic-info hover:bg-futuristic-info/5 bg-transparent"
                >
                  <FileText className="w-4 h-4 mr-2" />
                  Generar Factura PDF
                </Button>
                <Button
                  variant="outline"
                  className="border-futuristic-warning/30 text-futuristic-warning hover:bg-futuristic-warning/5 bg-transparent"
                >
                  <Send className="w-4 h-4 mr-2" />
                  Enviar Recordatorio
                </Button>
                <Button className="bg-gradient-to-r from-futuristic-success to-futuristic-success/80">
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Renovar Plan
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        )}

        {/* Modal de Seguimiento de Pagos */}
        {selectedSubscriptionForTracking && (
          <Dialog open={isPaymentTrackingOpen} onOpenChange={setIsPaymentTrackingOpen}>
            <DialogContent className="max-w-6xl bg-futuristic-surface border-futuristic-primary/20">
              <DialogHeader>
                <DialogTitle className="text-futuristic-text-primary flex items-center gap-3">
                  <DollarSign className="w-8 h-8 text-futuristic-success" />
                  Seguimiento de Pagos - {selectedSubscriptionForTracking.schoolName}
                </DialogTitle>
                <DialogDescription className="text-futuristic-text-secondary">
                  Monitoreo completo del historial y proyecciones de pagos
                </DialogDescription>
              </DialogHeader>

              <div className="py-4">
                <Tabs defaultValue="history" className="space-y-4">
                  <TabsList className="bg-futuristic-surface border border-futuristic-primary/10">
                    <TabsTrigger value="history" className="flex items-center gap-2">
                      <FileText className="w-4 h-4" />
                      Historial
                    </TabsTrigger>
                    <TabsTrigger value="schedule" className="flex items-center gap-2">
                      <Calendar className="w-4 h-4" />
                      Cronograma
                    </TabsTrigger>
                    <TabsTrigger value="analytics" className="flex items-center gap-2">
                      <BarChart3 className="w-4 h-4" />
                      Análisis
                    </TabsTrigger>
                    <TabsTrigger value="reminders" className="flex items-center gap-2">
                      <Bell className="w-4 h-4" />
                      Recordatorios
                    </TabsTrigger>
                  </TabsList>

                  {/* Tab de Historial */}
                  <TabsContent value="history" className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <Card className="bg-futuristic-surface border-futuristic-primary/10">
                        <CardHeader className="pb-2">
                          <CardTitle className="text-sm text-futuristic-text-secondary">Total Pagado</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="text-2xl font-bold text-futuristic-success">$25,500</div>
                          <p className="text-xs text-futuristic-text-secondary">5 pagos realizados</p>
                        </CardContent>
                      </Card>

                      <Card className="bg-futuristic-surface border-futuristic-primary/10">
                        <CardHeader className="pb-2">
                          <CardTitle className="text-sm text-futuristic-text-secondary">Próximo Pago</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="text-2xl font-bold text-futuristic-warning">$850</div>
                          <p className="text-xs text-futuristic-text-secondary">Vence en 15 días</p>
                        </CardContent>
                      </Card>

                      <Card className="bg-futuristic-surface border-futuristic-primary/10">
                        <CardHeader className="pb-2">
                          <CardTitle className="text-sm text-futuristic-text-secondary">Pagos Atrasados</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="text-2xl font-bold text-futuristic-error">0</div>
                          <p className="text-xs text-futuristic-success">Al día</p>
                        </CardContent>
                      </Card>
                    </div>

                    <Card className="bg-futuristic-surface border-futuristic-primary/10">
                      <CardHeader>
                        <CardTitle className="text-futuristic-text-primary">Historial de Transacciones</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-3 max-h-64 overflow-y-auto">
                          {[
                            {
                              id: 1,
                              date: "2024-06-01",
                              amount: 850,
                              method: "Stripe",
                              status: "Completado",
                              reference: "TXN-2024-001",
                              period: "Junio 2024",
                            },
                            {
                              id: 2,
                              date: "2024-05-01",
                              amount: 850,
                              method: "Transferencia",
                              status: "Completado",
                              reference: "TXN-2024-002",
                              period: "Mayo 2024",
                            },
                            {
                              id: 3,
                              date: "2024-04-01",
                              amount: 850,
                              method: "Stripe",
                              status: "Completado",
                              reference: "TXN-2024-003",
                              period: "Abril 2024",
                            },
                          ].map((payment) => (
                            <div
                              key={payment.id}
                              className="flex items-center justify-between p-3 bg-futuristic-background/30 rounded-lg"
                            >
                              <div className="flex items-center gap-3">
                                <div className="w-10 h-10 bg-futuristic-success/10 rounded-full flex items-center justify-center">
                                  <CheckCircle className="w-5 h-5 text-futuristic-success" />
                                </div>
                                <div>
                                  <div className="text-futuristic-text-primary font-medium">${payment.amount}</div>
                                  <div className="text-sm text-futuristic-text-secondary">{payment.period}</div>
                                </div>
                              </div>
                              <div className="text-right">
                                <div className="text-sm text-futuristic-text-primary">{payment.date}</div>
                                <div className="text-xs text-futuristic-text-secondary">{payment.method}</div>
                                <div className="text-xs text-futuristic-text-tertiary">{payment.reference}</div>
                              </div>
                              <Badge className="bg-futuristic-success/10 text-futuristic-success border-futuristic-success/20">
                                {payment.status}
                              </Badge>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  </TabsContent>

                  {/* Tab de Cronograma */}
                  <TabsContent value="schedule" className="space-y-4">
                    <Card className="bg-futuristic-surface border-futuristic-primary/10">
                      <CardHeader>
                        <CardTitle className="text-futuristic-text-primary">Cronograma de Pagos</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-3">
                          {[
                            {
                              date: "2024-07-01",
                              amount: 850,
                              status: "Próximo",
                              daysLeft: 15,
                              paymentStatus: "Pendiente",
                            },
                            {
                              date: "2024-08-01",
                              amount: 850,
                              status: "Programado",
                              daysLeft: 46,
                              paymentStatus: "Pendiente",
                            },
                            {
                              date: "2024-09-01",
                              amount: 850,
                              status: "Programado",
                              daysLeft: 77,
                              paymentStatus: "Pendiente",
                            },
                            {
                              date: "2024-10-01",
                              amount: 850,
                              status: "Programado",
                              daysLeft: 107,
                              paymentStatus: "Pendiente",
                            },
                          ].map((payment, index) => (
                            <div
                              key={index}
                              className="flex items-center justify-between p-4 border border-futuristic-primary/10 rounded-lg"
                            >
                              <div className="flex items-center gap-4">
                                <div
                                  className={`w-3 h-3 rounded-full ${
                                    payment.paymentStatus === "Pagado"
                                      ? "bg-futuristic-success"
                                      : payment.status === "Próximo"
                                        ? "bg-futuristic-warning"
                                        : "bg-futuristic-info"
                                  }`}
                                />
                                <div>
                                  <div className="text-futuristic-text-primary font-medium">{payment.date}</div>
                                  <div className="text-sm text-futuristic-text-secondary">
                                    {payment.status === "Próximo"
                                      ? `En ${payment.daysLeft} días`
                                      : `Faltan ${payment.daysLeft} días`}
                                  </div>
                                </div>
                              </div>

                              <div className="flex items-center gap-4">
                                <div className="text-right">
                                  <div className="text-futuristic-text-primary font-medium">${payment.amount}</div>
                                  <Badge
                                    className={
                                      payment.paymentStatus === "Pagado"
                                        ? "bg-futuristic-success/10 text-futuristic-success border-futuristic-success/20"
                                        : payment.status === "Próximo"
                                          ? "bg-futuristic-warning/10 text-futuristic-warning border-futuristic-warning/20"
                                          : "bg-futuristic-info/10 text-futuristic-info border-futuristic-info/20"
                                    }
                                  >
                                    {payment.paymentStatus === "Pagado" ? "Pagado" : payment.status}
                                  </Badge>
                                </div>

                                {/* Controles de Estado de Pago */}
                                <div className="flex gap-2">
                                  <Button
                                    size="sm"
                                    variant={payment.paymentStatus === "Pagado" ? "default" : "outline"}
                                    className={
                                      payment.paymentStatus === "Pagado"
                                        ? "bg-futuristic-success hover:bg-futuristic-success/80 text-white"
                                        : "border-futuristic-success/30 text-futuristic-success hover:bg-futuristic-success/5 bg-transparent"
                                    }
                                    onClick={() => {
                                      // Aquí iría la lógica para marcar como pagado
                                      console.log(`Marcando pago ${payment.date} como pagado`)
                                    }}
                                  >
                                    <CheckCircle className="w-4 h-4 mr-1" />
                                    Pagado
                                  </Button>

                                  <Button
                                    size="sm"
                                    variant={payment.paymentStatus === "No Pagado" ? "default" : "outline"}
                                    className={
                                      payment.paymentStatus === "No Pagado"
                                        ? "bg-futuristic-error hover:bg-futuristic-error/80 text-white"
                                        : "border-futuristic-error/30 text-futuristic-error hover:bg-futuristic-error/5 bg-transparent"
                                    }
                                    onClick={() => {
                                      // Aquí iría la lógica para marcar como no pagado
                                      console.log(`Marcando pago ${payment.date} como no pagado`)
                                    }}
                                  >
                                    <AlertTriangle className="w-4 h-4 mr-1" />
                                    No Pagado
                                  </Button>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>

                        {/* Resumen de Estados */}
                        <div className="mt-6 p-4 bg-futuristic-background/30 rounded-lg">
                          <h4 className="text-futuristic-text-primary font-medium mb-3">Resumen de Pagos</h4>
                          <div className="grid grid-cols-3 gap-4 text-center">
                            <div>
                              <div className="text-2xl font-bold text-futuristic-success">1</div>
                              <div className="text-sm text-futuristic-text-secondary">Pagados</div>
                            </div>
                            <div>
                              <div className="text-2xl font-bold text-futuristic-warning">1</div>
                              <div className="text-sm text-futuristic-text-secondary">Próximos</div>
                            </div>
                            <div>
                              <div className="text-2xl font-bold text-futuristic-info">2</div>
                              <div className="text-sm text-futuristic-text-secondary">Programados</div>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </TabsContent>

                  {/* Tab de Análisis */}
                  <TabsContent value="analytics" className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <Card className="bg-futuristic-surface border-futuristic-primary/10">
                        <CardHeader>
                          <CardTitle className="text-futuristic-text-primary">Métricas de Pago</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                          <div className="flex justify-between">
                            <span className="text-futuristic-text-secondary">Tasa de pago puntual:</span>
                            <span className="text-futuristic-success font-medium">95%</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-futuristic-text-secondary">Días promedio de retraso:</span>
                            <span className="text-futuristic-text-primary font-medium">2.3</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-futuristic-text-secondary">Método de pago preferido:</span>
                            <span className="text-futuristic-text-primary font-medium">Stripe</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-futuristic-text-secondary">Recordatorios enviados:</span>
                            <span className="text-futuristic-text-primary font-medium">12</span>
                          </div>
                        </CardContent>
                      </Card>

                      <Card className="bg-futuristic-surface border-futuristic-primary/10">
                        <CardHeader>
                          <CardTitle className="text-futuristic-text-primary">Proyección Anual</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                          <div className="flex justify-between">
                            <span className="text-futuristic-text-secondary">Ingresos proyectados:</span>
                            <span className="text-futuristic-success font-medium">$10,200</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-futuristic-text-secondary">Pagos restantes:</span>
                            <span className="text-futuristic-text-primary font-medium">6</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-futuristic-text-secondary">Valor del descuento:</span>
                            <span className="text-futuristic-info font-medium">$1,530</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-futuristic-text-secondary">Próxima renovación:</span>
                            <span className="text-futuristic-text-primary font-medium">2025-01-15</span>
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  </TabsContent>

                  {/* Tab de Recordatorios */}
                  <TabsContent value="reminders" className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <Card className="bg-futuristic-surface border-futuristic-primary/10">
                        <CardHeader>
                          <CardTitle className="text-futuristic-text-primary">Configurar Recordatorios</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                          <div className="space-y-2">
                            <Label className="text-futuristic-text-primary">Días antes del vencimiento</Label>
                            <Select>
                              <SelectTrigger className="bg-futuristic-background/50 border-futuristic-primary/20">
                                <SelectValue placeholder="Seleccionar días" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="3">3 días</SelectItem>
                                <SelectItem value="7">7 días</SelectItem>
                                <SelectItem value="15">15 días</SelectItem>
                                <SelectItem value="30">30 días</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div className="space-y-2">
                            <Label className="text-futuristic-text-primary">Canal de notificación</Label>
                            <div className="space-y-2">
                              <div className="flex items-center space-x-2">
                                <Checkbox id="email" />
                                <label htmlFor="email" className="text-sm text-futuristic-text-primary">
                                  Email
                                </label>
                              </div>
                              <div className="flex items-center space-x-2">
                                <Checkbox id="whatsapp" />
                                <label htmlFor="whatsapp" className="text-sm text-futuristic-text-primary">
                                  WhatsApp
                                </label>
                              </div>
                              <div className="flex items-center space-x-2">
                                <Checkbox id="system" />
                                <label htmlFor="system" className="text-sm text-futuristic-text-primary">
                                  Sistema
                                </label>
                              </div>
                            </div>
                          </div>
                          <Button className="w-full bg-gradient-to-r from-futuristic-primary to-futuristic-primary-light">
                            Programar Recordatorio
                          </Button>
                        </CardContent>
                      </Card>

                      <Card className="bg-futuristic-surface border-futuristic-primary/10">
                        <CardHeader>
                          <CardTitle className="text-futuristic-text-primary">Recordatorios Programados</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-3 max-h-48 overflow-y-auto">
                            {[
                              {
                                date: "2024-06-16",
                                type: "Recordatorio de pago",
                                channel: "Email + WhatsApp",
                                status: "Programado",
                              },
                              {
                                date: "2024-06-23",
                                type: "Último aviso",
                                channel: "Email",
                                status: "Programado",
                              },
                            ].map((reminder, index) => (
                              <div key={index} className="p-3 bg-futuristic-background/30 rounded-lg">
                                <div className="flex justify-between items-start">
                                  <div>
                                    <div className="text-futuristic-text-primary font-medium text-sm">
                                      {reminder.type}
                                    </div>
                                    <div className="text-futuristic-text-secondary text-xs">{reminder.channel}</div>
                                  </div>
                                  <div className="text-right">
                                    <div className="text-futuristic-text-secondary text-xs">{reminder.date}</div>
                                    <Badge className="bg-futuristic-info/10 text-futuristic-info border-futuristic-info/20">
                                      {reminder.status}
                                    </Badge>
                                  </div>
                                </div>
                              </div>
                            ))}
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  </TabsContent>
                </Tabs>
              </div>

              <DialogFooter className="flex gap-2">
                <Button
                  variant="outline"
                  onClick={() => setIsPaymentTrackingOpen(false)}
                  className="border-futuristic-primary/30 text-futuristic-text-secondary"
                >
                  Cerrar
                </Button>
                <Button
                  variant="outline"
                  className="border-futuristic-info/30 text-futuristic-info hover:bg-futuristic-info/5 bg-transparent"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Exportar Reporte
                </Button>
                <Button
                  variant="outline"
                  className="border-futuristic-warning/30 text-futuristic-warning hover:bg-futuristic-warning/5 bg-transparent"
                >
                  <Send className="w-4 h-4 mr-2" />
                  Enviar Recordatorio Manual
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        )}
      </main>
    </div>
  )
}
