"use client"

import { useState } from "react"
import { Header } from "@/components/dashboard/header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  Users,
  Search,
  Filter,
  Download,
  Edit,
  Eye,
  Trash2,
  UserPlus,
  RefreshCw,
  Building,
  Mail,
  Phone,
  Calendar,
  Shield,
  GraduationCap,
  UserCheck,
  Baby,
  Upload,
  FileSpreadsheet,
  FileText,
  Activity,
  TrendingUp,
  BarChart3,
  PieChart,
  Clock,
  AlertTriangle,
  CheckCircle,
  Key,
  Camera,
  Calculator,
  Settings,
  UserCog,
  Crown,
} from "lucide-react"

// Datos de colegios activos
const activeSchools = [
  { id: "1", name: "Colegio San Patricio", code: "SP-001" },
  { id: "2", name: "Instituto Tecnológico Avanzado", code: "ITA-002" },
  { id: "3", name: "Escuela Nueva Era", code: "ENE-003" },
  { id: "4", name: "Colegio María Auxiliadora", code: "CMA-004" },
  { id: "5", name: "Instituto San José", code: "ISJ-005" },
]

// Roles disponibles con configuración
const userRoles = [
  {
    id: "director",
    name: "Director",
    icon: Crown,
    color: "primary",
    description: "Administrador principal del colegio",
    permissions: ["all_modules", "user_management", "reports", "settings"],
    fields: ["leadership_experience", "education_level"],
  },
  {
    id: "coordinador-academico",
    name: "Coordinador Académico",
    icon: UserCog,
    color: "info",
    description: "Gestión académica y curricular",
    permissions: ["academic_modules", "curriculum", "teacher_management"],
    fields: ["academic_area", "specialization"],
  },
  {
    id: "coordinador-registro",
    name: "Coordinador de Registro",
    icon: Settings,
    color: "success",
    description: "Gestión de registros y documentación",
    permissions: ["student_records", "enrollment", "documentation"],
    fields: ["administrative_experience"],
  },
  {
    id: "profesor",
    name: "Profesor",
    icon: GraduationCap,
    color: "success",
    description: "Docente del centro educativo",
    permissions: ["teaching_modules", "grades", "attendance"],
    fields: ["subjects", "grade_levels", "specialization"],
  },
  {
    id: "padre",
    name: "Padre/Madre",
    icon: Users,
    color: "warning",
    description: "Padre o tutor de estudiante",
    permissions: ["student_tracking", "communication", "payments"],
    fields: ["student_relation", "emergency_contact"],
  },
  {
    id: "contable",
    name: "Contable",
    icon: Calculator,
    color: "amber",
    description: "Gestión financiera y contable",
    permissions: ["financial_modules", "billing", "reports"],
    fields: ["accounting_certification", "experience_years"],
  },
  {
    id: "estudiante",
    name: "Estudiante",
    icon: Baby,
    color: "info",
    description: "Estudiante del centro educativo",
    permissions: ["student_portal", "assignments", "grades_view"],
    fields: ["grade_level", "section", "parent_contact"],
  },
]

// Datos de usuarios de ejemplo
const usersData = [
  {
    id: "1",
    initials: "CR",
    name: "Carlos Rodríguez",
    email: "carlos@sanpatricio.edu",
    role: "director",
    school: "Colegio San Patricio",
    schoolId: "1",
    status: "Activo",
    lastAccess: "2024-06-06 14:30",
    createdAt: "2024-01-15",
    phone: "+1 234-567-8900",
    avatar: "/placeholder.svg?height=40&width=40",
    isAutoCreated: true, // Creado automáticamente al crear el colegio
    additionalInfo: {
      leadership_experience: "10 años",
      education_level: "Maestría en Educación",
    },
  },
  {
    id: "2",
    initials: "MG",
    name: "María González",
    email: "maria@sanpatricio.edu",
    role: "profesor",
    school: "Colegio San Patricio",
    schoolId: "1",
    status: "Activo",
    lastAccess: "2024-06-06 13:45",
    createdAt: "2024-02-20",
    phone: "+1 234-567-8901",
    avatar: "/placeholder.svg?height=40&width=40",
    isAutoCreated: false,
    additionalInfo: {
      subjects: ["Matemáticas", "Física"],
      grade_levels: ["10mo", "11mo", "12mo"],
      specialization: "Ciencias Exactas",
    },
  },
  {
    id: "3",
    initials: "AM",
    name: "Ana Martínez",
    email: "ana@tecnoavanzado.edu",
    role: "director",
    school: "Instituto Tecnológico Avanzado",
    schoolId: "2",
    status: "Activo",
    lastAccess: "2024-06-06 12:15",
    createdAt: "2024-01-10",
    phone: "+1 234-567-8902",
    avatar: "/placeholder.svg?height=40&width=40",
    isAutoCreated: true,
    additionalInfo: {
      leadership_experience: "8 años",
      education_level: "Licenciatura en Administración",
    },
  },
  {
    id: "4",
    initials: "JP",
    name: "Juan Pérez",
    email: "juan@sanpatricio.edu",
    role: "padre",
    school: "Colegio San Patricio",
    schoolId: "1",
    status: "Activo",
    lastAccess: "2024-06-05 18:20",
    createdAt: "2024-03-05",
    phone: "+1 234-567-8903",
    avatar: "/placeholder.svg?height=40&width=40",
    isAutoCreated: false,
    additionalInfo: {
      student_relation: "Padre",
      emergency_contact: "Sí",
    },
  },
  {
    id: "5",
    initials: "RS",
    name: "Roberto Sánchez",
    email: "roberto@nuevaera.edu",
    role: "profesor",
    school: "Escuela Nueva Era",
    schoolId: "3",
    status: "Inactivo",
    lastAccess: "2024-06-01 10:30",
    createdAt: "2024-01-25",
    phone: "+1 234-567-8904",
    avatar: "/placeholder.svg?height=40&width=40",
    isAutoCreated: false,
    additionalInfo: {
      subjects: ["Historia", "Geografía"],
      grade_levels: ["7mo", "8vo", "9no"],
      specialization: "Ciencias Sociales",
    },
  },
  {
    id: "6",
    initials: "LC",
    name: "Laura Castro",
    email: "laura@sanpatricio.edu",
    role: "coordinador-academico",
    school: "Colegio San Patricio",
    schoolId: "1",
    status: "Activo",
    lastAccess: "2024-06-06 11:20",
    createdAt: "2024-02-01",
    phone: "+1 234-567-8905",
    avatar: "/placeholder.svg?height=40&width=40",
    isAutoCreated: false,
    additionalInfo: {
      academic_area: "Ciencias",
      specialization: "Coordinación Curricular",
    },
  },
  {
    id: "7",
    initials: "PV",
    name: "Pedro Vásquez",
    email: "pedro@tecnoavanzado.edu",
    role: "contable",
    school: "Instituto Tecnológico Avanzado",
    schoolId: "2",
    status: "Activo",
    lastAccess: "2024-06-06 09:15",
    createdAt: "2024-01-20",
    phone: "+1 234-567-8906",
    avatar: "/placeholder.svg?height=40&width=40",
    isAutoCreated: false,
    additionalInfo: {
      accounting_certification: "CPA",
      experience_years: "12 años",
    },
  },
]

export default function UsersManagementPage() {
  const [selectedUser, setSelectedUser] = useState(null)
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [isDetailDialogOpen, setIsDetailDialogOpen] = useState(false)
  const [isImportDialogOpen, setIsImportDialogOpen] = useState(false)
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    school: "",
    role: "",
    password: "",
    avatar: null,
    additionalFields: {},
  })
  const [filters, setFilters] = useState({
    search: "",
    school: "",
    role: "",
    status: "",
  })

  // Filtrar usuarios
  const filteredUsers = usersData.filter((user) => {
    const matchesSearch =
      filters.search === "" ||
      user.name.toLowerCase().includes(filters.search.toLowerCase()) ||
      user.email.toLowerCase().includes(filters.search.toLowerCase())

    const matchesSchool = filters.school === "" || user.schoolId === filters.school
    const matchesRole = filters.role === "" || user.role === filters.role
    const matchesStatus = filters.status === "" || user.status === filters.status

    return matchesSearch && matchesSchool && matchesRole && matchesStatus
  })

  // Obtener configuración del rol
  const getRoleConfig = (roleId) => {
    return userRoles.find((role) => role.id === roleId) || userRoles[0]
  }

  // Obtener color del rol
  const getRoleColor = (role) => {
    const roleConfig = getRoleConfig(role)
    return `bg-futuristic-${roleConfig.color}/10 text-futuristic-${roleConfig.color} border-futuristic-${roleConfig.color}/20`
  }

  // Obtener color del estado
  const getStatusColor = (status) => {
    switch (status) {
      case "Activo":
        return "bg-futuristic-success/10 text-futuristic-success border-futuristic-success/20"
      case "Inactivo":
        return "bg-futuristic-error/10 text-futuristic-error border-futuristic-error/20"
      case "Pendiente":
        return "bg-futuristic-warning/10 text-futuristic-warning border-futuristic-warning/20"
      default:
        return "bg-futuristic-info/10 text-futuristic-info border-futuristic-info/20"
    }
  }

  // Generar contraseña automática
  const generatePassword = () => {
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
    let password = ""
    for (let i = 0; i < 8; i++) {
      password += chars.charAt(Math.floor(Math.random() * chars.length))
    }
    setFormData({ ...formData, password })
  }

  // Manejar cambio de rol
  const handleRoleChange = (roleId) => {
    const roleConfig = getRoleConfig(roleId)
    setFormData({
      ...formData,
      role: roleId,
      additionalFields: {},
    })
  }

  // Calcular estadísticas
  const totalUsers = usersData.length
  const totalTeachers = usersData.filter((user) => user.role === "profesor").length
  const totalDirectors = usersData.filter((user) => user.role === "director").length
  const activeUsers = usersData.filter((user) => user.status === "Activo").length
  const newUsersThisMonth = usersData.filter((user) => {
    const createdDate = new Date(user.createdAt)
    const now = new Date()
    return createdDate.getMonth() === now.getMonth() && createdDate.getFullYear() === now.getFullYear()
  }).length

  return (
    <div className="flex-1 flex flex-col">
      <Header title="Gestión de Usuarios" />

      <main className="flex-1 overflow-y-auto p-6 bg-futuristic-background">
        <Tabs defaultValue="users" className="space-y-6">
          <div className="flex items-center justify-between">
            <TabsList className="bg-futuristic-surface border border-futuristic-primary/10">
              <TabsTrigger value="users" className="flex items-center gap-2">
                <Users className="w-4 h-4" />
                Gestión de Usuarios
              </TabsTrigger>
              <TabsTrigger value="analytics" className="flex items-center gap-2">
                <BarChart3 className="w-4 h-4" />
                Analítica
              </TabsTrigger>
            </TabsList>

            <div className="flex gap-2">
              <Dialog open={isImportDialogOpen} onOpenChange={setIsImportDialogOpen}>
                <DialogTrigger asChild>
                  <Button
                    variant="outline"
                    className="border-futuristic-info/30 text-futuristic-info hover:bg-futuristic-info/5 bg-transparent"
                  >
                    <Upload className="w-4 h-4 mr-2" />
                    Importar Usuarios
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl bg-futuristic-surface border-futuristic-primary/20">
                  <DialogHeader>
                    <DialogTitle className="text-futuristic-text-primary flex items-center gap-2">
                      <Upload className="w-5 h-5" />
                      Importación Masiva de Usuarios
                    </DialogTitle>
                    <DialogDescription className="text-futuristic-text-secondary">
                      Carga múltiples usuarios usando una plantilla de Excel
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <div className="flex items-center justify-center p-8 border-2 border-dashed border-futuristic-primary/30 rounded-lg bg-futuristic-background/30">
                      <div className="text-center">
                        <FileSpreadsheet className="w-12 h-12 text-futuristic-text-secondary mx-auto mb-4" />
                        <h3 className="text-lg font-semibold text-futuristic-text-primary mb-2">
                          Arrastra tu archivo aquí
                        </h3>
                        <p className="text-sm text-futuristic-text-secondary mb-4">
                          O haz clic para seleccionar un archivo Excel (.xlsx, .xls)
                        </p>
                        <Button
                          variant="outline"
                          className="border-futuristic-primary/30 text-futuristic-primary hover:bg-futuristic-primary/5 bg-transparent"
                        >
                          Seleccionar Archivo
                        </Button>
                      </div>
                    </div>
                    <div className="bg-futuristic-info/5 border border-futuristic-info/20 rounded-lg p-4">
                      <h4 className="font-semibold text-futuristic-info mb-2">Instrucciones:</h4>
                      <ul className="text-sm text-futuristic-text-secondary space-y-1">
                        <li>• Descarga la plantilla oficial antes de importar</li>
                        <li>• Completa todos los campos obligatorios</li>
                        <li>• Verifica que los colegios existan en el sistema</li>
                        <li>• Los roles deben coincidir exactamente</li>
                      </ul>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        className="flex-1 border-futuristic-success/30 text-futuristic-success hover:bg-futuristic-success/5 bg-transparent"
                      >
                        <Download className="w-4 h-4 mr-2" />
                        Descargar Plantilla
                      </Button>
                      <Button
                        variant="outline"
                        className="flex-1 border-futuristic-info/30 text-futuristic-info hover:bg-futuristic-info/5 bg-transparent"
                      >
                        <FileText className="w-4 h-4 mr-2" />
                        Ver Ejemplo
                      </Button>
                    </div>
                  </div>
                  <DialogFooter>
                    <Button
                      variant="outline"
                      onClick={() => setIsImportDialogOpen(false)}
                      className="border-futuristic-primary/30 text-futuristic-text-secondary"
                    >
                      Cancelar
                    </Button>
                    <Button className="bg-gradient-to-r from-futuristic-primary to-futuristic-primary-light">
                      Procesar Importación
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>

              <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-gradient-to-r from-futuristic-primary to-futuristic-primary-light hover:from-futuristic-primary-dark hover:to-futuristic-primary">
                    <UserPlus className="w-4 h-4 mr-2" />
                    Nuevo Usuario
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto bg-futuristic-surface border-futuristic-primary/20">
                  <DialogHeader>
                    <DialogTitle className="text-futuristic-text-primary flex items-center gap-2">
                      <UserPlus className="w-5 h-5" />
                      Crear Nuevo Usuario
                    </DialogTitle>
                    <DialogDescription className="text-futuristic-text-secondary">
                      Complete la información del nuevo usuario del sistema
                    </DialogDescription>
                  </DialogHeader>

                  <div className="space-y-6 py-4">
                    {/* Información básica */}
                    <Card className="bg-futuristic-background/50 border-futuristic-primary/10">
                      <CardHeader>
                        <CardTitle className="text-futuristic-text-primary text-lg flex items-center gap-2">
                          <UserCheck className="w-5 h-5" />
                          Información Personal
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="name" className="text-futuristic-text-primary">
                              Nombres y Apellidos *
                            </Label>
                            <Input
                              id="name"
                              placeholder="Ej: María González Pérez"
                              value={formData.name}
                              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                              className="bg-futuristic-surface border-futuristic-primary/20"
                            />
                          </div>
                          <div>
                            <Label htmlFor="email" className="text-futuristic-text-primary">
                              Correo Institucional *
                            </Label>
                            <Input
                              id="email"
                              type="email"
                              placeholder="usuario@colegio.edu"
                              value={formData.email}
                              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                              className="bg-futuristic-surface border-futuristic-primary/20"
                            />
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="phone" className="text-futuristic-text-primary">
                              Teléfono de Contacto *
                            </Label>
                            <Input
                              id="phone"
                              placeholder="+1 234-567-8900"
                              value={formData.phone}
                              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                              className="bg-futuristic-surface border-futuristic-primary/20"
                            />
                          </div>
                          <div>
                            <Label className="text-futuristic-text-primary">Foto de Perfil</Label>
                            <div className="flex items-center gap-3">
                              <div className="w-12 h-12 bg-futuristic-primary/10 rounded-full flex items-center justify-center">
                                <Camera className="w-5 h-5 text-futuristic-primary" />
                              </div>
                              <Button
                                variant="outline"
                                size="sm"
                                className="border-futuristic-primary/30 text-futuristic-primary hover:bg-futuristic-primary/5 bg-transparent"
                              >
                                <Upload className="w-4 h-4 mr-2" />
                                Subir Foto
                              </Button>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Asignación institucional */}
                    <Card className="bg-futuristic-background/50 border-futuristic-primary/10">
                      <CardHeader>
                        <CardTitle className="text-futuristic-text-primary text-lg flex items-center gap-2">
                          <Building className="w-5 h-5" />
                          Asignación Institucional
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="school" className="text-futuristic-text-primary">
                              Colegio *
                            </Label>
                            <Select
                              value={formData.school}
                              onValueChange={(value) => setFormData({ ...formData, school: value })}
                            >
                              <SelectTrigger className="bg-futuristic-surface border-futuristic-primary/20">
                                <SelectValue placeholder="Seleccionar colegio" />
                              </SelectTrigger>
                              <SelectContent>
                                {activeSchools.map((school) => (
                                  <SelectItem key={school.id} value={school.id}>
                                    <div className="flex items-center gap-2">
                                      <Building className="w-4 h-4" />
                                      {school.name}
                                    </div>
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                          <div>
                            <Label htmlFor="role" className="text-futuristic-text-primary">
                              Rol *
                            </Label>
                            <Select value={formData.role} onValueChange={handleRoleChange}>
                              <SelectTrigger className="bg-futuristic-surface border-futuristic-primary/20">
                                <SelectValue placeholder="Seleccionar rol" />
                              </SelectTrigger>
                              <SelectContent>
                                {userRoles.map((role) => (
                                  <SelectItem key={role.id} value={role.id}>
                                    <div className="flex items-center gap-2">
                                      <role.icon className="w-4 h-4" />
                                      <div>
                                        <div>{role.name}</div>
                                        <div className="text-xs text-futuristic-text-tertiary">{role.description}</div>
                                      </div>
                                    </div>
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                        </div>

                        {/* Campos específicos por rol */}
                        {formData.role && (
                          <div className="mt-4 p-4 bg-futuristic-primary/5 border border-futuristic-primary/20 rounded-lg">
                            <h4 className="font-semibold text-futuristic-text-primary mb-3">
                              Información Específica del Rol
                            </h4>
                            <div className="grid grid-cols-1 gap-4">
                              {formData.role === "profesor" && (
                                <>
                                  <div>
                                    <Label className="text-futuristic-text-primary">Materias a Impartir</Label>
                                    <Input
                                      placeholder="Ej: Matemáticas, Física"
                                      className="bg-futuristic-surface border-futuristic-primary/20"
                                    />
                                  </div>
                                  <div>
                                    <Label className="text-futuristic-text-primary">Grados</Label>
                                    <Input
                                      placeholder="Ej: 10mo, 11mo, 12mo"
                                      className="bg-futuristic-surface border-futuristic-primary/20"
                                    />
                                  </div>
                                </>
                              )}
                              {formData.role === "padre" && (
                                <>
                                  <div>
                                    <Label className="text-futuristic-text-primary">Relación con el Estudiante</Label>
                                    <Select>
                                      <SelectTrigger className="bg-futuristic-surface border-futuristic-primary/20">
                                        <SelectValue placeholder="Seleccionar relación" />
                                      </SelectTrigger>
                                      <SelectContent>
                                        <SelectItem value="padre">Padre</SelectItem>
                                        <SelectItem value="madre">Madre</SelectItem>
                                        <SelectItem value="tutor">Tutor Legal</SelectItem>
                                        <SelectItem value="abuelo">Abuelo/a</SelectItem>
                                      </SelectContent>
                                    </Select>
                                  </div>
                                  <div>
                                    <Label className="text-futuristic-text-primary">¿Estudiante ya registrado?</Label>
                                    <Select>
                                      <SelectTrigger className="bg-futuristic-surface border-futuristic-primary/20">
                                        <SelectValue placeholder="Seleccionar opción" />
                                      </SelectTrigger>
                                      <SelectContent>
                                        <SelectItem value="si">Sí, seleccionar estudiante</SelectItem>
                                        <SelectItem value="no">No, registrar después</SelectItem>
                                      </SelectContent>
                                    </Select>
                                  </div>
                                </>
                              )}
                              {formData.role === "coordinador-academico" && (
                                <div>
                                  <Label className="text-futuristic-text-primary">Área Académica</Label>
                                  <Select>
                                    <SelectTrigger className="bg-futuristic-surface border-futuristic-primary/20">
                                      <SelectValue placeholder="Seleccionar área" />
                                    </SelectTrigger>
                                    <SelectContent>
                                      <SelectItem value="ciencias">Ciencias</SelectItem>
                                      <SelectItem value="humanidades">Humanidades</SelectItem>
                                      <SelectItem value="matematicas">Matemáticas</SelectItem>
                                      <SelectItem value="idiomas">Idiomas</SelectItem>
                                      <SelectItem value="artes">Artes</SelectItem>
                                    </SelectContent>
                                  </Select>
                                </div>
                              )}
                              {formData.role === "contable" && (
                                <div>
                                  <Label className="text-futuristic-text-primary">Certificación Contable</Label>
                                  <Input
                                    placeholder="Ej: CPA, Licenciado en Contabilidad"
                                    className="bg-futuristic-surface border-futuristic-primary/20"
                                  />
                                </div>
                              )}
                            </div>
                          </div>
                        )}
                      </CardContent>
                    </Card>

                    {/* Configuración de acceso */}
                    <Card className="bg-futuristic-background/50 border-futuristic-primary/10">
                      <CardHeader>
                        <CardTitle className="text-futuristic-text-primary text-lg flex items-center gap-2">
                          <Key className="w-5 h-5" />
                          Configuración de Acceso
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="password" className="text-futuristic-text-primary">
                              Contraseña
                            </Label>
                            <div className="flex gap-2">
                              <Input
                                id="password"
                                type="password"
                                placeholder="Contraseña temporal"
                                value={formData.password}
                                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                                className="bg-futuristic-surface border-futuristic-primary/20"
                              />
                              <Button
                                type="button"
                                variant="outline"
                                onClick={generatePassword}
                                className="border-futuristic-primary/30 text-futuristic-primary hover:bg-futuristic-primary/5 bg-transparent"
                              >
                                <RefreshCw className="w-4 h-4" />
                              </Button>
                            </div>
                            <p className="text-xs text-futuristic-text-tertiary mt-1">
                              El usuario deberá cambiar la contraseña en el primer acceso
                            </p>
                          </div>
                          <div>
                            <Label className="text-futuristic-text-primary">Estado Inicial</Label>
                            <Select defaultValue="activo">
                              <SelectTrigger className="bg-futuristic-surface border-futuristic-primary/20">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="activo">Activo</SelectItem>
                                <SelectItem value="pendiente">Pendiente de Activación</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </div>

                        {/* Permisos del rol */}
                        {formData.role && (
                          <div className="mt-4 p-4 bg-futuristic-success/5 border border-futuristic-success/20 rounded-lg">
                            <h4 className="font-semibold text-futuristic-success mb-3 flex items-center gap-2">
                              <Shield className="w-4 h-4" />
                              Permisos Asignados Automáticamente
                            </h4>
                            <div className="flex flex-wrap gap-2">
                              {getRoleConfig(formData.role).permissions.map((permission, index) => (
                                <Badge
                                  key={index}
                                  className="bg-futuristic-success/10 text-futuristic-success border-futuristic-success/20"
                                >
                                  <CheckCircle className="w-3 h-3 mr-1" />
                                  {permission.replace("_", " ")}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  </div>

                  <DialogFooter>
                    <Button
                      variant="outline"
                      onClick={() => setIsCreateDialogOpen(false)}
                      className="border-futuristic-primary/30 text-futuristic-text-secondary"
                    >
                      Cancelar
                    </Button>
                    <Button
                      className="bg-gradient-to-r from-futuristic-primary to-futuristic-primary-light"
                      disabled={!formData.name || !formData.email || !formData.school || !formData.role}
                    >
                      <UserPlus className="w-4 h-4 mr-2" />
                      Crear Usuario
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>

              {/* Edit User Dialog */}
              <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
                <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto bg-futuristic-surface border-futuristic-primary/20">
                  <DialogHeader>
                    <DialogTitle className="text-futuristic-text-primary flex items-center gap-2">
                      <Edit className="w-5 h-5" />
                      Editar Usuario
                    </DialogTitle>
                    <DialogDescription className="text-futuristic-text-secondary">
                      Modifica la información del usuario seleccionado
                    </DialogDescription>
                  </DialogHeader>

                  <div className="space-y-6 py-4">
                    {/* Información básica */}
                    <Card className="bg-futuristic-background/50 border-futuristic-primary/10">
                      <CardHeader>
                        <CardTitle className="text-futuristic-text-primary text-lg flex items-center gap-2">
                          <UserCheck className="w-5 h-5" />
                          Información Personal
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="edit-name" className="text-futuristic-text-primary">
                              Nombres y Apellidos *
                            </Label>
                            <Input
                              id="edit-name"
                              placeholder="Ej: María González Pérez"
                              value={formData.name}
                              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                              className="bg-futuristic-surface border-futuristic-primary/20"
                            />
                          </div>
                          <div>
                            <Label htmlFor="edit-email" className="text-futuristic-text-primary">
                              Correo Institucional *
                            </Label>
                            <Input
                              id="edit-email"
                              type="email"
                              placeholder="usuario@colegio.edu"
                              value={formData.email}
                              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                              className="bg-futuristic-surface border-futuristic-primary/20"
                            />
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="edit-phone" className="text-futuristic-text-primary">
                              Teléfono de Contacto *
                            </Label>
                            <Input
                              id="edit-phone"
                              placeholder="+1 234-567-8900"
                              value={formData.phone}
                              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                              className="bg-futuristic-surface border-futuristic-primary/20"
                            />
                          </div>
                          <div>
                            <Label className="text-futuristic-text-primary">Foto de Perfil</Label>
                            <div className="flex items-center gap-3">
                              <Avatar className="w-12 h-12">
                                <AvatarImage
                                  src={selectedUser?.avatar || "/placeholder.svg"}
                                  alt={selectedUser?.name}
                                />
                                <AvatarFallback className="bg-gradient-to-br from-futuristic-primary to-futuristic-creative text-white">
                                  {selectedUser?.initials}
                                </AvatarFallback>
                              </Avatar>
                              <Button
                                variant="outline"
                                size="sm"
                                className="border-futuristic-primary/30 text-futuristic-primary hover:bg-futuristic-primary/5 bg-transparent"
                              >
                                <Upload className="w-4 h-4 mr-2" />
                                Cambiar Foto
                              </Button>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Asignación institucional */}
                    <Card className="bg-futuristic-background/50 border-futuristic-primary/10">
                      <CardHeader>
                        <CardTitle className="text-futuristic-text-primary text-lg flex items-center gap-2">
                          <Building className="w-5 h-5" />
                          Asignación Institucional
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="edit-school" className="text-futuristic-text-primary">
                              Colegio *
                            </Label>
                            <Select
                              value={formData.school}
                              onValueChange={(value) => setFormData({ ...formData, school: value })}
                            >
                              <SelectTrigger className="bg-futuristic-surface border-futuristic-primary/20">
                                <SelectValue placeholder="Seleccionar colegio" />
                              </SelectTrigger>
                              <SelectContent>
                                {activeSchools.map((school) => (
                                  <SelectItem key={school.id} value={school.id}>
                                    <div className="flex items-center gap-2">
                                      <Building className="w-4 h-4" />
                                      {school.name}
                                    </div>
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                          <div>
                            <Label htmlFor="edit-role" className="text-futuristic-text-primary">
                              Rol *
                            </Label>
                            <Select
                              value={formData.role}
                              onValueChange={(value) => {
                                setFormData({
                                  ...formData,
                                  role: value,
                                  additionalFields: {},
                                })
                              }}
                            >
                              <SelectTrigger className="bg-futuristic-surface border-futuristic-primary/20">
                                <SelectValue placeholder="Seleccionar rol" />
                              </SelectTrigger>
                              <SelectContent>
                                {userRoles.map((role) => (
                                  <SelectItem key={role.id} value={role.id}>
                                    <div className="flex items-center gap-2">
                                      <role.icon className="w-4 h-4" />
                                      <div>
                                        <div>{role.name}</div>
                                        <div className="text-xs text-futuristic-text-tertiary">{role.description}</div>
                                      </div>
                                    </div>
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                        </div>

                        {/* Estado del usuario */}
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label className="text-futuristic-text-primary">Estado del Usuario</Label>
                            <Select defaultValue={selectedUser?.status.toLowerCase()}>
                              <SelectTrigger className="bg-futuristic-surface border-futuristic-primary/20">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="activo">Activo</SelectItem>
                                <SelectItem value="inactivo">Inactivo</SelectItem>
                                <SelectItem value="pendiente">Pendiente de Activación</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div>
                            <Label className="text-futuristic-text-primary">Tipo de Creación</Label>
                            <div className="flex items-center h-10 px-3 py-2 border border-futuristic-primary/20 rounded-md bg-futuristic-background/50">
                              <span className="text-futuristic-text-secondary text-sm">
                                {selectedUser?.isAutoCreated ? "Automática" : "Manual"}
                              </span>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Información específica del rol */}
                    {selectedUser?.additionalInfo && Object.keys(selectedUser.additionalInfo).length > 0 && (
                      <Card className="bg-futuristic-background/50 border-futuristic-primary/10">
                        <CardHeader>
                          <CardTitle className="text-futuristic-text-primary text-lg flex items-center gap-2">
                            <Settings className="w-5 h-5" />
                            Información Específica del Rol
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {Object.entries(selectedUser.additionalInfo).map(([key, value]) => (
                              <div key={key}>
                                <Label className="text-futuristic-text-primary capitalize">
                                  {key.replace("_", " ")}
                                </Label>
                                <Input
                                  defaultValue={value}
                                  className="bg-futuristic-surface border-futuristic-primary/20"
                                  placeholder={`Ingresa ${key.replace("_", " ").toLowerCase()}`}
                                />
                              </div>
                            ))}
                          </div>
                        </CardContent>
                      </Card>
                    )}

                    {/* Opciones de seguridad */}
                    <Card className="bg-futuristic-background/50 border-futuristic-primary/10">
                      <CardHeader>
                        <CardTitle className="text-futuristic-text-primary text-lg flex items-center gap-2">
                          <Key className="w-5 h-5" />
                          Opciones de Seguridad
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="flex items-center justify-between p-4 bg-futuristic-warning/5 border border-futuristic-warning/20 rounded-lg">
                          <div>
                            <h4 className="font-medium text-futuristic-text-primary">Restablecer Contraseña</h4>
                            <p className="text-sm text-futuristic-text-secondary">
                              Enviar nueva contraseña temporal al usuario
                            </p>
                          </div>
                          <Button
                            variant="outline"
                            className="border-futuristic-warning/30 text-futuristic-warning hover:bg-futuristic-warning/5 bg-transparent"
                          >
                            <RefreshCw className="w-4 h-4 mr-2" />
                            Restablecer
                          </Button>
                        </div>

                        <div className="flex items-center justify-between p-4 bg-futuristic-info/5 border border-futuristic-info/20 rounded-lg">
                          <div>
                            <h4 className="font-medium text-futuristic-text-primary">Último Acceso</h4>
                            <p className="text-sm text-futuristic-text-secondary">{selectedUser?.lastAccess}</p>
                          </div>
                          <Badge className="bg-futuristic-success/10 text-futuristic-success border-futuristic-success/20">
                            <Activity className="w-3 h-3 mr-1" />
                            Usuario Activo
                          </Badge>
                        </div>
                      </CardContent>
                    </Card>
                  </div>

                  <DialogFooter>
                    <Button
                      variant="outline"
                      onClick={() => {
                        setIsEditDialogOpen(false)
                        setSelectedUser(null)
                        setFormData({
                          name: "",
                          email: "",
                          phone: "",
                          school: "",
                          role: "",
                          password: "",
                          avatar: null,
                          additionalFields: {},
                        })
                      }}
                      className="border-futuristic-primary/30 text-futuristic-text-secondary"
                    >
                      Cancelar
                    </Button>
                    <Button
                      variant="outline"
                      className="border-futuristic-warning/30 text-futuristic-warning hover:bg-futuristic-warning/5 bg-transparent"
                    >
                      <RefreshCw className="w-4 h-4 mr-2" />
                      Restablecer Contraseña
                    </Button>
                    <Button
                      className="bg-gradient-to-r from-futuristic-primary to-futuristic-primary-light"
                      disabled={!formData.name || !formData.email || !formData.school || !formData.role}
                    >
                      <Edit className="w-4 h-4 mr-2" />
                      Guardar Cambios
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
          </div>

          <TabsContent value="users" className="space-y-6">
            {/* Métricas rápidas */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <Card className="bg-futuristic-surface border-futuristic-primary/10 hover:border-futuristic-primary/30 transition-all duration-300 hover:shadow-lg hover:shadow-futuristic-primary/10">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-futuristic-text-secondary text-sm font-medium">
                    Total de Usuarios
                  </CardTitle>
                  <div className="w-10 h-10 bg-gradient-to-br from-futuristic-primary to-futuristic-primary-light rounded-xl flex items-center justify-center">
                    <Users className="h-5 w-5 text-white" />
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-futuristic-text-primary">{totalUsers.toLocaleString()}</div>
                  <div className="flex items-center space-x-2 mt-2">
                    <TrendingUp className="h-4 w-4 text-futuristic-success" />
                    <p className="text-xs text-futuristic-success">+{newUsersThisMonth} este mes</p>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-futuristic-surface border-futuristic-primary/10 hover:border-futuristic-primary/30 transition-all duration-300 hover:shadow-lg hover:shadow-futuristic-success/10">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-futuristic-text-secondary text-sm font-medium">
                    Profesores Registrados
                  </CardTitle>
                  <div className="w-10 h-10 bg-gradient-to-br from-futuristic-success to-futuristic-amber rounded-xl flex items-center justify-center">
                    <GraduationCap className="h-5 w-5 text-white" />
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-futuristic-text-primary">
                    {totalTeachers.toLocaleString()}
                  </div>
                  <div className="flex items-center space-x-2 mt-2">
                    <TrendingUp className="h-4 w-4 text-futuristic-success" />
                    <p className="text-xs text-futuristic-success">+23 este mes</p>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-futuristic-surface border-futuristic-primary/10 hover:border-futuristic-primary/30 transition-all duration-300 hover:shadow-lg hover:shadow-futuristic-primary/10">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-futuristic-text-secondary text-sm font-medium">Directores</CardTitle>
                  <div className="w-10 h-10 bg-gradient-to-br from-futuristic-primary to-futuristic-creative rounded-xl flex items-center justify-center">
                    <Crown className="h-5 w-5 text-white" />
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-futuristic-text-primary">{totalDirectors}</div>
                  <div className="flex items-center space-x-2 mt-2">
                    <CheckCircle className="h-4 w-4 text-futuristic-info" />
                    <p className="text-xs text-futuristic-info">1 por colegio</p>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-futuristic-surface border-futuristic-primary/10 hover:border-futuristic-primary/30 transition-all duration-300 hover:shadow-lg hover:shadow-futuristic-success/10">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-futuristic-text-secondary text-sm font-medium">Usuarios Activos</CardTitle>
                  <div className="w-10 h-10 bg-gradient-to-br from-futuristic-success to-futuristic-info rounded-xl flex items-center justify-center">
                    <UserCheck className="h-5 w-5 text-white" />
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-futuristic-text-primary">{activeUsers.toLocaleString()}</div>
                  <div className="flex items-center space-x-2 mt-2">
                    <Activity className="h-4 w-4 text-futuristic-success" />
                    <p className="text-xs text-futuristic-success">
                      {Math.round((activeUsers / totalUsers) * 100)}% del total
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Filtros */}
            <Card className="bg-futuristic-surface border-futuristic-primary/10">
              <CardHeader>
                <CardTitle className="text-futuristic-text-primary flex items-center gap-2">
                  <Filter className="w-5 h-5" />
                  Filtros de Búsqueda
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-futuristic-text-tertiary w-4 h-4" />
                    <Input
                      placeholder="Buscar por nombre o correo..."
                      value={filters.search}
                      onChange={(e) => setFilters({ ...filters, search: e.target.value })}
                      className="pl-10 bg-futuristic-background/50 border-futuristic-primary/20"
                    />
                  </div>
                  <Select
                    value={filters.school}
                    onValueChange={(value) => setFilters({ ...filters, school: value === "all" ? "" : value })}
                  >
                    <SelectTrigger className="bg-futuristic-background/50 border-futuristic-primary/20">
                      <SelectValue placeholder="Filtrar por Colegio" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos los Colegios</SelectItem>
                      {activeSchools.map((school) => (
                        <SelectItem key={school.id} value={school.id}>
                          {school.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Select
                    value={filters.role}
                    onValueChange={(value) => setFilters({ ...filters, role: value === "all" ? "" : value })}
                  >
                    <SelectTrigger className="bg-futuristic-background/50 border-futuristic-primary/20">
                      <SelectValue placeholder="Filtrar por Rol" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos los Roles</SelectItem>
                      {userRoles.map((role) => (
                        <SelectItem key={role.id} value={role.id}>
                          {role.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Select
                    value={filters.status}
                    onValueChange={(value) => setFilters({ ...filters, status: value === "all" ? "" : value })}
                  >
                    <SelectTrigger className="bg-futuristic-background/50 border-futuristic-primary/20">
                      <SelectValue placeholder="Filtrar por Estado" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos los Estados</SelectItem>
                      <SelectItem value="Activo">Activo</SelectItem>
                      <SelectItem value="Inactivo">Inactivo</SelectItem>
                      <SelectItem value="Pendiente">Pendiente</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button
                    variant="outline"
                    className="border-futuristic-primary/30 text-futuristic-primary hover:bg-futuristic-primary/5 bg-transparent"
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Exportar
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Tabla de usuarios */}
            <Card className="bg-futuristic-surface border-futuristic-primary/10">
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-futuristic-primary/10">
                        <th className="text-left p-4 text-futuristic-text-secondary font-medium">Usuario</th>
                        <th className="text-left p-4 text-futuristic-text-secondary font-medium">Correo</th>
                        <th className="text-left p-4 text-futuristic-text-secondary font-medium">Rol</th>
                        <th className="text-left p-4 text-futuristic-text-secondary font-medium">Colegio</th>
                        <th className="text-left p-4 text-futuristic-text-secondary font-medium">Estado</th>
                        <th className="text-left p-4 text-futuristic-text-secondary font-medium">Último Acceso</th>
                        <th className="text-left p-4 text-futuristic-text-secondary font-medium">Fecha Creación</th>
                        <th className="text-right p-4 text-futuristic-text-secondary font-medium">Acciones</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredUsers.map((user) => (
                        <tr
                          key={user.id}
                          className="border-b border-futuristic-primary/5 hover:bg-futuristic-primary/5 transition-colors"
                        >
                          <td className="p-4">
                            <div className="flex items-center space-x-3">
                              <Avatar className="h-10 w-10">
                                <AvatarImage src={user.avatar || "/placeholder.svg"} alt={user.name} />
                                <AvatarFallback className="bg-gradient-to-br from-futuristic-primary to-futuristic-creative text-white text-sm">
                                  {user.initials}
                                </AvatarFallback>
                              </Avatar>
                              <div>
                                <div className="text-futuristic-text-primary font-medium flex items-center gap-2">
                                  {user.name}
                                  {user.isAutoCreated && (
                                    <Badge className="bg-futuristic-info/10 text-futuristic-info border-futuristic-info/20 text-xs">
                                      Auto
                                    </Badge>
                                  )}
                                </div>
                                <div className="text-sm text-futuristic-text-secondary">{user.initials}</div>
                              </div>
                            </div>
                          </td>
                          <td className="p-4">
                            <div className="flex items-center gap-1 text-futuristic-text-primary">
                              <Mail className="w-4 h-4 text-futuristic-info" />
                              {user.email}
                            </div>
                          </td>
                          <td className="p-4">
                            <Badge className={getRoleColor(user.role)}>
                              {(() => {
                                const RoleIcon = getRoleConfig(user.role).icon
                                return RoleIcon ? <RoleIcon className="w-3 h-3 mr-1" /> : null
                              })()}
                              {getRoleConfig(user.role).name}
                            </Badge>
                          </td>
                          <td className="p-4">
                            <div className="flex items-center gap-1 text-futuristic-text-primary">
                              <Building className="w-4 h-4 text-futuristic-info" />
                              {user.school}
                            </div>
                          </td>
                          <td className="p-4">
                            <Badge className={getStatusColor(user.status)}>{user.status}</Badge>
                          </td>
                          <td className="p-4">
                            <div className="flex items-center gap-1 text-futuristic-text-primary">
                              <Clock className="w-4 h-4 text-futuristic-success" />
                              {user.lastAccess}
                            </div>
                          </td>
                          <td className="p-4">
                            <div className="flex items-center gap-1 text-futuristic-text-primary">
                              <Calendar className="w-4 h-4 text-futuristic-success" />
                              {user.createdAt}
                            </div>
                          </td>
                          <td className="p-4 text-right">
                            <div className="flex justify-end gap-2">
                              <Button
                                size="sm"
                                variant="ghost"
                                className="h-8 w-8 p-0 hover:bg-futuristic-info/10"
                                onClick={() => {
                                  setSelectedUser(user)
                                  setIsDetailDialogOpen(true)
                                }}
                              >
                                <Eye className="h-4 w-4 text-futuristic-info" />
                              </Button>
                              <Button
                                size="sm"
                                variant="ghost"
                                className="h-8 w-8 p-0 hover:bg-futuristic-primary/10"
                                onClick={() => {
                                  setSelectedUser(user)
                                  setFormData({
                                    name: user.name,
                                    email: user.email,
                                    phone: user.phone,
                                    school: user.schoolId,
                                    role: user.role,
                                    password: "",
                                    avatar: user.avatar,
                                    additionalFields: user.additionalInfo || {},
                                  })
                                  setIsEditDialogOpen(true)
                                }}
                              >
                                <Edit className="h-4 w-4 text-futuristic-primary" />
                              </Button>
                              <Button
                                size="sm"
                                variant="ghost"
                                className="h-8 w-8 p-0 hover:bg-futuristic-warning/10"
                                title="Restablecer contraseña"
                              >
                                <RefreshCw className="h-4 w-4 text-futuristic-warning" />
                              </Button>
                              <AlertDialog>
                                <AlertDialogTrigger asChild>
                                  <Button
                                    size="sm"
                                    variant="ghost"
                                    className="h-8 w-8 p-0 hover:bg-futuristic-error/10"
                                  >
                                    <Trash2 className="h-4 w-4 text-futuristic-error" />
                                  </Button>
                                </AlertDialogTrigger>
                                <AlertDialogContent className="bg-futuristic-surface border-futuristic-primary/20">
                                  <AlertDialogHeader>
                                    <AlertDialogTitle className="text-futuristic-text-primary">
                                      ¿Eliminar Usuario?
                                    </AlertDialogTitle>
                                    <AlertDialogDescription className="text-futuristic-text-secondary">
                                      Esta acción eliminará permanentemente al usuario "{user.name}" y todos sus datos
                                      asociados. Esta acción no se puede deshacer.
                                    </AlertDialogDescription>
                                  </AlertDialogHeader>
                                  <AlertDialogFooter>
                                    <AlertDialogCancel className="border-futuristic-primary/30">
                                      Cancelar
                                    </AlertDialogCancel>
                                    <AlertDialogAction className="bg-futuristic-error hover:bg-futuristic-error/80">
                                      Eliminar Usuario
                                    </AlertDialogAction>
                                  </AlertDialogFooter>
                                </AlertDialogContent>
                              </AlertDialog>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            {/* Métricas de analítica */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="bg-futuristic-surface border-futuristic-primary/10">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-futuristic-text-secondary text-sm font-medium">
                    Usuarios por Colegio
                  </CardTitle>
                  <Building className="h-4 w-4 text-futuristic-primary" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-futuristic-text-primary">
                    {Math.round(totalUsers / activeSchools.length)}
                  </div>
                  <p className="text-xs text-futuristic-success">Promedio por institución</p>
                </CardContent>
              </Card>

              <Card className="bg-futuristic-surface border-futuristic-primary/10">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-futuristic-text-secondary text-sm font-medium">
                    Tasa de Actividad
                  </CardTitle>
                  <Activity className="h-4 w-4 text-futuristic-success" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-futuristic-text-primary">
                    {Math.round((activeUsers / totalUsers) * 100)}%
                  </div>
                  <p className="text-xs text-futuristic-success">Usuarios activos</p>
                </CardContent>
              </Card>

              <Card className="bg-futuristic-surface border-futuristic-primary/10">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-futuristic-text-secondary text-sm font-medium">
                    Crecimiento Mensual
                  </CardTitle>
                  <TrendingUp className="h-4 w-4 text-futuristic-success" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-futuristic-text-primary">+{newUsersThisMonth}</div>
                  <p className="text-xs text-futuristic-success">Nuevos usuarios</p>
                </CardContent>
              </Card>

              <Card className="bg-futuristic-surface border-futuristic-primary/10">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-futuristic-text-secondary text-sm font-medium">Roles Diversos</CardTitle>
                  <Users className="h-4 w-4 text-futuristic-info" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-futuristic-text-primary">{userRoles.length}</div>
                  <p className="text-xs text-futuristic-info">Tipos de usuario</p>
                </CardContent>
              </Card>
            </div>

            {/* Distribuciones */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-futuristic-surface border-futuristic-primary/10">
                <CardHeader>
                  <CardTitle className="text-futuristic-text-primary flex items-center gap-2">
                    <PieChart className="w-5 h-5" />
                    Distribución por Roles
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {userRoles.map((role) => {
                      const count = usersData.filter((user) => user.role === role.id).length
                      const percentage = totalUsers > 0 ? Math.round((count / totalUsers) * 100) : 0
                      return (
                        <div key={role.id} className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <role.icon className={`w-4 h-4 text-futuristic-${role.color}`} />
                            <span className="text-futuristic-text-primary">{role.name}</span>
                          </div>
                          <div className="text-right">
                            <div className="text-futuristic-text-primary font-medium">{count} usuarios</div>
                            <div className="text-xs text-futuristic-text-secondary">{percentage}%</div>
                          </div>
                        </div>
                      )
                    })}
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-futuristic-surface border-futuristic-primary/10">
                <CardHeader>
                  <CardTitle className="text-futuristic-text-primary flex items-center gap-2">
                    <BarChart3 className="w-5 h-5" />
                    Usuarios por Colegio
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {activeSchools.map((school) => {
                      const count = usersData.filter((user) => user.schoolId === school.id).length
                      const percentage = totalUsers > 0 ? Math.round((count / totalUsers) * 100) : 0
                      return (
                        <div key={school.id} className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <Building className="w-4 h-4 text-futuristic-info" />
                            <span className="text-futuristic-text-primary">{school.name}</span>
                          </div>
                          <div className="text-right">
                            <div className="text-futuristic-text-primary font-medium">{count} usuarios</div>
                            <div className="text-xs text-futuristic-text-secondary">{percentage}%</div>
                          </div>
                        </div>
                      )
                    })}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Actividad y alertas */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-futuristic-surface border-futuristic-primary/10">
                <CardHeader>
                  <CardTitle className="text-futuristic-text-primary flex items-center gap-2">
                    <Activity className="w-5 h-5" />
                    Actividad Reciente
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-start gap-3 p-3 bg-futuristic-success/5 border border-futuristic-success/20 rounded-lg">
                      <UserPlus className="w-4 h-4 text-futuristic-success mt-0.5" />
                      <div>
                        <div className="text-futuristic-text-primary font-medium">Nuevos Usuarios</div>
                        <div className="text-xs text-futuristic-text-secondary">
                          {newUsersThisMonth} usuarios creados este mes
                        </div>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 p-3 bg-futuristic-info/5 border border-futuristic-info/20 rounded-lg">
                      <Activity className="w-4 h-4 text-futuristic-info mt-0.5" />
                      <div>
                        <div className="text-futuristic-text-primary font-medium">Usuarios Activos</div>
                        <div className="text-xs text-futuristic-text-secondary">
                          {activeUsers} usuarios han accedido esta semana
                        </div>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 p-3 bg-futuristic-primary/5 border border-futuristic-primary/20 rounded-lg">
                      <Crown className="w-4 h-4 text-futuristic-primary mt-0.5" />
                      <div>
                        <div className="text-futuristic-text-primary font-medium">Directores Automáticos</div>
                        <div className="text-xs text-futuristic-text-secondary">
                          {usersData.filter((u) => u.isAutoCreated).length} creados automáticamente
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-futuristic-surface border-futuristic-primary/10">
                <CardHeader>
                  <CardTitle className="text-futuristic-text-primary flex items-center gap-2">
                    <AlertTriangle className="w-5 h-5" />
                    Alertas del Sistema
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-start gap-3 p-3 bg-futuristic-warning/5 border border-futuristic-warning/20 rounded-lg">
                      <Clock className="w-4 h-4 text-futuristic-warning mt-0.5" />
                      <div>
                        <div className="text-futuristic-text-primary font-medium">Usuarios Inactivos</div>
                        <div className="text-xs text-futuristic-text-secondary">
                          {totalUsers - activeUsers} usuarios sin acceso reciente
                        </div>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 p-3 bg-futuristic-info/5 border border-futuristic-info/20 rounded-lg">
                      <Key className="w-4 h-4 text-futuristic-info mt-0.5" />
                      <div>
                        <div className="text-futuristic-text-primary font-medium">Contraseñas Pendientes</div>
                        <div className="text-xs text-futuristic-text-secondary">
                          Usuarios que deben cambiar contraseña inicial
                        </div>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 p-3 bg-futuristic-success/5 border border-futuristic-success/20 rounded-lg">
                      <CheckCircle className="w-4 h-4 text-futuristic-success mt-0.5" />
                      <div>
                        <div className="text-futuristic-text-primary font-medium">Sistema Saludable</div>
                        <div className="text-xs text-futuristic-text-secondary">
                          Todos los módulos funcionando correctamente
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        {/* Modal de Detalle del Usuario */}
        {selectedUser && isDetailDialogOpen && (
          <Dialog open={isDetailDialogOpen} onOpenChange={setIsDetailDialogOpen}>
            <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto bg-futuristic-surface border-futuristic-primary/20">
              <DialogHeader>
                <DialogTitle className="text-futuristic-text-primary flex items-center gap-3">
                  <Avatar className="h-12 w-12">
                    <AvatarImage src={selectedUser.avatar || "/placeholder.svg"} alt={selectedUser.name} />
                    <AvatarFallback className="bg-gradient-to-br from-futuristic-primary to-futuristic-creative text-white">
                      {selectedUser.initials}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="flex items-center gap-2">
                      {selectedUser.name}
                      {selectedUser.isAutoCreated && (
                        <Badge className="bg-futuristic-info/10 text-futuristic-info border-futuristic-info/20 text-xs">
                          Creado Automáticamente
                        </Badge>
                      )}
                    </div>
                    <div className="text-sm text-futuristic-text-secondary font-normal">
                      {getRoleConfig(selectedUser.role).name}
                    </div>
                  </div>
                </DialogTitle>
                <DialogDescription className="text-futuristic-text-secondary">
                  Perfil detallado del usuario
                </DialogDescription>
              </DialogHeader>

              <div className="space-y-6 py-4">
                {/* Información personal */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Card className="bg-futuristic-background/50 border-futuristic-primary/10">
                    <CardHeader>
                      <CardTitle className="text-futuristic-text-primary text-lg flex items-center gap-2">
                        <UserCheck className="w-5 h-5" />
                        Información Personal
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="flex items-center gap-2">
                        <Mail className="w-4 h-4 text-futuristic-info" />
                        <span className="text-futuristic-text-primary">{selectedUser.email}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Phone className="w-4 h-4 text-futuristic-info" />
                        <span className="text-futuristic-text-primary">{selectedUser.phone}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Building className="w-4 h-4 text-futuristic-success" />
                        <span className="text-futuristic-text-primary">{selectedUser.school}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4 text-futuristic-primary" />
                        <span className="text-futuristic-text-primary">Creado: {selectedUser.createdAt}</span>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="bg-futuristic-background/50 border-futuristic-primary/10">
                    <CardHeader>
                      <CardTitle className="text-futuristic-text-primary text-lg flex items-center gap-2">
                        <Activity className="w-5 h-5" />
                        Estado y Actividad
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-futuristic-text-secondary">Estado:</span>
                        <Badge className={getStatusColor(selectedUser.status)}>{selectedUser.status}</Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-futuristic-text-secondary">Rol:</span>
                        <Badge className={getRoleColor(selectedUser.role)}>
                          {(() => {
                            const RoleIcon = getRoleConfig(selectedUser.role).icon
                            return RoleIcon ? <RoleIcon className="w-3 h-3 mr-1" /> : null
                          })()}
                          {getRoleConfig(selectedUser.role).name}
                        </Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-futuristic-text-secondary">Último Acceso:</span>
                        <span className="text-futuristic-text-primary">{selectedUser.lastAccess}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-futuristic-text-secondary">Tipo de Creación:</span>
                        <span className="text-futuristic-text-primary">
                          {selectedUser.isAutoCreated ? "Automática" : "Manual"}
                        </span>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Información específica del rol */}
                {selectedUser.additionalInfo && Object.keys(selectedUser.additionalInfo).length > 0 && (
                  <Card className="bg-futuristic-background/50 border-futuristic-primary/10">
                    <CardHeader>
                      <CardTitle className="text-futuristic-text-primary text-lg flex items-center gap-2">
                        <Settings className="w-5 h-5" />
                        Información Específica del Rol
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {Object.entries(selectedUser.additionalInfo).map(([key, value]) => (
                          <div key={key} className="flex items-center justify-between">
                            <span className="text-futuristic-text-secondary capitalize">{key.replace("_", " ")}:</span>
                            <span className="text-futuristic-text-primary">{value}</span>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )}

                {/* Permisos y accesos */}
                <Card className="bg-futuristic-background/50 border-futuristic-primary/10">
                  <CardHeader>
                    <CardTitle className="text-futuristic-text-primary text-lg flex items-center gap-2">
                      <Shield className="w-5 h-5" />
                      Permisos y Accesos
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div>
                        <h4 className="font-medium text-futuristic-text-primary mb-2">Módulos Disponibles:</h4>
                        <div className="flex flex-wrap gap-2">
                          {getRoleConfig(selectedUser.role).permissions.map((permission, index) => (
                            <Badge
                              key={index}
                              className="bg-futuristic-success/10 text-futuristic-success border-futuristic-success/20"
                            >
                              <CheckCircle className="w-3 h-3 mr-1" />
                              {permission.replace("_", " ")}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Historial de actividad */}
                <Card className="bg-futuristic-background/50 border-futuristic-primary/10">
                  <CardHeader>
                    <CardTitle className="text-futuristic-text-primary text-lg flex items-center gap-2">
                      <Clock className="w-5 h-5" />
                      Historial de Actividad
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex items-start gap-3 p-3 bg-futuristic-success/5 border border-futuristic-success/20 rounded-lg">
                        <CheckCircle className="w-4 h-4 text-futuristic-success mt-0.5" />
                        <div>
                          <div className="text-futuristic-text-primary font-medium">Último acceso exitoso</div>
                          <div className="text-xs text-futuristic-text-secondary">{selectedUser.lastAccess}</div>
                        </div>
                      </div>
                      <div className="flex items-start gap-3 p-3 bg-futuristic-info/5 border border-futuristic-info/20 rounded-lg">
                        <UserPlus className="w-4 h-4 text-futuristic-info mt-0.5" />
                        <div>
                          <div className="text-futuristic-text-primary font-medium">Usuario creado</div>
                          <div className="text-xs text-futuristic-text-secondary">
                            {selectedUser.createdAt} - {selectedUser.isAutoCreated ? "Automáticamente" : "Manualmente"}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-start gap-3 p-3 bg-futuristic-primary/5 border border-futuristic-primary/20 rounded-lg">
                        <Activity className="w-4 h-4 text-futuristic-primary mt-0.5" />
                        <div>
                          <div className="text-futuristic-text-primary font-medium">Actividad reciente</div>
                          <div className="text-xs text-futuristic-text-secondary">
                            Usuario activo en los últimos 7 días
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        )}
      </main>
    </div>
  )
}
