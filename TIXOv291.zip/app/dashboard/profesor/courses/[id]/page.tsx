"use client"

import { useState } from "react"
import { Header } from "@/components/dashboard/header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Calendar } from "@/components/ui/calendar"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Users, CalendarIcon, ClipboardCheck, BarChart3, ArrowLeft, Eye, Save, Send, Download, CheckCircle, XCircle, Clock, MessageSquare, AlertCircle, Target, Brain } from 'lucide-react'
import Link from "next/link"
import { format } from "date-fns"
import { es } from "date-fns/locale"

// Datos de ejemplo del curso
const courseData = {
  id: "1",
  name: "1° A Primaria - Matemáticas",
  grade: "1° A",
  level: "Primaria",
  subject: "Matemáticas",
  students: 24,
  status: "Activo",
  classroom: "Aula 101",
  schedule: "Lunes y Miércoles, 8:00 - 9:30",
}

// Datos de ejemplo de estudiantes
const studentsData = [
  {
    id: 1,
    name: "Ana María García López",
    photo: "/placeholder.svg?height=40&width=40&text=Ana",
    status: "Activo",
    attendanceRate: 95,
    currentAverage: 85,
  },
  {
    id: 2,
    name: "Carlos Mendoza Ruiz",
    photo: "/placeholder.svg?height=40&width=40&text=Carlos",
    status: "Activo",
    attendanceRate: 88,
    currentAverage: 72,
  },
  {
    id: 3,
    name: "María López Torres",
    photo: "/placeholder.svg?height=40&width=40&text=María",
    status: "Activo",
    attendanceRate: 92,
    currentAverage: 90,
  },
  {
    id: 4,
    name: "José Rodríguez Silva",
    photo: "/placeholder.svg?height=40&width=40&text=José",
    status: "Activo",
    attendanceRate: 85,
    currentAverage: 68,
  },
  {
    id: 5,
    name: "Laura Martínez Pérez",
    photo: "/placeholder.svg?height=40&width=40&text=Laura",
    status: "Activo",
    attendanceRate: 98,
    currentAverage: 88,
  },
]

// Datos de ejemplo de asistencia histórica
const attendanceHistory = [
  { date: "2024-01-15", studentId: 1, status: "Presente", comment: "" },
  { date: "2024-01-15", studentId: 2, status: "Ausente", comment: "Cita médica" },
  { date: "2024-01-15", studentId: 3, status: "Presente", comment: "" },
  { date: "2024-01-16", studentId: 1, status: "Presente", comment: "" },
  { date: "2024-01-16", studentId: 2, status: "Justificado", comment: "Enfermedad" },
]

export default function CourseDetailPage({ params }: { params: { id: string } }) {
  const [selectedDate, setSelectedDate] = useState<Date>(new Date())
  const [attendance, setAttendance] = useState<Record<number, { status: string; comment: string }>>({})
  const [grades, setGrades] = useState<Record<number, { grade: number; comment: string }>>({})
  const [selectedPeriod, setSelectedPeriod] = useState("")
  const [selectedEvalType, setSelectedEvalType] = useState("")
  const [attendanceFilter, setAttendanceFilter] = useState({
    student: "all",
    status: "all",
    dateRange: { start: "", end: "" },
  })

  // Verificar si ya existe asistencia para la fecha seleccionada
  const hasAttendanceForDate = (date: Date) => {
    const dateStr = format(date, "yyyy-MM-dd")
    return attendanceHistory.some((record) => record.date === dateStr)
  }

  // Manejar cambio de asistencia
  const handleAttendanceChange = (studentId: number, status: string, comment = "") => {
    setAttendance((prev) => ({
      ...prev,
      [studentId]: { status, comment },
    }))
  }

  // Manejar cambio de calificaciones
  const handleGradeChange = (studentId: number, grade: string, comment = "") => {
    setGrades((prev) => ({
      ...prev,
      [studentId]: { grade: Number.parseInt(grade) || 0, comment },
    }))
  }

  // Guardar asistencia
  const saveAttendance = () => {
    const dateStr = format(selectedDate, "yyyy-MM-dd")
    console.log("Guardando asistencia para:", dateStr, attendance)
    // Aquí iría la lógica para guardar en la base de datos
    alert("Asistencia guardada correctamente")
  }

  // Filtrar historial de asistencia
  const filteredAttendanceHistory = attendanceHistory.filter((record) => {
    const matchesStudent =
      attendanceFilter.student === "all" || record.studentId.toString() === attendanceFilter.student
    const matchesStatus = attendanceFilter.status === "all" || record.status === attendanceFilter.status
    return matchesStudent && matchesStatus
  })

  return (
    <div className="flex-1 flex flex-col bg-gray-50">
      <Header title={courseData.name} />

      <main className="flex-1 overflow-y-auto p-6">
        {/* Botón de regreso */}
        <div className="mb-6">
          <Link href="/dashboard/profesor/courses">
            <Button variant="outline" className="border-gray-300 text-gray-700 hover:bg-gray-50 bg-transparent">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Volver a Mis Cursos
            </Button>
          </Link>
        </div>

        {/* Información del curso */}
        <Card className="bg-white border border-gray-200 mb-6">
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-indigo-100 rounded-full flex items-center justify-center">
                  <Users className="h-6 w-6 text-indigo-600" />
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-600">Estudiantes</p>
                  <p className="text-xl font-bold text-gray-900">{courseData.students}</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                  <CalendarIcon className="h-6 w-6 text-green-600" />
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-600">Horario</p>
                  <p className="text-sm text-gray-900">{courseData.schedule}</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                  <ClipboardCheck className="h-6 w-6 text-blue-600" />
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-600">Aula</p>
                  <p className="text-sm text-gray-900">{courseData.classroom}</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <Badge
                  className={
                    courseData.status === "Activo"
                      ? "bg-green-100 text-green-800 border-green-200"
                      : "bg-gray-100 text-gray-600 border-gray-200"
                  }
                >
                  {courseData.status}
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Pestañas del curso */}
        <Tabs defaultValue="students" className="w-full">
          <TabsList className="grid w-full grid-cols-4 bg-white border border-gray-200">
            <TabsTrigger value="students" className="data-[state=active]:bg-indigo-600 data-[state=active]:text-white">
              <Users className="h-4 w-4 mr-2" />
              Estudiantes
            </TabsTrigger>
            <TabsTrigger
              value="attendance"
              className="data-[state=active]:bg-indigo-600 data-[state=active]:text-white"
            >
              <CalendarIcon className="h-4 w-4 mr-2" />
              Asistencia
            </TabsTrigger>
            <TabsTrigger
              value="grades"
              className="data-[state=active]:bg-indigo-600 data-[state=active]:text-white"
            >
              <ClipboardCheck className="h-4 w-4 mr-2" />
              Calificaciones
            </TabsTrigger>
            <TabsTrigger value="history" className="data-[state=active]:bg-indigo-600 data-[state=active]:text-white">
              <BarChart3 className="h-4 w-4 mr-2" />
              Historial
            </TabsTrigger>
          </TabsList>

          {/* 1. Pestaña de Estudiantes */}
          <TabsContent value="students" className="mt-6">
            <Card className="bg-white border border-gray-200">
              <CardHeader>
                <CardTitle className="text-gray-900 flex items-center">
                  <Users className="h-5 w-5 mr-2 text-indigo-600" />
                  Lista de Estudiantes
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {studentsData.map((student) => (
                    <div
                      key={student.id}
                      className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
                    >
                      <div className="flex items-center space-x-4">
                        <Avatar className="w-12 h-12">
                          <AvatarImage src={student.photo || "/placeholder.svg"} alt={student.name} />
                          <AvatarFallback className="bg-indigo-100 text-indigo-600 font-semibold">
                            {student.name
                              .split(" ")
                              .map((n) => n[0])
                              .join("")
                              .slice(0, 2)}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <h4 className="font-medium text-gray-900">{student.name}</h4>
                          <div className="flex items-center space-x-4 mt-1">
                            <Badge
                              className={
                                student.status === "Activo"
                                  ? "bg-green-100 text-green-800 border-green-200"
                                  : "bg-red-100 text-red-800 border-red-200"
                              }
                            >
                              {student.status}
                            </Badge>
                            <span className="text-sm text-gray-600">Asistencia: {student.attendanceRate}%</span>
                            <span className="text-sm text-gray-600">Promedio: {student.currentAverage}</span>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <div className="w-20 bg-gray-200 rounded-full h-2">
                          <div
                            className={`h-2 rounded-full ${
                              student.attendanceRate >= 90
                                ? "bg-green-500"
                                : student.attendanceRate >= 80
                                  ? "bg-yellow-500"
                                  : "bg-red-500"
                            }`}
                            style={{ width: `${student.attendanceRate}%` }}
                          ></div>
                        </div>
                        <Link href={`/dashboard/profesor/history?student=${student.id}`}>
                          <Button size="sm" className="bg-indigo-600 hover:bg-indigo-700 text-white">
                            <Eye className="h-3 w-3 mr-1" />
                            Ver Detalle
                          </Button>
                        </Link>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* 2. Pestaña de Asistencia */}
          <TabsContent value="attendance" className="mt-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Selector de fecha */}
              <Card className="bg-white border border-gray-200">
                <CardHeader>
                  <CardTitle className="text-gray-900 flex items-center">
                    <CalendarIcon className="h-5 w-5 mr-2 text-green-600" />
                    Seleccionar Fecha
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <Calendar
                    mode="single"
                    selected={selectedDate}
                    onSelect={(date) => date && setSelectedDate(date)}
                    locale={es}
                    className="rounded-md border border-gray-200"
                  />
                  <div className="mt-4 p-3 bg-blue-50 rounded-lg border border-blue-200">
                    <p className="text-sm font-medium text-blue-800">Fecha seleccionada:</p>
                    <p className="text-sm text-blue-600">
                      {format(selectedDate, "dd 'de' MMMM 'de' yyyy", { locale: es })}
                    </p>
                    {hasAttendanceForDate(selectedDate) && (
                      <div className="mt-2 flex items-center text-yellow-600">
                        <AlertCircle className="h-4 w-4 mr-1" />
                        <span className="text-xs">Ya existe asistencia para este día</span>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Registro de asistencia */}
              <div className="lg:col-span-2">
                <Card className="bg-white border border-gray-200">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-gray-900 flex items-center">
                        <CheckCircle className="h-5 w-5 mr-2 text-green-600" />
                        Registrar Asistencia
                      </CardTitle>
                      <Button onClick={saveAttendance} className="bg-green-600 hover:bg-green-700 text-white">
                        <Save className="h-4 w-4 mr-2" />
                        Guardar Asistencia
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {studentsData.map((student) => (
                        <div
                          key={student.id}
                          className="flex items-center justify-between p-4 border border-gray-200 rounded-lg"
                        >
                          <div className="flex items-center space-x-3">
                            <Avatar className="w-10 h-10">
                              <AvatarImage src={student.photo || "/placeholder.svg"} alt={student.name} />
                              <AvatarFallback className="bg-indigo-100 text-indigo-600 text-sm">
                                {student.name
                                  .split(" ")
                                  .map((n) => n[0])
                                  .join("")
                                  .slice(0, 2)}
                              </AvatarFallback>
                            </Avatar>
                            <span className="font-medium text-gray-900">{student.name}</span>
                          </div>
                          <div className="flex items-center space-x-4">
                            <div className="flex space-x-2">
                              <Button
                                size="sm"
                                variant={attendance[student.id]?.status === "Presente" ? "default" : "outline"}
                                onClick={() => handleAttendanceChange(student.id, "Presente")}
                                className={
                                  attendance[student.id]?.status === "Presente"
                                    ? "bg-green-600 hover:bg-green-700 text-white"
                                    : "border-green-300 text-green-700 hover:bg-green-50"
                                }
                              >
                                <CheckCircle className="h-3 w-3 mr-1" />
                                Presente
                              </Button>
                              <Button
                                size="sm"
                                variant={attendance[student.id]?.status === "Ausente" ? "default" : "outline"}
                                onClick={() => handleAttendanceChange(student.id, "Ausente")}
                                className={
                                  attendance[student.id]?.status === "Ausente"
                                    ? "bg-red-600 hover:bg-red-700 text-white"
                                    : "border-red-300 text-red-700 hover:bg-red-50"
                                }
                              >
                                <XCircle className="h-3 w-3 mr-1" />
                                Ausente
                              </Button>
                              <Button
                                size="sm"
                                variant={attendance[student.id]?.status === "Justificado" ? "default" : "outline"}
                                onClick={() => handleAttendanceChange(student.id, "Justificado")}
                                className={
                                  attendance[student.id]?.status === "Justificado"
                                    ? "bg-yellow-600 hover:bg-yellow-700 text-white"
                                    : "border-yellow-300 text-yellow-700 hover:bg-yellow-50"
                                }
                              >
                                <Clock className="h-3 w-3 mr-1" />
                                Justificado
                              </Button>
                            </div>
                            <Dialog>
                              <DialogTrigger asChild>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="border-gray-300 text-gray-700 bg-transparent"
                                >
                                  <MessageSquare className="h-3 w-3 mr-1" />
                                  Comentario
                                </Button>
                              </DialogTrigger>
                              <DialogContent>
                                <DialogHeader>
                                  <DialogTitle>Agregar Comentario</DialogTitle>
                                  <DialogDescription>Comentario para {student.name}</DialogDescription>
                                </DialogHeader>
                                <div className="space-y-4 mt-4">
                                  <Textarea
                                    placeholder="Escribir comentario..."
                                    value={attendance[student.id]?.comment || ""}
                                    onChange={(e) =>
                                      handleAttendanceChange(
                                        student.id,
                                        attendance[student.id]?.status || "Presente",
                                        e.target.value,
                                      )
                                    }
                                    className="border-gray-300"
                                  />
                                  <div className="flex justify-end">
                                    <Button className="bg-indigo-600 hover:bg-indigo-700 text-white">Guardar</Button>
                                  </div>
                                </div>
                              </DialogContent>
                            </Dialog>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          {/* 3. Pestaña de Calificaciones */}
          <TabsContent value="grades" className="mt-6">
            {
              // Flujo completo de calificaciones por competencias (similar al módulo de calificaciones)
              <div className="space-y-6">
                {/* Selector de período */}
                <Card className="bg-white border border-gray-200">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-gray-900 flex items-center">
                        <Target className="h-5 w-5 mr-2 text-blue-600" />
                        Calificaciones por Competencias - {courseData.name}
                      </CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                      <div>
                        <Label htmlFor="period" className="text-sm font-medium text-gray-700">
                          Período Académico
                        </Label>
                        <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
                          <SelectTrigger className="border-gray-300">
                            <SelectValue placeholder="Seleccionar período" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="P1">Primer Período (P1)</SelectItem>
                            <SelectItem value="P2">Segundo Período (P2)</SelectItem>
                            <SelectItem value="P3">Tercer Período (P3)</SelectItem>
                            <SelectItem value="P4">Cuarto Período (P4)</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor="competencia" className="text-sm font-medium text-gray-700">
                          Competencia MINERD
                        </Label>
                        <Select value={selectedEvalType} onValueChange={setSelectedEvalType}>
                          <SelectTrigger className="border-gray-300">
                            <SelectValue placeholder="Seleccionar competencia" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="comunicativa">Comunicativa</SelectItem>
                            <SelectItem value="pensamiento">Pensamiento Lógico y Crítico</SelectItem>
                            <SelectItem value="cientifica">Científica y Tecnológica</SelectItem>
                            <SelectItem value="ambiental">Ambiental y de la Salud</SelectItem>
                            <SelectItem value="etica">Ética y Ciudadana</SelectItem>
                            <SelectItem value="personal">Desarrollo Personal</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    {/* Competencias del MINERD */}
                    {selectedPeriod && selectedEvalType && (
                      <div className="space-y-6">
                        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                          <h3 className="font-semibold text-blue-900 mb-2">
                            Sistema de Calificación por Competencias MINERD
                          </h3>
                          <p className="text-sm text-blue-700">
                            Evaluación integral basada en las 6 competencias fundamentales del currículo dominicano.
                            Cada competencia se evalúa de 0 a 100 puntos.
                          </p>
                        </div>

                        {/* Tabla de calificaciones por competencias */}
                        <Card className="bg-white border border-gray-200">
                          <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                              <Brain className="h-5 w-5 text-purple-600" />
                              Calificaciones - {selectedEvalType.charAt(0).toUpperCase() + selectedEvalType.slice(1)}
                            </CardTitle>
                          </CardHeader>
                          <CardContent>
                            <div className="space-y-4">
                              {studentsData.map((student) => (
                                <div
                                  key={student.id}
                                  className="flex items-center justify-between p-4 border border-gray-200 rounded-lg"
                                >
                                  <div className="flex items-center space-x-3">
                                    <Avatar className="w-10 h-10">
                                      <AvatarImage src={student.photo || "/placeholder.svg"} alt={student.name} />
                                      <AvatarFallback className="bg-indigo-100 text-indigo-600 text-sm">
                                        {student.name
                                          .split(" ")
                                          .map((n) => n[0])
                                          .join("")
                                          .slice(0, 2)}
                                      </AvatarFallback>
                                    </Avatar>
                                    <div>
                                      <span className="font-medium text-gray-900">{student.name}</span>
                                      <p className="text-sm text-gray-500">
                                        Promedio general: {student.currentAverage}
                                      </p>
                                    </div>
                                  </div>
                                  <div className="flex items-center space-x-4">
                                    <div className="grid grid-cols-3 gap-2">
                                      <div className="text-center">
                                        <Label className="text-xs text-gray-600">Actividad 1</Label>
                                        <Input
                                          type="number"
                                          min="0"
                                          max="100"
                                          placeholder="0-100"
                                          className="w-16 h-8 text-xs text-center border-gray-300"
                                        />
                                      </div>
                                      <div className="text-center">
                                        <Label className="text-xs text-gray-600">Actividad 2</Label>
                                        <Input
                                          type="number"
                                          min="0"
                                          max="100"
                                          placeholder="0-100"
                                          className="w-16 h-8 text-xs text-center border-gray-300"
                                        />
                                      </div>
                                      <div className="text-center">
                                        <Label className="text-xs text-gray-600">Actividad 3</Label>
                                        <Input
                                          type="number"
                                          min="0"
                                          max="100"
                                          placeholder="0-100"
                                          className="w-16 h-8 text-xs text-center border-gray-300"
                                        />
                                      </div>
                                    </div>
                                    <div className="text-center">
                                      <Label className="text-xs text-gray-600">Promedio</Label>
                                      <Badge className="bg-blue-100 text-blue-800 mt-1">
                                        {Math.round(Math.random() * 30 + 70)}
                                      </Badge>
                                    </div>
                                    <Dialog>
                                      <DialogTrigger asChild>
                                        <Button
                                          size="sm"
                                          variant="outline"
                                          className="border-gray-300 text-gray-700 bg-transparent"
                                        >
                                          <MessageSquare className="h-3 w-3 mr-1" />
                                          Observación
                                        </Button>
                                      </DialogTrigger>
                                      <DialogContent>
                                        <DialogHeader>
                                          <DialogTitle>Observación - {selectedEvalType}</DialogTitle>
                                          <DialogDescription>Comentario para {student.name}</DialogDescription>
                                        </DialogHeader>
                                        <div className="space-y-4 mt-4">
                                          <Textarea
                                            placeholder="Escribir observación sobre el desempeño en esta competencia..."
                                            className="border-gray-300"
                                          />
                                          <div className="flex justify-end">
                                            <Button className="bg-indigo-600 hover:bg-indigo-700 text-white">
                                              Guardar
                                            </Button>
                                          </div>
                                        </div>
                                      </DialogContent>
                                    </Dialog>
                                  </div>
                                </div>
                              ))}
                            </div>

                            <div className="flex justify-end space-x-2 mt-6">
                              <Button
                                variant="outline"
                                className="border-gray-300 text-gray-700 hover:bg-gray-50 bg-transparent"
                              >
                                <Save className="h-4 w-4 mr-2" />
                                Guardar Borrador
                              </Button>
                              <Button className="bg-green-600 hover:bg-green-700 text-white">
                                <Send className="h-4 w-4 mr-2" />
                                Enviar al Coordinador
                              </Button>
                            </div>
                          </CardContent>
                        </Card>

                        {/* Resumen de competencias */}
                        <Card className="bg-gradient-to-r from-purple-50 to-blue-50 border border-purple-200">
                          <CardHeader>
                            <CardTitle className="flex items-center gap-2 text-purple-800">
                              <BarChart3 className="h-5 w-5" />
                              Resumen del Período {selectedPeriod}
                            </CardTitle>
                          </CardHeader>
                          <CardContent>
                            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                              <div className="text-center">
                                <div className="text-2xl font-bold text-purple-600">{studentsData.length}</div>
                                <div className="text-sm text-purple-700">Estudiantes</div>
                              </div>
                              <div className="text-center">
                                <div className="text-2xl font-bold text-green-600">
                                  {Math.round(
                                    (studentsData.filter((s) => s.currentAverage >= 80).length / studentsData.length) *
                                      100,
                                  )}
                                  %
                                </div>
                                <div className="text-sm text-green-700">Aprobados</div>
                              </div>
                              <div className="text-center">
                                <div className="text-2xl font-bold text-blue-600">
                                  {Math.round(
                                    studentsData.reduce((sum, s) => sum + s.currentAverage, 0) / studentsData.length,
                                  )}
                                </div>
                                <div className="text-sm text-blue-700">Promedio General</div>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      </div>
                    )}

                    {(!selectedPeriod || !selectedEvalType) && (
                      <div className="text-center py-12">
                        <Target className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                        <h3 className="text-lg font-medium text-gray-900 mb-2">Selecciona período y competencia</h3>
                        <p className="text-gray-500">Elige los filtros para comenzar a calificar por competencias</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            }
          </TabsContent>

          {/* 4. Pestaña de Historial */}
          <TabsContent value="history" className="mt-6">
            <Card className="bg-white border border-gray-200">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-gray-900 flex items-center">
                    <BarChart3 className="h-5 w-5 mr-2 text-purple-600" />
                    Historial de Asistencia
                  </CardTitle>
                  <Button variant="outline" className="border-gray-300 text-gray-700 hover:bg-gray-50 bg-transparent">
                    <Download className="h-4 w-4 mr-2" />
                    Exportar PDF/CSV
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {/* Filtros */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                  <div>
                    <Label htmlFor="studentFilter" className="text-sm font-medium text-gray-700">
                      Estudiante
                    </Label>
                    <Select
                      value={attendanceFilter.student}
                      onValueChange={(value) => setAttendanceFilter((prev) => ({ ...prev, student: value }))}
                    >
                      <SelectTrigger className="border-gray-300">
                        <SelectValue placeholder="Seleccionar estudiante" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Todos los estudiantes</SelectItem>
                        {studentsData.map((student) => (
                          <SelectItem key={student.id} value={student.id.toString()}>
                            {student.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="statusFilter" className="text-sm font-medium text-gray-700">
                      Estado
                    </Label>
                    <Select
                      value={attendanceFilter.status}
                      onValueChange={(value) => setAttendanceFilter((prev) => ({ ...prev, status: value }))}
                    >
                      <SelectTrigger className="border-gray-300">
                        <SelectValue placeholder="Filtrar por estado" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Todos los estados</SelectItem>
                        <SelectItem value="Presente">Presente</SelectItem>
                        <SelectItem value="Ausente">Ausente</SelectItem>
                        <SelectItem value="Justificado">Justificado</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-700">Rango de Fechas</Label>
                    <div className="flex space-x-2">
                      <Input
                        type="date"
                        value={attendanceFilter.dateRange.start}
                        onChange={(e) =>
                          setAttendanceFilter((prev) => ({
                            ...prev,
                            dateRange: { ...prev.dateRange, start: e.target.value },
                          }))
                        }
                        className="border-gray-300"
                      />
                      <Input
                        type="date"
                        value={attendanceFilter.dateRange.end}
                        onChange={(e) =>
                          setAttendanceFilter((prev) => ({
                            ...prev,
                            dateRange: { ...prev.dateRange, end: e.target.value },
                          }))
                        }
                        className="border-gray-300"
                      />
                    </div>
                  </div>
                </div>

                {/* Tabla de historial */}
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="text-gray-700">Fecha</TableHead>
                        <TableHead className="text-gray-700">Estudiante</TableHead>
                        <TableHead className="text-gray-700">Estado</TableHead>
                        <TableHead className="text-gray-700">Comentario</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredAttendanceHistory.map((record, index) => {
                        const student = studentsData.find((s) => s.id === record.studentId)
                        return (
                          <TableRow key={index}>
                            <TableCell className="text-gray-900">{record.date}</TableCell>
                            <TableCell className="text-gray-900">{student?.name}</TableCell>
                            <TableCell>
                              <Badge
                                className={
                                  record.status === "Presente"
                                    ? "bg-green-100 text-green-800 border-green-200"
                                    : record.status === "Ausente"
                                      ? "bg-red-100 text-red-800 border-red-200"
                                      : "bg-yellow-100 text-yellow-800 border-yellow-200"
                                }
                              >
                                {record.status === "Presente" && <CheckCircle className="h-3 w-3 mr-1" />}
                                {record.status === "Ausente" && <XCircle className="h-3 w-3 mr-1" />}
                                {record.status === "Justificado" && <Clock className="h-3 w-3 mr-1" />}
                                {record.status}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-gray-600 text-sm">{record.comment || "-"}</TableCell>
                          </TableRow>
                        )
                      })}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Notificación automática */}
        <Card className="bg-blue-50 border border-blue-200 mt-6">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <MessageSquare className="h-5 w-5 text-blue-600" />
              <div className="flex-1">
                <p className="text-sm font-medium text-blue-800">Notificaciones Automáticas Activas</p>
                <p className="text-xs text-blue-600">
                  Cada acción realizada (asistencia, calificación, comentario) enviará automáticamente una notificación
                  al padre vía WhatsApp.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
