"use client"

import { Header } from "@/components/dashboard/header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import {
  BookOpen,
  Users,
  Calendar,
  Search,
  Eye,
  CheckCircle,
  AlertCircle,
  GraduationCap,
  BarChart3,
} from "lucide-react"
import Link from "next/link"
import { useState } from "react"

// Datos del curso encargado (asignado por coordinador académico)
const courseInCharge = {
  id: "course_in_charge_1",
  name: "5to C",
  grade: "5to",
  level: "Primaria",
  section: "C",
  turn: "Tarde",
  capacity: 25,
  studentsCount: 23,
  classroom: "Aula 203",
  schedule: "Lunes a Viernes, 1:00 - 5:00 PM",
  subjects: [
    { name: "Matemáticas", teacher: "Ana Rodríguez", average: 82 },
    { name: "Lengua Española", teacher: "Carlos Mendoza", average: 78 },
    { name: "Ciencias Naturales", teacher: "María González", average: 85 },
    { name: "Ciencias Sociales", teacher: "Luis Pérez", average: 80 },
    { name: "Educación Física", teacher: "Roberto Silva", average: 90 },
  ],
  students: [
    {
      id: 1,
      name: "Ana María García López",
      overallAverage: 85,
      subjects: {
        Matemáticas: 88,
        "Lengua Española": 82,
        "Ciencias Naturales": 90,
        "Ciencias Sociales": 85,
        "Educación Física": 95,
      },
    },
    {
      id: 2,
      name: "Carlos Mendoza Ruiz",
      overallAverage: 78,
      subjects: {
        Matemáticas: 75,
        "Lengua Española": 80,
        "Ciencias Naturales": 82,
        "Ciencias Sociales": 76,
        "Educación Física": 85,
      },
    },
    {
      id: 3,
      name: "María López Torres",
      overallAverage: 92,
      subjects: {
        Matemáticas: 95,
        "Lengua Española": 90,
        "Ciencias Naturales": 94,
        "Ciencias Sociales": 88,
        "Educación Física": 93,
      },
    },
    {
      id: 4,
      name: "José Rodríguez Silva",
      overallAverage: 72,
      subjects: {
        Matemáticas: 70,
        "Lengua Española": 75,
        "Ciencias Naturales": 68,
        "Ciencias Sociales": 74,
        "Educación Física": 83,
      },
    },
    {
      id: 5,
      name: "Laura Martínez Pérez",
      overallAverage: 88,
      subjects: {
        Matemáticas: 90,
        "Lengua Española": 85,
        "Ciencias Naturales": 92,
        "Ciencias Sociales": 86,
        "Educación Física": 87,
      },
    },
  ],
}

const courses = [
  {
    id: 1,
    grade: "1° A",
    level: "Primaria",
    subject: "Matemáticas",
    students: 24,
    schedule: "Lunes y Miércoles, 8:00 - 9:30",
    classroom: "Aula 101",
    pendingGrades: false,
    pendingAttendance: true,
    attendanceRate: 95,
    averageGrade: 85,
  },
  {
    id: 2,
    grade: "1° B",
    level: "Primaria",
    subject: "Matemáticas",
    students: 22,
    schedule: "Lunes y Miércoles, 10:00 - 11:30",
    classroom: "Aula 102",
    pendingGrades: true,
    pendingAttendance: false,
    attendanceRate: 88,
    averageGrade: 72,
  },
  {
    id: 3,
    grade: "2° A",
    level: "Primaria",
    subject: "Matemáticas",
    students: 20,
    schedule: "Martes y Jueves, 8:00 - 9:30",
    classroom: "Aula 201",
    pendingGrades: false,
    pendingAttendance: false,
    attendanceRate: 92,
    averageGrade: 88,
  },
  {
    id: 4,
    grade: "2° B",
    level: "Primaria",
    subject: "Matemáticas",
    students: 21,
    schedule: "Martes y Jueves, 10:00 - 11:30",
    classroom: "Aula 202",
    pendingGrades: true,
    pendingAttendance: true,
    attendanceRate: 90,
    averageGrade: 65,
  },
]

export default function MisCursosPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedStudentDetail, setSelectedStudentDetail] = useState(null)
  const [showDetailModal, setShowDetailModal] = useState(false)
  const [showActivityDetailModal, setShowActivityDetailModal] = useState(false)
  const [selectedCompetenciaDetail, setSelectedCompetenciaDetail] = useState(null)

  const filteredCourses = courses.filter(
    (course) =>
      course.grade.toLowerCase().includes(searchTerm.toLowerCase()) ||
      course.subject.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  return (
    <div className="flex-1 flex flex-col bg-gray-50">
      <Header title="Mis Cursos" />

      <main className="flex-1 overflow-y-auto p-6">
        {/* Estadísticas Generales */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-white border border-gray-200">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Cursos</p>
                  <p className="text-3xl font-bold text-gray-900">{courses.length}</p>
                </div>
                <div className="w-12 h-12 bg-indigo-100 rounded-full flex items-center justify-center">
                  <BookOpen className="h-6 w-6 text-indigo-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white border border-gray-200">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Estudiantes</p>
                  <p className="text-3xl font-bold text-gray-900">
                    {courses.reduce((sum, course) => sum + course.students, 0)}
                  </p>
                </div>
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                  <Users className="h-6 w-6 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white border border-gray-200">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Asistencia Promedio</p>
                  <p className="text-3xl font-bold text-gray-900">
                    {Math.round(courses.reduce((sum, course) => sum + course.attendanceRate, 0) / courses.length)}%
                  </p>
                </div>
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                  <CheckCircle className="h-6 w-6 text-green-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white border border-gray-200">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Tareas Pendientes</p>
                  <p className="text-3xl font-bold text-gray-900">
                    {courses.filter((c) => c.pendingGrades || c.pendingAttendance).length}
                  </p>
                </div>
                <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center">
                  <AlertCircle className="h-6 w-6 text-yellow-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Curso Encargado - Sección Especial */}
        {courseInCharge && (
          <div className="mb-8">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                <GraduationCap className="h-5 w-5 text-purple-600" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-gray-900">👨‍🏫 Curso Encargado</h2>
                <p className="text-sm text-gray-600">Asignado por el Coordinador Académico</p>
              </div>
            </div>

            <Card className="bg-gradient-to-r from-purple-50 to-indigo-50 border-2 border-purple-200 shadow-lg">
              <CardHeader className="pb-4">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-2xl text-purple-900 flex items-center gap-2">
                      <BookOpen className="h-6 w-6" />
                      {courseInCharge.name} {courseInCharge.level}
                    </CardTitle>
                    <p className="text-purple-700 mt-1">
                      Sección {courseInCharge.section} - Turno {courseInCharge.turn}
                    </p>
                  </div>
                  <Badge className="bg-purple-100 text-purple-800 border-purple-300 text-lg px-4 py-2">
                    🏆 Encargado
                  </Badge>
                </div>
              </CardHeader>

              <CardContent className="space-y-6">
                {/* Información General del Curso */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 p-4 bg-white rounded-lg border border-purple-200">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                      <Users className="h-5 w-5 text-blue-600" />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-600">Estudiantes</p>
                      <p className="text-xl font-bold text-gray-900">
                        {courseInCharge.studentsCount}/{courseInCharge.capacity}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                      <Calendar className="h-5 w-5 text-green-600" />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-600">Horario</p>
                      <p className="text-sm text-gray-900">{courseInCharge.schedule}</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-orange-100 rounded-full flex items-center justify-center">
                      <BookOpen className="h-5 w-5 text-orange-600" />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-600">Aula</p>
                      <p className="text-sm text-gray-900">{courseInCharge.classroom}</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                      <CheckCircle className="h-5 w-5 text-purple-600" />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-600">Materias</p>
                      <p className="text-xl font-bold text-gray-900">{courseInCharge.subjects.length}</p>
                    </div>
                  </div>
                </div>

                {/* Materias del Curso */}
                <div className="bg-white rounded-lg border border-purple-200 p-4">
                  <h3 className="text-lg font-semibold text-gray-900 mb-3 flex items-center gap-2">
                    <BookOpen className="h-5 w-5 text-purple-600" />
                    Materias y Docentes
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                    {courseInCharge.subjects.map((subject, index) => (
                      <div key={index} className="p-3 bg-gray-50 rounded-lg border">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="font-medium text-gray-900">{subject.name}</p>
                            <p className="text-sm text-gray-600">{subject.teacher}</p>
                          </div>
                          <Badge
                            className={`${subject.average >= 80 ? "bg-green-100 text-green-800" : subject.average >= 70 ? "bg-yellow-100 text-yellow-800" : "bg-red-100 text-red-800"}`}
                          >
                            {subject.average}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Calificaciones de Estudiantes */}
                <div className="bg-white rounded-lg border border-purple-200 p-4">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
                    <BarChart3 className="h-5 w-5 text-purple-600" />
                    Calificaciones por Estudiante
                  </h3>
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b border-gray-200">
                          <th className="text-left py-2 px-3 font-medium text-gray-700">Estudiante</th>
                          <th className="text-center py-2 px-3 font-medium text-gray-700">Promedio General</th>
                          {courseInCharge.subjects.map((subject, index) => (
                            <th key={index} className="text-center py-2 px-2 font-medium text-gray-700 text-sm">
                              {subject.name}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {courseInCharge.students.map((student) => (
                          <tr key={student.id} className="border-b border-gray-100 hover:bg-gray-50">
                            <td className="py-3 px-3">
                              <div className="font-medium text-gray-900">{student.name}</div>
                            </td>
                            <td className="py-3 px-3 text-center">
                              <Badge
                                className={`${student.overallAverage >= 80 ? "bg-green-100 text-green-800" : student.overallAverage >= 70 ? "bg-yellow-100 text-yellow-800" : "bg-red-100 text-red-800"}`}
                              >
                                {student.overallAverage}
                              </Badge>
                            </td>
                            {courseInCharge.subjects.map((subject, index) => (
                              <td key={index} className="py-3 px-2 text-center">
                                <div className="flex items-center justify-center gap-2">
                                  <span
                                    className={`inline-block px-2 py-1 rounded text-sm ${
                                      student.subjects[subject.name] >= 80
                                        ? "bg-green-100 text-green-800"
                                        : student.subjects[subject.name] >= 70
                                          ? "bg-yellow-100 text-yellow-800"
                                          : "bg-red-100 text-red-800"
                                    }`}
                                  >
                                    {student.subjects[subject.name]}
                                  </span>
                                  <button
                                    onClick={() => {
                                      setSelectedStudentDetail({
                                        student: student,
                                        subject: subject,
                                        courseInfo: courseInCharge,
                                      })
                                      setShowDetailModal(true)
                                    }}
                                    className="p-1 hover:bg-gray-100 rounded transition-colors duration-200"
                                    title="Ver detalle de calificaciones"
                                  >
                                    <Eye className="h-3 w-3 text-gray-500 hover:text-blue-600" />
                                  </button>
                                </div>
                              </td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Estadísticas del Curso Encargado */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-green-700">Estudiantes Aprobados</p>
                        <p className="text-2xl font-bold text-green-800">
                          {courseInCharge.students.filter((s) => s.overallAverage >= 70).length}
                        </p>
                      </div>
                      <CheckCircle className="h-8 w-8 text-green-600" />
                    </div>
                  </div>
                  <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-blue-700">Promedio General</p>
                        <p className="text-2xl font-bold text-blue-800">
                          {Math.round(
                            courseInCharge.students.reduce((sum, s) => sum + s.overallAverage, 0) /
                              courseInCharge.students.length,
                          )}
                        </p>
                      </div>
                      <BarChart3 className="h-8 w-8 text-blue-600" />
                    </div>
                  </div>
                  <div className="bg-purple-50 p-4 rounded-lg border border-purple-200">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-purple-700">Excelencia (≥90)</p>
                        <p className="text-2xl font-bold text-purple-800">
                          {courseInCharge.students.filter((s) => s.overallAverage >= 90).length}
                        </p>
                      </div>
                      <AlertCircle className="h-8 w-8 text-purple-600" />
                    </div>
                  </div>
                </div>

                {/* Nota informativa */}
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <div className="flex items-start space-x-3">
                    <AlertCircle className="h-5 w-5 text-blue-600 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium text-blue-800">Información de Consulta</p>
                      <p className="text-sm text-blue-700 mt-1">
                        Como docente encargado, puedes consultar toda la información del curso y el rendimiento de los
                        estudiantes. Para modificar calificaciones específicas, accede a las materias individuales que
                        impartes.
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Separador visual */}
        <div className="border-t border-gray-200 mb-6">
          <div className="flex items-center justify-center -mt-3">
            <div className="bg-gray-50 px-4 py-1 rounded-full">
              <span className="text-sm font-medium text-gray-600">📚 Mis Materias Individuales</span>
            </div>
          </div>
        </div>

        {/* Buscador */}
        <div className="mb-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="Buscar por grado o materia..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-white border-gray-300"
            />
          </div>
        </div>

        {/* Lista de Cursos */}
        <div className="grid grid-cols-1 gap-6">
          {filteredCourses.map((course) => (
            <Card
              key={course.id}
              className="bg-white border border-gray-200 hover:shadow-lg transition-all duration-200"
            >
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-gray-900">
                    {course.grade} {course.level} - {course.subject}
                  </CardTitle>
                  <div className="flex space-x-2">
                    {course.pendingGrades && (
                      <Badge className="bg-red-100 text-red-800 border-red-200">Calificaciones Pendientes</Badge>
                    )}
                    {course.pendingAttendance && (
                      <Badge className="bg-yellow-100 text-yellow-800 border-yellow-200">Asistencia Pendiente</Badge>
                    )}
                    {!course.pendingGrades && !course.pendingAttendance && (
                      <Badge className="bg-green-100 text-green-800 border-green-200">Al Día</Badge>
                    )}
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                  <div className="flex items-center text-gray-600">
                    <Users className="h-4 w-4 mr-2" />
                    <span className="text-sm">{course.students} estudiantes</span>
                  </div>
                  <div className="flex items-center text-gray-600">
                    <Calendar className="h-4 w-4 mr-2" />
                    <span className="text-sm">{course.schedule}</span>
                  </div>
                  <div className="flex items-center text-gray-600">
                    <BookOpen className="h-4 w-4 mr-2" />
                    <span className="text-sm">{course.classroom}</span>
                  </div>
                  <div className="flex items-center text-gray-600">
                    <CheckCircle className="h-4 w-4 mr-2" />
                    <span className="text-sm">Asistencia: {course.attendanceRate}%</span>
                  </div>
                </div>

                {/* Estadísticas del Curso */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <p className="text-sm font-medium text-gray-600 mb-2">Promedio General</p>
                    <div className="flex items-center space-x-2">
                      <div className="flex-1 bg-gray-200 rounded-full h-2">
                        <div
                          className={`h-2 rounded-full ${
                            course.averageGrade >= 80
                              ? "bg-green-500"
                              : course.averageGrade >= 70
                                ? "bg-yellow-500"
                                : "bg-red-500"
                          }`}
                          style={{ width: `${course.averageGrade}%` }}
                        ></div>
                      </div>
                      <span className="text-sm font-bold text-gray-900">{course.averageGrade}</span>
                    </div>
                  </div>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <p className="text-sm font-medium text-gray-600 mb-2">Asistencia</p>
                    <div className="flex items-center space-x-2">
                      <div className="flex-1 bg-gray-200 rounded-full h-2">
                        <div
                          className={`h-2 rounded-full ${
                            course.attendanceRate >= 90
                              ? "bg-green-500"
                              : course.attendanceRate >= 80
                                ? "bg-yellow-500"
                                : "bg-red-500"
                          }`}
                          style={{ width: `${course.attendanceRate}%` }}
                        ></div>
                      </div>
                      <span className="text-sm font-bold text-gray-900">{course.attendanceRate}%</span>
                    </div>
                  </div>
                </div>

                {/* Acciones */}
                <div className="flex flex-wrap gap-3">
                  <Link href={`/dashboard/profesor/courses/${course.id}`}>
                    <Button className="bg-indigo-600 hover:bg-indigo-700 text-white">
                      <Eye className="h-4 w-4 mr-2" />
                      Entrar al Curso
                    </Button>
                  </Link>
                  <Link href={`/dashboard/profesor/courses/${course.id}?tab=attendance`}>
                    <Button
                      variant="outline"
                      className="border-blue-300 text-blue-700 hover:bg-blue-50 hover:border-blue-400 bg-white transition-colors duration-200"
                    >
                      <Calendar className="h-4 w-4 mr-2" />
                      Registrar Asistencia
                    </Button>
                  </Link>
                  <Link href={`/dashboard/profesor/grades?course=${course.id}`}>
                    <Button variant="outline" className="border-gray-300 text-gray-700 hover:bg-gray-50 bg-transparent">
                      <CheckCircle className="h-4 w-4 mr-2" />
                      Calificaciones
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredCourses.length === 0 && (
          <Card className="bg-white border border-gray-200">
            <CardContent className="p-12 text-center">
              <BookOpen className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No se encontraron cursos</h3>
              <p className="text-gray-500">Intenta con otros términos de búsqueda</p>
            </CardContent>
          </Card>
        )}

        {/* Modal de Detalle de Calificaciones */}
        {showDetailModal && selectedStudentDetail && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
              <div className="p-6">
                {/* Header */}
                <div className="flex items-center justify-between mb-6 pb-4 border-b">
                  <div>
                    <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2">
                      📊 P1 Todas las materias
                    </h2>
                    <p className="text-gray-600 mt-1">Detalle de calificaciones por competencias</p>
                  </div>
                  <button
                    onClick={() => setShowDetailModal(false)}
                    className="text-gray-400 hover:text-gray-600 text-2xl font-bold"
                  >
                    ×
                  </button>
                </div>

                {/* Información del Estudiante y Materia */}
                <div className="mb-6">
                  <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                    <h3 className="text-lg font-semibold text-blue-900 flex items-center gap-2">
                      📚 {selectedStudentDetail.subject.name} ({selectedStudentDetail.student.name})
                    </h3>
                    <p className="text-blue-700 text-sm mt-1">
                      Curso: {selectedStudentDetail.courseInfo.name} - {selectedStudentDetail.courseInfo.level}
                    </p>
                  </div>
                </div>

                {/* Calificaciones Originales */}
                <div className="mb-6">
                  <h4 className="text-md font-semibold text-gray-800 mb-4">
                    Calificaciones Originales - {selectedStudentDetail.subject.name}
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                    {[
                      { name: "Comunicativa", score: 60, color: "bg-red-100 text-red-800" },
                      { name: "Pensamiento Lógico", score: 60, color: "bg-red-100 text-red-800" },
                      { name: "Científica y Tecnológica", score: 60, color: "bg-red-100 text-red-800" },
                      { name: "Ambiental y de la Salud", score: 60, color: "bg-red-100 text-red-800" },
                      { name: "Ética y Ciudadana", score: 60, color: "bg-red-100 text-red-800" },
                      { name: "Desarrollo Personal", score: 60, color: "bg-red-100 text-red-800" },
                    ].map((competencia, index) => (
                      <div
                        key={index}
                        className="bg-gray-50 p-3 rounded-lg border cursor-pointer hover:bg-gray-100 transition-colors duration-200"
                        onClick={() => {
                          setSelectedCompetenciaDetail({
                            competencia: competencia,
                            student: selectedStudentDetail.student,
                            subject: selectedStudentDetail.subject,
                            period: "P1",
                          })
                          setShowActivityDetailModal(true)
                        }}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium text-gray-700">{competencia.name}</span>
                          <div className="flex items-center gap-2">
                            <span className={`px-2 py-1 rounded text-sm font-medium ${competencia.color}`}>
                              {competencia.score}
                            </span>
                            <Eye className="h-3 w-3 text-gray-400" />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Recuperaciones Aplicadas */}
                <div className="mb-6">
                  <h4 className="text-md font-semibold text-gray-800 mb-4">
                    Recuperaciones Aplicadas - {selectedStudentDetail.subject.name}
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                    {[
                      { name: "Comunicativa", score: 70, recovery: true },
                      { name: "Pensamiento Lógico", score: 71, recovery: true },
                      { name: "Científica y Tecnológica", score: 70, recovery: true },
                      { name: "Ambiental y de la Salud", score: 70, recovery: true },
                      { name: "Ética y Ciudadana", score: 70, recovery: true },
                      { name: "Desarrollo Personal", score: 72, recovery: true },
                    ].map((competencia, index) => (
                      <div key={index} className="bg-orange-50 p-3 rounded-lg border border-orange-200">
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium text-gray-700">{competencia.name}</span>
                          <div className="flex items-center gap-2">
                            <span className="px-2 py-1 rounded text-sm font-medium bg-orange-100 text-orange-800">
                              {competencia.score} {competencia.recovery && "(Recuperación)"}
                            </span>
                            <button
                              onClick={() => {
                                setSelectedCompetenciaDetail({
                                  competencia: competencia,
                                  student: selectedStudentDetail.student,
                                  subject: selectedStudentDetail.subject,
                                  period: "P1",
                                  isRecovery: true,
                                })
                                setShowActivityDetailModal(true)
                              }}
                              className="p-1 hover:bg-orange-100 rounded transition-colors duration-200"
                              title="Ver detalle de evaluaciones de recuperación"
                            >
                              <Eye className="h-3 w-3 text-orange-600 hover:text-orange-800" />
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Mensaje de Éxito */}
                <div className="mb-6">
                  <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                    <div className="flex items-start space-x-3">
                      <CheckCircle className="h-5 w-5 text-green-600 mt-0.5" />
                      <div>
                        <p className="text-sm font-medium text-green-800">
                          ✓ Recuperaciones aplicadas en {selectedStudentDetail.subject.name} - Competencias elevadas por
                          encima de 70 puntos
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Promedio Final */}
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <div className="flex items-center justify-between">
                    <span className="text-lg font-semibold text-blue-900">
                      Promedio P1 - {selectedStudentDetail.subject.name}:
                    </span>
                    <span className="text-2xl font-bold text-blue-900">
                      {selectedStudentDetail.student.subjects[selectedStudentDetail.subject.name]}
                    </span>
                  </div>
                </div>

                {/* Botones de Acción */}
                <div className="flex justify-end gap-3 mt-6 pt-4 border-t">
                  <button
                    onClick={() => setShowDetailModal(false)}
                    className="px-4 py-2 text-gray-600 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors duration-200"
                  >
                    Cerrar
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Modal de Detalle de Actividades por Competencia */}
        {showActivityDetailModal && selectedCompetenciaDetail && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-lg shadow-xl max-w-3xl w-full max-h-[90vh] overflow-y-auto">
              <div className="p-6">
                {/* Header */}
                <div className="flex items-center justify-between mb-6 pb-4 border-b">
                  <div>
                    <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2">
                      📋 Detalle de Actividades - {selectedCompetenciaDetail.competencia.name}
                    </h2>
                    <p className="text-gray-600 mt-1">
                      {selectedCompetenciaDetail.student.name} - {selectedCompetenciaDetail.subject.name} (
                      {selectedCompetenciaDetail.period})
                    </p>
                  </div>
                  <button
                    onClick={() => setShowActivityDetailModal(false)}
                    className="text-gray-400 hover:text-gray-600 text-2xl font-bold"
                  >
                    ×
                  </button>
                </div>

                {/* Actividades Configuradas */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold text-gray-800 mb-4">Actividades Evaluativas</h3>

                  {/* Lista de Actividades */}
                  <div className="space-y-3">
                    {[
                      { name: "Examen Parcial", type: "Examen", weight: 40, score: 65, date: "2024-02-15" },
                      { name: "Trabajo en Equipo", type: "Trabajo", weight: 30, score: 58, date: "2024-02-20" },
                      { name: "Exposición Oral", type: "Exposición", weight: 30, score: 55, date: "2024-02-25" },
                    ].map((activity, index) => (
                      <div key={index} className="bg-gray-50 p-4 rounded-lg border">
                        <div className="flex items-center justify-between mb-2">
                          <div>
                            <h4 className="font-medium text-gray-900">{activity.name}</h4>
                            <p className="text-sm text-gray-600">
                              {activity.type} - {activity.date}
                            </p>
                          </div>
                          <div className="text-right">
                            <div className="flex items-center gap-2">
                              <span className="text-sm text-gray-500">Peso: {activity.weight}%</span>
                              <span
                                className={`px-2 py-1 rounded text-sm font-medium ${
                                  activity.score >= 70 ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
                                }`}
                              >
                                {activity.score}
                              </span>
                            </div>
                          </div>
                        </div>

                        {/* Barra de progreso del peso */}
                        <div className="mt-2">
                          <div className="flex items-center justify-between text-xs text-gray-500 mb-1">
                            <span>Ponderación</span>
                            <span>{activity.weight}%</span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div
                              className="bg-blue-500 h-2 rounded-full"
                              style={{ width: `${activity.weight}%` }}
                            ></div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Cálculo del Promedio */}
                  <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-900 mb-3">Cálculo del Promedio</h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span>Examen Parcial (40%): 65 × 0.40 =</span>
                        <span className="font-medium">26.0</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Trabajo en Equipo (30%): 58 × 0.30 =</span>
                        <span className="font-medium">17.4</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Exposición Oral (30%): 55 × 0.30 =</span>
                        <span className="font-medium">16.5</span>
                      </div>
                      <div className="border-t pt-2 flex justify-between font-bold text-blue-900">
                        <span>Promedio Final:</span>
                        <span
                          className={`px-2 py-1 rounded ${
                            selectedCompetenciaDetail.competencia.score >= 70
                              ? "bg-green-100 text-green-800"
                              : "bg-red-100 text-red-800"
                          }`}
                        >
                          {selectedCompetenciaDetail.competencia.score}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Observaciones */}
                  <div className="mt-4 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <h4 className="font-semibold text-yellow-900 mb-2">Observaciones</h4>
                    <p className="text-sm text-yellow-800">
                      {selectedCompetenciaDetail.competencia.score < 70
                        ? "⚠️ Competencia por debajo del mínimo requerido (70). Se recomienda aplicar recuperación."
                        : "✅ Competencia aprobada satisfactoriamente."}
                    </p>
                  </div>
                </div>

                {/* Botones de Acción */}
                <div className="flex justify-end gap-3 mt-6 pt-4 border-t">
                  <button
                    onClick={() => setShowActivityDetailModal(false)}
                    className="px-4 py-2 text-gray-600 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors duration-200"
                  >
                    Cerrar
                  </button>
                  <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors duration-200">
                    Editar Actividades
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  )
}
