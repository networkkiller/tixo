"use client"

import { useAuth } from "@/contexts/auth-context"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  Bell,
  Calendar,
  CheckCircle2,
  ClipboardList,
  FileText,
  Users,
  AlertTriangle,
  BookOpen,
  TrendingUp,
  TrendingDown,
  Phone,
  Mail,
  Cake,
  Gift,
} from "lucide-react"
import Link from "next/link"
import { CalendarActivities } from "@/components/dashboard/calendar-activities"

export default function ProfesorDashboard() {
  const { user } = useAuth()

  if (!user) return null

  // Datos de ejemplo de estudiantes por curso y rendimiento con fechas de cumpleaños
  const courseData = [
    {
      courseName: "1° A Primaria - Matemáticas",
      totalStudents: 25,
      highPerformance: [
        { name: "Ana María González", grade: 92, attendance: 98, birthday: "2018-01-23" },
        { name: "Carlos Eduardo Pérez", grade: 89, attendance: 95, birthday: "2018-03-15" },
        { name: "Sofía Alejandra López", grade: 87, attendance: 100, birthday: "2018-07-08" },
      ],
      averagePerformance: [
        { name: "Luis Fernando Martínez", grade: 78, attendance: 92, birthday: "2018-01-23" },
        { name: "María José Rodríguez", grade: 82, attendance: 88, birthday: "2018-05-12" },
        { name: "Diego Alejandro Castro", grade: 75, attendance: 90, birthday: "2018-09-30" },
        { name: "Valentina Méndez", grade: 80, attendance: 94, birthday: "2018-11-18" },
      ],
      lowPerformance: [
        { name: "Roberto Carlos Sánchez", grade: 65, attendance: 85, birthday: "2018-02-14" },
        { name: "Carmen Isabel Fernández", grade: 58, attendance: 78, birthday: "2018-06-25" },
      ],
    },
    {
      courseName: "1° B Primaria - Matemáticas",
      totalStudents: 28,
      highPerformance: [
        { name: "Isabella María Torres", grade: 94, attendance: 97, birthday: "2018-01-23" },
        { name: "Sebastián José Ramírez", grade: 88, attendance: 96, birthday: "2018-04-20" },
      ],
      averagePerformance: [
        { name: "Camila Andrea Morales", grade: 77, attendance: 91, birthday: "2018-08-07" },
        { name: "Andrés Felipe Vargas", grade: 83, attendance: 89, birthday: "2018-10-03" },
        { name: "Gabriela Sofía Herrera", grade: 79, attendance: 93, birthday: "2018-12-22" },
        { name: "Mateo Alejandro Jiménez", grade: 81, attendance: 87, birthday: "2018-01-23" },
        { name: "Lucía Fernanda Ortiz", grade: 76, attendance: 92, birthday: "2018-07-16" },
      ],
      lowPerformance: [
        { name: "Nicolás David Ruiz", grade: 68, attendance: 82, birthday: "2018-03-28" },
        { name: "Valeria Cristina Delgado", grade: 62, attendance: 79, birthday: "2018-09-11" },
        { name: "Santiago Miguel Vega", grade: 59, attendance: 75, birthday: "2018-05-05" },
      ],
    },
    {
      courseName: "2° A Primaria - Matemáticas",
      totalStudents: 26,
      highPerformance: [
        { name: "Emilia Valentina Cruz", grade: 91, attendance: 99, birthday: "2017-01-23" },
        { name: "Joaquín Sebastián Moreno", grade: 86, attendance: 94, birthday: "2017-06-14" },
        { name: "Antonella Sofía Guerrero", grade: 90, attendance: 97, birthday: "2017-11-09" },
      ],
      averagePerformance: [
        { name: "Maximiliano José Peña", grade: 74, attendance: 90, birthday: "2017-02-18" },
        { name: "Renata Isabel Campos", grade: 82, attendance: 86, birthday: "2017-08-26" },
        { name: "Tomás Alejandro Silva", grade: 78, attendance: 91, birthday: "2017-04-12" },
      ],
      lowPerformance: [
        { name: "Esperanza María Rojas", grade: 66, attendance: 83, birthday: "2017-10-07" },
        { name: "Benjamín Carlos Mendoza", grade: 61, attendance: 77, birthday: "2017-12-31" },
      ],
    },
    {
      courseName: "2° B Primaria - Matemáticas",
      totalStudents: 24,
      highPerformance: [
        { name: "Catalina Andrea Flores", grade: 93, attendance: 98, birthday: "2017-01-23" },
        { name: "Alejandro José Paredes", grade: 87, attendance: 95, birthday: "2017-07-19" },
      ],
      averagePerformance: [
        { name: "Mariana Sofía Aguilar", grade: 80, attendance: 89, birthday: "2017-03-04" },
        { name: "Felipe Andrés Navarro", grade: 76, attendance: 92, birthday: "2017-09-15" },
        { name: "Daniela Cristina Ramos", grade: 83, attendance: 88, birthday: "2017-05-21" },
        { name: "Ignacio Miguel Cortés", grade: 79, attendance: 90, birthday: "2017-11-28" },
      ],
      lowPerformance: [
        { name: "Fernanda Isabel Molina", grade: 64, attendance: 81, birthday: "2017-01-23" },
        { name: "Patricio Sebastián Reyes", grade: 67, attendance: 84, birthday: "2017-08-13" },
        { name: "Constanza María Espinoza", grade: 58, attendance: 76, birthday: "2017-06-02" },
      ],
    },
  ]

  // Función para obtener todos los estudiantes
  const getAllStudents = () => {
    const allStudents = []
    courseData.forEach((course) => {
      course.highPerformance.forEach((student) => allStudents.push({ ...student, course: course.courseName }))
      course.averagePerformance.forEach((student) => allStudents.push({ ...student, course: course.courseName }))
      course.lowPerformance.forEach((student) => allStudents.push({ ...student, course: course.courseName }))
    })
    return allStudents
  }

  // Función para obtener estudiantes que cumplen años hoy
  const getStudentsWithBirthdayToday = () => {
    const today = new Date()
    const todayMonth = today.getMonth() + 1
    const todayDay = today.getDate()

    return getAllStudents().filter((student) => {
      const birthday = new Date(student.birthday)
      return birthday.getMonth() + 1 === todayMonth && birthday.getDate() === todayDay
    })
  }

  // Función para obtener estudiantes que cumplen años este mes
  const getStudentsWithBirthdayThisMonth = () => {
    const today = new Date()
    const currentMonth = today.getMonth() + 1

    return getAllStudents()
      .filter((student) => {
        const birthday = new Date(student.birthday)
        return birthday.getMonth() + 1 === currentMonth
      })
      .sort((a, b) => {
        const dayA = new Date(a.birthday).getDate()
        const dayB = new Date(b.birthday).getDate()
        return dayA - dayB
      })
  }

  // Función para calcular la edad
  const calculateAge = (birthday) => {
    const today = new Date()
    const birthDate = new Date(birthday)
    let age = today.getFullYear() - birthDate.getFullYear()
    const monthDiff = today.getMonth() - birthDate.getMonth()
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      age--
    }
    return age
  }

  const studentsWithBirthdayToday = getStudentsWithBirthdayToday()
  const studentsWithBirthdayThisMonth = getStudentsWithBirthdayThisMonth()

  // Calcular totales
  const totalStudents = courseData.reduce((acc, course) => acc + course.totalStudents, 0)
  const totalHighPerformance = courseData.reduce((acc, course) => acc + course.highPerformance.length, 0)
  const totalAveragePerformance = courseData.reduce((acc, course) => acc + course.averagePerformance.length, 0)
  const totalLowPerformance = courseData.reduce((acc, course) => acc + course.lowPerformance.length, 0)

  return (
    <div className="flex flex-col gap-5 p-8 bg-[#f0f4f8]">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-gray-900">Dashboard Profesor</h1>
          <p className="text-gray-500">Bienvenido(a) de nuevo, {user.name}</p>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            className="gap-1 bg-white text-indigo-700 border-indigo-200 hover:bg-indigo-50"
          >
            <Calendar className="h-4 w-4" />
            <span>Hoy</span>
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="relative bg-white text-indigo-700 border-indigo-200 hover:bg-indigo-50"
          >
            <Bell className="h-4 w-4" />
            <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-indigo-600 text-[10px] text-white">
              3
            </span>
          </Button>
        </div>
      </div>

      {/* Alertas y tareas pendientes */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Alert className="border-l-4 border-amber-500 bg-white">
          <AlertTriangle className="h-5 w-5 text-amber-500" />
          <AlertTitle className="text-amber-800">Calificaciones pendientes</AlertTitle>
          <AlertDescription className="text-amber-700">5 evaluaciones sin calificar en 2° Primaria B</AlertDescription>
          <Button variant="link" className="mt-2 h-auto p-0 text-amber-700">
            Ver evaluaciones
          </Button>
        </Alert>

        <Alert className="border-l-4 border-indigo-500 bg-white">
          <Calendar className="h-5 w-5 text-indigo-500" />
          <AlertTitle className="text-indigo-800">Clase próxima</AlertTitle>
          <AlertDescription className="text-indigo-700">Matemáticas 1° A en 45 minutos - Aula 201</AlertDescription>
          <Button variant="link" className="mt-2 h-auto p-0 text-indigo-700">
            Ver horario
          </Button>
        </Alert>

        <Alert className="border-l-4 border-red-500 bg-white">
          <TrendingDown className="h-5 w-5 text-red-500" />
          <AlertTitle className="text-red-800">Estudiantes en riesgo</AlertTitle>
          <AlertDescription className="text-red-700">
            {totalLowPerformance} estudiantes con bajo rendimiento requieren atención
          </AlertDescription>
          <Button variant="link" className="mt-2 h-auto p-0 text-red-700">
            Ver detalles
          </Button>
        </Alert>
      </div>

      {/* Cumpleaños de estudiantes */}
      <div className="grid gap-4 md:grid-cols-2">
        {/* Cumpleaños de hoy */}
        <Card className="border-l-4 border-pink-500">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-pink-800">
              <Cake className="h-5 w-5" />
              Cumpleaños de Hoy
            </CardTitle>
            <CardDescription>
              {studentsWithBirthdayToday.length === 0
                ? "No hay estudiantes que cumplan años hoy"
                : `${studentsWithBirthdayToday.length} estudiante(s) cumple(n) años hoy`}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {studentsWithBirthdayToday.length > 0 ? (
              <div className="space-y-3">
                {studentsWithBirthdayToday.map((student, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-3 bg-pink-50 rounded-lg border border-pink-200"
                  >
                    <div className="flex items-center gap-3">
                      <div className="flex h-10 w-10 items-center justify-center rounded-full bg-pink-100">
                        <Gift className="h-5 w-5 text-pink-600" />
                      </div>
                      <div>
                        <p className="font-medium text-pink-900">{student.name}</p>
                        <p className="text-sm text-pink-700">{student.course}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <Badge className="bg-pink-100 text-pink-800">{calculateAge(student.birthday) + 1} años</Badge>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-6 text-gray-500">
                <Cake className="h-12 w-12 mx-auto mb-2 text-gray-300" />
                <p>No hay cumpleaños hoy</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Cumpleaños del mes */}
        <Card className="border-l-4 border-purple-500">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-purple-800">
              <Calendar className="h-5 w-5" />
              Cumpleaños de Este Mes
            </CardTitle>
            <CardDescription>
              {studentsWithBirthdayThisMonth.length} estudiante(s) cumple(n) años este mes
            </CardDescription>
          </CardHeader>
          <CardContent>
            {studentsWithBirthdayThisMonth.length > 0 ? (
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {studentsWithBirthdayThisMonth.map((student, index) => {
                  const birthdayDate = new Date(student.birthday)
                  const isToday = studentsWithBirthdayToday.some((todayStudent) => todayStudent.name === student.name)

                  return (
                    <div
                      key={index}
                      className={`flex items-center justify-between p-2 rounded-lg border ${
                        isToday ? "bg-pink-50 border-pink-200" : "bg-purple-50 border-purple-200"
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <div
                          className={`flex h-8 w-8 items-center justify-center rounded-full ${
                            isToday ? "bg-pink-100" : "bg-purple-100"
                          }`}
                        >
                          {isToday ? (
                            <Gift className="h-4 w-4 text-pink-600" />
                          ) : (
                            <Cake className="h-4 w-4 text-purple-600" />
                          )}
                        </div>
                        <div>
                          <p className={`text-sm font-medium ${isToday ? "text-pink-900" : "text-purple-900"}`}>
                            {student.name}
                          </p>
                          <p className={`text-xs ${isToday ? "text-pink-700" : "text-purple-700"}`}>{student.course}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className={`text-xs font-medium ${isToday ? "text-pink-800" : "text-purple-800"}`}>
                          {birthdayDate.getDate()}/{birthdayDate.getMonth() + 1}
                        </p>
                        {isToday && <Badge className="bg-pink-100 text-pink-800 text-xs">¡Hoy!</Badge>}
                      </div>
                    </div>
                  )
                })}
              </div>
            ) : (
              <div className="text-center py-6 text-gray-500">
                <Calendar className="h-12 w-12 mx-auto mb-2 text-gray-300" />
                <p>No hay cumpleaños este mes</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Indicadores de rendimiento */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Total Estudiantes</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-2xl font-bold">{totalStudents}</div>
              <Users className="h-5 w-5 text-indigo-600" />
            </div>
            <div className="mt-2 flex items-center text-xs">
              <Badge variant="outline" className="bg-indigo-50 text-indigo-700 border-indigo-200">
                4 cursos
              </Badge>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Alto Rendimiento</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-2xl font-bold text-green-600">{totalHighPerformance}</div>
              <TrendingUp className="h-5 w-5 text-green-600" />
            </div>
            <div className="mt-2 flex items-center text-xs">
              <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                ≥85 puntos
              </Badge>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Rendimiento Promedio</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-2xl font-bold text-blue-600">{totalAveragePerformance}</div>
              <div className="h-5 w-5 rounded-full bg-blue-600"></div>
            </div>
            <div className="mt-2 flex items-center text-xs">
              <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                70-84 puntos
              </Badge>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Bajo Rendimiento</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-2xl font-bold text-red-600">{totalLowPerformance}</div>
              <TrendingDown className="h-5 w-5 text-red-600" />
            </div>
            <div className="mt-2 flex items-center text-xs">
              <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
                &lt;70 puntos
              </Badge>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Estudiantes por curso y rendimiento */}
      <div className="space-y-6">
        {courseData.map((course, courseIndex) => (
          <Card key={courseIndex}>
            <CardHeader>
              <CardTitle>{course.courseName}</CardTitle>
              <CardDescription>
                {course.totalStudents} estudiantes - Distribución por rendimiento académico
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-6 md:grid-cols-3">
                {/* Alto Rendimiento (90-100) */}
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <TrendingUp className="h-4 w-4 text-green-600" />
                    <h4 className="font-medium text-green-800">Alto Rendimiento</h4>
                    <Badge className="bg-green-100 text-green-800">{course.highPerformance.length}</Badge>
                  </div>
                  <p className="text-xs text-green-700 mb-3">90-100 puntos</p>
                  <div className="space-y-2">
                    {course.highPerformance.map((student, index) => (
                      <Link
                        key={index}
                        href={`/dashboard/profesor/history?student=${encodeURIComponent(student.name)}`}
                        className="block"
                      >
                        <div className="p-3 bg-green-50 rounded-lg border border-green-200 hover:bg-green-100 hover:border-green-300 transition-all duration-200 cursor-pointer hover:shadow-sm">
                          <div className="font-medium text-sm text-green-900">{student.name}</div>
                          <div className="flex justify-between text-xs text-green-700 mt-1">
                            <span>Promedio: {student.grade}</span>
                            <span>Asistencia: {student.attendance}%</span>
                          </div>
                        </div>
                      </Link>
                    ))}
                  </div>
                </div>

                {/* Rendimiento Promedio (70-89) */}
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <div className="h-4 w-4 rounded-full bg-blue-600"></div>
                    <h4 className="font-medium text-blue-800">Rendimiento Promedio</h4>
                    <Badge className="bg-blue-100 text-blue-800">{course.averagePerformance.length}</Badge>
                  </div>
                  <p className="text-xs text-blue-700 mb-3">70-89 puntos</p>
                  <div className="space-y-2">
                    {course.averagePerformance.map((student, index) => (
                      <Link
                        key={index}
                        href={`/dashboard/profesor/history?student=${encodeURIComponent(student.name)}`}
                        className="block"
                      >
                        <div className="p-3 bg-blue-50 rounded-lg border border-blue-200 hover:bg-blue-100 hover:border-blue-300 transition-all duration-200 cursor-pointer hover:shadow-sm">
                          <div className="font-medium text-sm text-blue-900">{student.name}</div>
                          <div className="flex justify-between text-xs text-blue-700 mt-1">
                            <span>Promedio: {student.grade}</span>
                            <span>Asistencia: {student.attendance}%</span>
                          </div>
                        </div>
                      </Link>
                    ))}
                  </div>
                </div>

                {/* Bajo Rendimiento (60-69) */}
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <TrendingDown className="h-4 w-4 text-red-600" />
                    <h4 className="font-medium text-red-800">Bajo Rendimiento</h4>
                    <Badge className="bg-red-100 text-red-800">{course.lowPerformance.length}</Badge>
                  </div>
                  <p className="text-xs text-red-700 mb-3">60-69 puntos (En riesgo)</p>
                  <div className="space-y-2">
                    {course.lowPerformance.map((student, index) => (
                      <Link
                        key={index}
                        href={`/dashboard/profesor/history?student=${encodeURIComponent(student.name)}`}
                        className="block"
                      >
                        <div className="p-3 bg-red-50 rounded-lg border border-red-200 hover:bg-red-100 hover:border-red-300 transition-all duration-200 cursor-pointer hover:shadow-sm">
                          <div className="font-medium text-sm text-red-900">{student.name}</div>
                          <div className="flex justify-between text-xs text-red-700 mt-1">
                            <span>Promedio: {student.grade}</span>
                            <span>Asistencia: {student.attendance}%</span>
                          </div>
                          <Button
                            variant="outline"
                            size="sm"
                            className="mt-2 text-xs h-6 bg-transparent border-red-300 text-red-700 hover:bg-red-50"
                            onClick={(e) => {
                              e.preventDefault() // Prevent navigation when clicking the button
                              e.stopPropagation()
                              // Handle contact parents functionality
                            }}
                          >
                            <Phone className="h-3 w-3 mr-1" />
                            Contactar Padres
                          </Button>
                        </div>
                      </Link>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Accesos rápidos */}
      <Card>
        <CardHeader>
          <CardTitle>Accesos Rápidos</CardTitle>
          <CardDescription>Funciones frecuentes para agilizar tu trabajo</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
            <Link
              href="/dashboard/profesor/courses"
              className="flex flex-col items-center gap-2 rounded-lg border border-gray-200 bg-white p-4 text-center transition-all hover:border-indigo-200 hover:bg-indigo-50"
            >
              <div className="rounded-full bg-indigo-100 p-2">
                <BookOpen className="h-5 w-5 text-indigo-600" />
              </div>
              <span className="text-sm font-medium">Mis Cursos</span>
            </Link>

            <Link
              href="/dashboard/profesor/grades"
              className="flex flex-col items-center gap-2 rounded-lg border border-gray-200 bg-white p-4 text-center transition-all hover:border-indigo-200 hover:bg-indigo-50"
            >
              <div className="rounded-full bg-green-100 p-2">
                <ClipboardList className="h-5 w-5 text-green-600" />
              </div>
              <span className="text-sm font-medium">Calificaciones</span>
            </Link>

            <Link
              href="/dashboard/profesor/tasks"
              className="flex flex-col items-center gap-2 rounded-lg border border-gray-200 bg-white p-4 text-center transition-all hover:border-indigo-200 hover:bg-indigo-50"
            >
              <div className="rounded-full bg-blue-100 p-2">
                <Calendar className="h-5 w-5 text-blue-600" />
              </div>
              <span className="text-sm font-medium">Planificación</span>
            </Link>

            <Link
              href="/dashboard/profesor/communication"
              className="flex flex-col items-center gap-2 rounded-lg border border-gray-200 bg-white p-4 text-center transition-all hover:border-indigo-200 hover:bg-indigo-50"
            >
              <div className="rounded-full bg-purple-100 p-2">
                <Mail className="h-5 w-5 text-purple-600" />
              </div>
              <span className="text-sm font-medium">Comunicación</span>
            </Link>

            <Link
              href="/dashboard/profesor/history"
              className="flex flex-col items-center gap-2 rounded-lg border border-gray-200 bg-white p-4 text-center transition-all hover:border-indigo-200 hover:bg-indigo-50"
            >
              <div className="rounded-full bg-orange-100 p-2">
                <FileText className="h-5 w-5 text-orange-600" />
              </div>
              <span className="text-sm font-medium">Historial</span>
            </Link>
          </div>
        </CardContent>
      </Card>

      {/* Actividad reciente */}
      <Card>
        <CardHeader>
          <CardTitle>Actividad Reciente</CardTitle>
          <CardDescription>Últimas acciones realizadas en el sistema</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-start gap-4">
            <div className="rounded-full bg-green-100 p-1.5">
              <CheckCircle2 className="h-4 w-4 text-green-600" />
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium">Calificaciones registradas</p>
              <p className="text-xs text-gray-500">Examen de Matemáticas - 1° A Primaria</p>
              <p className="text-xs text-gray-400">Hace 35 minutos</p>
            </div>
          </div>

          <div className="flex items-start gap-4">
            <div className="rounded-full bg-indigo-100 p-1.5">
              <FileText className="h-4 w-4 text-indigo-600" />
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium">Tarea asignada</p>
              <p className="text-xs text-gray-500">Ejercicios de suma y resta - 2° B Primaria</p>
              <p className="text-xs text-gray-400">Hace 1 hora</p>
            </div>
          </div>

          <div className="flex items-start gap-4">
            <div className="rounded-full bg-blue-100 p-1.5">
              <Calendar className="h-4 w-4 text-blue-600" />
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium">Clase planificada</p>
              <p className="text-xs text-gray-500">Fracciones básicas - 2° A Primaria</p>
              <p className="text-xs text-gray-400">Hace 2 horas</p>
            </div>
          </div>

          <div className="flex items-start gap-4">
            <div className="rounded-full bg-purple-100 p-1.5">
              <Mail className="h-4 w-4 text-purple-600" />
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium">Mensaje enviado</p>
              <p className="text-xs text-gray-500">Comunicación con padres sobre bajo rendimiento</p>
              <p className="text-xs text-gray-400">Hace 3 horas</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Calendario de Actividades Sincronizado */}
      <CalendarActivities userRole="profesor" />
    </div>
  )
}
