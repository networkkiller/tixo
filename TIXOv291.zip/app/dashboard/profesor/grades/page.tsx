"use client"

import { useState } from "react"
import { Header } from "@/components/dashboard/header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Progress } from "@/components/ui/progress"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Settings,
  Edit3,
  Save,
  BarChart3,
  CheckCircle,
  Clock,
  BookOpen,
  Plus,
  Trash2,
  Eye,
  Calculator,
  Target,
  Brain,
  Lightbulb,
  Microscope,
  Heart,
  User,
} from "lucide-react"

// Competencias oficiales del MINERD
const competenciasMinerd = [
  {
    id: "comunicativa",
    name: "Comunicativa",
    description: "Capacidad de comunicarse efectivamente",
    icon: <BookOpen className="h-4 w-4" />,
    color: "bg-blue-500",
  },
  {
    id: "pensamiento",
    name: "Pensamiento Lógico, Creativo y Crítico",
    description: "Resolución de problemas y pensamiento crítico",
    icon: <Brain className="h-4 w-4" />,
    color: "bg-purple-500",
  },
  {
    id: "cientifica",
    name: "Científica y Tecnológica",
    description: "Comprensión científica y tecnológica",
    icon: <Microscope className="h-4 w-4" />,
    color: "bg-green-500",
  },
  {
    id: "ambiental",
    name: "Ambiental y de la Salud",
    description: "Conciencia ambiental y cuidado de la salud",
    icon: <Lightbulb className="h-4 w-4" />,
    color: "bg-emerald-500",
  },
  {
    id: "etica",
    name: "Ética y Ciudadana",
    description: "Valores éticos y ciudadanos",
    icon: <Heart className="h-4 w-4" />,
    color: "bg-red-500",
  },
  {
    id: "personal",
    name: "Desarrollo Personal y Espiritual",
    description: "Crecimiento personal y espiritual",
    icon: <User className="h-4 w-4" />,
    color: "bg-orange-500",
  },
]

// Tipos de evaluación disponibles
const tiposEvaluacion = ["Examen", "Trabajo", "Ensayo", "Exposición", "Maqueta", "Prueba", "Investigación"]

// Datos de ejemplo de cursos del profesor
const cursosProfesor = [
  {
    id: 1,
    name: "1° A Primaria",
    subject: "Matemáticas",
    students: 24,
    status: "active",
    periods: {
      P1: { configured: true, closed: true, startDate: "2024-01-15", endDate: "2024-03-15" },
      P2: { configured: true, closed: false, startDate: "2024-03-16", endDate: "2024-05-15" },
      P3: { configured: false, closed: false, startDate: "2024-05-16", endDate: "2024-07-15" },
      P4: { configured: false, closed: false, startDate: "2024-07-16", endDate: "2024-09-15" },
    },
  },
  {
    id: 2,
    name: "1° B Primaria",
    subject: "Matemáticas",
    students: 22,
    status: "active",
    periods: {
      P1: { configured: true, closed: true, startDate: "2024-01-15", endDate: "2024-03-15" },
      P2: { configured: true, closed: false, startDate: "2024-03-16", endDate: "2024-05-15" },
      P3: { configured: false, closed: false, startDate: "2024-05-16", endDate: "2024-07-15" },
      P4: { configured: false, closed: false, startDate: "2024-07-16", endDate: "2024-09-15" },
    },
  },
  {
    id: 3,
    name: "2° A Primaria",
    subject: "Matemáticas",
    students: 20,
    status: "active",
    periods: {
      P1: { configured: true, closed: true, startDate: "2024-01-15", endDate: "2024-03-15" },
      P2: { configured: false, closed: false, startDate: "2024-03-16", endDate: "2024-05-15" },
      P3: { configured: false, closed: false, startDate: "2024-05-16", endDate: "2024-07-15" },
      P4: { configured: false, closed: false, startDate: "2024-07-16", endDate: "2024-09-15" },
    },
  },
]

// Datos de ejemplo de estudiantes
const estudiantesEjemplo = [
  {
    id: 1,
    name: "Ana María González",
    matricula: "2024001",
    grades: {
      P1: 78,
      RP1: null,
      P2: 85,
      RP2: null,
      P3: null,
      RP3: null,
      P4: null,
      RP4: null,
      CF: null,
      CCF: null,
      CEXF: null,
      CE: null,
    },
    competencias: {
      P1: { comunicativa: 80, pensamiento: 75, cientifica: 78, ambiental: 82, etica: 76, personal: 79 },
    },
    status: "regular",
  },
  {
    id: 2,
    name: "Carlos Eduardo Pérez",
    matricula: "2024002",
    grades: {
      P1: 65,
      RP1: 72,
      P2: 68,
      RP2: null,
      P3: null,
      RP3: null,
      P4: null,
      RP4: null,
      CF: null,
      CCF: null,
      CEXF: null,
      CE: null,
    },
    competencias: {
      P1: { comunicativa: 68, pensamiento: 62, cientifica: 65, ambiental: 67, etica: 64, personal: 66 },
    },
    status: "recuperacion",
  },
  {
    id: 3,
    name: "María José Rodríguez",
    matricula: "2024003",
    grades: {
      P1: 92,
      RP1: null,
      P2: 88,
      RP2: null,
      P3: null,
      RP3: null,
      P4: null,
      RP4: null,
      CF: null,
      CCF: null,
      CEXF: null,
      CE: null,
    },
    competencias: {
      P1: { comunicativa: 95, pensamiento: 90, cientifica: 92, ambiental: 94, etica: 91, personal: 93 },
    },
    status: "excelente",
  },
]

export default function CalificacionesPage() {
  const [selectedCourse, setSelectedCourse] = useState(null)
  const [selectedPeriod, setSelectedPeriod] = useState("")
  const [configModalOpen, setConfigModalOpen] = useState(false)
  const [gradesModalOpen, setGradesModalOpen] = useState(false)
  const [currentConfigPeriod, setCurrentConfigPeriod] = useState("")
  const [periodActivities, setPeriodActivities] = useState({})
  const [students, setStudents] = useState(estudiantesEjemplo)
  const [selectedCompetencia, setSelectedCompetencia] = useState("")
  const [newActivity, setNewActivity] = useState({
    name: "",
    type: "",
    weight: 0,
    date: "",
  })

  const [studentDetailModalOpen, setStudentDetailModalOpen] = useState(false)
  const [selectedStudent, setSelectedStudent] = useState(null)
  const [selectedStudentPeriod, setSelectedStudentPeriod] = useState("")

  const [activityGrades, setActivityGrades] = useState({})

  // Add this function before the component return statement
  const calculateFinalGrade = (student) => {
    const { P1, P2, P3, P4, RP1, RP2, RP3, RP4 } = student.grades
    const grades = []

    // Use recovery grade if available and original grade was below 70, otherwise use original
    if (P1 !== null) grades.push(P1 < 70 && RP1 ? RP1 : P1)
    if (P2 !== null) grades.push(P2 < 70 && RP2 ? RP2 : P2)
    if (P3 !== null) grades.push(P3 < 70 && RP3 ? RP3 : P3)
    if (P4 !== null) grades.push(P4 < 70 && RP4 ? RP4 : P4)

    if (grades.length === 0) return null

    // Calculate average of available grades
    const average = Math.round(grades.reduce((sum, grade) => sum + grade, 0) / grades.length)
    return average
  }

  // Función para obtener el estado de un período
  const getPeriodStatus = (course, period) => {
    const periodData = course.periods[period]
    if (periodData.closed) return "closed"
    if (periodData.configured) return "active"
    return "pending"
  }

  // Función para calcular el promedio de competencias
  const calculateCompetenciaAverage = (competencias) => {
    const values = Object.values(competencias)
    return Math.round(values.reduce((sum, val) => sum + val, 0) / values.length)
  }

  // Función para obtener el color según la calificación
  const getGradeColor = (grade) => {
    if (grade >= 90) return "text-green-600 bg-green-50 border-green-200"
    if (grade >= 80) return "text-blue-600 bg-blue-50 border-blue-200"
    if (grade >= 70) return "text-yellow-600 bg-yellow-50 border-yellow-200"
    return "text-red-600 bg-red-50 border-red-200"
  }

  // Función para obtener el estado del estudiante
  const getStudentStatus = (student) => {
    const { P1, P2, RP1, RP2 } = student.grades
    if (P1 && P1 < 70 && !RP1) return "needs-recovery"
    if (P2 && P2 < 70 && !RP2) return "needs-recovery"
    if ((P1 && P1 >= 90) || (P2 && P2 >= 90)) return "excellent"
    return "regular"
  }

  // Función para configurar período
  const handleConfigurePeriod = (period) => {
    setCurrentConfigPeriod(period)
    setConfigModalOpen(true)
  }

  // Función para agregar actividad
  const handleAddActivity = () => {
    if (!selectedCompetencia || !newActivity.name || !newActivity.type || newActivity.weight <= 0) {
      alert("Por favor complete todos los campos")
      return
    }

    const key = `${currentConfigPeriod}-${selectedCompetencia}`
    const currentActivities = periodActivities[key] || []
    const totalWeight = currentActivities.reduce((sum, act) => sum + act.weight, 0) + newActivity.weight

    if (totalWeight > 100) {
      alert("La ponderación total no puede exceder 100%")
      return
    }

    setPeriodActivities((prev) => ({
      ...prev,
      [key]: [...currentActivities, { ...newActivity, id: Date.now() }],
    }))

    setNewActivity({ name: "", type: "", weight: 0, date: "" })
  }

  // Función para eliminar actividad
  const handleRemoveActivity = (competenciaId, activityId) => {
    const key = `${currentConfigPeriod}-${competenciaId}`
    setPeriodActivities((prev) => ({
      ...prev,
      [key]: prev[key]?.filter((act) => act.id !== activityId) || [],
    }))
  }

  // Función para validar configuración del período
  const validatePeriodConfig = () => {
    for (const competencia of competenciasMinerd) {
      const key = `${currentConfigPeriod}-${competencia.id}`
      const activities = periodActivities[key] || []
      const totalWeight = activities.reduce((sum, act) => sum + act.weight, 0)

      if (totalWeight !== 100) {
        alert(`La competencia "${competencia.name}" debe sumar exactamente 100%. Actual: ${totalWeight}%`)
        return false
      }
    }
    return true
  }

  // Función para guardar configuración del período
  const handleSavePeriodConfig = () => {
    if (validatePeriodConfig()) {
      // Marcar período como configurado
      setSelectedCourse((prev) => ({
        ...prev,
        periods: {
          ...prev.periods,
          [currentConfigPeriod]: {
            ...prev.periods[currentConfigPeriod],
            configured: true,
          },
        },
      }))
      setConfigModalOpen(false)
      alert("Configuración guardada exitosamente")
    }
  }

  // Función para ver detalle del estudiante
  const handleViewStudentDetail = (student: any, period: string) => {
    setSelectedStudent(student)
    setSelectedStudentPeriod(period)
    setStudentDetailModalOpen(true)
  }

  const handleActivityGradeChange = (studentId, competenciaId, activityIndex, value) => {
    const key = `${studentId}-${competenciaId}`
    setActivityGrades((prev) => ({
      ...prev,
      [key]: {
        ...prev[key],
        [activityIndex]: Number(value) || 0,
      },
    }))
  }

  const calculateActivityAverage = (studentId, competenciaId) => {
    const key = `${studentId}-${competenciaId}`
    const grades = activityGrades[key] || {}
    const values = Object.values(grades).filter((grade) => grade > 0)
    if (values.length === 0) return 0
    return Math.round(values.reduce((sum, grade) => sum + grade, 0) / values.length)
  }

  return (
    <div className="flex-1 flex flex-col bg-gray-50">
      <Header title="Calificaciones por Competencias" />

      <main className="flex-1 overflow-y-auto p-6">
        {!selectedCourse ? (
          // Vista de selección de curso
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-gray-900">Mis Cursos y Asignaturas</h2>
                <p className="text-gray-600">Selecciona un curso para gestionar las calificaciones</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {cursosProfesor.map((curso) => (
                <Card key={curso.id} className="hover:shadow-lg transition-shadow cursor-pointer">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">{curso.name}</CardTitle>
                      <Badge className="bg-indigo-100 text-indigo-800">{curso.subject}</Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">Estudiantes:</span>
                        <span className="font-medium">{curso.students}</span>
                      </div>

                      {/* Estado de períodos */}
                      <div className="space-y-2">
                        <span className="text-sm font-medium text-gray-700">Estado de Períodos:</span>
                        <div className="grid grid-cols-4 gap-1">
                          {["P1", "P2", "P3", "P4"].map((period) => {
                            const status = getPeriodStatus(curso, period)
                            return (
                              <div
                                key={period}
                                className={`text-xs px-2 py-1 rounded text-center ${
                                  status === "closed"
                                    ? "bg-green-100 text-green-800"
                                    : status === "active"
                                      ? "bg-blue-100 text-blue-800"
                                      : "bg-gray-100 text-gray-600"
                                }`}
                              >
                                {period}
                              </div>
                            )
                          })}
                        </div>
                      </div>

                      <Button
                        onClick={() => setSelectedCourse(curso)}
                        className="w-full bg-indigo-600 hover:bg-indigo-700"
                      >
                        <BarChart3 className="h-4 w-4 mr-2" />
                        Calificar
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        ) : (
          // Vista de calificaciones del curso seleccionado
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <Button variant="outline" onClick={() => setSelectedCourse(null)} className="mb-2">
                  ← Volver a Cursos
                </Button>
                <h2 className="text-2xl font-bold text-gray-900">
                  {selectedCourse.name} - {selectedCourse.subject}
                </h2>
                <p className="text-gray-600">{selectedCourse.students} estudiantes</p>
              </div>
            </div>

            {/* Tabs para períodos */}
            <Tabs value={selectedPeriod} onValueChange={setSelectedPeriod} className="w-full">
              <TabsList className="grid w-full grid-cols-4">
                {["P1", "P2", "P3", "P4"].map((period) => {
                  const status = getPeriodStatus(selectedCourse, period)
                  return (
                    <TabsTrigger
                      key={period}
                      value={period}
                      className={`${
                        status === "closed"
                          ? "data-[state=active]:bg-green-100 data-[state=active]:text-green-800"
                          : status === "active"
                            ? "data-[state=active]:bg-blue-100 data-[state=active]:text-blue-800"
                            : "data-[state=active]:bg-gray-100 data-[state=active]:text-gray-600"
                      }`}
                    >
                      {period}
                      {status === "closed" && <CheckCircle className="h-3 w-3 ml-1" />}
                      {status === "pending" && <Clock className="h-3 w-3 ml-1" />}
                    </TabsTrigger>
                  )
                })}
              </TabsList>

              {["P1", "P2", "P3", "P4"].map((period) => (
                <TabsContent key={period} value={period} className="space-y-6">
                  <Card>
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <CardTitle className="flex items-center gap-2">
                          <Target className="h-5 w-5" />
                          Período {period}
                        </CardTitle>
                        <div className="flex gap-2">
                          <Button
                            variant="outline"
                            onClick={() => handleConfigurePeriod(period)}
                            disabled={selectedCourse.periods[period].closed}
                          >
                            <Settings className="h-4 w-4 mr-2" />
                            Configurar {period}
                          </Button>
                          <Button
                            onClick={() => setGradesModalOpen(true)}
                            disabled={!selectedCourse.periods[period].configured}
                            className="bg-green-600 hover:bg-green-700"
                          >
                            <Edit3 className="h-4 w-4 mr-2" />
                            Ingresar Calificaciones
                          </Button>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {/* Información del período */}
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <div className="bg-gray-50 p-4 rounded-lg">
                            <div className="text-sm text-gray-600">Fecha de Inicio</div>
                            <div className="font-medium">{selectedCourse.periods[period].startDate}</div>
                          </div>
                          <div className="bg-gray-50 p-4 rounded-lg">
                            <div className="text-sm text-gray-600">Fecha de Cierre</div>
                            <div className="font-medium">{selectedCourse.periods[period].endDate}</div>
                          </div>
                          <div className="bg-gray-50 p-4 rounded-lg">
                            <div className="text-sm text-gray-600">Estado</div>
                            <Badge
                              className={
                                selectedCourse.periods[period].closed
                                  ? "bg-green-100 text-green-800"
                                  : selectedCourse.periods[period].configured
                                    ? "bg-blue-100 text-blue-800"
                                    : "bg-gray-100 text-gray-600"
                              }
                            >
                              {selectedCourse.periods[period].closed
                                ? "Cerrado"
                                : selectedCourse.periods[period].configured
                                  ? "Activo"
                                  : "Pendiente"}
                            </Badge>
                          </div>
                        </div>

                        {/* Tabla de calificaciones */}
                        <div className="overflow-x-auto">
                          <Table>
                            <TableHeader>
                              <TableRow>
                                <TableHead>Estudiante</TableHead>
                                <TableHead className="text-center">{period}</TableHead>
                                <TableHead className="text-center">R{period}</TableHead>
                                <TableHead className="text-center">Estado</TableHead>
                                <TableHead className="text-center">Acciones</TableHead>
                              </TableRow>
                            </TableHeader>
                            <TableBody>
                              {students.map((student) => {
                                const periodGrade = student.grades[period]
                                const recoveryGrade = student.grades[`R${period}`]
                                const status = getStudentStatus(student)

                                return (
                                  <TableRow key={student.id}>
                                    <TableCell>
                                      <div>
                                        <div className="font-medium">{student.name}</div>
                                        <div className="text-sm text-gray-500">{student.matricula}</div>
                                      </div>
                                    </TableCell>
                                    <TableCell className="text-center">
                                      {periodGrade ? (
                                        <Badge className={getGradeColor(periodGrade)}>{periodGrade}</Badge>
                                      ) : (
                                        <span className="text-gray-400">-</span>
                                      )}
                                    </TableCell>
                                    <TableCell className="text-center">
                                      {recoveryGrade ? (
                                        <Badge className={getGradeColor(recoveryGrade)}>{recoveryGrade}</Badge>
                                      ) : periodGrade && periodGrade < 70 ? (
                                        <Badge className="bg-yellow-100 text-yellow-800">Pendiente</Badge>
                                      ) : (
                                        <span className="text-gray-400">-</span>
                                      )}
                                    </TableCell>
                                    <TableCell className="text-center">
                                      <Badge
                                        className={
                                          status === "excellent"
                                            ? "bg-green-100 text-green-800"
                                            : status === "needs-recovery"
                                              ? "bg-red-100 text-red-800"
                                              : "bg-blue-100 text-blue-800"
                                        }
                                      >
                                        {status === "excellent"
                                          ? "Excelente"
                                          : status === "needs-recovery"
                                            ? "Recuperación"
                                            : "Regular"}
                                      </Badge>
                                    </TableCell>
                                    <TableCell className="text-center">
                                      <Button
                                        size="sm"
                                        variant="outline"
                                        onClick={() => handleViewStudentDetail(student, period)}
                                        className="border-blue-300 text-blue-700 hover:bg-blue-50 hover:border-blue-400 bg-white transition-colors duration-200"
                                      >
                                        <Eye className="h-3 w-3 mr-1" />
                                        Ver Detalle
                                      </Button>
                                    </TableCell>
                                  </TableRow>
                                )
                              })}
                            </TableBody>
                          </Table>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
              ))}
            </Tabs>

            {/* Resumen de calificaciones finales */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calculator className="h-5 w-5" />
                  Calificaciones Finales
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Estudiante</TableHead>
                        <TableHead className="text-center">P1</TableHead>
                        <TableHead className="text-center">P2</TableHead>
                        <TableHead className="text-center">P3</TableHead>
                        <TableHead className="text-center">P4</TableHead>
                        <TableHead className="text-center">C.F.</TableHead>
                        <TableHead className="text-center">C.C.F.</TableHead>
                        <TableHead className="text-center">C.EX.F.</TableHead>
                        <TableHead className="text-center">C.E.</TableHead>
                        <TableHead className="text-center">Estado Final</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {students.map((student) => (
                        <TableRow key={student.id}>
                          <TableCell>
                            <div className="font-medium">{student.name}</div>
                          </TableCell>
                          <TableCell className="text-center">
                            {student.grades.P1 ? (
                              <Badge className={getGradeColor(student.grades.P1)}>{student.grades.P1}</Badge>
                            ) : (
                              <span className="text-gray-400">-</span>
                            )}
                          </TableCell>
                          <TableCell className="text-center">
                            {student.grades.P2 ? (
                              <Badge className={getGradeColor(student.grades.P2)}>{student.grades.P2}</Badge>
                            ) : (
                              <span className="text-gray-400">-</span>
                            )}
                          </TableCell>
                          <TableCell className="text-center">
                            {student.grades.P3 ? (
                              <Badge className={getGradeColor(student.grades.P3)}>{student.grades.P3}</Badge>
                            ) : (
                              <span className="text-gray-400">-</span>
                            )}
                          </TableCell>
                          <TableCell className="text-center">
                            {student.grades.P4 ? (
                              <Badge className={getGradeColor(student.grades.P4)}>{student.grades.P4}</Badge>
                            ) : (
                              <span className="text-gray-400">-</span>
                            )}
                          </TableCell>
                          <TableCell className="text-center">
                            {(() => {
                              const calculatedGrade = calculateFinalGrade(student)
                              return calculatedGrade ? (
                                <div className="flex flex-col items-center gap-1">
                                  <Badge className={getGradeColor(calculatedGrade)}>{calculatedGrade}</Badge>
                                  <span className="text-xs text-gray-500">Auto</span>
                                </div>
                              ) : (
                                <span className="text-gray-400">-</span>
                              )
                            })()}
                          </TableCell>
                          <TableCell className="text-center">
                            {student.grades.CCF ? (
                              <Badge className={getGradeColor(student.grades.CCF)}>{student.grades.CCF}</Badge>
                            ) : (
                              <span className="text-gray-400">-</span>
                            )}
                          </TableCell>
                          <TableCell className="text-center">
                            {student.grades.CEXF ? (
                              <Badge className={getGradeColor(student.grades.CEXF)}>{student.grades.CEXF}</Badge>
                            ) : (
                              <span className="text-gray-400">-</span>
                            )}
                          </TableCell>
                          <TableCell className="text-center">
                            {student.grades.CE ? (
                              <Badge className={getGradeColor(student.grades.CE)}>{student.grades.CE}</Badge>
                            ) : (
                              <span className="text-gray-400">-</span>
                            )}
                          </TableCell>
                          <TableCell className="text-center">
                            <Badge className="bg-gray-100 text-gray-800">En Proceso</Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Modal de configuración de período */}
        <Dialog open={configModalOpen} onOpenChange={setConfigModalOpen}>
          <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Configurar {currentConfigPeriod} - Competencias y Actividades</DialogTitle>
              <DialogDescription>
                Configure las actividades evaluativas para cada competencia. Cada competencia debe sumar exactamente
                100%.
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-6">
              {competenciasMinerd.map((competencia) => {
                const key = `${currentConfigPeriod}-${competencia.id}`
                const activities = periodActivities[key] || []
                const totalWeight = activities.reduce((sum, act) => sum + act.weight, 0)

                return (
                  <Card key={competencia.id}>
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className={`p-2 rounded-lg ${competencia.color} text-white`}>{competencia.icon}</div>
                          <div>
                            <CardTitle className="text-lg">{competencia.name}</CardTitle>
                            <p className="text-sm text-gray-600">{competencia.description}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-2xl font-bold">{totalWeight}%</div>
                          <Progress value={totalWeight} className="w-24" />
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {/* Lista de actividades */}
                        {activities.length > 0 && (
                          <div className="space-y-2">
                            {activities.map((activity) => (
                              <div
                                key={activity.id}
                                className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                              >
                                <div>
                                  <div className="font-medium">{activity.name}</div>
                                  <div className="text-sm text-gray-600">
                                    {activity.type} - {activity.date}
                                  </div>
                                </div>
                                <div className="flex items-center gap-2">
                                  <Badge>{activity.weight}%</Badge>
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => handleRemoveActivity(competencia.id, activity.id)}
                                  >
                                    <Trash2 className="h-3 w-3" />
                                  </Button>
                                </div>
                              </div>
                            ))}
                          </div>
                        )}

                        {/* Formulario para agregar actividad */}
                        {totalWeight < 100 && (
                          <div className="border-t pt-4">
                            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                              <div>
                                <Label>Nombre de la Actividad</Label>
                                <Input
                                  value={selectedCompetencia === competencia.id ? newActivity.name : ""}
                                  onChange={(e) => {
                                    setSelectedCompetencia(competencia.id)
                                    setNewActivity((prev) => ({ ...prev, name: e.target.value }))
                                  }}
                                  placeholder="Ej: Examen parcial"
                                />
                              </div>
                              <div>
                                <Label>Tipo</Label>
                                <Select
                                  value={selectedCompetencia === competencia.id ? newActivity.type : ""}
                                  onValueChange={(value) => {
                                    setSelectedCompetencia(competencia.id)
                                    setNewActivity((prev) => ({ ...prev, type: value }))
                                  }}
                                >
                                  <SelectTrigger>
                                    <SelectValue placeholder="Seleccionar tipo" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    {tiposEvaluacion.map((tipo) => (
                                      <SelectItem key={tipo} value={tipo}>
                                        {tipo}
                                      </SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                              </div>
                              <div>
                                <Label>Ponderación (%)</Label>
                                <Input
                                  type="number"
                                  min="1"
                                  max={100 - totalWeight}
                                  value={selectedCompetencia === competencia.id ? newActivity.weight : ""}
                                  onChange={(e) => {
                                    setSelectedCompetencia(competencia.id)
                                    setNewActivity((prev) => ({
                                      ...prev,
                                      weight: Number.parseInt(e.target.value) || 0,
                                    }))
                                  }}
                                />
                              </div>
                              <div>
                                <Label>Fecha</Label>
                                <Input
                                  type="date"
                                  value={selectedCompetencia === competencia.id ? newActivity.date : ""}
                                  onChange={(e) => {
                                    setSelectedCompetencia(competencia.id)
                                    setNewActivity((prev) => ({ ...prev, date: e.target.value }))
                                  }}
                                />
                              </div>
                            </div>
                            <Button
                              onClick={handleAddActivity}
                              className="mt-4"
                              disabled={selectedCompetencia !== competencia.id}
                            >
                              <Plus className="h-4 w-4 mr-2" />
                              Agregar Actividad
                            </Button>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                )
              })}

              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setConfigModalOpen(false)}>
                  Cancelar
                </Button>
                <Button onClick={handleSavePeriodConfig}>
                  <Save className="h-4 w-4 mr-2" />
                  Guardar Configuración
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Modal de ingreso de calificaciones */}
        <Dialog open={gradesModalOpen} onOpenChange={setGradesModalOpen}>
          <DialogContent className="max-w-6xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Ingresar Calificaciones - {selectedPeriod}</DialogTitle>
              <DialogDescription>
                Ingrese las calificaciones por competencia y actividad para cada estudiante.
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-6">
              <Tabs defaultValue={competenciasMinerd[0]?.id} className="w-full">
                <TabsList className="grid w-full grid-cols-6">
                  {competenciasMinerd.map((competencia) => (
                    <TabsTrigger key={competencia.id} value={competencia.id} className="text-xs">
                      {competencia.name.split(" ")[0]}
                    </TabsTrigger>
                  ))}
                </TabsList>

                {competenciasMinerd.map((competencia) => (
                  <TabsContent key={competencia.id} value={competencia.id}>
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <div className={`p-2 rounded-lg ${competencia.color} text-white`}>{competencia.icon}</div>
                          {competencia.name}
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="overflow-x-auto">
                          <Table>
                            <TableHeader>
                              <TableRow>
                                <TableHead>Estudiante</TableHead>
                                <TableHead className="text-center">Actividad 1</TableHead>
                                <TableHead className="text-center">Actividad 2</TableHead>
                                <TableHead className="text-center">Actividad 3</TableHead>
                                <TableHead className="text-center">Promedio</TableHead>
                              </TableRow>
                            </TableHeader>
                            <TableBody>
                              {students.map((student) => (
                                <TableRow key={student.id}>
                                  <TableCell>
                                    <div className="font-medium">{student.name}</div>
                                  </TableCell>
                                  <TableCell className="text-center">
                                    <Input
                                      type="number"
                                      min="0"
                                      max="100"
                                      className="w-20 text-center"
                                      placeholder="0-100"
                                      onChange={(e) =>
                                        handleActivityGradeChange(student.id, competencia.id, 0, e.target.value)
                                      }
                                    />
                                  </TableCell>
                                  <TableCell className="text-center">
                                    <Input
                                      type="number"
                                      min="0"
                                      max="100"
                                      className="w-20 text-center"
                                      placeholder="0-100"
                                      onChange={(e) =>
                                        handleActivityGradeChange(student.id, competencia.id, 1, e.target.value)
                                      }
                                    />
                                  </TableCell>
                                  <TableCell className="text-center">
                                    <Input
                                      type="number"
                                      min="0"
                                      max="100"
                                      className="w-20 text-center"
                                      placeholder="0-100"
                                      onChange={(e) =>
                                        handleActivityGradeChange(student.id, competencia.id, 2, e.target.value)
                                      }
                                    />
                                  </TableCell>
                                  <TableCell className="text-center">
                                    <Badge
                                      className={`${
                                        calculateActivityAverage(student.id, competencia.id) >= 70
                                          ? "bg-green-100 text-green-800"
                                          : calculateActivityAverage(student.id, competencia.id) >= 60
                                            ? "bg-yellow-100 text-yellow-800"
                                            : "bg-red-100 text-red-800"
                                      }`}
                                    >
                                      {calculateActivityAverage(student.id, competencia.id) || "-"}
                                    </Badge>
                                  </TableCell>
                                </TableRow>
                              ))}
                            </TableBody>
                          </Table>
                        </div>
                      </CardContent>
                    </Card>
                  </TabsContent>
                ))}
              </Tabs>

              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setGradesModalOpen(false)}>
                  Cancelar
                </Button>
                <Button>
                  <Save className="h-4 w-4 mr-2" />
                  Guardar Calificaciones
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Modal de detalle del estudiante */}
        <Dialog open={studentDetailModalOpen} onOpenChange={setStudentDetailModalOpen}>
          <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <div className="bg-blue-100 text-blue-800 px-3 py-1 rounded-lg text-sm font-medium">
                  {selectedStudentPeriod}
                </div>
                Todas las materias
              </DialogTitle>
              <DialogDescription>
                Detalle de evaluaciones por competencias para {selectedStudent?.name}
              </DialogDescription>
            </DialogHeader>

            {selectedStudent && (
              <div className="space-y-6">
                {/* Información del estudiante y materia */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <BookOpen className="h-5 w-5 text-green-600" />
                      {selectedCourse?.subject} ({selectedStudent.name})
                    </CardTitle>
                  </CardHeader>
                </Card>

                {/* Calificaciones Originales */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg text-gray-700">
                      Calificaciones Originales - {selectedCourse?.subject}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {competenciasMinerd.map((competencia) => {
                        const originalGrade = selectedStudent.competencias[selectedStudentPeriod]?.[competencia.id] || 0
                        return (
                          <div
                            key={competencia.id}
                            className="flex items-center justify-between p-4 bg-gray-50 rounded-lg border"
                          >
                            <div className="flex items-center gap-3">
                              <div className={`p-2 rounded-lg ${competencia.color} text-white`}>{competencia.icon}</div>
                              <span className="font-medium text-sm">{competencia.name}</span>
                            </div>
                            <Badge
                              className={`${
                                originalGrade >= 70
                                  ? "bg-green-100 text-green-800 border-green-200"
                                  : "bg-red-100 text-red-800 border-red-200"
                              } text-lg font-bold px-3 py-1`}
                            >
                              {originalGrade}
                            </Badge>
                          </div>
                        )
                      })}
                    </div>
                  </CardContent>
                </Card>

                {/* Recuperaciones Aplicadas (solo si hay recuperaciones) */}
                {selectedStudent.grades[`R${selectedStudentPeriod}`] && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg text-orange-700">
                        Recuperaciones Aplicadas - {selectedCourse?.subject}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        {competenciasMinerd.map((competencia) => {
                          const originalGrade =
                            selectedStudent.competencias[selectedStudentPeriod]?.[competencia.id] || 0
                          const recoveryGrade = originalGrade < 70 ? originalGrade + 10 : originalGrade // Simulamos recuperación

                          if (originalGrade < 70) {
                            return (
                              <div
                                key={competencia.id}
                                className="flex items-center justify-between p-4 bg-orange-50 rounded-lg border border-orange-200"
                              >
                                <div className="flex items-center gap-3">
                                  <div className={`p-2 rounded-lg ${competencia.color} text-white`}>
                                    {competencia.icon}
                                  </div>
                                  <span className="font-medium text-sm">{competencia.name}</span>
                                </div>
                                <div className="text-right">
                                  <Badge className="bg-orange-100 text-orange-800 border-orange-200 text-lg font-bold px-3 py-1">
                                    {recoveryGrade}
                                  </Badge>
                                  <div className="text-xs text-orange-600 mt-1">(Recuperación)</div>
                                </div>
                              </div>
                            )
                          }
                          return null
                        })}
                      </div>

                      {/* Mensaje de éxito */}
                      <div className="mt-4 p-3 bg-green-50 border border-green-200 rounded-lg">
                        <div className="flex items-center gap-2 text-green-700">
                          <CheckCircle className="h-4 w-4" />
                          <span className="text-sm font-medium">
                            ✓ Recuperaciones aplicadas en {selectedCourse?.subject} - Competencias elevadas por encima
                            de 70 puntos
                          </span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )}

                {/* Promedio Final */}
                <Card>
                  <CardContent className="pt-6">
                    <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg border border-blue-200">
                      <div className="flex items-center gap-2">
                        <Calculator className="h-5 w-5 text-blue-600" />
                        <span className="text-lg font-semibold text-blue-800">
                          Promedio {selectedStudentPeriod} - {selectedCourse?.subject}:
                        </span>
                      </div>
                      <Badge className="bg-blue-100 text-blue-800 border-blue-200 text-2xl font-bold px-4 py-2">
                        {selectedStudent.grades[selectedStudentPeriod] ||
                          selectedStudent.grades[`R${selectedStudentPeriod}`] ||
                          calculateCompetenciaAverage(selectedStudent.competencias[selectedStudentPeriod] || {})}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>

                {/* Botones de acción */}
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setStudentDetailModalOpen(false)}>
                    Cerrar
                  </Button>
                  <Button className="bg-blue-600 hover:bg-blue-700">
                    <Edit3 className="h-4 w-4 mr-2" />
                    Editar Calificaciones
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </main>
    </div>
  )
}
