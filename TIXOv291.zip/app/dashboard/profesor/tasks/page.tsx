"use client"

import { useState } from "react"
import { Header } from "@/components/dashboard/header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog"
import { PlusCircle, Search, Calendar, FileText, CheckCircle, XCircle, Clock, Download, Send, Bell, Eye, Filter, Upload, BarChart3, AlertTriangle, Paperclip, LinkIcon, BookOpen, Brain, Microscope, Lightbulb, Heart, User, Target, Edit } from 'lucide-react'
import Link from "next/link"

// Datos de ejemplo
const courses = [
  { id: 1, name: "1° A Primaria", subject: "Matemáticas" },
  { id: 2, name: "1° B Primaria", subject: "Matemáticas" },
  { id: 3, name: "2° A Primaria", subject: "Matemáticas" },
  { id: 4, name: "2° B Primaria", subject: "Matemáticas" },
]

const subjects = [
  { id: 1, name: "Matemáticas" },
  { id: 2, name: "Lenguaje" },
  { id: 3, name: "Ciencias Naturales" },
  { id: 4, name: "Ciencias Sociales" },
]

// Datos de ejemplo de tareas basadas en competencias
const tasks = [
  {
    id: 1,
    title: "Resolución de problemas matemáticos",
    description: "Resolver ejercicios aplicando pensamiento lógico y crítico para desarrollar habilidades de razonamiento.",
    course: "1° A Primaria",
    subject: "Matemáticas",
    competencia: "pensamiento",
    competenciaName: "Pensamiento Lógico, Creativo y Crítico",
    period: "P2",
    dueDate: "2024-06-15",
    status: "active",
    weight: 40,
    activityType: "Examen",
    attachments: [
      { name: "ejercicios_razonamiento.pdf", type: "pdf" },
      { name: "rubrica_evaluacion.pdf", type: "pdf" },
    ],
    submissions: [
      { studentId: 1, status: "submitted", date: "2024-06-14", grade: 85, comment: "Excelente razonamiento lógico" },
      { studentId: 2, status: "late", date: "2024-06-16", grade: 72, comment: "Entregado con retraso pero bien resuelto" },
      { studentId: 3, status: "submitted", date: "2024-06-15", grade: 90, comment: "Demuestra pensamiento crítico avanzado" },
      { studentId: 4, status: "not_submitted", date: "", grade: null, comment: "" },
      { studentId: 5, status: "submitted", date: "2024-06-13", grade: 78, comment: "Buen desarrollo del pensamiento lógico" },
    ],
  },
  {
    id: 2,
    title: "Comunicación oral - Exposición",
    description: "Presentación oral sobre un tema de interés para desarrollar competencias comunicativas.",
    course: "1° A Primaria",
    subject: "Lenguaje",
    competencia: "comunicativa",
    competenciaName: "Comunicativa",
    period: "P2",
    dueDate: "2024-06-20",
    status: "active",
    weight: 35,
    activityType: "Exposición",
    attachments: [{ name: "guia_exposicion.pdf", type: "pdf" }],
    submissions: [
      { studentId: 1, status: "submitted", date: "2024-06-18", grade: 88, comment: "Excelente expresión oral" },
      { studentId: 2, status: "not_submitted", date: "", grade: null, comment: "" },
      { studentId: 3, status: "submitted", date: "2024-06-19", grade: 92, comment: "Comunicación muy efectiva" },
      { studentId: 4, status: "not_submitted", date: "", grade: null, comment: "" },
    ],
  },
  {
    id: 3,
    title: "Proyecto de ciencias naturales",
    description: "Investigación sobre el medio ambiente para desarrollar competencias científicas y ambientales.",
    course: "1° B Primaria",
    subject: "Ciencias Naturales",
    competencia: "cientifica",
    competenciaName: "Científica y Tecnológica",
    period: "P1",
    dueDate: "2024-06-10",
    status: "completed",
    weight: 50,
    activityType: "Investigación",
    attachments: [
      { name: "guia_proyecto.pdf", type: "pdf" },
      { name: "formato_investigacion.docx", type: "document" },
    ],
    submissions: [
      { studentId: 6, status: "submitted", date: "2024-06-09", grade: 85, comment: "Investigación bien estructurada" },
      { studentId: 7, status: "submitted", date: "2024-06-10", grade: 90, comment: "Excelente método científico" },
      { studentId: 8, status: "submitted", date: "2024-06-08", grade: 95, comment: "Proyecto sobresaliente" },
      { studentId: 9, status: "not_submitted", date: "", grade: 0, comment: "No presentó el proyecto" },
    ],
  },
]

// Competencias oficiales del MINERD
const competenciasMinerd = [
  {
    id: "comunicativa",
    name: "Comunicativa",
    description: "Capacidad de comunicarse efectivamente",
    icon: <BookOpen className="h-4 w-4" />,
    color: "bg-blue-500",
  },
  {
    id: "pensamiento",
    name: "Pensamiento Lógico, Creativo y Crítico",
    description: "Resolución de problemas y pensamiento crítico",
    icon: <Brain className="h-4 w-4" />,
    color: "bg-purple-500",
  },
  {
    id: "cientifica",
    name: "Científica y Tecnológica",
    description: "Comprensión científica y tecnológica",
    icon: <Microscope className="h-4 w-4" />,
    color: "bg-green-500",
  },
  {
    id: "ambiental",
    name: "Ambiental y de la Salud",
    description: "Conciencia ambiental y cuidado de la salud",
    icon: <Lightbulb className="h-4 w-4" />,
    color: "bg-emerald-500",
  },
  {
    id: "etica",
    name: "Ética y Ciudadana",
    description: "Valores éticos y ciudadanos",
    icon: <Heart className="h-4 w-4" />,
    color: "bg-red-500",
  },
  {
    id: "personal",
    name: "Desarrollo Personal y Espiritual",
    description: "Crecimiento personal y espiritual",
    icon: <User className="h-4 w-4" />,
    color: "bg-orange-500",
  },
]

// Datos de ejemplo de estudiantes
const students = [
  { id: 1, name: "Ana García Pérez", photo: "/placeholder.svg?height=40&width=40&text=Ana" },
  { id: 2, name: "Carlos Mendoza López", photo: "/placeholder.svg?height=40&width=40&text=Carlos" },
  { id: 3, name: "María López Ruiz", photo: "/placeholder.svg?height=40&width=40&text=María" },
  { id: 4, name: "José Rodríguez Silva", photo: "/placeholder.svg?height=40&width=40&text=José" },
  { id: 5, name: "Laura Martínez Torres", photo: "/placeholder.svg?height=40&width=40&text=Laura" },
  { id: 6, name: "Pedro Sánchez Gómez", photo: "/placeholder.svg?height=40&width=40&text=Pedro" },
  { id: 7, name: "Sofía Ramírez Ortiz", photo: "/placeholder.svg?height=40&width=40&text=Sofía" },
  { id: 8, name: "Miguel Ángel Torres", photo: "/placeholder.svg?height=40&width=40&text=Miguel" },
  { id: 9, name: "Valentina Díaz Ruiz", photo: "/placeholder.svg?height=40&width=40&text=Valentina" },
  { id: 10, name: "Daniel Flores Vargas", photo: "/placeholder.svg?height=40&width=40&text=Daniel" },
  { id: 11, name: "Camila Morales Soto", photo: "/placeholder.svg?height=40&width=40&text=Camila" },
  { id: 12, name: "Alejandro Herrera", photo: "/placeholder.svg?height=40&width=40&text=Alejandro" },
  { id: 13, name: "Isabella Castro Ríos", photo: "/placeholder.svg?height=40&width=40&text=Isabella" },
]

export default function TasksPage() {
  const [activeTab, setActiveTab] = useState("all")
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedTask, setSelectedTask] = useState<any>(null)
  const [newTaskDialogOpen, setNewTaskDialogOpen] = useState(false)
  const [taskFilter, setTaskFilter] = useState({
    course: "",
    subject: "",
    status: "all",
  })

  // Formulario de nueva tarea
  const [newTask, setNewTask] = useState({
    title: "",
    description: "",
    course: "",
    subject: "",
    competencia: "",
    period: "",
    weight: 0,
    activityType: "",
    dueDate: "",
    attachments: [] as any[],
  })

  const [editTaskDialogOpen, setEditTaskDialogOpen] = useState(false)
  const [editingTask, setEditingTask] = useState<any>(null)

  // Filtrar tareas
  const filteredTasks = tasks.filter((task) => {
    const matchesSearch = task.title.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCourse = taskFilter.course === "" || task.course === taskFilter.course
    const matchesSubject = taskFilter.subject === "" || task.subject === taskFilter.subject
    const matchesStatus =
      taskFilter.status === "all" ||
      (taskFilter.status === "active" && task.status === "active") ||
      (taskFilter.status === "completed" && task.status === "completed")

    return matchesSearch && matchesCourse && matchesSubject && matchesStatus
  })

  // Manejar cambios en el formulario de nueva tarea
  const handleNewTaskChange = (field: string, value: any) => {
    setNewTask((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  // Agregar archivo adjunto
  const handleAddAttachment = () => {
    // Simulación de agregar un archivo
    const newAttachment = { name: "nuevo_archivo.pdf", type: "pdf" }
    setNewTask((prev) => ({
      ...prev,
      attachments: [...prev.attachments, newAttachment],
    }))
  }

  // Crear nueva tarea
  const handleCreateTask = () => {
    // Aquí iría la lógica para guardar la tarea en la base de datos
    console.log("Nueva tarea:", newTask)
    setNewTaskDialogOpen(false)
    alert("Tarea creada y notificada a los padres y alumnos")
  }

  const handleEditTask = (task: any) => {
    setEditingTask(task)
    setNewTask({
      title: task.title,
      description: task.description,
      course: task.course,
      subject: task.subject,
      competencia: task.competencia,
      period: task.period,
      weight: task.weight,
      activityType: task.activityType,
      dueDate: task.dueDate,
      attachments: task.attachments || [],
    })
    setEditTaskDialogOpen(true)
  }

  const handleUpdateTask = () => {
    // Aquí iría la lógica para actualizar la tarea en la base de datos
    console.log("Tarea actualizada:", newTask)
    setEditTaskDialogOpen(false)
    setEditingTask(null)
    alert("Tarea actualizada exitosamente")
  }

  // Actualizar estado de entrega
  const handleUpdateSubmissionStatus = (taskId: number, studentId: number, status: string) => {
    // Aquí iría la lógica para actualizar el estado en la base de datos
    console.log(`Actualizando estado de entrega: Tarea ${taskId}, Estudiante ${studentId}, Estado ${status}`)
    alert("Estado de entrega actualizado")
  }

  // Notificar al padre
  const handleNotifyParent = (taskId: number, studentId: number) => {
    // Aquí iría la lógica para enviar notificación
    console.log(`Notificando al padre: Tarea ${taskId}, Estudiante ${studentId}`)
    alert("Notificación enviada al padre vía WhatsApp")
  }

  // Obtener estudiante por ID
  const getStudentById = (id: number) => {
    return students.find((student) => student.id === id)
  }

  // Obtener color según estado de entrega
  const getSubmissionStatusColor = (status: string) => {
    switch (status) {
      case "submitted":
        return "bg-green-100 text-green-800 border-green-200"
      case "late":
        return "bg-yellow-100 text-yellow-800 border-yellow-200"
      case "not_submitted":
        return "bg-red-100 text-red-800 border-red-200"
      default:
        return "bg-gray-100 text-gray-800 border-gray-200"
    }
  }

  // Obtener icono según estado de entrega
  const getSubmissionStatusIcon = (status: string) => {
    switch (status) {
      case "submitted":
        return <CheckCircle className="h-3 w-3 mr-1" />
      case "late":
        return <Clock className="h-3 w-3 mr-1" />
      case "not_submitted":
        return <XCircle className="h-3 w-3 mr-1" />
      default:
        return null
    }
  }

  // Obtener texto según estado de entrega
  const getSubmissionStatusText = (status: string) => {
    switch (status) {
      case "submitted":
        return "Entregado"
      case "late":
        return "Fuera de fecha"
      case "not_submitted":
        return "No entregado"
      default:
        return "Desconocido"
    }
  }

  // Calcular estadísticas de entrega
  const calculateSubmissionStats = (submissions: any[]) => {
    const total = submissions.length
    const submitted = submissions.filter((s) => s.status === "submitted").length
    const late = submissions.filter((s) => s.status === "late").length
    const notSubmitted = submissions.filter((s) => s.status === "not_submitted").length

    return {
      total,
      submitted,
      late,
      notSubmitted,
      submittedPercentage: Math.round((submitted / total) * 100),
      latePercentage: Math.round((late / total) * 100),
      notSubmittedPercentage: Math.round((notSubmitted / total) * 100),
    }
  }

  const getGradeColor = (grade: number) => {
    if (grade >= 90) {
      return "bg-green-100 text-green-800 border-green-200"
    } else if (grade >= 80) {
      return "bg-blue-100 text-blue-800 border-blue-200"
    } else if (grade >= 70) {
      return "bg-yellow-100 text-yellow-800 border-yellow-200"
    } else {
      return "bg-red-100 text-red-800 border-red-200"
    }
  }

  return (
    <div className="flex-1 flex flex-col bg-gray-50">
      <Header title="Planificación de Tareas" />

      <main className="flex-1 overflow-y-auto p-6">
        {/* Acciones principales */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="Buscar tarea..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-white border-gray-300"
            />
          </div>
          <Dialog open={newTaskDialogOpen} onOpenChange={setNewTaskDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-indigo-600 hover:bg-indigo-700 text-white">
                <PlusCircle className="h-4 w-4 mr-2" />
                Crear Nueva Tarea
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-3xl">
              <DialogHeader>
                <DialogTitle>Crear Nueva Tarea</DialogTitle>
                <DialogDescription>
                  Completa el formulario para crear y asignar una nueva tarea a los estudiantes
                </DialogDescription>
              </DialogHeader>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 py-4">
                <div className="md:col-span-2">
                  <Label htmlFor="title" className="text-sm font-medium text-gray-700">
                    Título de la Tarea *
                  </Label>
                  <Input
                    id="title"
                    value={newTask.title}
                    onChange={(e) => handleNewTaskChange("title", e.target.value)}
                    className="mt-1 border-gray-300"
                    placeholder="Ej: Ejercicios de multiplicación"
                  />
                </div>
                <div className="md:col-span-2">
                  <Label htmlFor="description" className="text-sm font-medium text-gray-700">
                    Descripción Detallada *
                  </Label>
                  <Textarea
                    id="description"
                    value={newTask.description}
                    onChange={(e) => handleNewTaskChange("description", e.target.value)}
                    className="mt-1 min-h-[100px] border-gray-300"
                    placeholder="Instrucciones detalladas para los estudiantes..."
                  />
                </div>
                <div>
                  <Label htmlFor="course" className="text-sm font-medium text-gray-700">
                    Curso *
                  </Label>
                  <Select value={newTask.course} onValueChange={(value) => handleNewTaskChange("course", value)}>
                    <SelectTrigger className="mt-1 border-gray-300">
                      <SelectValue placeholder="Seleccionar curso" />
                    </SelectTrigger>
                    <SelectContent>
                      {courses.map((course) => (
                        <SelectItem key={course.id} value={course.name}>
                          {course.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="subject" className="text-sm font-medium text-gray-700">
                    Materia *
                  </Label>
                  <Select value={newTask.subject} onValueChange={(value) => handleNewTaskChange("subject", value)}>
                    <SelectTrigger className="mt-1 border-gray-300">
                      <SelectValue placeholder="Seleccionar materia" />
                    </SelectTrigger>
                    <SelectContent>
                      {subjects.map((subject) => (
                        <SelectItem key={subject.id} value={subject.name}>
                          {subject.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="competencia" className="text-sm font-medium text-gray-700">
                    Competencia *
                  </Label>
                  <Select value={newTask.competencia} onValueChange={(value) => handleNewTaskChange("competencia", value)}>
                    <SelectTrigger className="mt-1 border-gray-300">
                      <SelectValue placeholder="Seleccionar competencia" />
                    </SelectTrigger>
                    <SelectContent>
                      {competenciasMinerd.map((competencia) => (
                        <SelectItem key={competencia.id} value={competencia.id}>
                          {competencia.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="period" className="text-sm font-medium text-gray-700">
                    Período *
                  </Label>
                  <Select value={newTask.period} onValueChange={(value) => handleNewTaskChange("period", value)}>
                    <SelectTrigger className="mt-1 border-gray-300">
                      <SelectValue placeholder="Seleccionar período" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="P1">Período 1</SelectItem>
                      <SelectItem value="P2">Período 2</SelectItem>
                      <SelectItem value="P3">Período 3</SelectItem>
                      <SelectItem value="P4">Período 4</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="weight" className="text-sm font-medium text-gray-700">
                    Ponderación (%) *
                  </Label>
                  <Input
                    id="weight"
                    type="number"
                    min="1"
                    max="100"
                    value={newTask.weight}
                    onChange={(e) => handleNewTaskChange("weight", parseInt(e.target.value) || 0)}
                    className="mt-1 border-gray-300"
                    placeholder="Ej: 40"
                  />
                </div>
                <div>
                  <Label htmlFor="activityType" className="text-sm font-medium text-gray-700">
                    Tipo de Actividad *
                  </Label>
                  <Select value={newTask.activityType} onValueChange={(value) => handleNewTaskChange("activityType", value)}>
                    <SelectTrigger className="mt-1 border-gray-300">
                      <SelectValue placeholder="Seleccionar tipo" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Examen">Examen</SelectItem>
                      <SelectItem value="Trabajo">Trabajo</SelectItem>
                      <SelectItem value="Ensayo">Ensayo</SelectItem>
                      <SelectItem value="Exposición">Exposición</SelectItem>
                      <SelectItem value="Maqueta">Maqueta</SelectItem>
                      <SelectItem value="Prueba">Prueba</SelectItem>
                      <SelectItem value="Investigación">Investigación</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="dueDate" className="text-sm font-medium text-gray-700">
                    Fecha Límite *
                  </Label>
                  <Input
                    id="dueDate"
                    type="date"
                    value={newTask.dueDate}
                    onChange={(e) => handleNewTaskChange("dueDate", e.target.value)}
                    className="mt-1 border-gray-300"
                  />
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-700">Adjuntos (Máx. 5)</Label>
                  <div className="mt-1 flex items-center space-x-2">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={handleAddAttachment}
                      className="border-gray-300 text-gray-700"
                      disabled={newTask.attachments.length >= 5}
                    >
                      <Upload className="h-4 w-4 mr-2" />
                      Subir Archivo
                    </Button>
                    <Button
                      type="button"
                      variant="outline"
                      className="border-gray-300 text-gray-700"
                      disabled={newTask.attachments.length >= 5}
                    >
                      <LinkIcon className="h-4 w-4 mr-2" />
                      Agregar Enlace
                    </Button>
                  </div>
                  {newTask.attachments.length > 0 && (
                    <div className="mt-2 space-y-1">
                      {newTask.attachments.map((attachment, index) => (
                        <div key={index} className="flex items-center text-sm text-gray-600">
                          <Paperclip className="h-3 w-3 mr-1" />
                          {attachment.name}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
                <div className="md:col-span-2">
                  <div className="flex items-center space-x-2 text-sm text-blue-600 bg-blue-50 p-3 rounded-md border border-blue-200">
                    <Bell className="h-4 w-4" />
                    <span>
                      Al crear la tarea, se enviará una notificación automática a los padres y alumnos vía WhatsApp y
                      correo electrónico.
                    </span>
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setNewTaskDialogOpen(false)}
                  className="border-gray-300 text-gray-700"
                >
                  Cancelar
                </Button>
                <Button
                  type="button"
                  onClick={handleCreateTask}
                  className="bg-indigo-600 hover:bg-indigo-700 text-white"
                  disabled={!newTask.title || !newTask.course || !newTask.subject || !newTask.competencia || !newTask.period || !newTask.weight || !newTask.activityType || !newTask.dueDate}
                >
                  <Send className="h-4 w-4 mr-2" />
                  Crear y Notificar
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
          <Dialog open={editTaskDialogOpen} onOpenChange={setEditTaskDialogOpen}>
            <DialogContent className="max-w-3xl">
              <DialogHeader>
                <DialogTitle>Editar Tarea</DialogTitle>
                <DialogDescription>
                  Modifica los detalles de la tarea para completar su configuración
                </DialogDescription>
              </DialogHeader>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 py-4">
                <div className="md:col-span-2">
                  <Label htmlFor="edit-title" className="text-sm font-medium text-gray-700">
                    Título de la Tarea *
                  </Label>
                  <Input
                    id="edit-title"
                    value={newTask.title}
                    onChange={(e) => handleNewTaskChange("title", e.target.value)}
                    className="mt-1 border-gray-300"
                    placeholder="Ej: Ejercicios de multiplicación"
                  />
                </div>
                <div className="md:col-span-2">
                  <Label htmlFor="edit-description" className="text-sm font-medium text-gray-700">
                    Descripción Detallada *
                  </Label>
                  <Textarea
                    id="edit-description"
                    value={newTask.description}
                    onChange={(e) => handleNewTaskChange("description", e.target.value)}
                    className="mt-1 min-h-[100px] border-gray-300"
                    placeholder="Instrucciones detalladas para los estudiantes..."
                  />
                </div>
                <div>
                  <Label htmlFor="edit-course" className="text-sm font-medium text-gray-700">
                    Curso *
                  </Label>
                  <Select value={newTask.course} onValueChange={(value) => handleNewTaskChange("course", value)}>
                    <SelectTrigger className="mt-1 border-gray-300">
                      <SelectValue placeholder="Seleccionar curso" />
                    </SelectTrigger>
                    <SelectContent>
                      {courses.map((course) => (
                        <SelectItem key={course.id} value={course.name}>
                          {course.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="edit-subject" className="text-sm font-medium text-gray-700">
                    Materia *
                  </Label>
                  <Select value={newTask.subject} onValueChange={(value) => handleNewTaskChange("subject", value)}>
                    <SelectTrigger className="mt-1 border-gray-300">
                      <SelectValue placeholder="Seleccionar materia" />
                    </SelectTrigger>
                    <SelectContent>
                      {subjects.map((subject) => (
                        <SelectItem key={subject.id} value={subject.name}>
                          {subject.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="edit-competencia" className="text-sm font-medium text-gray-700">
                    Competencia *
                  </Label>
                  <Select value={newTask.competencia} onValueChange={(value) => handleNewTaskChange("competencia", value)}>
                    <SelectTrigger className="mt-1 border-gray-300">
                      <SelectValue placeholder="Seleccionar competencia" />
                    </SelectTrigger>
                    <SelectContent>
                      {competenciasMinerd.map((competencia) => (
                        <SelectItem key={competencia.id} value={competencia.id}>
                          {competencia.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="edit-period" className="text-sm font-medium text-gray-700">
                    Período *
                  </Label>
                  <Select value={newTask.period} onValueChange={(value) => handleNewTaskChange("period", value)}>
                    <SelectTrigger className="mt-1 border-gray-300">
                      <SelectValue placeholder="Seleccionar período" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="P1">Período 1</SelectItem>
                      <SelectItem value="P2">Período 2</SelectItem>
                      <SelectItem value="P3">Período 3</SelectItem>
                      <SelectItem value="P4">Período 4</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="edit-weight" className="text-sm font-medium text-gray-700">
                    Ponderación (%) *
                  </Label>
                  <Input
                    id="edit-weight"
                    type="number"
                    min="1"
                    max="100"
                    value={newTask.weight}
                    onChange={(e) => handleNewTaskChange("weight", parseInt(e.target.value) || 0)}
                    className="mt-1 border-gray-300"
                    placeholder="Ej: 40"
                  />
                </div>
                <div>
                  <Label htmlFor="edit-activityType" className="text-sm font-medium text-gray-700">
                    Tipo de Actividad *
                  </Label>
                  <Select value={newTask.activityType} onValueChange={(value) => handleNewTaskChange("activityType", value)}>
                    <SelectTrigger className="mt-1 border-gray-300">
                      <SelectValue placeholder="Seleccionar tipo" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Examen">Examen</SelectItem>
                      <SelectItem value="Trabajo">Trabajo</SelectItem>
                      <SelectItem value="Ensayo">Ensayo</SelectItem>
                      <SelectItem value="Exposición">Exposición</SelectItem>
                      <SelectItem value="Maqueta">Maqueta</SelectItem>
                      <SelectItem value="Prueba">Prueba</SelectItem>
                      <SelectItem value="Investigación">Investigación</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="edit-dueDate" className="text-sm font-medium text-gray-700">
                    Fecha Límite *
                  </Label>
                  <Input
                    id="edit-dueDate"
                    type="date"
                    value={newTask.dueDate}
                    onChange={(e) => handleNewTaskChange("dueDate", e.target.value)}
                    className="mt-1 border-gray-300"
                  />
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-700">Adjuntos (Máx. 5)</Label>
                  <div className="mt-1 flex items-center space-x-2">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={handleAddAttachment}
                      className="border-gray-300 text-gray-700"
                      disabled={newTask.attachments.length >= 5}
                    >
                      <Upload className="h-4 w-4 mr-2" />
                      Subir Archivo
                    </Button>
                    <Button
                      type="button"
                      variant="outline"
                      className="border-gray-300 text-gray-700"
                      disabled={newTask.attachments.length >= 5}
                    >
                      <LinkIcon className="h-4 w-4 mr-2" />
                      Agregar Enlace
                    </Button>
                  </div>
                  {newTask.attachments.length > 0 && (
                    <div className="mt-2 space-y-1">
                      {newTask.attachments.map((attachment, index) => (
                        <div key={index} className="flex items-center text-sm text-gray-600">
                          <Paperclip className="h-3 w-3 mr-1" />
                          {attachment.name}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
                <div className="md:col-span-2">
                  <div className="flex items-center space-x-2 text-sm text-blue-600 bg-blue-50 p-3 rounded-md border border-blue-200">
                    <Bell className="h-4 w-4" />
                    <span>
                      Al actualizar la tarea, se enviará una notificación a los padres y alumnos sobre los cambios realizados.
                    </span>
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    setEditTaskDialogOpen(false)
                    setEditingTask(null)
                  }}
                  className="border-gray-300 text-gray-700"
                >
                  Cancelar
                </Button>
                <Button
                  type="button"
                  onClick={handleUpdateTask}
                  className="bg-indigo-600 hover:bg-indigo-700 text-white"
                  disabled={!newTask.title || !newTask.course || !newTask.subject || !newTask.competencia || !newTask.period || !newTask.weight || !newTask.activityType || !newTask.dueDate}
                >
                  <Send className="h-4 w-4 mr-2" />
                  Actualizar Tarea
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        {/* Filtros */}
        <Card className="bg-white border border-gray-200 mb-6">
          <CardHeader>
            <CardTitle className="text-gray-900 flex items-center">
              <Filter className="h-5 w-5 mr-2 text-indigo-600" />
              Filtros
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="courseFilter" className="text-sm font-medium text-gray-700">
                  Curso
                </Label>
                <Select
                  value={taskFilter.course}
                  onValueChange={(value) => setTaskFilter((prev) => ({ ...prev, course: value }))}
                >
                  <SelectTrigger className="border-gray-300">
                    <SelectValue placeholder="Todos los cursos" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos los cursos</SelectItem>
                    {courses.map((course) => (
                      <SelectItem key={course.id} value={course.name}>
                        {course.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="subjectFilter" className="text-sm font-medium text-gray-700">
                  Materia
                </Label>
                <Select
                  value={taskFilter.subject}
                  onValueChange={(value) => setTaskFilter((prev) => ({ ...prev, subject: value }))}
                >
                  <SelectTrigger className="border-gray-300">
                    <SelectValue placeholder="Todas las materias" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todas las materias</SelectItem>
                    {subjects.map((subject) => (
                      <SelectItem key={subject.id} value={subject.name}>
                        {subject.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="statusFilter" className="text-sm font-medium text-gray-700">
                  Estado
                </Label>
                <Select
                  value={taskFilter.status}
                  onValueChange={(value) => setTaskFilter((prev) => ({ ...prev, status: value }))}
                >
                  <SelectTrigger className="border-gray-300">
                    <SelectValue placeholder="Todos los estados" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos los estados</SelectItem>
                    <SelectItem value="active">Activas</SelectItem>
                    <SelectItem value="completed">Completadas</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Pestañas */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full mb-6">
          <TabsList className="grid w-full grid-cols-3 bg-white border border-gray-200">
            <TabsTrigger value="all" className="data-[state=active]:bg-indigo-600 data-[state=active]:text-white">
              Todas las Tareas
            </TabsTrigger>
            <TabsTrigger value="active" className="data-[state=active]:bg-indigo-600 data-[state=active]:text-white">
              Tareas Activas
            </TabsTrigger>
            <TabsTrigger value="completed" className="data-[state=active]:bg-indigo-600 data-[state=active]:text-white">
              Tareas Completadas
            </TabsTrigger>
          </TabsList>
        </Tabs>

        {/* Lista de tareas */}
        {filteredTasks.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
            {filteredTasks.map((task) => (
              <Card
                key={task.id}
                className="bg-white border border-gray-200 hover:border-indigo-300 hover:shadow-md transition-all"
              >
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <CardTitle className="text-lg text-gray-900">{task.title}</CardTitle>
                    <Badge
                      className={
                        task.status === "active"
                          ? "bg-green-100 text-green-800 border-green-200"
                          : "bg-gray-100 text-gray-800 border-gray-200"
                      }
                    >
                      {task.status === "active" ? "Activa" : "Completada"}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="pt-2">
                  <div className="space-y-4">
                    <p className="text-sm text-gray-600 line-clamp-2">{task.description}</p>

                    <div className="flex flex-wrap gap-2">
                      <Badge variant="outline" className="bg-blue-50 text-blue-800 border-blue-200">
                        <FileText className="h-3 w-3 mr-1" />
                        {task.course}
                      </Badge>
                      <Badge variant="outline" className="bg-purple-50 text-purple-800 border-purple-200">
                        <Target className="h-3 w-3 mr-1" />
                        {task.period}
                      </Badge>
                      <Badge variant="outline" className="bg-green-50 text-green-800 border-green-200">
                        {competenciasMinerd.find(c => c.id === task.competencia)?.icon}
                        <span className="ml-1">{task.competenciaName}</span>
                      </Badge>
                      <Badge variant="outline" className="bg-amber-50 text-amber-800 border-amber-200">
                        <Calendar className="h-3 w-3 mr-1" />
                        {task.dueDate}
                      </Badge>
                      <Badge variant="outline" className="bg-indigo-50 text-indigo-800 border-indigo-200">
                        {task.weight}% - {task.activityType}
                      </Badge>
                    </div>

                    {task.attachments.length > 0 && (
                      <div className="text-xs text-gray-500">
                        <span className="font-medium">Adjuntos:</span> {task.attachments.length} archivo(s)
                      </div>
                    )}

                    <div className="flex items-center justify-between">
                      <div className="flex -space-x-2">
                        {task.submissions.slice(0, 3).map((submission, index) => {
                          const student = getStudentById(submission.studentId)
                          return (
                            <Avatar key={index} className="h-6 w-6 border-2 border-white">
                              <AvatarImage src={student?.photo || ""} alt={student?.name || ""} />
                              <AvatarFallback className="text-[10px] bg-indigo-100 text-indigo-600">
                                {student?.name
                                  .split(" ")
                                  .map((n) => n[0])
                                  .join("")
                                  .slice(0, 2)}
                              </AvatarFallback>
                            </Avatar>
                          )
                        })}
                        {task.submissions.length > 3 && (
                          <div className="h-6 w-6 rounded-full bg-gray-200 flex items-center justify-center text-xs text-gray-600 border-2 border-white">
                            +{task.submissions.length - 3}
                          </div>
                        )}
                      </div>

                      <div className="flex space-x-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleEditTask(task)}
                          className="border-gray-300 text-gray-700 hover:bg-gray-50"
                        >
                          <Edit className="h-3 w-3 mr-1" />
                          Editar
                        </Button>
                        <Button
                          size="sm"
                          onClick={() => setSelectedTask(task)}
                          className="bg-indigo-600 hover:bg-indigo-700 text-white"
                        >
                          <Eye className="h-3 w-3 mr-1" />
                          Ver Detalle
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="bg-white border border-gray-200 mb-6">
            <CardContent className="p-12 text-center">
              <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No se encontraron tareas</h3>
              <p className="text-gray-500">No hay tareas que coincidan con los filtros seleccionados</p>
            </CardContent>
          </Card>
        )}

        {/* Detalle de tarea seleccionada */}
        {selectedTask && (
          <Card className="bg-white border border-gray-200 mb-6">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-gray-900 flex items-center">
                  <FileText className="h-5 w-5 mr-2 text-indigo-600" />
                  Detalle de Tarea: {selectedTask.title}
                </CardTitle>
                <div className="flex space-x-2">
                  <Button
                    variant="outline"
                    onClick={() => setSelectedTask(null)}
                    className="border-gray-300 text-gray-700"
                  >
                    Volver a la Lista
                  </Button>
                  <Button variant="outline" className="border-gray-300 text-gray-700">
                    <Download className="h-4 w-4 mr-2" />
                    Exportar
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {/* Información de la tarea */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <h3 className="text-sm font-medium text-gray-700">Descripción</h3>
                      <p className="mt-1 text-gray-600">{selectedTask.description}</p>
                    </div>
                    <div>
                      <h3 className="text-sm font-medium text-gray-700">Curso y Materia</h3>
                      <div className="mt-1 flex space-x-2">
                        <Badge variant="outline" className="bg-blue-50 text-blue-800 border-blue-200">
                          {selectedTask.course}
                        </Badge>
                        <Badge variant="outline" className="bg-purple-50 text-purple-800 border-purple-200">
                          {selectedTask.subject}
                        </Badge>
                      </div>
                    </div>
                    <div>
                      <h3 className="text-sm font-medium text-gray-700">Fecha Límite</h3>
                      <p className="mt-1 text-gray-600 flex items-center">
                        <Calendar className="h-4 w-4 mr-1 text-amber-600" />
                        {selectedTask.dueDate}
                      </p>
                    </div>
                    <div>
                      <h3 className="text-sm font-medium text-gray-700">Competencia y Período</h3>
                      <div className="mt-1 flex space-x-2">
                        <Badge variant="outline" className="bg-green-50 text-green-800 border-green-200">
                          {competenciasMinerd.find(c => c.id === selectedTask.competencia)?.icon}
                          <span className="ml-1">{selectedTask.competenciaName}</span>
                        </Badge>
                        <Badge variant="outline" className="bg-purple-50 text-purple-800 border-purple-200">
                          {selectedTask.period}
                        </Badge>
                        <Badge variant="outline" className="bg-indigo-50 text-indigo-800 border-indigo-200">
                          {selectedTask.weight}% - {selectedTask.activityType}
                        </Badge>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-4">
                    <div>
                      <h3 className="text-sm font-medium text-gray-700">Archivos Adjuntos</h3>
                      {selectedTask.attachments.length > 0 ? (
                        <div className="mt-1 space-y-2">
                          {selectedTask.attachments.map((attachment: any, index: number) => (
                            <div
                              key={index}
                              className="flex items-center p-2 border border-gray-200 rounded-md hover:bg-gray-50"
                            >
                              <Paperclip className="h-4 w-4 text-gray-500 mr-2" />
                              <span className="text-sm text-gray-600">{attachment.name}</span>
                              <Button size="sm" variant="ghost" className="ml-auto h-8 w-8 p-0">
                                <Download className="h-4 w-4 text-gray-500" />
                              </Button>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <p className="mt-1 text-gray-500 text-sm">No hay archivos adjuntos</p>
                      )}
                    </div>
                    <div>
                      <h3 className="text-sm font-medium text-gray-700">Estadísticas de Entrega</h3>
                      <div className="mt-2">
                        {(() => {
                          const stats = calculateSubmissionStats(selectedTask.submissions)
                          return (
                            <div className="space-y-2">
                              <div className="flex items-center justify-between text-sm">
                                <span className="text-gray-600">Entregados:</span>
                                <Badge className="bg-green-100 text-green-800 border-green-200">
                                  {stats.submitted} ({stats.submittedPercentage}%)
                                </Badge>
                              </div>
                              <div className="w-full bg-gray-200 rounded-full h-2">
                                <div
                                  className="bg-green-500 h-2 rounded-full"
                                  style={{ width: `${stats.submittedPercentage}%` }}
                                ></div>
                              </div>
                              <div className="flex items-center justify-between text-sm">
                                <span className="text-gray-600">Fuera de fecha:</span>
                                <Badge className="bg-yellow-100 text-yellow-800 border-yellow-200">
                                  {stats.late} ({stats.latePercentage}%)
                                </Badge>
                              </div>
                              <div className="w-full bg-gray-200 rounded-full h-2">
                                <div
                                  className="bg-yellow-500 h-2 rounded-full"
                                  style={{ width: `${stats.latePercentage}%` }}
                                ></div>
                              </div>
                              <div className="flex items-center justify-between text-sm">
                                <span className="text-gray-600">No entregados:</span>
                                <Badge className="bg-red-100 text-red-800 border-red-200">
                                  {stats.notSubmitted} ({stats.notSubmittedPercentage}%)
                                </Badge>
                              </div>
                              <div className="w-full bg-gray-200 rounded-full h-2">
                                <div
                                  className="bg-red-500 h-2 rounded-full"
                                  style={{ width: `${stats.notSubmittedPercentage}%` }}
                                ></div>
                              </div>
                            </div>
                          )
                        })()}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Tabla de seguimiento por estudiante */}
                <div>
                  <h3 className="text-base font-medium text-gray-900 mb-3">Seguimiento por Estudiante</h3>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="text-gray-700">Estudiante</TableHead>
                        <TableHead className="text-gray-700">Estado</TableHead>
                        <TableHead className="text-gray-700">Fecha de Entrega</TableHead>
                        <TableHead className="text-gray-700">Calificación</TableHead>
                        <TableHead className="text-gray-700">Comentario</TableHead>
                        <TableHead className="text-gray-700 text-right">Acciones</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {selectedTask.submissions.map((submission: any, index: number) => {
                        const student = getStudentById(submission.studentId)
                        return (
                          <TableRow key={index}>
                            <TableCell>
                              <div className="flex items-center space-x-3">
                                <Avatar className="h-8 w-8">
                                  <AvatarImage src={student?.photo || ""} alt={student?.name || ""} />
                                  <AvatarFallback className="bg-indigo-100 text-indigo-600 text-xs">
                                    {student?.name
                                      .split(" ")
                                      .map((n) => n[0])
                                      .join("")
                                      .slice(0, 2)}
                                  </AvatarFallback>
                                </Avatar>
                                <div>
                                  <Link
                                    href={`/dashboard/profesor/history?student=${student?.id}`}
                                    className="font-medium text-indigo-600 hover:text-indigo-800 hover:underline"
                                  >
                                    {student?.name}
                                  </Link>
                                </div>
                              </div>
                            </TableCell>
                            <TableCell>
                              <Badge className={getSubmissionStatusColor(submission.status)}>
                                {getSubmissionStatusIcon(submission.status)}
                                {getSubmissionStatusText(submission.status)}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              {submission.date ? (
                                <span className="text-gray-600">{submission.date}</span>
                              ) : (
                                <span className="text-gray-400">-</span>
                              )}
                            </TableCell>
                            <TableCell className="text-center">
                              {submission.grade !== null ? (
                                <Badge className={getGradeColor(submission.grade)}>
                                  {submission.grade}
                                </Badge>
                              ) : (
                                <span className="text-gray-400">-</span>
                              )}
                            </TableCell>
                            <TableCell>
                              <Dialog>
                                <DialogTrigger asChild>
                                  <Button size="sm" variant="outline" className="w-full border-gray-300 text-gray-700">
                                    {submission.comment ? "Ver/Editar" : "Agregar"}
                                  </Button>
                                </DialogTrigger>
                                <DialogContent>
                                  <DialogHeader>
                                    <DialogTitle>Comentario para {student?.name}</DialogTitle>
                                    <DialogDescription>
                                      Agrega un comentario sobre la entrega del estudiante
                                    </DialogDescription>
                                  </DialogHeader>
                                  <div className="space-y-4 mt-4">
                                    <Textarea
                                      placeholder="Escribir comentario..."
                                      defaultValue={submission.comment}
                                      className="min-h-[100px] border-gray-300"
                                    />
                                    <div className="flex justify-end">
                                      <Button className="bg-indigo-600 hover:bg-indigo-700 text-white">
                                        Guardar Comentario
                                      </Button>
                                    </div>
                                  </div>
                                </DialogContent>
                              </Dialog>
                            </TableCell>
                            <TableCell className="text-right">
                              <div className="flex justify-end space-x-1">
                                <Select
                                  defaultValue={submission.status}
                                  onValueChange={(value) =>
                                    handleUpdateSubmissionStatus(selectedTask.id, submission.studentId, value)
                                  }
                                >
                                  <SelectTrigger className="w-[130px] h-8 text-xs border-gray-300">
                                    <SelectValue placeholder="Cambiar estado" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="submitted">Entregado</SelectItem>
                                    <SelectItem value="late">Fuera de fecha</SelectItem>
                                    <SelectItem value="not_submitted">No entregado</SelectItem>
                                  </SelectContent>
                                </Select>
                                <Button
                                  size="sm"
                                  onClick={() => handleNotifyParent(selectedTask.id, submission.studentId)}
                                  className="bg-blue-600 hover:bg-blue-700 text-white"
                                  disabled={submission.status === "submitted"}
                                >
                                  <Bell className="h-3 w-3" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        )
                      })}
                    </TableBody>
                  </Table>
                </div>

                {/* Alerta de notificación */}
                {selectedTask.submissions.filter((s: any) => s.status === "not_submitted").length > 0 && (
                  <div className="flex items-center p-4 bg-yellow-50 border border-yellow-200 rounded-md">
                    <AlertTriangle className="h-5 w-5 text-yellow-600 mr-3" />
                    <div className="flex-1">
                      <p className="text-sm font-medium text-yellow-800">
                        {selectedTask.submissions.filter((s: any) => s.status === "not_submitted").length} estudiantes
                        aún no han entregado esta tarea
                      </p>
                      <p className="text-xs text-yellow-600 mt-1">
                        Puedes enviar una notificación a los padres haciendo clic en el botón de campana.
                      </p>
                    </div>
                    <Button
                      onClick={() => alert("Notificaciones enviadas a todos los padres de estudiantes sin entrega")}
                      className="bg-yellow-600 hover:bg-yellow-700 text-white"
                    >
                      <Bell className="h-4 w-4 mr-2" />
                      Notificar a Todos
                    </Button>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Estadísticas generales */}
        <Card className="bg-white border border-gray-200">
          <CardHeader>
            <CardTitle className="text-gray-900 flex items-center">
              <BarChart3 className="h-5 w-5 mr-2 text-indigo-600" />
              Estadísticas de Cumplimiento
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <div className="h-64 flex items-center justify-center">
              <p className="text-gray-500 text-center">
                Gráfica mostrando el porcentaje de cumplimiento de tareas por curso
              </p>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
