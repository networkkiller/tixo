"use client"

import type React from "react"

import { useState } from "react"
import { Header } from "@/components/dashboard/header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { MessageSquare, Send, Search, Paperclip, Phone, Mail, Bell, Users, UserCheck, CalendarIcon, Clock, Eye, RotateCcw, Trash2, Filter, Plus, FileText, TrendingDown, CalendarDays, UserX, Building, CheckCircle, XCircle, AlertCircle, MoreVertical } from 'lucide-react'

// Datos simulados
const teacherCourses = [
  {
    id: "1a-primaria",
    name: "1° A Primaria",
    students: [
      { id: "1", name: "Ana García", parent: "María García", parentEmail: "maria.garcia@email.com", parentPhone: "+1234567890" },
      { id: "2", name: "Luis Rodríguez", parent: "Carlos Rodríguez", parentEmail: "carlos.rodriguez@email.com", parentPhone: "+1234567891" },
      { id: "3", name: "Sofia Martínez", parent: "Elena Martínez", parentEmail: "elena.martinez@email.com", parentPhone: "+1234567892" },
    ]
  },
  {
    id: "2b-primaria",
    name: "2° B Primaria",
    students: [
      { id: "4", name: "Diego López", parent: "Ana López", parentEmail: "ana.lopez@email.com", parentPhone: "+1234567893" },
      { id: "5", name: "Camila Torres", parent: "Roberto Torres", parentEmail: "roberto.torres@email.com", parentPhone: "+1234567894" },
    ]
  }
]

const administrativeStaff = [
  { id: "director", name: "Director", role: "Director General" },
  { id: "coord-academico", name: "Coordinador Académico", role: "Coordinación Académica" },
  { id: "coord-registro", name: "Coordinador de Registro", role: "Registro y Control" },
  { id: "contable", name: "Contable", role: "Área Financiera" },
]

const messageTemplates = [
  {
    id: "tarea",
    title: "📌 Notificación de Tarea",
    description: "Informar sobre una tarea asignada y su fecha límite",
    subject: "Nueva tarea asignada - [Materia]",
    content: "Estimado padre de familia,\n\nLe informo que se ha asignado una nueva tarea a su hijo(a) en la materia de [MATERIA].\n\nDescripción: [DESCRIPCIÓN DE LA TAREA]\nFecha de entrega: [FECHA]\n\nPor favor, apoye a su hijo(a) en la realización de esta actividad.\n\nSaludos cordiales,\nProf. [NOMBRE]"
  },
  {
    id: "rendimiento",
    title: "📉 Rendimiento Bajo",
    description: "Alertar al padre sobre bajo desempeño de su hijo",
    subject: "Seguimiento académico - [Estudiante]",
    content: "Estimado padre de familia,\n\nMe dirijo a usted para informarle sobre el rendimiento académico de su hijo(a) [NOMBRE DEL ESTUDIANTE] en la materia de [MATERIA].\n\nHe observado algunas dificultades en:\n- [ÁREA DE DIFICULTAD 1]\n- [ÁREA DE DIFICULTAD 2]\n\nMe gustaría coordinar una reunión para establecer estrategias de apoyo.\n\nQuedo atento a su respuesta.\n\nSaludos cordiales,\nProf. [NOMBRE]"
  },
  {
    id: "reunion",
    title: "📆 Reunión de Padres",
    description: "Convocatoria a reunión presencial o virtual",
    subject: "Convocatoria a Reunión de Padres",
    content: "Estimados padres de familia,\n\nTengo el gusto de convocarlos a la reunión de padres que se realizará:\n\nFecha: [FECHA]\nHora: [HORA]\nLugar: [LUGAR/ENLACE]\nTema: [TEMA PRINCIPAL]\n\nSu participación es muy importante para el seguimiento académico de sus hijos.\n\nConfirmen su asistencia por favor.\n\nSaludos cordiales,\nProf. [NOMBRE]"
  },
  {
    id: "ausencia",
    title: "🚫 Ausencia Reiterada",
    description: "Informar al padre sobre ausencias repetidas",
    subject: "Notificación de Ausencias - [Estudiante]",
    content: "Estimado padre de familia,\n\nLe informo que su hijo(a) [NOMBRE DEL ESTUDIANTE] ha presentado ausencias reiteradas en las siguientes fechas:\n\n- [FECHA 1]\n- [FECHA 2]\n- [FECHA 3]\n\nEs importante mantener la asistencia regular para no afectar el rendimiento académico.\n\nPor favor, justifique las ausencias o póngase en contacto conmigo.\n\nSaludos cordiales,\nProf. [NOMBRE]"
  }
]

const sentMessages = [
  {
    id: 1,
    date: "2025-01-17",
    subject: "Reunión de Padres",
    recipients: "1° A Primaria - Padres",
    type: "Externo",
    channels: ["WhatsApp", "Email"],
    status: "Enviado",
    readCount: 8,
    totalCount: 12
  },
  {
    id: 2,
    date: "2025-01-15",
    subject: "Evaluación Competencia 1",
    recipients: "Coordinador Académico",
    type: "Interno",
    channels: ["Interna"],
    status: "Leído",
    readCount: 1,
    totalCount: 1
  },
  {
    id: 3,
    date: "2025-01-10",
    subject: "Tarea de Matemáticas",
    recipients: "2° B Primaria - Padres",
    type: "Externo",
    channels: ["WhatsApp", "Email"],
    status: "Enviado",
    readCount: 4,
    totalCount: 5
  }
]

export default function CommunicationModule() {
  const [showNewMessageDialog, setShowNewMessageDialog] = useState(false)
  const [messageType, setMessageType] = useState<"parents" | "admin">("parents")
  const [selectedCourse, setSelectedCourse] = useState("")
  const [selectedStudents, setSelectedStudents] = useState<string[]>([])
  const [selectedAdmins, setSelectedAdmins] = useState<string[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [filterType, setFilterType] = useState("all")
  const [filterStatus, setFilterStatus] = useState("all")
  const [filterDateFrom, setFilterDateFrom] = useState<Date>()
  const [filterDateTo, setFilterDateTo] = useState<Date>()
  
  const [newMessage, setNewMessage] = useState({
    subject: "",
    content: "",
    attachments: [] as File[],
    channels: {
      internal: true,
      email: true,
      whatsapp: true
    },
    scheduled: false,
    scheduleDate: undefined as Date | undefined,
    scheduleTime: ""
  })

  const [notifications] = useState([
    { id: 1, from: "Director", subject: "Reunión de coordinación", time: "10:30 AM", unread: true },
    { id: 2, from: "Coord. Académico", subject: "Entrega de planificaciones", time: "Ayer", unread: false },
    { id: 3, from: "Sistema", subject: "Recordatorio: Calificaciones P1", time: "2 días", unread: true },
  ])

  const handleStudentSelection = (studentId: string, checked: boolean) => {
    if (checked) {
      setSelectedStudents([...selectedStudents, studentId])
    } else {
      setSelectedStudents(selectedStudents.filter(id => id !== studentId))
    }
  }

  const handleSelectAllStudents = (checked: boolean) => {
    if (checked && selectedCourse) {
      const course = teacherCourses.find(c => c.id === selectedCourse)
      if (course) {
        setSelectedStudents(course.students.map(s => s.id))
      }
    } else {
      setSelectedStudents([])
    }
  }

  const handleAdminSelection = (adminId: string, checked: boolean) => {
    if (checked) {
      setSelectedAdmins([...selectedAdmins, adminId])
    } else {
      setSelectedAdmins(selectedAdmins.filter(id => id !== adminId))
    }
  }

  const handleTemplateSelect = (template: any) => {
    setNewMessage(prev => ({
      ...prev,
      subject: template.subject,
      content: template.content
    }))
  }

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || [])
    setNewMessage(prev => ({
      ...prev,
      attachments: [...prev.attachments, ...files]
    }))
  }

  const handleSendMessage = async () => {
    try {
      // Simulación de envío
      await new Promise(resolve => setTimeout(resolve, 1500))
      
      alert("Mensaje enviado exitosamente")
      setShowNewMessageDialog(false)
      resetForm()
    } catch (error) {
      alert("Error al enviar el mensaje")
    }
  }

  const resetForm = () => {
    setNewMessage({
      subject: "",
      content: "",
      attachments: [],
      channels: { internal: true, email: true, whatsapp: true },
      scheduled: false,
      scheduleDate: undefined,
      scheduleTime: ""
    })
    setSelectedStudents([])
    setSelectedAdmins([])
    setSelectedCourse("")
    setMessageType("parents")
  }

  const filteredMessages = sentMessages.filter(msg => {
    const matchesSearch = msg.subject.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         msg.recipients.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesType = filterType === "all" || 
                       (filterType === "external" && msg.type === "Externo") ||
                       (filterType === "internal" && msg.type === "Interno")
    const matchesStatus = filterStatus === "all" || msg.status.toLowerCase() === filterStatus.toLowerCase()
    
    return matchesSearch && matchesType && matchesStatus
  })

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "Enviado": return <CheckCircle className="h-4 w-4 text-green-500" />
      case "Leído": return <Eye className="h-4 w-4 text-blue-500" />
      case "Fallido": return <XCircle className="h-4 w-4 text-red-500" />
      case "Programado": return <Clock className="h-4 w-4 text-yellow-500" />
      default: return <AlertCircle className="h-4 w-4 text-gray-500" />
    }
  }

  return (
    <div className="flex-1 flex flex-col bg-gray-50">
      <Header title="Comunicación" />

      <main className="flex-1 overflow-hidden p-6">
        <div className="space-y-6">
          {/* Encabezado del Módulo */}
          <div className="flex flex-col lg:flex-row gap-4 items-start lg:items-center justify-between">
            <div className="flex items-center space-x-4">
              <Dialog open={showNewMessageDialog} onOpenChange={setShowNewMessageDialog}>
                <DialogTrigger asChild>
                  <Button className="bg-indigo-600 hover:bg-indigo-700 text-white">
                    <Plus className="h-4 w-4 mr-2" />
                    Nuevo Mensaje
                  </Button>
                </DialogTrigger>
              </Dialog>

              {/* Panel de Notificaciones */}
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="relative">
                    <Bell className="h-4 w-4 mr-2" />
                    Notificaciones
                    {notifications.filter(n => n.unread).length > 0 && (
                      <Badge className="absolute -top-2 -right-2 h-5 w-5 p-0 bg-red-500 text-white text-xs">
                        {notifications.filter(n => n.unread).length}
                      </Badge>
                    )}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-80">
                  <div className="space-y-2">
                    <h4 className="font-medium">Notificaciones Recientes</h4>
                    {notifications.map(notification => (
                      <div key={notification.id} className={`p-2 rounded border ${notification.unread ? 'bg-blue-50 border-blue-200' : 'bg-gray-50'}`}>
                        <div className="flex justify-between items-start">
                          <div className="flex-1">
                            <p className="text-sm font-medium">{notification.from}</p>
                            <p className="text-xs text-gray-600">{notification.subject}</p>
                          </div>
                          <span className="text-xs text-gray-500">{notification.time}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </PopoverContent>
              </Popover>
            </div>

            {/* Buscador y Filtros */}
            <div className="flex flex-col lg:flex-row gap-2 w-full lg:w-auto">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="Buscar mensajes..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 w-full lg:w-64"
                />
              </div>
              
              <Select value={filterType} onValueChange={setFilterType}>
                <SelectTrigger className="w-full lg:w-40">
                  <SelectValue placeholder="Tipo" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos</SelectItem>
                  <SelectItem value="external">Externos</SelectItem>
                  <SelectItem value="internal">Internos</SelectItem>
                </SelectContent>
              </Select>

              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger className="w-full lg:w-40">
                  <SelectValue placeholder="Estado" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos</SelectItem>
                  <SelectItem value="enviado">Enviado</SelectItem>
                  <SelectItem value="leído">Leído</SelectItem>
                  <SelectItem value="fallido">Fallido</SelectItem>
                  <SelectItem value="programado">Programado</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Historial de Mensajes */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <MessageSquare className="h-5 w-5 mr-2 text-indigo-600" />
                Historial de Mensajes Enviados
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left p-2">Fecha</th>
                      <th className="text-left p-2">Asunto</th>
                      <th className="text-left p-2">Destinatarios</th>
                      <th className="text-left p-2">Tipo</th>
                      <th className="text-left p-2">Canales</th>
                      <th className="text-left p-2">Estado</th>
                      <th className="text-left p-2">Acciones</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredMessages.map(message => (
                      <tr key={message.id} className="border-b hover:bg-gray-50">
                        <td className="p-2 text-sm">{message.date}</td>
                        <td className="p-2 text-sm font-medium">{message.subject}</td>
                        <td className="p-2 text-sm">{message.recipients}</td>
                        <td className="p-2">
                          <Badge variant={message.type === "Externo" ? "default" : "secondary"}>
                            {message.type}
                          </Badge>
                        </td>
                        <td className="p-2">
                          <div className="flex space-x-1">
                            {message.channels.map(channel => (
                              <Badge key={channel} variant="outline" className="text-xs">
                                {channel}
                              </Badge>
                            ))}
                          </div>
                        </td>
                        <td className="p-2">
                          <div className="flex items-center space-x-2">
                            {getStatusIcon(message.status)}
                            <span className="text-sm">{message.status}</span>
                            {message.type === "Externo" && (
                              <span className="text-xs text-gray-500">
                                ({message.readCount}/{message.totalCount})
                              </span>
                            )}
                          </div>
                        </td>
                        <td className="p-2">
                          <div className="flex space-x-1">
                            <Button size="sm" variant="ghost" className="h-8 w-8 p-0">
                              <Eye className="h-4 w-4" />
                            </Button>
                            <Button size="sm" variant="ghost" className="h-8 w-8 p-0">
                              <RotateCcw className="h-4 w-4" />
                            </Button>
                            <Button size="sm" variant="ghost" className="h-8 w-8 p-0 text-red-500">
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Modal Nuevo Mensaje */}
        <Dialog open={showNewMessageDialog} onOpenChange={setShowNewMessageDialog}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Nuevo Mensaje</DialogTitle>
            </DialogHeader>

            <Tabs value={messageType} onValueChange={(value) => setMessageType(value as "parents" | "admin")}>
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="parents" className="flex items-center">
                  <Users className="h-4 w-4 mr-2" />
                  Enviar a Padres
                </TabsTrigger>
                <TabsTrigger value="admin" className="flex items-center">
                  <Building className="h-4 w-4 mr-2" />
                  Enviar a Administrativos
                </TabsTrigger>
              </TabsList>

              <TabsContent value="parents" className="space-y-4">
                {/* Selección de Destinatarios - Padres */}
                <div className="space-y-4">
                  <div>
                    <Label>Seleccionar Curso</Label>
                    <Select value={selectedCourse} onValueChange={setSelectedCourse}>
                      <SelectTrigger>
                        <SelectValue placeholder="Seleccione un curso" />
                      </SelectTrigger>
                      <SelectContent>
                        {teacherCourses.map(course => (
                          <SelectItem key={course.id} value={course.id}>
                            {course.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {selectedCourse && (
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <Label>Estudiantes y Padres</Label>
                        <div className="flex items-center space-x-2">
                          <Checkbox
                            id="select-all"
                            checked={selectedStudents.length === teacherCourses.find(c => c.id === selectedCourse)?.students.length}
                            onCheckedChange={handleSelectAllStudents}
                          />
                          <Label htmlFor="select-all" className="text-sm">Seleccionar todos</Label>
                        </div>
                      </div>
                      <div className="border rounded-lg p-4 max-h-40 overflow-y-auto">
                        {teacherCourses.find(c => c.id === selectedCourse)?.students.map(student => (
                          <div key={student.id} className="flex items-center space-x-3 py-2">
                            <Checkbox
                              id={student.id}
                              checked={selectedStudents.includes(student.id)}
                              onCheckedChange={(checked) => handleStudentSelection(student.id, checked as boolean)}
                            />
                            <div className="flex-1">
                              <p className="text-sm font-medium">{student.name}</p>
                              <p className="text-xs text-gray-500">Padre: {student.parent}</p>
                              <p className="text-xs text-gray-400">{student.parentEmail} | {student.parentPhone}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Canales de Envío */}
                  <div>
                    <Label>Canales de Envío</Label>
                    <div className="flex space-x-4 mt-2">
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="internal"
                          checked={newMessage.channels.internal}
                          onCheckedChange={(checked) => 
                            setNewMessage(prev => ({
                              ...prev,
                              channels: { ...prev.channels, internal: checked as boolean }
                            }))
                          }
                        />
                        <Label htmlFor="internal" className="flex items-center">
                          <Bell className="h-4 w-4 mr-1 text-blue-600" />
                          Notificación Interna
                        </Label>
                      </div>

                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="email"
                          checked={newMessage.channels.email}
                          onCheckedChange={(checked) => 
                            setNewMessage(prev => ({
                              ...prev,
                              channels: { ...prev.channels, email: checked as boolean }
                            }))
                          }
                        />
                        <Label htmlFor="email" className="flex items-center">
                          <Mail className="h-4 w-4 mr-1 text-red-600" />
                          Correo Electrónico
                        </Label>
                      </div>

                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="whatsapp"
                          checked={newMessage.channels.whatsapp}
                          onCheckedChange={(checked) => 
                            setNewMessage(prev => ({
                              ...prev,
                              channels: { ...prev.channels, whatsapp: checked as boolean }
                            }))
                          }
                        />
                        <Label htmlFor="whatsapp" className="flex items-center">
                          <Phone className="h-4 w-4 mr-1 text-green-600" />
                          WhatsApp
                        </Label>
                      </div>
                    </div>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="admin" className="space-y-4">
                {/* Selección de Destinatarios - Administrativos */}
                <div>
                  <Label>Destinatarios Administrativos</Label>
                  <div className="border rounded-lg p-4 space-y-3 mt-2">
                    {administrativeStaff.map(admin => (
                      <div key={admin.id} className="flex items-center space-x-3">
                        <Checkbox
                          id={admin.id}
                          checked={selectedAdmins.includes(admin.id)}
                          onCheckedChange={(checked) => handleAdminSelection(admin.id, checked as boolean)}
                        />
                        <div className="flex-1">
                          <p className="text-sm font-medium">{admin.name}</p>
                          <p className="text-xs text-gray-500">{admin.role}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </TabsContent>
            </Tabs>

            {/* Plantillas Predefinidas */}
            <div>
              <Label>Plantilla Predefinida (Opcional)</Label>
              <Select onValueChange={(value) => {
                const template = messageTemplates.find(t => t.id === value)
                if (template) handleTemplateSelect(template)
              }}>
                <SelectTrigger>
                  <SelectValue placeholder="Seleccionar plantilla" />
                </SelectTrigger>
                <SelectContent>
                  {messageTemplates.map(template => (
                    <SelectItem key={template.id} value={template.id}>
                      <div>
                        <p className="font-medium">{template.title}</p>
                        <p className="text-xs text-gray-500">{template.description}</p>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Redacción del Mensaje */}
            <div className="space-y-4">
              <div>
                <Label htmlFor="subject">Asunto *</Label>
                <Input
                  id="subject"
                  value={newMessage.subject}
                  onChange={(e) => setNewMessage(prev => ({ ...prev, subject: e.target.value }))}
                  placeholder="Ingrese el asunto del mensaje"
                />
              </div>

              <div>
                <Label htmlFor="content">Mensaje *</Label>
                <Textarea
                  id="content"
                  value={newMessage.content}
                  onChange={(e) => setNewMessage(prev => ({ ...prev, content: e.target.value }))}
                  placeholder="Escriba su mensaje aquí..."
                  rows={6}
                />
              </div>

              <div>
                <Label>Adjuntos (máximo 5MB)</Label>
                <div className="flex items-center space-x-2 mt-2">
                  <Input
                    type="file"
                    multiple
                    onChange={handleFileUpload}
                    className="hidden"
                    id="file-upload"
                    accept=".pdf,.doc,.docx,.xls,.xlsx,.jpg,.jpeg,.png"
                  />
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => document.getElementById("file-upload")?.click()}
                  >
                    <Paperclip className="h-4 w-4 mr-2" />
                    Adjuntar Archivos
                  </Button>
                  <span className="text-sm text-gray-500">
                    {newMessage.attachments.length} archivo(s) seleccionado(s)
                  </span>
                </div>
              </div>

              {/* Programación */}
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="scheduled"
                    checked={newMessage.scheduled}
                    onCheckedChange={(checked) => 
                      setNewMessage(prev => ({ ...prev, scheduled: checked as boolean }))
                    }
                  />
                  <Label htmlFor="scheduled">Programar envío</Label>
                </div>

                {newMessage.scheduled && (
                  <div className="flex space-x-2">
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button variant="outline" className="justify-start text-left font-normal">
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {newMessage.scheduleDate ? newMessage.scheduleDate.toLocaleDateString() : "Seleccionar fecha"}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0">
                        <Calendar
                          mode="single"
                          selected={newMessage.scheduleDate}
                          onSelect={(date) => setNewMessage(prev => ({ ...prev, scheduleDate: date }))}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                    <Input
                      type="time"
                      value={newMessage.scheduleTime}
                      onChange={(e) => setNewMessage(prev => ({ ...prev, scheduleTime: e.target.value }))}
                      className="w-32"
                    />
                  </div>
                )}
              </div>
            </div>

            {/* Botones de Acción */}
            <div className="flex justify-end space-x-2 pt-4">
              <Button variant="outline" onClick={() => setShowNewMessageDialog(false)}>
                Cancelar
              </Button>
              <Button
                onClick={handleSendMessage}
                className="bg-indigo-600 hover:bg-indigo-700 text-white"
                disabled={!newMessage.subject || !newMessage.content || 
                         (messageType === "parents" && selectedStudents.length === 0) ||
                         (messageType === "admin" && selectedAdmins.length === 0)}
              >
                <Send className="h-4 w-4 mr-2" />
                {newMessage.scheduled ? "Programar Mensaje" : "Enviar Mensaje"}
              </Button>
            </div>

            {/* Información de Integración */}
            <div className="text-xs text-gray-500 mt-4 bg-gray-50 p-3 rounded">
              <p><strong>Integración API:</strong> El mensaje se enviará a través de las plataformas seleccionadas.</p>
              <p><strong>WhatsApp Business API:</strong> Permite envío de mensajes de texto, imágenes y documentos.</p>
              <p><strong>Email API:</strong> Permite envío de correos con formato HTML y adjuntos.</p>
              <p><strong>Límites:</strong> Máximo 50 destinatarios por envío masivo. Confirmación requerida para más de 10 destinatarios.</p>
            </div>
          </DialogContent>
        </Dialog>
      </main>
    </div>
  )
}
