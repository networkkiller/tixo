"use client"

import { useState } from "react"
import { Header } from "@/components/dashboard/header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  Calendar,
  CheckCircle,
  XCircle,
  Clock,
  MessageSquare,
  Download,
  Send,
  ArrowLeft,
  BarChart3,
  FileText,
  AlertCircle,
  TrendingUp,
  TrendingDown,
  Minus,
} from "lucide-react"
import Link from "next/link"

// Datos de ejemplo de todos los estudiantes de los cursos del profesor
const allStudentsData = [
  {
    id: "EST001",
    name: "Ana María García López",
    photo: "/placeholder.svg?height=100&width=100&text=Ana",
    currentGrade: "2° A Primaria",
    course: "2° A Primaria - Matemáticas",
    generalAttendance: 92,
    generalAverage: 78,
  },
  {
    id: "EST002",
    name: "Carlos Eduardo Pérez",
    photo: "/placeholder.svg?height=100&width=100&text=Carlos",
    currentGrade: "2° A Primaria",
    course: "2° A Primaria - Matemáticas",
    generalAttendance: 95,
    generalAverage: 85,
  },
  {
    id: "EST003",
    name: "Sofía Alejandra López",
    photo: "/placeholder.svg?height=100&width=100&text=Sofia",
    currentGrade: "1° A Primaria",
    course: "1° A Primaria - Matemáticas",
    generalAttendance: 98,
    generalAverage: 90,
  },
  {
    id: "EST004",
    name: "Luis Fernando Martínez",
    photo: "/placeholder.svg?height=100&width=100&text=Luis",
    currentGrade: "1° B Primaria",
    course: "1° B Primaria - Matemáticas",
    generalAttendance: 88,
    generalAverage: 75,
  },
  {
    id: "EST005",
    name: "Isabella María Torres",
    photo: "/placeholder.svg?height=100&width=100&text=Isabella",
    currentGrade: "2° B Primaria",
    course: "2° B Primaria - Matemáticas",
    generalAttendance: 94,
    generalAverage: 88,
  },
]

// Datos de cursos del profesor
const teacherCourses = [
  "1° A Primaria - Matemáticas",
  "1° B Primaria - Matemáticas",
  "2° A Primaria - Matemáticas",
  "2° B Primaria - Matemáticas",
]

// Datos de ejemplo de calificaciones
const gradesData = [
  {
    id: 1,
    date: "2024-01-15",
    subject: "Matemáticas",
    type: "Prueba",
    grade: 85,
    observations: "Excelente comprensión de fracciones",
    period: "Primer Trimestre",
  },
  {
    id: 2,
    date: "2024-01-22",
    subject: "Matemáticas",
    type: "Tarea",
    grade: 78,
    observations: "Necesita reforzar multiplicaciones",
    period: "Primer Trimestre",
  },
  {
    id: 3,
    date: "2024-02-05",
    subject: "Matemáticas",
    type: "Proyecto",
    grade: 90,
    observations: "Creatividad excepcional en la presentación",
    period: "Primer Trimestre",
  },
  {
    id: 4,
    date: "2024-02-12",
    subject: "Lenguaje",
    type: "Prueba",
    grade: 72,
    observations: "Mejorar comprensión lectora",
    period: "Primer Trimestre",
  },
]

// Datos de ejemplo de asistencia
const attendanceData = [
  { date: "2024-01-15", status: "Presente", comment: "" },
  { date: "2024-01-16", status: "Ausente", comment: "Cita médica" },
  { date: "2024-01-17", status: "Presente", comment: "" },
  { date: "2024-01-18", status: "Justificado", comment: "Enfermedad" },
  { date: "2024-01-19", status: "Presente", comment: "" },
]

// Datos de ejemplo de tareas
const tasksData = [
  {
    id: 1,
    title: "Ejercicios de Fracciones",
    dueDate: "2024-01-20",
    status: "Entregado",
    comments: "Trabajo completo y ordenado",
    grade: 85,
  },
  {
    id: 2,
    title: "Proyecto de Geometría",
    dueDate: "2024-01-25",
    status: "Entregado",
    comments: "Muy creativo",
    grade: 90,
  },
  {
    id: 3,
    title: "Problemas de División",
    dueDate: "2024-01-30",
    status: "No entregado",
    comments: "Pendiente de entrega",
    grade: null,
  },
]

// Datos de ejemplo de observaciones
const observationsData = [
  {
    id: 1,
    date: "2024-01-15",
    type: "Académico",
    content: "Ana muestra gran interés en matemáticas. Recomendar ejercicios adicionales.",
    teacher: "Prof. Juan Pérez",
  },
  {
    id: 2,
    date: "2024-01-22",
    type: "Conducta",
    content: "Excelente comportamiento en clase. Ayuda a sus compañeros.",
    teacher: "Prof. Juan Pérez",
  },
  {
    id: 3,
    date: "2024-02-05",
    type: "Comunicación",
    content: "Se envió mensaje al padre sobre el excelente rendimiento en el proyecto.",
    teacher: "Prof. Juan Pérez",
  },
]

export default function HistorialAcademico() {
  const [selectedPeriod, setSelectedPeriod] = useState("all")
  const [selectedSubject, setSelectedSubject] = useState("all")
  const [selectedEvalType, setSelectedEvalType] = useState("all")
  const [attendanceFilter, setAttendanceFilter] = useState("all")
  const [dateRange, setDateRange] = useState({ start: "", end: "" })
  const [newObservation, setNewObservation] = useState("")
  const [observationType, setObservationType] = useState("Académico")
  const [selectedStudentId, setSelectedStudentId] = useState("EST001")

  // Obtener datos del estudiante seleccionado
  const selectedStudent = allStudentsData.find((student) => student.id === selectedStudentId) || allStudentsData[0]

  // Datos del estudiante actual (usar selectedStudent en lugar de studentData)
  const studentData = {
    ...selectedStudent,
    subjects: [
      { name: "Matemáticas", teacher: "Prof. Juan Pérez", isCurrentTeacher: true },
      { name: "Lenguaje", teacher: "Prof. María González", isCurrentTeacher: false },
      { name: "Ciencias", teacher: "Prof. Carlos Ruiz", isCurrentTeacher: false },
      { name: "Historia", teacher: "Prof. Ana Torres", isCurrentTeacher: false },
    ],
  }

  // Filtrar calificaciones
  const filteredGrades = gradesData.filter((grade) => {
    return (
      (selectedPeriod === "all" || grade.period === selectedPeriod) &&
      (selectedSubject === "all" || grade.subject === selectedSubject) &&
      (selectedEvalType === "all" || grade.type === selectedEvalType)
    )
  })

  // Filtrar asistencia
  const filteredAttendance = attendanceData.filter((attendance) => {
    return attendanceFilter === "all" || attendance.status === attendanceFilter
  })

  // Calcular tendencia de calificaciones
  const getGradeTrend = (grades: typeof gradesData) => {
    if (grades.length < 2) return "stable"
    const recent = grades.slice(-2)
    if (recent[1].grade > recent[0].grade) return "up"
    if (recent[1].grade < recent[0].grade) return "down"
    return "stable"
  }

  const gradeTrend = getGradeTrend(filteredGrades)

  return (
    <div className="flex-1 flex flex-col bg-gray-50">
      <Header title="Historial Académico" />

      <main className="flex-1 overflow-y-auto p-6">
        {/* Botón de regreso */}
        <div className="mb-6">
          <Link href="/dashboard/profesor/courses">
            <Button variant="outline" className="border-gray-300 text-gray-700 hover:bg-gray-50 bg-transparent">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Regresar a Mis Cursos
            </Button>
          </Link>
        </div>

        {/* 1. Datos del Alumno (Encabezado) */}
        <Card className="bg-white border border-gray-200 mb-6">
          <CardContent className="p-6">
            {/* Selector de Estudiante */}
            <div className="mb-6 p-4 bg-indigo-50 rounded-lg border border-indigo-200">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold text-indigo-900 mb-2">Seleccionar Estudiante</h3>
                  <p className="text-sm text-indigo-700">
                    Elige un estudiante de tus cursos para ver su historial académico
                  </p>
                </div>
                <div className="w-80">
                  <Label htmlFor="student-select" className="text-sm font-medium text-indigo-800 mb-2 block">
                    Estudiante
                  </Label>
                  <Select value={selectedStudentId} onValueChange={setSelectedStudentId}>
                    <SelectTrigger className="border-indigo-300 bg-white">
                      <SelectValue placeholder="Seleccionar estudiante" />
                    </SelectTrigger>
                    <SelectContent>
                      {teacherCourses.map((course) => (
                        <div key={course}>
                          <div className="px-2 py-1 text-xs font-semibold text-gray-500 bg-gray-100">{course}</div>
                          {allStudentsData
                            .filter((student) => student.course === course)
                            .map((student) => (
                              <SelectItem key={student.id} value={student.id}>
                                <div className="flex items-center space-x-2">
                                  <div className="w-6 h-6 rounded-full bg-indigo-100 flex items-center justify-center text-xs font-medium text-indigo-600">
                                    {student.name
                                      .split(" ")
                                      .map((n) => n[0])
                                      .join("")
                                      .slice(0, 2)}
                                  </div>
                                  <span>{student.name}</span>
                                </div>
                              </SelectItem>
                            ))}
                        </div>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            {/* Información del Estudiante Seleccionado */}
            <div className="flex items-center space-x-6">
              <Avatar className="w-20 h-20">
                <AvatarImage src={studentData.photo || "/placeholder.svg"} alt={studentData.name} />
                <AvatarFallback className="bg-indigo-100 text-indigo-600 text-lg font-semibold">
                  {studentData.name
                    .split(" ")
                    .map((n) => n[0])
                    .join("")
                    .slice(0, 2)}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <h1 className="text-2xl font-bold text-gray-900 mb-2">{studentData.name}</h1>
                <p className="text-gray-600 mb-3">{studentData.currentGrade}</p>
                <div className="flex flex-wrap gap-2 mb-4">
                  {studentData.subjects.map((subject, index) => (
                    <Badge
                      key={index}
                      className={
                        subject.isCurrentTeacher
                          ? "bg-indigo-100 text-indigo-800 border-indigo-200"
                          : "bg-gray-100 text-gray-600 border-gray-200"
                      }
                    >
                      {subject.name} - {subject.teacher}
                    </Badge>
                  ))}
                </div>
                <div className="flex space-x-6">
                  <div className="flex items-center space-x-2">
                    <Calendar className="h-5 w-5 text-green-600" />
                    <span className="text-sm text-gray-600">Asistencia:</span>
                    <span className="font-semibold text-green-600">{studentData.generalAttendance}%</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <BarChart3 className="h-5 w-5 text-blue-600" />
                    <span className="text-sm text-gray-600">Promedio General:</span>
                    <span className="font-semibold text-blue-600">{studentData.generalAverage}</span>
                  </div>
                </div>
              </div>
              <div className="flex flex-col space-y-2">
                <Dialog>
                  <DialogTrigger asChild>
                    <Button className="bg-indigo-600 hover:bg-indigo-700 text-white">
                      <Download className="h-4 w-4 mr-2" />
                      Exportar PDF
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Exportar Historial Académico</DialogTitle>
                      <DialogDescription>
                        Se generará un PDF completo con toda la información académica del estudiante {studentData.name}.
                      </DialogDescription>
                    </DialogHeader>
                    <div className="flex justify-end space-x-2 mt-4">
                      <Button variant="outline">Cancelar</Button>
                      <Button className="bg-indigo-600 hover:bg-indigo-700 text-white">Generar PDF</Button>
                    </div>
                  </DialogContent>
                </Dialog>
                <Dialog>
                  <DialogTrigger asChild>
                    <Button
                      variant="outline"
                      className="border-green-300 text-green-700 hover:bg-green-50 bg-transparent"
                    >
                      <Send className="h-4 w-4 mr-2" />
                      Enviar al Padre
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Enviar Informe al Padre</DialogTitle>
                      <DialogDescription>
                        Selecciona el método de envío del informe académico de {studentData.name}.
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4 mt-4">
                      <div className="flex space-x-2">
                        <Button className="flex-1 bg-green-600 hover:bg-green-700 text-white">
                          <MessageSquare className="h-4 w-4 mr-2" />
                          WhatsApp
                        </Button>
                        <Button variant="outline" className="flex-1 bg-transparent">
                          <Send className="h-4 w-4 mr-2" />
                          Correo
                        </Button>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          {/* 2. Rendimiento Académico */}
          <Card className="bg-white border border-gray-200">
            <CardHeader>
              <CardTitle className="text-gray-900 flex items-center justify-between">
                <div className="flex items-center">
                  <BarChart3 className="h-5 w-5 mr-2 text-indigo-600" />
                  Rendimiento Académico
                </div>
                <div className="flex items-center space-x-2">
                  {gradeTrend === "up" && <TrendingUp className="h-5 w-5 text-green-600" />}
                  {gradeTrend === "down" && <TrendingDown className="h-5 w-5 text-red-600" />}
                  {gradeTrend === "stable" && <Minus className="h-5 w-5 text-gray-600" />}
                  <span className="text-sm text-gray-600">
                    {gradeTrend === "up" && "Mejorando"}
                    {gradeTrend === "down" && "Descendiendo"}
                    {gradeTrend === "stable" && "Estable"}
                  </span>
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {/* Filtros */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                <div>
                  <Label htmlFor="period" className="text-sm font-medium text-gray-700">
                    Período
                  </Label>
                  <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
                    <SelectTrigger className="border-gray-300">
                      <SelectValue placeholder="Seleccionar período" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos los períodos</SelectItem>
                      <SelectItem value="Primer Trimestre">Primer Trimestre</SelectItem>
                      <SelectItem value="Segundo Trimestre">Segundo Trimestre</SelectItem>
                      <SelectItem value="Tercer Trimestre">Tercer Trimestre</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="subject" className="text-sm font-medium text-gray-700">
                    Materia
                  </Label>
                  <Select value={selectedSubject} onValueChange={setSelectedSubject}>
                    <SelectTrigger className="border-gray-300">
                      <SelectValue placeholder="Seleccionar materia" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todas las materias</SelectItem>
                      <SelectItem value="Matemáticas">Matemáticas</SelectItem>
                      <SelectItem value="Lenguaje">Lenguaje</SelectItem>
                      <SelectItem value="Ciencias">Ciencias</SelectItem>
                      <SelectItem value="Historia">Historia</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="evalType" className="text-sm font-medium text-gray-700">
                    Tipo de Evaluación
                  </Label>
                  <Select value={selectedEvalType} onValueChange={setSelectedEvalType}>
                    <SelectTrigger className="border-gray-300">
                      <SelectValue placeholder="Tipo de evaluación" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos los tipos</SelectItem>
                      <SelectItem value="Prueba">Prueba</SelectItem>
                      <SelectItem value="Tarea">Tarea</SelectItem>
                      <SelectItem value="Proyecto">Proyecto</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Tabla de Calificaciones */}
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="text-gray-700">Fecha</TableHead>
                      <TableHead className="text-gray-700">Materia</TableHead>
                      <TableHead className="text-gray-700">Tipo</TableHead>
                      <TableHead className="text-gray-700">Calificación</TableHead>
                      <TableHead className="text-gray-700">Observaciones</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredGrades.map((grade) => (
                      <TableRow key={grade.id}>
                        <TableCell className="text-gray-900">{grade.date}</TableCell>
                        <TableCell className="text-gray-900">{grade.subject}</TableCell>
                        <TableCell>
                          <Badge
                            className={
                              grade.type === "Prueba"
                                ? "bg-blue-100 text-blue-800 border-blue-200"
                                : grade.type === "Tarea"
                                  ? "bg-green-100 text-green-800 border-green-200"
                                  : "bg-purple-100 text-purple-800 border-purple-200"
                            }
                          >
                            {grade.type}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <span
                            className={`font-semibold ${
                              grade.grade >= 80
                                ? "text-green-600"
                                : grade.grade >= 70
                                  ? "text-yellow-600"
                                  : "text-red-600"
                            }`}
                          >
                            {grade.grade}
                          </span>
                        </TableCell>
                        <TableCell className="text-gray-600 text-sm">{grade.observations}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>

          {/* 3. Historial de Asistencia */}
          <Card className="bg-white border border-gray-200">
            <CardHeader>
              <CardTitle className="text-gray-900 flex items-center">
                <Calendar className="h-5 w-5 mr-2 text-green-600" />
                Historial de Asistencia
              </CardTitle>
            </CardHeader>
            <CardContent>
              {/* Indicador de asistencia */}
              <div className="mb-4 p-4 bg-green-50 rounded-lg border border-green-200">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-green-800">Porcentaje de Asistencia</span>
                  <span className="text-lg font-bold text-green-600">{studentData.generalAttendance}%</span>
                </div>
                <div className="w-full bg-green-200 rounded-full h-2">
                  <div
                    className="bg-green-600 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${studentData.generalAttendance}%` }}
                  ></div>
                </div>
              </div>

              {/* Filtro de asistencia */}
              <div className="mb-4">
                <Label htmlFor="attendanceFilter" className="text-sm font-medium text-gray-700">
                  Filtrar por Estado
                </Label>
                <Select value={attendanceFilter} onValueChange={setAttendanceFilter}>
                  <SelectTrigger className="border-gray-300">
                    <SelectValue placeholder="Filtrar asistencia" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos los estados</SelectItem>
                    <SelectItem value="Presente">Presente</SelectItem>
                    <SelectItem value="Ausente">Ausente</SelectItem>
                    <SelectItem value="Justificado">Justificado</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Tabla de Asistencia */}
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="text-gray-700">Fecha</TableHead>
                      <TableHead className="text-gray-700">Estado</TableHead>
                      <TableHead className="text-gray-700">Comentario</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredAttendance.map((attendance, index) => (
                      <TableRow key={index}>
                        <TableCell className="text-gray-900">{attendance.date}</TableCell>
                        <TableCell>
                          <Badge
                            className={
                              attendance.status === "Presente"
                                ? "bg-green-100 text-green-800 border-green-200"
                                : attendance.status === "Ausente"
                                  ? "bg-red-100 text-red-800 border-red-200"
                                  : "bg-yellow-100 text-yellow-800 border-yellow-200"
                            }
                          >
                            {attendance.status === "Presente" && <CheckCircle className="h-3 w-3 mr-1" />}
                            {attendance.status === "Ausente" && <XCircle className="h-3 w-3 mr-1" />}
                            {attendance.status === "Justificado" && <Clock className="h-3 w-3 mr-1" />}
                            {attendance.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-gray-600 text-sm">{attendance.comment || "-"}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          {/* 4. Entregas de Tareas */}
          <Card className="bg-white border border-gray-200">
            <CardHeader>
              <CardTitle className="text-gray-900 flex items-center">
                <FileText className="h-5 w-5 mr-2 text-blue-600" />
                Entregas de Tareas
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {tasksData.map((task) => (
                  <div key={task.id} className="p-4 border border-gray-200 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium text-gray-900">{task.title}</h4>
                      <Badge
                        className={
                          task.status === "Entregado"
                            ? "bg-green-100 text-green-800 border-green-200"
                            : task.status === "No entregado"
                              ? "bg-red-100 text-red-800 border-red-200"
                              : "bg-yellow-100 text-yellow-800 border-yellow-200"
                        }
                      >
                        {task.status}
                      </Badge>
                    </div>
                    <div className="text-sm text-gray-600 space-y-1">
                      <p>
                        <strong>Fecha límite:</strong> {task.dueDate}
                      </p>
                      {task.grade && (
                        <p>
                          <strong>Calificación:</strong>{" "}
                          <span
                            className={`font-semibold ${
                              task.grade >= 80
                                ? "text-green-600"
                                : task.grade >= 70
                                  ? "text-yellow-600"
                                  : "text-red-600"
                            }`}
                          >
                            {task.grade}
                          </span>
                        </p>
                      )}
                      <p>
                        <strong>Comentarios:</strong> {task.comments}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* 5. Observaciones y Comunicaciones */}
          <Card className="bg-white border border-gray-200">
            <CardHeader>
              <CardTitle className="text-gray-900 flex items-center justify-between">
                <div className="flex items-center">
                  <MessageSquare className="h-5 w-5 mr-2 text-purple-600" />
                  Observaciones y Comunicaciones
                </div>
                <Dialog>
                  <DialogTrigger asChild>
                    <Button size="sm" className="bg-purple-600 hover:bg-purple-700 text-white">
                      Nueva Observación
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Agregar Nueva Observación</DialogTitle>
                      <DialogDescription>Registra una nueva observación sobre el estudiante.</DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4 mt-4">
                      <div>
                        <Label htmlFor="obsType" className="text-sm font-medium text-gray-700">
                          Tipo de Observación
                        </Label>
                        <Select value={observationType} onValueChange={setObservationType}>
                          <SelectTrigger className="border-gray-300">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Académico">Académico</SelectItem>
                            <SelectItem value="Conducta">Conducta</SelectItem>
                            <SelectItem value="Comunicación">Comunicación</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor="observation" className="text-sm font-medium text-gray-700">
                          Observación
                        </Label>
                        <Textarea
                          id="observation"
                          value={newObservation}
                          onChange={(e) => setNewObservation(e.target.value)}
                          placeholder="Escribe tu observación aquí..."
                          className="border-gray-300"
                          rows={4}
                        />
                      </div>
                      <div className="flex justify-end space-x-2">
                        <Button variant="outline">Cancelar</Button>
                        <Button className="bg-purple-600 hover:bg-purple-700 text-white">Guardar Observación</Button>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {observationsData.map((obs) => (
                  <div key={obs.id} className="p-4 border-l-4 border-purple-500 bg-purple-50 rounded-r-lg">
                    <div className="flex items-center justify-between mb-2">
                      <Badge
                        className={
                          obs.type === "Académico"
                            ? "bg-blue-100 text-blue-800 border-blue-200"
                            : obs.type === "Conducta"
                              ? "bg-green-100 text-green-800 border-green-200"
                              : "bg-purple-100 text-purple-800 border-purple-200"
                        }
                      >
                        {obs.type}
                      </Badge>
                      <span className="text-xs text-gray-500">{obs.date}</span>
                    </div>
                    <p className="text-sm text-gray-700 mb-2">{obs.content}</p>
                    <p className="text-xs text-gray-500">Por: {obs.teacher}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Notificación automática */}
        <Card className="bg-blue-50 border border-blue-200">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <AlertCircle className="h-5 w-5 text-blue-600" />
              <div className="flex-1">
                <p className="text-sm font-medium text-blue-800">Notificaciones Automáticas Activas</p>
                <p className="text-xs text-blue-600">
                  Cada actualización en este historial enviará automáticamente una notificación al padre vía WhatsApp.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
