"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  Users,
  UserPlus,
  GraduationCap,
  AlertTriangle,
  CheckCircle,
  Clock,
  FileText,
  BarChart3,
  CalendarDays,
  ChevronRight,
  School,
} from "lucide-react"
import { CourseStatusCard } from "@/components/course/course-status-card"
import { CourseNotifications } from "@/components/notifications/course-notifications"
import type { Course } from "@/lib/course-interoperability"

export default function CoordinadorRegistroDashboard() {
  const [selectedPeriod, setSelectedPeriod] = useState("2024-1")

  // Cursos disponibles para asignación de estudiantes
  const [availableForStudents] = useState<Course[]>([
    {
      id: "course_available_1",
      name: "3ro C",
      grade: "3ro",
      level: "Primaria",
      modality: "Regular",
      section: "C",
      turn: "Mañana",
      capacity: 28,
      teacher: "Luis Fernández",
      schoolYear: "2024-2025",
      notes: "",
      createdAt: new Date().toISOString(),
      createdBy: "director_001",
      status: "active",
      studentsCount: 0,
      subjectsCount: 6,
      configurationStatus: {
        hasSubjects: true,
        hasTeacher: true,
        hasSchedule: true,
        hasStudents: false,
        isComplete: false,
        completionPercentage: 75,
      },
    },
  ])

  const [partiallyFilled] = useState<Course[]>([
    {
      id: "course_partial_1",
      name: "4to A",
      grade: "4to",
      level: "Primaria",
      modality: "Regular",
      section: "A",
      turn: "Tarde",
      capacity: 30,
      teacher: "Carmen Jiménez",
      schoolYear: "2024-2025",
      notes: "",
      createdAt: new Date().toISOString(),
      createdBy: "director_001",
      status: "active",
      studentsCount: 18,
      subjectsCount: 7,
      configurationStatus: {
        hasSubjects: true,
        hasTeacher: true,
        hasSchedule: true,
        hasStudents: true,
        isComplete: false,
        completionPercentage: 100,
      },
    },
  ])

  const stats = {
    totalStudents: 1247,
    enrolledStudents: 1180,
    pendingEnrollment: 67,
    availableCourses: 24,
    fullCourses: 8,
    enrollmentRate: 94.6,
  }

  const alerts = [
    {
      id: 1,
      type: "warning",
      title: "Estudiantes sin Asignar",
      description: "67 estudiantes requieren asignación a curso",
      priority: "high",
    },
    {
      id: 2,
      type: "info",
      title: "Cursos Disponibles",
      description: "16 cursos tienen cupos disponibles",
      priority: "medium",
    },
    {
      id: 3,
      type: "success",
      title: "Meta de Matrícula",
      description: "94.6% de la meta anual alcanzada",
      priority: "low",
    },
  ]

  const recentActivities = [
    {
      id: 1,
      action: "Asignó estudiante",
      subject: "María Rodríguez a 5to B",
      teacher: "Sistema",
      time: "Hace 1 hora",
    },
    {
      id: 2,
      action: "Completó matrícula",
      subject: "2do A - 25/25 estudiantes",
      teacher: "Sistema",
      time: "Hace 3 horas",
    },
    {
      id: 3,
      action: "Transfirió estudiante",
      subject: "Carlos López de 3ro A a 3ro B",
      teacher: "Sistema",
      time: "Hace 1 día",
    },
  ]

  const quickActions = [
    {
      title: "Asignar Estudiantes",
      description: "Distribuir estudiantes por curso",
      icon: UserPlus,
      href: "/dashboard/coordinador/student-assignment",
      color: "bg-blue-500",
    },
    {
      title: "Gestionar Matrícula",
      description: "Procesar inscripciones y reinscripciones",
      icon: School,
      href: "/dashboard/coordinador/enrollment",
      color: "bg-green-500",
    },
    {
      title: "Ver Reportes",
      description: "Estadísticas de matrícula",
      icon: FileText,
      href: "/dashboard/coordinador/reports",
      color: "bg-purple-500",
    },
    {
      title: "Historial de Cambios",
      description: "Auditoría de asignaciones",
      icon: BarChart3,
      href: "/dashboard/coordinador/audit",
      color: "bg-orange-500",
    },
  ]

  const handleViewDetails = (courseId: string) => {
    window.location.href = `/dashboard/coordinador/courses/${courseId}`
  }

  const handleAssignStudents = (courseId: string) => {
    window.location.href = `/dashboard/coordinador/student-assignment?course=${courseId}`
  }

  return (
    <div className="flex-1 space-y-6 p-6 bg-white">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Coordinación de Registro y Control Académico</h1>
          <p className="text-muted-foreground">Gestión de matrícula y distribución estudiantil</p>
        </div>
        <div className="flex items-center space-x-4">
          <CourseNotifications userRole="coordinador" />
          <select
            value={selectedPeriod}
            onChange={(e) => setSelectedPeriod(e.target.value)}
            className="px-3 py-2 border rounded-md"
          >
            <option value="2024-1">Período 2024-1</option>
            <option value="2023-2">Período 2023-2</option>
            <option value="2023-1">Período 2023-1</option>
          </select>
        </div>
      </div>

      {/* Cursos Disponibles para Estudiantes */}
      {availableForStudents.length > 0 && (
        <Card className="bg-blue-50 border-blue-200">
          <CardHeader>
            <CardTitle className="text-blue-800 flex items-center gap-2">
              <Clock className="h-5 w-5" />📚 Cursos Disponibles para Asociación de Estudiantes
            </CardTitle>
            <CardDescription className="text-blue-700">
              Estos cursos están listos para recibir estudiantes
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {availableForStudents.map((course) => (
                <CourseStatusCard
                  key={course.id}
                  course={course}
                  userRole="coordinador"
                  onViewDetails={handleViewDetails}
                  onEdit={handleAssignStudents}
                />
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Estudiantes</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalStudents.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">+45 desde el período anterior</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Estudiantes Asignados</CardTitle>
            <UserPlus className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.enrolledStudents.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">{stats.pendingEnrollment} pendientes por asignar</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Tasa de Matrícula</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.enrollmentRate}%</div>
            <Progress value={stats.enrollmentRate} className="mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Cursos Disponibles</CardTitle>
            <GraduationCap className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.availableCourses}</div>
            <p className="text-xs text-muted-foreground">{stats.fullCourses} en capacidad máxima</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {/* Alertas */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5" />
              Alertas de Matrícula
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {alerts.map((alert) => (
              <div
                key={alert.id}
                className={`flex items-start space-x-3 p-3 rounded-lg border ${
                  alert.type === "warning"
                    ? "bg-yellow-50 border-yellow-200"
                    : alert.type === "info"
                      ? "bg-blue-50 border-blue-200"
                      : "bg-green-50 border-green-200"
                }`}
              >
                <div className="flex-shrink-0">
                  {alert.type === "warning" ? (
                    <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  ) : alert.type === "info" ? (
                    <Clock className="h-5 w-5 text-blue-600" />
                  ) : (
                    <CheckCircle className="h-5 w-5 text-green-600" />
                  )}
                </div>
                <div className="flex-1">
                  <h4 className="font-medium">{alert.title}</h4>
                  <p className="text-sm text-muted-foreground">{alert.description}</p>
                </div>
                <Badge
                  variant={
                    alert.priority === "high" ? "destructive" : alert.priority === "medium" ? "default" : "secondary"
                  }
                >
                  {alert.priority === "high" ? "Alta" : alert.priority === "medium" ? "Media" : "Baja"}
                </Badge>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle>Acciones Rápidas</CardTitle>
            <CardDescription>Tareas frecuentes de registro</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {quickActions.map((action, index) => (
              <Button key={index} variant="outline" className="w-full justify-start h-auto p-3 bg-transparent" asChild>
                <a href={action.href}>
                  <div className="flex items-center space-x-3">
                    <div className={`p-2 rounded-md ${action.color}`}>
                      <action.icon className="h-4 w-4 text-white" />
                    </div>
                    <div className="text-left">
                      <div className="font-medium">{action.title}</div>
                      <div className="text-xs text-muted-foreground">{action.description}</div>
                    </div>
                    <ChevronRight className="ml-auto h-4 w-4 text-muted-foreground" />
                  </div>
                </a>
              </Button>
            ))}
          </CardContent>
        </Card>
      </div>

      {/* Cursos Parcialmente Llenos */}
      {partiallyFilled.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5 text-green-600" />
              Cursos con Matrícula Parcial
            </CardTitle>
            <CardDescription>Cursos que tienen estudiantes asignados pero aún tienen cupos disponibles</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {partiallyFilled.map((course) => (
                <CourseStatusCard
                  key={course.id}
                  course={course}
                  userRole="coordinador"
                  onViewDetails={handleViewDetails}
                  onEdit={handleAssignStudents}
                />
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Recent Activities */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5" />
            Actividad Reciente
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {recentActivities.map((activity) => (
              <div key={activity.id} className="flex items-center space-x-4 p-3 rounded-lg bg-muted/50">
                <div className="flex-shrink-0">
                  <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                    <CalendarDays className="h-4 w-4 text-primary" />
                  </div>
                </div>
                <div className="flex-1">
                  <p className="text-sm">
                    <span className="font-medium">{activity.action}</span>: {activity.subject}
                  </p>
                  <p className="text-xs text-muted-foreground">{activity.time}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
