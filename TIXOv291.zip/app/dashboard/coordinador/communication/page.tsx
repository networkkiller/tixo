"use client"

import { useAuth } from "@/contexts/auth-context"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { MessageSquare, Send, Users, Mail, Bell, Calendar, FileText, Plus, Search, Filter } from "lucide-react"

export default function CommunicationPage() {
  const { user } = useAuth()

  if (!user) return null

  const communications = [
    {
      id: "1",
      subject: "Reunión de Padres - 5° Grado",
      type: "Circular",
      recipients: "Padres de 5° Grado",
      recipientCount: 28,
      status: "Enviado",
      date: "2024-01-15",
      priority: "Alta",
      readCount: 24,
    },
    {
      id: "2",
      subject: "Cambio de Horario - Matemáticas",
      type: "Notificación",
      recipients: "Estudiantes de 3° Secundaria",
      recipientCount: 35,
      status: "Programado",
      date: "2024-01-16",
      priority: "Media",
      readCount: 0,
    },
    {
      id: "3",
      subject: "Inscripciones Abiertas 2024",
      type: "Anuncio",
      recipients: "Comunidad General",
      recipientCount: 450,
      status: "Borrador",
      date: "2024-01-18",
      priority: "Alta",
      readCount: 0,
    },
    {
      id: "4",
      subject: "Evaluaciones Trimestrales",
      type: "Recordatorio",
      recipients: "Profesores",
      recipientCount: 25,
      status: "Enviado",
      date: "2024-01-12",
      priority: "Media",
      readCount: 22,
    },
  ]

  const getStatusBadge = (status: string) => {
    const variants = {
      Enviado: "bg-green-100 text-green-800",
      Programado: "bg-blue-100 text-blue-800",
      Borrador: "bg-yellow-100 text-yellow-800",
      Error: "bg-red-100 text-red-800",
    }
    return variants[status as keyof typeof variants] || "bg-gray-100 text-gray-800"
  }

  const getPriorityBadge = (priority: string) => {
    const variants = {
      Alta: "bg-red-100 text-red-800",
      Media: "bg-yellow-100 text-yellow-800",
      Baja: "bg-green-100 text-green-800",
    }
    return variants[priority as keyof typeof variants] || "bg-gray-100 text-gray-800"
  }

  const getTypeIcon = (type: string) => {
    const icons = {
      Circular: <FileText className="h-5 w-5 text-blue-500" />,
      Notificación: <Bell className="h-5 w-5 text-orange-500" />,
      Anuncio: <MessageSquare className="h-5 w-5 text-purple-500" />,
      Recordatorio: <Calendar className="h-5 w-5 text-green-500" />,
    }
    return icons[type as keyof typeof icons] || <Mail className="h-5 w-5 text-gray-500" />
  }

  return (
    <div className="flex flex-col gap-6 p-8 bg-gray-50 min-h-screen">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-gray-900">Comunicación</h1>
          <p className="text-gray-500">Centro de comunicación institucional</p>
        </div>
        <Button className="bg-indigo-600 hover:bg-indigo-700">
          <Plus className="h-4 w-4 mr-2" />
          Nueva Comunicación
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Enviados Hoy</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">12</div>
            <div className="text-xs text-green-600">+3 vs ayer</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Programados</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">8</div>
            <div className="text-xs text-blue-600">Esta semana</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Tasa de Lectura</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">87%</div>
            <div className="text-xs text-purple-600">Promedio mensual</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Destinatarios</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">1,247</div>
            <div className="text-xs text-orange-600">Contactos activos</div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Communication */}
      <Card>
        <CardHeader>
          <CardTitle>Envío Rápido</CardTitle>
          <CardDescription>Crear y enviar comunicación rápida</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Destinatarios</label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Seleccionar grupo" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all-parents">Todos los Padres</SelectItem>
                  <SelectItem value="all-teachers">Todos los Profesores</SelectItem>
                  <SelectItem value="all-students">Todos los Estudiantes</SelectItem>
                  <SelectItem value="grade-specific">Grado Específico</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">Tipo</label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Tipo de comunicación" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="circular">Circular</SelectItem>
                  <SelectItem value="notification">Notificación</SelectItem>
                  <SelectItem value="announcement">Anuncio</SelectItem>
                  <SelectItem value="reminder">Recordatorio</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <label className="text-sm font-medium mb-2 block">Asunto</label>
            <Input placeholder="Ingrese el asunto del mensaje" />
          </div>

          <div>
            <label className="text-sm font-medium mb-2 block">Mensaje</label>
            <Textarea placeholder="Escriba su mensaje aquí..." className="min-h-[120px]" />
          </div>

          <div className="flex justify-end space-x-2">
            <Button variant="outline">Guardar Borrador</Button>
            <Button className="bg-indigo-600 hover:bg-indigo-700">
              <Send className="h-4 w-4 mr-2" />
              Enviar Ahora
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Communication History */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Historial de Comunicaciones</CardTitle>
              <CardDescription>Comunicaciones enviadas y programadas</CardDescription>
            </div>
            <div className="flex space-x-2">
              <Button variant="outline" size="sm">
                <Search className="h-4 w-4 mr-2" />
                Buscar
              </Button>
              <Button variant="outline" size="sm">
                <Filter className="h-4 w-4 mr-2" />
                Filtrar
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {communications.map((comm) => (
              <div key={comm.id} className="border rounded-lg p-4 hover:bg-gray-50">
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-4">
                    <div className="mt-1">{getTypeIcon(comm.type)}</div>
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-2">
                        <h3 className="font-semibold text-gray-900">{comm.subject}</h3>
                        <Badge variant="outline">{comm.type}</Badge>
                        <Badge className={getStatusBadge(comm.status)}>{comm.status}</Badge>
                        <Badge className={getPriorityBadge(comm.priority)}>{comm.priority}</Badge>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-gray-600">
                        <div className="flex items-center space-x-2">
                          <Users className="h-4 w-4" />
                          <span>
                            {comm.recipients} ({comm.recipientCount})
                          </span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Calendar className="h-4 w-4" />
                          <span>{comm.date}</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Mail className="h-4 w-4" />
                          <span>
                            {comm.readCount} de {comm.recipientCount} leídos
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="flex space-x-2 ml-4">
                    <Button variant="outline" size="sm">
                      Ver Detalles
                    </Button>
                    {comm.status === "Borrador" && (
                      <Button variant="outline" size="sm">
                        Editar
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
