"use client"

import { AlertDialogTrigger } from "@/components/ui/alert-dialog"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  AlertDialog,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import {
  Search,
  Download,
  Filter,
  FileText,
  User,
  BookOpen,
  MoreHorizontal,
  Eye,
  Edit,
  Upload,
  RefreshCw,
  Users,
  GraduationCap,
  Clock,
  CheckCircle,
  AlertTriangle,
  Plus,
  Trash2,
} from "lucide-react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

// Tipos de datos
interface Student {
  id: string
  firstName: string
  lastName: string
  cedula: string
  birthDate: string
  gender: "Masculino" | "Femenino" | "Otro"
  phone?: string
  email?: string
  address?: string
  parentName: string
  parentPhone: string
  parentEmail: string
  courseId?: string
  courseName?: string
  status: "Activo" | "Proceso de inscripción" | "Inactivo"
  documents: Document[]
  missingDocuments: string[]
  enrollmentDate: string
  academicHistory: AcademicRecord[]
}

interface Document {
  id: string
  name: string
  type: string
  uploadDate: string
  url: string
}

interface AcademicRecord {
  id: string
  year: string
  course: string
  status: string
  notes?: string
}

interface Course {
  id: string
  name: string
  grade: string
  section: string
  turn: "Mañana" | "Tarde" | "Extendida"
  capacity: number
  currentStudents: number
  teacher: string
  status: "active" | "inactive"
}

// Datos de ejemplo
const mockStudents: Student[] = [
  {
    id: "ST001",
    firstName: "Ana María",
    lastName: "González Pérez",
    cedula: "001-1234567-8",
    birthDate: "2014-05-12",
    gender: "Femenino",
    phone: "809-555-0123",
    email: "ana.gonzalez@email.com",
    address: "Calle Principal 123, Santo Domingo",
    parentName: "Carlos González",
    parentPhone: "809-555-1234",
    parentEmail: "carlos.gonzalez@email.com",
    courseId: "course_1",
    courseName: "3° Primaria A",
    status: "Activo",
    documents: [
      { id: "doc1", name: "Acta de Nacimiento", type: "birth_certificate", uploadDate: "2024-01-15", url: "#" },
      { id: "doc2", name: "Foto", type: "photo", uploadDate: "2024-01-15", url: "#" },
    ],
    missingDocuments: ["Certificado Médico"],
    enrollmentDate: "2024-01-15",
    academicHistory: [{ id: "hist1", year: "2023-2024", course: "2° Primaria A", status: "Aprobado" }],
  },
  {
    id: "ST002",
    firstName: "Luis Fernando",
    lastName: "Martínez López",
    cedula: "001-2345678-9",
    birthDate: "2012-08-23",
    gender: "Masculino",
    phone: "809-555-0124",
    address: "Av. Central 456, Santiago",
    parentName: "María Martínez",
    parentPhone: "809-555-5678",
    parentEmail: "maria.martinez@email.com",
    status: "Proceso de inscripción",
    documents: [],
    missingDocuments: ["Acta de Nacimiento", "Foto", "Certificado Médico"],
    enrollmentDate: "2024-01-20",
    academicHistory: [],
  },
]

const mockCourses: Course[] = [
  {
    id: "course_1",
    name: "3° Primaria A",
    grade: "3°",
    section: "A",
    turn: "Mañana",
    capacity: 28,
    currentStudents: 21,
    teacher: "Prof. Carmen Jiménez",
    status: "active",
  },
  {
    id: "course_2",
    name: "3° Primaria B",
    grade: "3°",
    section: "B",
    turn: "Tarde",
    capacity: 30,
    currentStudents: 18,
    teacher: "Prof. Luis Fernández",
    status: "active",
  },
  {
    id: "course_3",
    name: "4° Primaria A",
    grade: "4°",
    section: "A",
    turn: "Mañana",
    capacity: 25,
    currentStudents: 25,
    teacher: "Prof. Ana Rodríguez",
    status: "active",
  },
]

export default function StudentsManagementPage() {
  const [students, setStudents] = useState<Student[]>(mockStudents)
  const [courses] = useState<Course[]>(mockCourses)
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedGrade, setSelectedGrade] = useState("all")
  const [selectedStatus, setSelectedStatus] = useState("all")
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null)
  const [isNewStudentDialogOpen, setIsNewStudentDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [isDocumentsDialogOpen, setIsDocumentsDialogOpen] = useState(false)
  const [isCourseChangeDialogOpen, setIsCourseChangeDialogOpen] = useState(false)
  const [isProfileDialogOpen, setIsProfileDialogOpen] = useState(false)
  const [activeTab, setActiveTab] = useState("students")
  // Add after existing states
  const [editStudentForm, setEditStudentForm] = useState({
    firstName: "",
    lastName: "",
    cedula: "",
    birthDate: "",
    gender: "",
    phone: "",
    email: "",
    address: "",
    parentName: "",
    parentPhone: "",
    parentEmail: "",
    courseId: "",
  })

  // Estados para formularios
  const [newStudentForm, setNewStudentForm] = useState({
    firstName: "",
    lastName: "",
    cedula: "",
    birthDate: "",
    gender: "",
    phone: "",
    email: "",
    address: "",
    parentName: "",
    parentPhone: "",
    parentEmail: "",
    courseId: "",
  })

  const [isCourseStudentsDialogOpen, setIsCourseStudentsDialogOpen] = useState(false)
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null)
  const [courseStudentsSearch, setCourseStudentsSearch] = useState("")
  const [courseStudentsFilter, setCourseStudentsFilter] = useState("all")

  // Filtrar estudiantes
  const filteredStudents = students.filter((student) => {
    const fullName = `${student.firstName} ${student.lastName}`.toLowerCase()
    const matchesSearch =
      fullName.includes(searchTerm.toLowerCase()) || student.cedula.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesGrade = selectedGrade === "all" || student.courseName?.includes(selectedGrade)
    const matchesStatus = selectedStatus === "all" || student.status === selectedStatus

    return matchesSearch && matchesGrade && matchesStatus
  })

  // Estudiantes no asignados
  const unassignedStudents = students.filter((student) => !student.courseId)

  // Función para obtener estudiantes de un curso específico
  const getCourseStudents = (courseId: string) => {
    return students.filter((student) => student.courseId === courseId)
  }

  // Función para calcular edad
  const calculateAge = (birthDate: string) => {
    const today = new Date()
    const birth = new Date(birthDate)
    let age = today.getFullYear() - birth.getFullYear()
    const monthDiff = today.getMonth() - birth.getMonth()
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
      age--
    }
    return age
  }

  // Función para desasignar estudiante
  const handleUnassignStudent = (studentId: string, courseId: string) => {
    const course = courses.find((c) => c.id === courseId)
    if (!course) return

    setStudents(
      students.map((student) => {
        if (student.id === studentId) {
          // Actualizar contador del curso
          course.currentStudents -= 1

          // Agregar al historial académico
          const newHistory: AcademicRecord = {
            id: `hist_${Date.now()}`,
            year: new Date().getFullYear().toString(),
            course: student.courseName || "Sin curso",
            status: "Desasignado",
            notes: `Desasignado de ${course.name}`,
          }

          return {
            ...student,
            courseId: undefined,
            courseName: undefined,
            status: "Proceso de inscripción" as const,
            academicHistory: [...student.academicHistory, newHistory],
          }
        }
        return student
      }),
    )

    alert("Estudiante desasignado exitosamente")
  }

  const handleCreateStudent = () => {
    if (!newStudentForm.firstName || !newStudentForm.lastName || !newStudentForm.cedula || !newStudentForm.parentName) {
      alert("Por favor complete todos los campos obligatorios")
      return
    }

    // Validar cédula única
    const existingStudent = students.find((s) => s.cedula === newStudentForm.cedula)
    if (existingStudent) {
      alert("Ya existe un estudiante con esta cédula")
      return
    }

    const newStudent: Student = {
      id: `ST${Date.now()}`,
      firstName: newStudentForm.firstName,
      lastName: newStudentForm.lastName,
      cedula: newStudentForm.cedula,
      birthDate: newStudentForm.birthDate,
      gender: newStudentForm.gender as "Masculino" | "Femenino" | "Otro",
      phone: newStudentForm.phone,
      email: newStudentForm.email,
      address: newStudentForm.address,
      parentName: newStudentForm.parentName,
      parentPhone: newStudentForm.parentPhone,
      parentEmail: newStudentForm.parentEmail,
      courseId: newStudentForm.courseId || undefined,
      courseName: newStudentForm.courseId ? courses.find((c) => c.id === newStudentForm.courseId)?.name : undefined,
      status: "Proceso de inscripción",
      documents: [],
      missingDocuments: ["Acta de Nacimiento", "Foto", "Certificado Médico"],
      enrollmentDate: new Date().toISOString().split("T")[0],
      academicHistory: [],
    }

    setStudents([...students, newStudent])
    setNewStudentForm({
      firstName: "",
      lastName: "",
      cedula: "",
      birthDate: "",
      gender: "",
      phone: "",
      email: "",
      address: "",
      parentName: "",
      parentPhone: "",
      parentEmail: "",
      courseId: "",
    })
    setIsNewStudentDialogOpen(false)

    // Mostrar perfil del estudiante creado
    setSelectedStudent(newStudent)
    setIsProfileDialogOpen(true)
  }

  const handleAssignStudentToCourse = (studentId: string, courseId: string) => {
    const course = courses.find((c) => c.id === courseId)
    if (!course) return

    if (course.currentStudents >= course.capacity) {
      alert("El curso ha alcanzado su capacidad máxima")
      return
    }

    setStudents(
      students.map((student) =>
        student.id === studentId
          ? {
              ...student,
              courseId,
              courseName: course.name,
              status: "Activo" as const,
            }
          : student,
      ),
    )

    // Actualizar contador del curso (simulado)
    course.currentStudents += 1
  }

  const handleAutoAssignStudents = () => {
    const unassigned = students.filter((s) => !s.courseId && s.status !== "Inactivo")
    const availableCourses = courses.filter((c) => c.currentStudents < c.capacity && c.status === "active")

    if (unassigned.length === 0) {
      alert("No hay estudiantes sin asignar")
      return
    }

    if (availableCourses.length === 0) {
      alert("No hay cursos disponibles")
      return
    }

    let courseIndex = 0
    const updatedStudents = students.map((student) => {
      if (!student.courseId && student.status !== "Inactivo") {
        const course = availableCourses[courseIndex]
        if (course && course.currentStudents < course.capacity) {
          course.currentStudents += 1
          courseIndex = (courseIndex + 1) % availableCourses.length

          return {
            ...student,
            courseId: course.id,
            courseName: course.name,
            status: "Activo" as const,
          }
        }
      }
      return student
    })

    setStudents(updatedStudents)
    alert(`Se asignaron automáticamente ${unassigned.length} estudiantes`)
  }

  const handleChangeCourse = (studentId: string, newCourseId: string) => {
    const newCourse = courses.find((c) => c.id === newCourseId)
    if (!newCourse) return

    if (newCourse.currentStudents >= newCourse.capacity) {
      alert("El curso seleccionado ha alcanzado su capacidad máxima")
      return
    }

    setStudents(
      students.map((student) => {
        if (student.id === studentId) {
          // Actualizar contadores de cursos (simulado)
          if (student.courseId) {
            const oldCourse = courses.find((c) => c.id === student.courseId)
            if (oldCourse) oldCourse.currentStudents -= 1
          }
          newCourse.currentStudents += 1

          // Agregar al historial académico
          const newHistory: AcademicRecord = {
            id: `hist_${Date.now()}`,
            year: new Date().getFullYear().toString(),
            course: student.courseName || "Sin curso",
            status: "Transferido",
            notes: `Transferido a ${newCourse.name}`,
          }

          return {
            ...student,
            courseId: newCourseId,
            courseName: newCourse.name,
            academicHistory: [...student.academicHistory, newHistory],
          }
        }
        return student
      }),
    )

    setIsCourseChangeDialogOpen(false)
    alert("Cambio de curso realizado exitosamente")
  }

  // Add the handleEditStudent function after the existing functions:

  const handleEditStudent = (student: Student) => {
    setSelectedStudent(student)
    setEditStudentForm({
      firstName: student.firstName,
      lastName: student.lastName,
      cedula: student.cedula,
      birthDate: student.birthDate,
      gender: student.gender,
      phone: student.phone || "",
      email: student.email || "",
      address: student.address || "",
      parentName: student.parentName,
      parentPhone: student.parentPhone,
      parentEmail: student.parentEmail,
      courseId: student.courseId || "unassigned",
    })
    setIsEditDialogOpen(true)
  }

  const handleUpdateStudent = () => {
    if (!selectedStudent || !editStudentForm.firstName || !editStudentForm.lastName || !editStudentForm.cedula) {
      alert("Por favor complete todos los campos obligatorios")
      return
    }

    setStudents(
      students.map((student) =>
        student.id === selectedStudent.id
          ? {
              ...student,
              firstName: editStudentForm.firstName,
              lastName: editStudentForm.lastName,
              cedula: editStudentForm.cedula,
              birthDate: editStudentForm.birthDate,
              gender: editStudentForm.gender as "Masculino" | "Femenino" | "Otro",
              phone: editStudentForm.phone,
              email: editStudentForm.email,
              address: editStudentForm.address,
              parentName: editStudentForm.parentName,
              parentPhone: editStudentForm.parentPhone,
              parentEmail: editStudentForm.parentEmail,
              courseId: editStudentForm.courseId === "unassigned" ? undefined : editStudentForm.courseId || undefined,
              courseName:
                editStudentForm.courseId === "unassigned"
                  ? undefined
                  : editStudentForm.courseId
                    ? courses.find((c) => c.id === editStudentForm.courseId)?.name
                    : undefined,
            }
          : student,
      ),
    )

    setIsEditDialogOpen(false)
    alert("Información del estudiante actualizada exitosamente")
  }

  const handleDeleteStudent = (studentId: string) => {
    if (confirm("¿Está seguro de que desea eliminar este estudiante? Esta acción no se puede deshacer.")) {
      setStudents(students.filter((student) => student.id !== studentId))
      alert("Estudiante eliminado exitosamente")
    }
  }

  const handleViewStudent = (student: Student) => {
    setSelectedStudent(student)
    setIsProfileDialogOpen(true)
  }

  return (
    <div className="flex flex-col gap-6 p-8 bg-gray-50 min-h-screen">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-gray-900">Gestión de Estudiantes</h1>
          <p className="text-gray-500">Administra el registro y seguimiento de estudiantes</p>
        </div>
        <div className="flex items-center gap-2">
          {/* Dialog: Editar Estudiante */}
          <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Editar Información del Estudiante</DialogTitle>
                <DialogDescription>
                  Modifica la información del estudiante. Los campos marcados con * son obligatorios.
                </DialogDescription>
              </DialogHeader>

              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="editFirstName">Nombres *</Label>
                    <Input
                      id="editFirstName"
                      value={editStudentForm.firstName}
                      onChange={(e) => setEditStudentForm({ ...editStudentForm, firstName: e.target.value })}
                      placeholder="Nombres del estudiante"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="editLastName">Apellidos *</Label>
                    <Input
                      id="editLastName"
                      value={editStudentForm.lastName}
                      onChange={(e) => setEditStudentForm({ ...editStudentForm, lastName: e.target.value })}
                      placeholder="Apellidos del estudiante"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="editCedula">Cédula / ID Estudiantil *</Label>
                    <Input
                      id="editCedula"
                      value={editStudentForm.cedula}
                      onChange={(e) => setEditStudentForm({ ...editStudentForm, cedula: e.target.value })}
                      placeholder="001-1234567-8"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="editBirthDate">Fecha de Nacimiento *</Label>
                    <Input
                      id="editBirthDate"
                      type="date"
                      value={editStudentForm.birthDate}
                      onChange={(e) => setEditStudentForm({ ...editStudentForm, birthDate: e.target.value })}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="editGender">Sexo *</Label>
                    <Select
                      value={editStudentForm.gender}
                      onValueChange={(value) => setEditStudentForm({ ...editStudentForm, gender: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Seleccionar sexo" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Masculino">Masculino</SelectItem>
                        <SelectItem value="Femenino">Femenino</SelectItem>
                        <SelectItem value="Otro">Otro</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="editPhone">Teléfono de Contacto</Label>
                    <Input
                      id="editPhone"
                      value={editStudentForm.phone}
                      onChange={(e) => setEditStudentForm({ ...editStudentForm, phone: e.target.value })}
                      placeholder="809-555-0123"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="editEmail">Correo Electrónico</Label>
                  <Input
                    id="editEmail"
                    type="email"
                    value={editStudentForm.email}
                    onChange={(e) => setEditStudentForm({ ...editStudentForm, email: e.target.value })}
                    placeholder="estudiante@email.com"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="editAddress">Dirección</Label>
                  <Textarea
                    id="editAddress"
                    value={editStudentForm.address}
                    onChange={(e) => setEditStudentForm({ ...editStudentForm, address: e.target.value })}
                    placeholder="Dirección completa del estudiante"
                  />
                </div>

                <div className="border-t pt-4">
                  <h4 className="font-medium mb-4">Información del Padre/Madre/Tutor</h4>
                  <div className="grid gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="editParentName">Nombre del Tutor *</Label>
                      <Input
                        id="editParentName"
                        value={editStudentForm.parentName}
                        onChange={(e) => setEditStudentForm({ ...editStudentForm, parentName: e.target.value })}
                        placeholder="Nombre completo del tutor"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="editParentPhone">Teléfono del Tutor</Label>
                        <Input
                          id="editParentPhone"
                          value={editStudentForm.parentPhone}
                          onChange={(e) => setEditStudentForm({ ...editStudentForm, parentPhone: e.target.value })}
                          placeholder="809-555-1234"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="editParentEmail">Email del Tutor</Label>
                        <Input
                          id="editParentEmail"
                          type="email"
                          value={editStudentForm.parentEmail}
                          onChange={(e) => setEditStudentForm({ ...editStudentForm, parentEmail: e.target.value })}
                          placeholder="tutor@email.com"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="editCourseId">Curso Asignado</Label>
                  <Select
                    value={editStudentForm.courseId}
                    onValueChange={(value) => setEditStudentForm({ ...editStudentForm, courseId: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Seleccionar curso" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="unassigned">Sin asignar</SelectItem>
                      {courses
                        .filter((c) => c.status === "active")
                        .map((course) => (
                          <SelectItem key={course.id} value={course.id}>
                            {course.name} - {course.turn} ({course.currentStudents}/{course.capacity})
                          </SelectItem>
                        ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <DialogFooter>
                <Button
                  variant="outline"
                  onClick={() => {
                    setIsEditDialogOpen(false)
                    setEditStudentForm({
                      firstName: "",
                      lastName: "",
                      cedula: "",
                      birthDate: "",
                      gender: "",
                      phone: "",
                      email: "",
                      address: "",
                      parentName: "",
                      parentPhone: "",
                      parentEmail: "",
                      courseId: "",
                    })
                  }}
                >
                  Cancelar
                </Button>
                <Button
                  onClick={handleUpdateStudent}
                  className="bg-indigo-600 hover:bg-indigo-700"
                  disabled={
                    !editStudentForm.firstName ||
                    !editStudentForm.lastName ||
                    !editStudentForm.cedula ||
                    !editStudentForm.parentName
                  }
                >
                  Actualizar Información
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          <Button variant="outline" className="gap-2 bg-transparent">
            <Download className="h-4 w-4" />
            <span>Exportar</span>
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2 lg:w-[400px]">
          <TabsTrigger value="students">Listado de Estudiantes</TabsTrigger>
          <TabsTrigger value="course-assignment">Asignación de Cursos</TabsTrigger>
        </TabsList>

        <TabsContent value="students" className="mt-6">
          <div className="flex flex-col gap-4 md:flex-row md:items-center mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
              <Input
                placeholder="Buscar por nombre o cédula..."
                className="pl-9"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="flex gap-2">
              <Select value={selectedGrade} onValueChange={setSelectedGrade}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Filtrar por grado" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos los grados</SelectItem>
                  <SelectItem value="1°">1° Primaria</SelectItem>
                  <SelectItem value="2°">2° Primaria</SelectItem>
                  <SelectItem value="3°">3° Primaria</SelectItem>
                  <SelectItem value="4°">4° Primaria</SelectItem>
                  <SelectItem value="5°">5° Primaria</SelectItem>
                  <SelectItem value="6°">6° Primaria</SelectItem>
                </SelectContent>
              </Select>

              <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Filtrar por estado" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos los estados</SelectItem>
                  <SelectItem value="Activo">Activo</SelectItem>
                  <SelectItem value="Proceso de inscripción">En inscripción</SelectItem>
                  <SelectItem value="Inactivo">Inactivo</SelectItem>
                </SelectContent>
              </Select>

              <Button variant="outline" size="icon">
                <Filter className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Estudiante</TableHead>
                    <TableHead>Cédula</TableHead>
                    <TableHead>Curso Actual</TableHead>
                    <TableHead>Estado</TableHead>
                    <TableHead>Documentos</TableHead>
                    <TableHead>Tutor</TableHead>
                    <TableHead>Acciones</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredStudents.map((student) => (
                    <TableRow key={student.id}>
                      <TableCell>
                        <div>
                          <div className="font-medium">
                            {student.firstName} {student.lastName}
                          </div>
                          <div className="text-sm text-gray-500">
                            Inscrito: {new Date(student.enrollmentDate).toLocaleDateString()}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell className="font-mono text-sm">{student.cedula}</TableCell>
                      <TableCell>
                        {student.courseName ? (
                          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                            {student.courseName}
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="bg-gray-50 text-gray-700 border-gray-200">
                            Sin asignar
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant="outline"
                          className={
                            student.status === "Activo"
                              ? "bg-green-50 text-green-700 border-green-200"
                              : student.status === "Proceso de inscripción"
                                ? "bg-amber-50 text-amber-700 border-amber-200"
                                : "bg-gray-50 text-gray-700 border-gray-200"
                          }
                        >
                          {student.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {student.missingDocuments.length > 0 ? (
                          <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
                            {student.missingDocuments.length} pendientes
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                            Completos
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="text-sm">
                          <div className="font-medium">{student.parentName}</div>
                          <div className="text-gray-500">{student.parentPhone}</div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Acciones</DropdownMenuLabel>
                            <DropdownMenuItem onClick={() => handleViewStudent(student)}>
                              <Eye className="mr-2 h-4 w-4" />
                              Ver Perfil
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleEditStudent(student)}>
                              <Edit className="mr-2 h-4 w-4" />
                              Editar Información
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              onClick={() => {
                                setSelectedStudent(student)
                                setIsDocumentsDialogOpen(true)
                              }}
                            >
                              <FileText className="mr-2 h-4 w-4" />
                              Documentos
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem
                              onClick={() => {
                                setSelectedStudent(student)
                                setIsCourseChangeDialogOpen(true)
                              }}
                            >
                              <RefreshCw className="mr-2 h-4 w-4" />
                              Cambio de Curso
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              onClick={() => handleDeleteStudent(student.id)}
                              className="text-red-600 focus:text-red-600"
                            >
                              <Trash2 className="mr-2 h-4 w-4" />
                              Eliminar Estudiante
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
            <CardFooter className="flex items-center justify-between border-t p-4">
              <div className="text-sm text-gray-500">
                Mostrando {filteredStudents.length} de {students.length} estudiantes
              </div>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm" disabled>
                  Anterior
                </Button>
                <Button variant="outline" size="sm">
                  Siguiente
                </Button>
              </div>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="course-assignment" className="mt-6">
          <div className="space-y-6">
            {/* Estadísticas */}
            <div className="grid gap-4 md:grid-cols-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-gray-500">Total Estudiantes</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{students.length}</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-gray-500">Estudiantes Asignados</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{students.filter((s) => s.courseId).length}</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-gray-500">Sin Asignar</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-orange-600">{unassignedStudents.length}</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-gray-500">Cursos Activos</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{courses.filter((c) => c.status === "active").length}</div>
                </CardContent>
              </Card>
            </div>

            {/* Asignación Automática */}
            {unassignedStudents.length > 0 && (
              <Card className="bg-orange-50 border-orange-200">
                <CardHeader>
                  <CardTitle className="text-orange-800 flex items-center gap-2">
                    <AlertTriangle className="h-5 w-5" />
                    Estudiantes Sin Asignar
                  </CardTitle>
                  <CardDescription className="text-orange-700">
                    Hay {unassignedStudents.length} estudiantes que necesitan ser asignados a un curso
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Button onClick={handleAutoAssignStudents} className="bg-orange-600 hover:bg-orange-700">
                    <RefreshCw className="mr-2 h-4 w-4" />
                    Asignar Automáticamente
                  </Button>
                </CardContent>
              </Card>
            )}

            {/* Lista de Cursos */}

            <div className="grid gap-4">
              <h3 className="text-lg font-semibold">Cursos Disponibles</h3>
              {courses
                .filter((c) => c.status === "active")
                .map((course) => (
                  <Card key={course.id}>
                    <CardHeader
                      className="cursor-pointer hover:bg-gray-50 transition-colors"
                      onClick={() => {
                        setSelectedCourse(course)
                        setIsCourseStudentsDialogOpen(true)
                      }}
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <CardTitle className="flex items-center gap-2">
                            <GraduationCap className="h-5 w-5" />
                            {course.name}
                          </CardTitle>
                          <CardDescription>
                            {course.turn} • Docente: {course.teacher}
                          </CardDescription>
                        </div>
                        <div className="text-right">
                          <div className="text-2xl font-bold">
                            {course.currentStudents}/{course.capacity}
                          </div>
                          <div className="text-sm text-gray-500">estudiantes</div>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex-1 mr-4">
                          <div className="flex justify-between text-sm mb-1">
                            <span>Capacidad</span>
                            <span>{Math.round((course.currentStudents / course.capacity) * 100)}%</span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div
                              className={`h-2 rounded-full ${
                                course.currentStudents >= course.capacity
                                  ? "bg-red-500"
                                  : course.currentStudents / course.capacity > 0.8
                                    ? "bg-yellow-500"
                                    : "bg-green-500"
                              }`}
                              style={{ width: `${(course.currentStudents / course.capacity) * 100}%` }}
                            />
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button variant="outline" size="sm" disabled={course.currentStudents >= course.capacity}>
                                <Plus className="mr-2 h-4 w-4" />
                                Asignar Estudiante
                              </Button>
                            </DialogTrigger>
                            <DialogContent>
                              <DialogHeader>
                                <DialogTitle>Asignar Estudiante a {course.name}</DialogTitle>
                                <DialogDescription>
                                  Selecciona un estudiante para asignar a este curso
                                </DialogDescription>
                              </DialogHeader>
                              <div className="space-y-4">
                                <div className="max-h-60 overflow-y-auto space-y-2">
                                  {unassignedStudents.map((student) => (
                                    <div
                                      key={student.id}
                                      className="flex items-center justify-between p-3 border rounded-lg hover:bg-gray-50"
                                    >
                                      <div>
                                        <div className="font-medium">
                                          {student.firstName} {student.lastName}
                                        </div>
                                        <div className="text-sm text-gray-500">
                                          {student.cedula} • {student.parentName}
                                        </div>
                                      </div>
                                      <Button
                                        size="sm"
                                        onClick={() => handleAssignStudentToCourse(student.id, course.id)}
                                      >
                                        Asignar
                                      </Button>
                                    </div>
                                  ))}
                                </div>
                                {unassignedStudents.length === 0 && (
                                  <div className="text-center py-8 text-gray-500">No hay estudiantes sin asignar</div>
                                )}
                              </div>
                            </DialogContent>
                          </Dialog>
                        </div>
                      </div>

                      {course.currentStudents >= course.capacity && (
                        <div className="flex items-center gap-2 text-red-600 text-sm">
                          <AlertTriangle className="h-4 w-4" />
                          Curso en capacidad máxima
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
            </div>
          </div>
        </TabsContent>
      </Tabs>

      {/* Dialog: Ver Perfil del Estudiante */}
      <Dialog open={isProfileDialogOpen} onOpenChange={setIsProfileDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Perfil del Estudiante</DialogTitle>
            <DialogDescription>Información completa del estudiante y su historial académico</DialogDescription>
          </DialogHeader>

          {selectedStudent && (
            <div className="space-y-6">
              {/* Información Personal */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <User className="h-5 w-5" />
                    Información Personal
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label className="text-sm font-medium text-gray-500">Nombre Completo</Label>
                      <p className="text-lg font-semibold">
                        {selectedStudent.firstName} {selectedStudent.lastName}
                      </p>
                    </div>
                    <div>
                      <Label className="text-sm font-medium text-gray-500">Cédula</Label>
                      <p className="font-mono">{selectedStudent.cedula}</p>
                    </div>
                    <div>
                      <Label className="text-sm font-medium text-gray-500">Fecha de Nacimiento</Label>
                      <p>{new Date(selectedStudent.birthDate).toLocaleDateString()}</p>
                    </div>
                    <div>
                      <Label className="text-sm font-medium text-gray-500">Sexo</Label>
                      <p>{selectedStudent.gender}</p>
                    </div>
                    <div>
                      <Label className="text-sm font-medium text-gray-500">Teléfono</Label>
                      <p>{selectedStudent.phone || "No registrado"}</p>
                    </div>
                    <div>
                      <Label className="text-sm font-medium text-gray-500">Email</Label>
                      <p>{selectedStudent.email || "No registrado"}</p>
                    </div>
                    <div className="md:col-span-2">
                      <Label className="text-sm font-medium text-gray-500">Dirección</Label>
                      <p>{selectedStudent.address || "No registrada"}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Información del Tutor */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="h-5 w-5" />
                    Información del Tutor
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <Label className="text-sm font-medium text-gray-500">Nombre</Label>
                      <p className="font-semibold">{selectedStudent.parentName}</p>
                    </div>
                    <div>
                      <Label className="text-sm font-medium text-gray-500">Teléfono</Label>
                      <p>{selectedStudent.parentPhone}</p>
                    </div>
                    <div>
                      <Label className="text-sm font-medium text-gray-500">Email</Label>
                      <p>{selectedStudent.parentEmail}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Curso Actual */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BookOpen className="h-5 w-5" />
                    Curso Actual
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {selectedStudent.courseName ? (
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-lg font-semibold">{selectedStudent.courseName}</p>
                        <p className="text-sm text-gray-500">
                          Estado: <Badge className="ml-1">{selectedStudent.status}</Badge>
                        </p>
                      </div>
                      <Button
                        variant="outline"
                        onClick={() => {
                          setIsCourseChangeDialogOpen(true)
                          setIsProfileDialogOpen(false)
                        }}
                      >
                        <RefreshCw className="mr-2 h-4 w-4" />
                        Cambiar Curso
                      </Button>
                    </div>
                  ) : (
                    <div className="text-center py-8 text-gray-500">
                      <BookOpen className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                      <p>Estudiante no asignado a ningún curso</p>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Documentos */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="h-5 w-5" />
                    Documentación
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {selectedStudent.documents.map((doc) => (
                      <div key={doc.id} className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="flex items-center gap-3">
                          <CheckCircle className="h-5 w-5 text-green-600" />
                          <div>
                            <p className="font-medium">{doc.name}</p>
                            <p className="text-sm text-gray-500">
                              Subido: {new Date(doc.uploadDate).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Button variant="outline" size="sm">
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button variant="outline" size="sm">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}

                    {selectedStudent.missingDocuments.map((docName) => (
                      <div
                        key={docName}
                        className="flex items-center justify-between p-3 border border-red-200 rounded-lg bg-red-50"
                      >
                        <div className="flex items-center gap-3">
                          <AlertTriangle className="h-5 w-5 text-red-600" />
                          <div>
                            <p className="font-medium text-red-800">{docName}</p>
                            <p className="text-sm text-red-600">Documento pendiente</p>
                          </div>
                        </div>
                        <Button variant="outline" size="sm">
                          <Upload className="h-4 w-4" />
                          Subir
                        </Button>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Historial Académico */}
              {selectedStudent.academicHistory.length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Clock className="h-5 w-5" />
                      Historial Académico
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {selectedStudent.academicHistory.map((record) => (
                        <div key={record.id} className="flex items-center justify-between p-3 border rounded-lg">
                          <div>
                            <p className="font-medium">{record.course}</p>
                            <p className="text-sm text-gray-500">
                              {record.year} • {record.status}
                            </p>
                            {record.notes && <p className="text-sm text-gray-600 mt-1">{record.notes}</p>}
                          </div>
                          <Badge variant="outline">{record.status}</Badge>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Dialog: Cambio de Curso */}
      <AlertDialog open={isCourseChangeDialogOpen} onOpenChange={setIsCourseChangeDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Cambiar Curso del Estudiante</AlertDialogTitle>
            <AlertDialogDescription>
              {selectedStudent && (
                <>
                  ¿Deseas cambiar a{" "}
                  <strong>
                    {selectedStudent.firstName} {selectedStudent.lastName}
                  </strong>
                  {selectedStudent.courseName ? ` del curso ${selectedStudent.courseName}` : ""} a un nuevo curso?
                </>
              )}
            </AlertDialogDescription>
          </AlertDialogHeader>

          <div className="space-y-4">
            <Label>Seleccionar nuevo curso:</Label>
            <Select
              onValueChange={(value) => {
                if (selectedStudent) {
                  handleChangeCourse(selectedStudent.id, value)
                }
              }}
            >
              <SelectTrigger>
                <SelectValue placeholder="Seleccionar curso" />
              </SelectTrigger>
              <SelectContent>
                {courses
                  .filter(
                    (c) =>
                      c.status === "active" && c.currentStudents < c.capacity && c.id !== selectedStudent?.courseId,
                  )
                  .map((course) => (
                    <SelectItem key={course.id} value={course.id}>
                      {course.name} - {course.turn} ({course.currentStudents}/{course.capacity})
                    </SelectItem>
                  ))}
              </SelectContent>
            </Select>
          </div>

          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Dialog: Estudiantes del Curso */}
      <Dialog open={isCourseStudentsDialogOpen} onOpenChange={setIsCourseStudentsDialogOpen}>
        <DialogContent className="max-w-6xl max-h-[90vh] overflow-hidden flex flex-col">
          <DialogHeader className="pb-4 border-b">
            <DialogTitle className="flex items-center gap-3">
              <GraduationCap className="h-6 w-6 text-indigo-600" />
              Estudiantes Asignados - {selectedCourse?.name}
            </DialogTitle>
            <DialogDescription>Gestiona los estudiantes asignados a este curso</DialogDescription>
          </DialogHeader>

          {selectedCourse && (
            <div className="flex-1 overflow-hidden flex flex-col">
              {/* Información del Curso */}
              <Card className="mb-4">
                <CardContent className="p-4">
                  <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                    <div className="flex items-center gap-2">
                      <BookOpen className="h-4 w-4 text-gray-500" />
                      <div>
                        <p className="text-sm text-gray-500">Curso</p>
                        <p className="font-semibold">{selectedCourse.name}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4 text-gray-500" />
                      <div>
                        <p className="text-sm text-gray-500">Turno</p>
                        <p className="font-semibold">{selectedCourse.turn}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <User className="h-4 w-4 text-gray-500" />
                      <div>
                        <p className="text-sm text-gray-500">Docente</p>
                        <p className="font-semibold">{selectedCourse.teacher}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Users className="h-4 w-4 text-gray-500" />
                      <div>
                        <p className="text-sm text-gray-500">Capacidad</p>
                        <p className="font-semibold">
                          {selectedCourse.currentStudents}/{selectedCourse.capacity}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <BookOpen className="h-4 w-4 text-gray-500" />
                      <div>
                        <p className="text-sm text-gray-500">Materias</p>
                        <p className="font-semibold">7 configuradas</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Controles de Búsqueda y Filtros */}
              <div className="flex flex-col md:flex-row gap-4 mb-4">
                <div className="relative flex-1">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
                  <Input
                    placeholder="Buscar por nombre, cédula o tutor..."
                    className="pl-9"
                    value={courseStudentsSearch}
                    onChange={(e) => setCourseStudentsSearch(e.target.value)}
                  />
                </div>
                <div className="flex gap-2">
                  <Select value={courseStudentsFilter} onValueChange={setCourseStudentsFilter}>
                    <SelectTrigger className="w-[200px]">
                      <SelectValue placeholder="Filtrar por documentación" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos los estudiantes</SelectItem>
                      <SelectItem value="complete">Documentación completa</SelectItem>
                      <SelectItem value="incomplete">Documentación incompleta</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button variant="outline" size="icon">
                    <Filter className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              {/* Lista de Estudiantes */}
              <Card className="flex-1 overflow-hidden">
                <CardContent className="p-0 h-full">
                  <div className="overflow-auto h-full">
                    <Table>
                      <TableHeader className="sticky top-0 bg-white z-10">
                        <TableRow>
                          <TableHead>Estudiante</TableHead>
                          <TableHead>Cédula/ID</TableHead>
                          <TableHead>Edad</TableHead>
                          <TableHead>Tutor</TableHead>
                          <TableHead>Documentación</TableHead>
                          <TableHead>Fecha Asignación</TableHead>
                          <TableHead>Acciones</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {getCourseStudents(selectedCourse.id)
                          .filter((student) => {
                            const searchTerm = courseStudentsSearch.toLowerCase()
                            const matchesSearch =
                              `${student.firstName} ${student.lastName}`.toLowerCase().includes(searchTerm) ||
                              student.cedula.toLowerCase().includes(searchTerm) ||
                              student.parentName.toLowerCase().includes(searchTerm)

                            const matchesFilter =
                              courseStudentsFilter === "all" ||
                              (courseStudentsFilter === "complete" && student.missingDocuments.length === 0) ||
                              (courseStudentsFilter === "incomplete" && student.missingDocuments.length > 0)

                            return matchesSearch && matchesFilter
                          })
                          .map((student) => (
                            <TableRow key={student.id}>
                              <TableCell>
                                <div className="flex items-center gap-3">
                                  <div className="w-10 h-10 bg-indigo-100 rounded-full flex items-center justify-center">
                                    <User className="w-5 h-5 text-indigo-600" />
                                  </div>
                                  <div>
                                    <div className="font-medium">
                                      {student.firstName} {student.lastName}
                                    </div>
                                    <div className="text-sm text-gray-500">{student.gender}</div>
                                  </div>
                                </div>
                              </TableCell>
                              <TableCell className="font-mono text-sm">{student.cedula}</TableCell>
                              <TableCell>
                                <div className="text-center">
                                  <div className="font-semibold">{calculateAge(student.birthDate)} años</div>
                                  <div className="text-xs text-gray-500">
                                    {new Date(student.birthDate).toLocaleDateString()}
                                  </div>
                                </div>
                              </TableCell>
                              <TableCell>
                                <div>
                                  <div className="font-medium">{student.parentName}</div>
                                  <div className="text-sm text-gray-500">{student.parentPhone}</div>
                                </div>
                              </TableCell>
                              <TableCell>
                                <div className="flex items-center gap-2">
                                  {student.missingDocuments.length === 0 ? (
                                    <>
                                      <CheckCircle className="h-5 w-5 text-green-600" />
                                      <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                                        Completa
                                      </Badge>
                                    </>
                                  ) : (
                                    <>
                                      <AlertTriangle className="h-5 w-5 text-red-600" />
                                      <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
                                        {student.missingDocuments.length} pendientes
                                      </Badge>
                                    </>
                                  )}
                                </div>
                              </TableCell>
                              <TableCell>
                                <div className="text-sm">{new Date(student.enrollmentDate).toLocaleDateString()}</div>
                              </TableCell>
                              <TableCell>
                                <div className="flex items-center gap-2">
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => {
                                      setSelectedStudent(student)
                                      setIsProfileDialogOpen(true)
                                      setIsCourseStudentsDialogOpen(false)
                                    }}
                                  >
                                    <Eye className="h-4 w-4" />
                                  </Button>
                                  <AlertDialog>
                                    <AlertDialogTrigger asChild>
                                      <Button
                                        variant="outline"
                                        size="sm"
                                        className="text-red-600 hover:text-red-700 bg-transparent"
                                      >
                                        <Trash2 className="h-4 w-4" />
                                      </Button>
                                    </AlertDialogTrigger>
                                    <AlertDialogContent>
                                      <AlertDialogHeader>
                                        <AlertDialogTitle>Desasignar Estudiante</AlertDialogTitle>
                                        <AlertDialogDescription>
                                          ¿Estás seguro de que deseas desasignar a{" "}
                                          <strong>
                                            {student.firstName} {student.lastName}
                                          </strong>{" "}
                                          del curso {selectedCourse.name}?
                                          <br />
                                          <br />
                                          Esta acción:
                                          <ul className="list-disc list-inside mt-2 text-sm">
                                            <li>Removerá al estudiante del curso</li>
                                            <li>Lo marcará como "En proceso de inscripción"</li>
                                            <li>Se registrará en su historial académico</li>
                                            <li>Ya no aparecerá en listas de asistencia</li>
                                          </ul>
                                        </AlertDialogDescription>
                                      </AlertDialogHeader>
                                      <AlertDialogFooter>
                                        <AlertDialogCancel>Cancelar</AlertDialogCancel>
                                        <Button
                                          variant="destructive"
                                          onClick={() => handleUnassignStudent(student.id, selectedCourse.id)}
                                        >
                                          Desasignar
                                        </Button>
                                      </AlertDialogFooter>
                                    </AlertDialogContent>
                                  </AlertDialog>
                                </div>
                              </TableCell>
                            </TableRow>
                          ))}
                      </TableBody>
                    </Table>

                    {getCourseStudents(selectedCourse.id).length === 0 && (
                      <div className="text-center py-12">
                        <Users className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                        <p className="text-gray-500 text-lg">No hay estudiantes asignados a este curso</p>
                        <p className="text-gray-400 text-sm">
                          Usa el botón "Asignar Estudiante" para agregar estudiantes
                        </p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Botones de Acción */}
              <div className="flex items-center justify-between pt-4 border-t bg-white">
                <div className="text-sm text-gray-500">
                  {
                    getCourseStudents(selectedCourse.id).filter((student) => {
                      const searchTerm = courseStudentsSearch.toLowerCase()
                      const matchesSearch =
                        `${student.firstName} ${student.lastName}`.toLowerCase().includes(searchTerm) ||
                        student.cedula.toLowerCase().includes(searchTerm) ||
                        student.parentName.toLowerCase().includes(searchTerm)

                      const matchesFilter =
                        courseStudentsFilter === "all" ||
                        (courseStudentsFilter === "complete" && student.missingDocuments.length === 0) ||
                        (courseStudentsFilter === "incomplete" && student.missingDocuments.length > 0)

                      return matchesSearch && matchesFilter
                    }).length
                  }{" "}
                  estudiantes mostrados
                </div>

                <div className="flex items-center gap-2">
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button
                        variant="outline"
                        className="gap-2 bg-transparent"
                        disabled={selectedCourse.currentStudents >= selectedCourse.capacity}
                      >
                        <Plus className="h-4 w-4" />
                        Asignar Nuevo Estudiante
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Asignar Estudiante a {selectedCourse.name}</DialogTitle>
                        <DialogDescription>Selecciona un estudiante para asignar a este curso</DialogDescription>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div className="max-h-60 overflow-y-auto space-y-2">
                          {unassignedStudents.map((student) => (
                            <div
                              key={student.id}
                              className="flex items-center justify-between p-3 border rounded-lg hover:bg-gray-50"
                            >
                              <div>
                                <div className="font-medium">
                                  {student.firstName} {student.lastName}
                                </div>
                                <div className="text-sm text-gray-500">
                                  {student.cedula} • {student.parentName}
                                </div>
                              </div>
                              <Button
                                size="sm"
                                onClick={() => {
                                  handleAssignStudentToCourse(student.id, selectedCourse.id)
                                  // Actualizar la vista
                                  setSelectedCourse({
                                    ...selectedCourse,
                                    currentStudents: selectedCourse.currentStudents + 1,
                                  })
                                }}
                              >
                                Asignar
                              </Button>
                            </div>
                          ))}
                        </div>
                        {unassignedStudents.length === 0 && (
                          <div className="text-center py-8 text-gray-500">No hay estudiantes sin asignar</div>
                        )}
                      </div>
                    </DialogContent>
                  </Dialog>

                  <Button variant="outline" className="gap-2 bg-transparent">
                    <RefreshCw className="h-4 w-4" />
                    Actualizar
                  </Button>

                  <Button variant="outline" className="gap-2 bg-transparent">
                    <Download className="h-4 w-4" />
                    Exportar
                  </Button>

                  <Button variant="outline" onClick={() => setIsCourseStudentsDialogOpen(false)}>
                    Cerrar
                  </Button>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
