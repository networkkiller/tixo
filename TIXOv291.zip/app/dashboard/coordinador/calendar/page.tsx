"use client"

import { useAuth } from "@/contexts/auth-context"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Calendar, Clock, Plus, Users, MapPin, Phone, Mail, Filter, Search } from "lucide-react"

export default function CalendarPage() {
  const { user } = useAuth()

  if (!user) return null

  const appointments = [
    {
      id: "1",
      title: "Reunión con Padres de 5° Grado",
      date: "2024-01-15",
      time: "14:00",
      duration: "2 horas",
      type: "Reunión",
      attendees: 25,
      location: "Aula Magna",
      status: "Confirmada",
      contact: "María González",
      phone: "+1 809-555-0123",
    },
    {
      id: "2",
      title: "Entrevista - Nuevo Estudiante",
      date: "2024-01-16",
      time: "09:30",
      duration: "45 min",
      type: "Entrevista",
      attendees: 3,
      location: "Oficina de Coordinación",
      status: "Pendiente",
      contact: "Carlos Méndez",
      phone: "+1 809-555-0124",
    },
    {
      id: "3",
      title: "Evaluación Docente - Matemáticas",
      date: "2024-01-17",
      time: "10:00",
      duration: "1 hora",
      type: "Evaluación",
      attendees: 2,
      location: "Aula 201",
      status: "Programada",
      contact: "Ana Rodríguez",
      phone: "+1 809-555-0125",
    },
    {
      id: "4",
      title: "Inscripción - Estudiantes Nuevos",
      date: "2024-01-18",
      time: "08:00",
      duration: "4 horas",
      type: "Inscripción",
      attendees: 15,
      location: "Secretaría Académica",
      status: "Confirmada",
      contact: "Luis Fernández",
      phone: "+1 809-555-0126",
    },
  ]

  const getStatusBadge = (status: string) => {
    const variants = {
      Confirmada: "bg-green-100 text-green-800",
      Pendiente: "bg-yellow-100 text-yellow-800",
      Programada: "bg-blue-100 text-blue-800",
      Cancelada: "bg-red-100 text-red-800",
    }
    return variants[status as keyof typeof variants] || "bg-gray-100 text-gray-800"
  }

  const getTypeBadge = (type: string) => {
    const variants = {
      Reunión: "bg-purple-100 text-purple-800",
      Entrevista: "bg-blue-100 text-blue-800",
      Evaluación: "bg-orange-100 text-orange-800",
      Inscripción: "bg-green-100 text-green-800",
    }
    return variants[type as keyof typeof variants] || "bg-gray-100 text-gray-800"
  }

  return (
    <div className="flex flex-col gap-6 p-8 bg-gray-50 min-h-screen">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-gray-900">Calendario y Citas</h1>
          <p className="text-gray-500">Gestión de eventos y citas académicas</p>
        </div>
        <Button className="bg-indigo-600 hover:bg-indigo-700">
          <Plus className="h-4 w-4 mr-2" />
          Nueva Cita
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Citas Hoy</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">8</div>
            <div className="text-xs text-blue-600">6 confirmadas</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Esta Semana</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">24</div>
            <div className="text-xs text-green-600">+3 vs semana anterior</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Pendientes</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">5</div>
            <div className="text-xs text-orange-600">Requieren confirmación</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Próximo Mes</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">67</div>
            <div className="text-xs text-purple-600">eventos programados</div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Acciones Rápidas</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
            <Button variant="outline" className="h-20 flex-col bg-transparent">
              <Users className="h-6 w-6 mb-2" />
              <span>Reunión Padres</span>
            </Button>
            <Button variant="outline" className="h-20 flex-col bg-transparent">
              <Calendar className="h-6 w-6 mb-2" />
              <span>Entrevista</span>
            </Button>
            <Button variant="outline" className="h-20 flex-col bg-transparent">
              <Clock className="h-6 w-6 mb-2" />
              <span>Evaluación</span>
            </Button>
            <Button variant="outline" className="h-20 flex-col bg-transparent">
              <Plus className="h-6 w-6 mb-2" />
              <span>Evento Especial</span>
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Upcoming Appointments */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Próximas Citas</CardTitle>
              <CardDescription>Eventos y citas programadas</CardDescription>
            </div>
            <div className="flex space-x-2">
              <Button variant="outline" size="sm">
                <Filter className="h-4 w-4 mr-2" />
                Filtrar
              </Button>
              <Button variant="outline" size="sm">
                <Search className="h-4 w-4 mr-2" />
                Buscar
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {appointments.map((appointment) => (
              <div key={appointment.id} className="border rounded-lg p-4 hover:bg-gray-50">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      <h3 className="font-semibold text-gray-900">{appointment.title}</h3>
                      <Badge className={getTypeBadge(appointment.type)}>{appointment.type}</Badge>
                      <Badge className={getStatusBadge(appointment.status)}>{appointment.status}</Badge>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-gray-600">
                      <div className="flex items-center space-x-2">
                        <Calendar className="h-4 w-4" />
                        <span>{appointment.date}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Clock className="h-4 w-4" />
                        <span>
                          {appointment.time} ({appointment.duration})
                        </span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <MapPin className="h-4 w-4" />
                        <span>{appointment.location}</span>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-2 text-sm text-gray-600">
                      <div className="flex items-center space-x-2">
                        <Users className="h-4 w-4" />
                        <span>{appointment.attendees} participantes</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Phone className="h-4 w-4" />
                        <span>{appointment.phone}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Mail className="h-4 w-4" />
                        <span>{appointment.contact}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex space-x-2 ml-4">
                    <Button variant="outline" size="sm">
                      Editar
                    </Button>
                    <Button variant="outline" size="sm">
                      Ver Detalles
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Calendar View */}
      <Card>
        <CardHeader>
          <CardTitle>Vista de Calendario</CardTitle>
          <CardDescription>Calendario mensual con actividades programadas</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="mb-4">
            <h3 className="text-lg font-semibold text-center">Enero 2024</h3>
          </div>

          {/* Calendar Grid */}
          <div className="grid grid-cols-7 gap-1 mb-4">
            {/* Calendar Header */}
            <div className="text-center font-medium text-gray-600 p-2 bg-gray-50">Dom</div>
            <div className="text-center font-medium text-gray-600 p-2 bg-gray-50">Lun</div>
            <div className="text-center font-medium text-gray-600 p-2 bg-gray-50">Mar</div>
            <div className="text-center font-medium text-gray-600 p-2 bg-gray-50">Mié</div>
            <div className="text-center font-medium text-gray-600 p-2 bg-gray-50">Jue</div>
            <div className="text-center font-medium text-gray-600 p-2 bg-gray-50">Vie</div>
            <div className="text-center font-medium text-gray-600 p-2 bg-gray-50">Sáb</div>

            {/* Calendar Days */}
            {Array.from({ length: 35 }, (_, i) => {
              const dayNumber = i - 6 + 1
              const isCurrentMonth = dayNumber > 0 && dayNumber <= 31
              const hasActivity = [15, 16, 17, 18].includes(dayNumber)

              return (
                <div
                  key={i}
                  className={`
                    min-h-[80px] p-2 border border-gray-200 relative
                    ${isCurrentMonth ? "bg-white hover:bg-gray-50" : "bg-gray-50"}
                    ${hasActivity ? "bg-blue-50" : ""}
                  `}
                >
                  {isCurrentMonth && (
                    <>
                      <div className="text-sm font-medium text-gray-900 mb-1">{dayNumber}</div>
                      {hasActivity && (
                        <div className="space-y-1">
                          {dayNumber === 15 && (
                            <div className="text-xs bg-purple-100 text-purple-800 px-1 py-0.5 rounded">
                              Reunión Padres
                            </div>
                          )}
                          {dayNumber === 16 && (
                            <div className="text-xs bg-blue-100 text-blue-800 px-1 py-0.5 rounded">Entrevista</div>
                          )}
                          {dayNumber === 17 && (
                            <div className="text-xs bg-orange-100 text-orange-800 px-1 py-0.5 rounded">Evaluación</div>
                          )}
                          {dayNumber === 18 && (
                            <div className="text-xs bg-green-100 text-green-800 px-1 py-0.5 rounded">Inscripción</div>
                          )}
                        </div>
                      )}
                    </>
                  )}
                </div>
              )
            })}
          </div>

          {/* Calendar Legend */}
          <div className="flex flex-wrap gap-4 text-sm border-t pt-4">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-purple-100 rounded"></div>
              <span>Reuniones</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-blue-100 rounded"></div>
              <span>Entrevistas</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-orange-100 rounded"></div>
              <span>Evaluaciones</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-green-100 rounded"></div>
              <span>Inscripciones</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
