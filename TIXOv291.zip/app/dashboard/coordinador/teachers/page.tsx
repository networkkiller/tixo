"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Checkbox } from "@/components/ui/checkbox"
import { Search, Download, Plus, FileText, Edit, UserX, Clock } from 'lucide-react'

export default function TeachersPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [filterStatus, setFilterStatus] = useState("all")
  const [filterSubject, setFilterSubject] = useState("all")

  const [viewTeacherModalOpen, setViewTeacherModalOpen] = useState(false)
  const [editTeacherModalOpen, setEditTeacherModalOpen] = useState(false)
  const [selectedTeacher, setSelectedTeacher] = useState<any>(null)
  const [editingTeacher, setEditingTeacher] = useState<any>({
    name: "",
    document: "",
    phone: "",
    email: "",
    address: "",
    contractType: "",
    hoursPerWeek: "",
    subjects: []
  })

  // Datos de ejemplo
  const teachers = [
    {
      id: 1,
      name: "Juan Pérez",
      document: "001-1234567-8",
      subjects: ["Matemáticas", "Física"],
      contractType: "Fijo",
      hoursPerWeek: 30,
      status: "active",
      phone: "809-555-5555",
      email: "juan.perez@example.com",
      address: "Calle Principal #123"
    },
    {
      id: 2,
      name: "María Rodríguez",
      document: "001-2345678-9",
      subjects: ["Lengua Española", "Literatura"],
      contractType: "Fijo",
      hoursPerWeek: 25,
      status: "active",
      phone: "829-555-5555",
      email: "maria.rodriguez@example.com",
      address: "Avenida Secundaria #456"
    },
    {
      id: 3,
      name: "Carlos Gómez",
      document: "001-3456789-0",
      subjects: ["Ciencias Naturales", "Química"],
      contractType: "Temporal",
      hoursPerWeek: 20,
      status: "active",
      phone: "849-555-5555",
      email: "carlos.gomez@example.com",
      address: "Calle Transversal #789"
    },
    {
      id: 4,
      name: "Ana Martínez",
      document: "001-4567890-1",
      subjects: ["Historia", "Geografía"],
      contractType: "Fijo",
      hoursPerWeek: 28,
      status: "inactive",
      phone: "809-555-1212",
      email: "ana.martinez@example.com",
      address: "Residencial Los Pinos #10"
    },
    {
      id: 5,
      name: "Roberto Sánchez",
      document: "001-5678901-2",
      subjects: ["Educación Física"],
      contractType: "Temporal",
      hoursPerWeek: 15,
      status: "active",
      phone: "829-555-3434",
      email: "roberto.sanchez@example.com",
      address: "Urbanización Las Flores #22"
    },
  ]

  const handleViewTeacher = (teacher: any) => {
    setSelectedTeacher(teacher)
    setViewTeacherModalOpen(true)
  }

  const handleEditTeacher = (teacher: any) => {
    setEditingTeacher({
      name: teacher.name,
      document: teacher.document,
      phone: teacher.phone || "",
      email: teacher.email || "",
      address: teacher.address || "",
      contractType: teacher.contractType,
      hoursPerWeek: teacher.hoursPerWeek.toString(),
      subjects: teacher.subjects
    })
    setSelectedTeacher(teacher)
    setEditTeacherModalOpen(true)
  }

  const handleUpdateTeacher = () => {
    // Validaciones
    if (!editingTeacher.name || !editingTeacher.document || !editingTeacher.contractType) {
      alert("Por favor completa todos los campos obligatorios")
      return
    }

    // Aquí iría la lógica para actualizar el docente
    console.log("Actualizando docente:", editingTeacher)
    
    // Cerrar modal y limpiar estado
    setEditTeacherModalOpen(false)
    setEditingTeacher({
      name: "",
      document: "",
      phone: "",
      email: "",
      address: "",
      contractType: "",
      hoursPerWeek: "",
      subjects: []
    })
    setSelectedTeacher(null)
  }

  const handleDeactivateTeacher = (teacher: any) => {
    if (confirm(`¿Estás seguro de que deseas desactivar a ${teacher.name}?`)) {
      // Aquí iría la lógica para desactivar el docente
      console.log("Desactivando docente:", teacher)
    }
  }

  // Filtrar profesores
  const filteredTeachers = teachers.filter((teacher) => {
    const matchesSearch =
      teacher.name.toLowerCase().includes(searchTerm.toLowerCase()) || teacher.document.includes(searchTerm)
    const matchesStatus = filterStatus === "all" || teacher.status === filterStatus
    const matchesSubject = filterSubject === "all" || teacher.subjects.includes(filterSubject)

    return matchesSearch && matchesStatus && matchesSubject
  })

  return (
    <div className="flex flex-col gap-5 p-8 bg-[#f0f4f8]">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-gray-900">Gestión de Docentes</h1>
          <p className="text-gray-500">Administra la información de los profesores del centro educativo</p>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            className="gap-1 bg-white text-indigo-700 border-indigo-200 hover:bg-indigo-50"
          >
            <Download className="h-4 w-4" />
            <span>Exportar</span>
          </Button>
          <Dialog>
            <DialogTrigger asChild>
              <Button size="sm" className="gap-1 bg-indigo-600 hover:bg-indigo-700 text-white">
                <Plus className="h-4 w-4" />
                <span>Nuevo Docente</span>
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[600px]">
              <DialogHeader>
                <DialogTitle>Registrar Nuevo Docente</DialogTitle>
                <DialogDescription>
                  Completa la información del profesor para registrarlo en el sistema.
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Nombre completo</Label>
                    <Input id="name" placeholder="Nombre y apellidos" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="document">Cédula</Label>
                    <Input id="document" placeholder="000-0000000-0" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="phone">Teléfono</Label>
                    <Input id="phone" placeholder="000-000-0000" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Correo electrónico</Label>
                    <Input id="email" type="email" placeholder="correo@ejemplo.com" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="address">Dirección</Label>
                  <Input id="address" placeholder="Dirección completa" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="contract">Tipo de contrato</Label>
                    <Select>
                      <SelectTrigger id="contract">
                        <SelectValue placeholder="Seleccionar" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="fixed">Fijo</SelectItem>
                        <SelectItem value="temporary">Temporal</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="hours">Horas semanales</Label>
                    <Input id="hours" type="number" placeholder="0" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Áreas de docencia</Label>
                  <div className="grid grid-cols-2 gap-2">
                    <div className="flex items-center space-x-2">
                      <Checkbox id="math" />
                      <label htmlFor="math" className="text-sm">
                        Matemáticas
                      </label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox id="language" />
                      <label htmlFor="language" className="text-sm">
                        Lengua Española
                      </label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox id="science" />
                      <label htmlFor="science" className="text-sm">
                        Ciencias Naturales
                      </label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox id="social" />
                      <label htmlFor="social" className="text-sm">
                        Ciencias Sociales
                      </label>
                    </div>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="cv">CV y títulos (PDF)</Label>
                  <Input id="cv" type="file" accept=".pdf" />
                </div>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline">
                  Cancelar
                </Button>
                <Button type="submit" className="bg-indigo-600 hover:bg-indigo-700">
                  Guardar
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle>Listado de Docentes</CardTitle>
          <CardDescription>Gestiona la información de los profesores registrados en el sistema</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col gap-4">
            <div className="flex flex-wrap gap-4 items-center justify-between">
              <div className="flex gap-2 flex-1">
                <div className="relative flex-1 max-w-sm">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
                  <Input
                    placeholder="Buscar por nombre o cédula..."
                    className="pl-8"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                <Select value={filterStatus} onValueChange={setFilterStatus}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Estado" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos los estados</SelectItem>
                    <SelectItem value="active">Activos</SelectItem>
                    <SelectItem value="inactive">Inactivos</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={filterSubject} onValueChange={setFilterSubject}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Materia" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todas las materias</SelectItem>
                    <SelectItem value="Matemáticas">Matemáticas</SelectItem>
                    <SelectItem value="Lengua Española">Lengua Española</SelectItem>
                    <SelectItem value="Ciencias Naturales">Ciencias Naturales</SelectItem>
                    <SelectItem value="Química">Química</SelectItem>
                    <SelectItem value="Historia">Historia</SelectItem>
                    <SelectItem value="Geografía">Geografía</SelectItem>
                    <SelectItem value="Educación Física">Educación Física</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Nombre</TableHead>
                    <TableHead>Cédula</TableHead>
                    <TableHead>Materias</TableHead>
                    <TableHead>Contrato</TableHead>
                    <TableHead>Horas</TableHead>
                    <TableHead>Estado</TableHead>
                    <TableHead className="text-right">Acciones</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredTeachers.map((teacher) => (
                    <TableRow key={teacher.id}>
                      <TableCell className="font-medium">{teacher.name}</TableCell>
                      <TableCell>{teacher.document}</TableCell>
                      <TableCell>
                        <div className="flex flex-wrap gap-1">
                          {teacher.subjects.map((subject, index) => (
                            <Badge
                              key={index}
                              variant="outline"
                              className="bg-indigo-50 text-indigo-700 border-indigo-200"
                            >
                              {subject}
                            </Badge>
                          ))}
                        </div>
                      </TableCell>
                      <TableCell>{teacher.contractType}</TableCell>
                      <TableCell>{teacher.hoursPerWeek}h</TableCell>
                      <TableCell>
                        {teacher.status === "active" ? (
                          <Badge className="bg-green-100 text-green-800 border-green-200">Activo</Badge>
                        ) : (
                          <Badge className="bg-gray-100 text-gray-800 border-gray-200">Inactivo</Badge>
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-8 w-8"
                            onClick={() => handleViewTeacher(teacher)}
                            title="Ver perfil del docente"
                          >
                            <FileText className="h-4 w-4 text-indigo-600" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-8 w-8"
                            onClick={() => handleEditTeacher(teacher)}
                            title="Editar información del docente"
                          >
                            <Edit className="h-4 w-4 text-amber-600" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-8 w-8"
                            onClick={() => handleDeactivateTeacher(teacher)}
                            title="Desactivar docente"
                          >
                            <UserX className="h-4 w-4 text-red-600" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Distribución de Carga Horaria</CardTitle>
            <CardDescription>Horas asignadas por área académica</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="h-3 w-3 rounded-full bg-indigo-500"></div>
                  <span className="text-sm">Matemáticas</span>
                </div>
                <span className="font-medium">45 horas</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="h-3 w-3 rounded-full bg-blue-500"></div>
                  <span className="text-sm">Lengua Española</span>
                </div>
                <span className="font-medium">40 horas</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="h-3 w-3 rounded-full bg-green-500"></div>
                  <span className="text-sm">Ciencias Naturales</span>
                </div>
                <span className="font-medium">35 horas</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="h-3 w-3 rounded-full bg-amber-500"></div>
                  <span className="text-sm">Ciencias Sociales</span>
                </div>
                <span className="font-medium">30 horas</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="h-3 w-3 rounded-full bg-red-500"></div>
                  <span className="text-sm">Educación Física</span>
                </div>
                <span className="font-medium">15 horas</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Próximas Renovaciones</CardTitle>
            <CardDescription>Contratos que vencen en los próximos 30 días</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-start gap-4 rounded-lg border border-gray-100 bg-white p-3">
                <div className="rounded-full bg-amber-100 p-1.5">
                  <Clock className="h-4 w-4 text-amber-500" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <h4 className="font-medium">Roberto Sánchez</h4>
                    <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
                      7 días
                    </Badge>
                  </div>
                  <p className="text-sm text-gray-500">Contrato temporal - Educación Física</p>
                </div>
              </div>

              <div className="flex items-start gap-4 rounded-lg border border-gray-100 bg-white p-3">
                <div className="rounded-full bg-amber-100 p-1.5">
                  <Clock className="h-4 w-4 text-amber-500" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <h4 className="font-medium">Luisa Fernández</h4>
                    <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
                      15 días
                    </Badge>
                  </div>
                  <p className="text-sm text-gray-500">Contrato temporal - Arte</p>
                </div>
              </div>

              <div className="flex items-start gap-4 rounded-lg border border-gray-100 bg-white p-3">
                <div className="rounded-full bg-amber-100 p-1.5">
                  <Clock className="h-4 w-4 text-amber-500" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <h4 className="font-medium">Pedro Díaz</h4>
                    <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
                      28 días
                    </Badge>
                  </div>
                  <p className="text-sm text-gray-500">Contrato temporal - Informática</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Modal Ver Docente */}
      <Dialog open={viewTeacherModalOpen} onOpenChange={setViewTeacherModalOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Perfil del Docente</DialogTitle>
            <DialogDescription>
              Información detallada del profesor
            </DialogDescription>
          </DialogHeader>
          {selectedTeacher && (
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="font-medium">Nombre completo</Label>
                  <p className="text-sm text-gray-600">{selectedTeacher.name}</p>
                </div>
                <div className="space-y-2">
                  <Label className="font-medium">Cédula</Label>
                  <p className="text-sm text-gray-600">{selectedTeacher.document}</p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="font-medium">Tipo de contrato</Label>
                  <p className="text-sm text-gray-600">{selectedTeacher.contractType}</p>
                </div>
                <div className="space-y-2">
                  <Label className="font-medium">Horas semanales</Label>
                  <p className="text-sm text-gray-600">{selectedTeacher.hoursPerWeek} horas</p>
                </div>
              </div>
              <div className="space-y-2">
                <Label className="font-medium">Materias que imparte</Label>
                <div className="flex flex-wrap gap-2">
                  {selectedTeacher.subjects.map((subject: string, index: number) => (
                    <Badge key={index} variant="outline" className="bg-indigo-50 text-indigo-700 border-indigo-200">
                      {subject}
                    </Badge>
                  ))}
                </div>
              </div>
              <div className="space-y-2">
                <Label className="font-medium">Estado</Label>
                <Badge className={selectedTeacher.status === "active" ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"}>
                  {selectedTeacher.status === "active" ? "Activo" : "Inactivo"}
                </Badge>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setViewTeacherModalOpen(false)}>
              Cerrar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Modal Editar Docente */}
      <Dialog open={editTeacherModalOpen} onOpenChange={setEditTeacherModalOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Editar Docente</DialogTitle>
            <DialogDescription>
              Modifica la información del profesor
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-name">Nombre completo *</Label>
                <Input 
                  id="edit-name" 
                  value={editingTeacher.name}
                  onChange={(e) => setEditingTeacher({...editingTeacher, name: e.target.value})}
                  placeholder="Nombre y apellidos" 
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-document">Cédula *</Label>
                <Input 
                  id="edit-document" 
                  value={editingTeacher.document}
                  onChange={(e) => setEditingTeacher({...editingTeacher, document: e.target.value})}
                  placeholder="000-0000000-0" 
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-phone">Teléfono</Label>
                <Input 
                  id="edit-phone" 
                  value={editingTeacher.phone}
                  onChange={(e) => setEditingTeacher({...editingTeacher, phone: e.target.value})}
                  placeholder="000-000-0000" 
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-email">Correo electrónico</Label>
                <Input 
                  id="edit-email" 
                  type="email" 
                  value={editingTeacher.email}
                  onChange={(e) => setEditingTeacher({...editingTeacher, email: e.target.value})}
                  placeholder="correo@ejemplo.com" 
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-address">Dirección</Label>
              <Input 
                id="edit-address" 
                value={editingTeacher.address}
                onChange={(e) => setEditingTeacher({...editingTeacher, address: e.target.value})}
                placeholder="Dirección completa" 
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-contract">Tipo de contrato *</Label>
                <Select value={editingTeacher.contractType} onValueChange={(value) => setEditingTeacher({...editingTeacher, contractType: value})}>
                  <SelectTrigger id="edit-contract">
                    <SelectValue placeholder="Seleccionar" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Fijo">Fijo</SelectItem>
                    <SelectItem value="Temporal">Temporal</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-hours">Horas semanales</Label>
                <Input 
                  id="edit-hours" 
                  type="number" 
                  value={editingTeacher.hoursPerWeek}
                  onChange={(e) => setEditingTeacher({...editingTeacher, hoursPerWeek: e.target.value})}
                  placeholder="0" 
                />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setEditTeacherModalOpen(false)}>
              Cancelar
            </Button>
            <Button 
              type="submit" 
              className="bg-indigo-600 hover:bg-indigo-700"
              onClick={handleUpdateTeacher}
              disabled={!editingTeacher.name || !editingTeacher.document || !editingTeacher.contractType}
            >
              Guardar Cambios
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
