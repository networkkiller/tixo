"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Checkbox } from "@/components/ui/checkbox"
import {
  Search,
  Plus,
  Filter,
  Download,
  Mail,
  Phone,
  User,
  Users,
  Home,
  Briefcase,
  FileText,
  AlertCircle,
  Bell,
  MoreHorizontal,
  Edit,
} from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

export default function ParentsPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [filterRelation, setFilterRelation] = useState("all")
  const [openDialog, setOpenDialog] = useState(false)
  const [selectedParentForEdit, setSelectedParentForEdit] = useState(null)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [isStudentSearchOpen, setIsStudentSearchOpen] = useState(false)
  const [studentSearchTerm, setStudentSearchTerm] = useState("")
  const [associatedStudents, setAssociatedStudents] = useState([])

  // Datos de ejemplo
  const parents = [
    {
      id: 1,
      name: "Ana María Gómez",
      relation: "Madre",
      children: ["Carlos Rodríguez (3° Primaria)", "Laura Rodríguez (1° Primaria)"],
      phone: "+1 555-123-4567",
      email: "ana.gomez@example.com",
      occupation: "Ingeniera",
      address: "Calle Principal 123",
      hasDebt: false,
      lastContact: "2023-06-10",
    },
    {
      id: 2,
      name: "Roberto Sánchez",
      relation: "Padre",
      children: ["Miguel Sánchez (5° Primaria)"],
      phone: "+1 555-987-6543",
      email: "roberto.sanchez@example.com",
      occupation: "Abogado",
      address: "Avenida Central 456",
      hasDebt: true,
      debtAmount: "$250",
      lastContact: "2023-06-05",
    },
    {
      id: 3,
      name: "Carmen Martínez",
      relation: "Abuela",
      children: ["José Martínez (2° Secundaria)"],
      phone: "+1 555-456-7890",
      email: "carmen.martinez@example.com",
      occupation: "Jubilada",
      address: "Plaza Mayor 789",
      hasDebt: false,
      lastContact: "2023-06-08",
    },
    {
      id: 4,
      name: "Francisco Pérez",
      relation: "Tutor Legal",
      children: ["Diana López (4° Primaria)"],
      phone: "+1 555-789-0123",
      email: "francisco.perez@example.com",
      occupation: "Médico",
      address: "Calle Secundaria 321",
      hasDebt: true,
      debtAmount: "$150",
      lastContact: "2023-06-01",
    },
    {
      id: 5,
      name: "Luisa Hernández",
      relation: "Madre",
      children: ["Pedro Hernández (6° Primaria)", "María Hernández (3° Secundaria)"],
      phone: "+1 555-234-5678",
      email: "luisa.hernandez@example.com",
      occupation: "Profesora",
      address: "Avenida Principal 654",
      hasDebt: false,
      lastContact: "2023-06-09",
    },
  ]

  const allStudents = [
    { id: 1, name: "Carlos Rodríguez", grade: "3° Primaria", section: "A" },
    { id: 2, name: "Laura Rodríguez", grade: "1° Primaria", section: "B" },
    { id: 3, name: "Miguel Sánchez", grade: "5° Primaria", section: "A" },
    { id: 4, name: "José Martínez", grade: "2° Secundaria", section: "C" },
    { id: 5, name: "Diana López", grade: "4° Primaria", section: "B" },
    { id: 6, name: "Pedro Hernández", grade: "6° Primaria", section: "A" },
    { id: 7, name: "María Hernández", grade: "3° Secundaria", section: "B" },
    { id: 8, name: "Ana García", grade: "2° Primaria", section: "A" },
    { id: 9, name: "Luis Torres", grade: "1° Secundaria", section: "C" },
    { id: 10, name: "Sofia Morales", grade: "5° Primaria", section: "B" },
  ]

  const filteredParents = parents.filter((parent) => {
    const matchesSearch =
      parent.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      parent.children.some((child) => child.toLowerCase().includes(searchTerm.toLowerCase()))

    const matchesRelation = filterRelation === "all" || parent.relation === filterRelation

    return matchesSearch && matchesRelation
  })

  const filteredStudents = allStudents.filter(
    (student) =>
      student.name.toLowerCase().includes(studentSearchTerm.toLowerCase()) &&
      !associatedStudents.some((assoc) => assoc.id === student.id),
  )

  return (
    <div className="p-8 bg-[#f0f4f8]">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Gestión de Padres y Tutores</h1>
          <p className="text-gray-500">Administra la información de padres, madres y tutores legales</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="gap-1 bg-transparent">
            <Download className="h-4 w-4" />
            <span>Exportar</span>
          </Button>
          <Dialog open={openDialog} onOpenChange={setOpenDialog}>
            <DialogTrigger asChild>
              <Button className="bg-indigo-600 hover:bg-indigo-700 text-white gap-1">
                <Plus className="h-4 w-4" />
                <span>Nuevo Padre/Tutor</span>
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[600px]">
              <DialogHeader>
                <DialogTitle>Registrar Nuevo Padre/Tutor</DialogTitle>
                <DialogDescription>
                  Complete la información del padre, madre o tutor legal para registrarlo en el sistema.
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Nombre Completo</Label>
                    <Input id="name" placeholder="Nombre y apellidos" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="id-number">Cédula/Documento</Label>
                    <Input id="id-number" placeholder="Número de identificación" />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="phone">Teléfono</Label>
                    <Input id="phone" placeholder="Número de contacto" type="tel" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Correo Electrónico</Label>
                    <Input id="email" placeholder="ejemplo@correo.com" type="email" />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="occupation">Ocupación</Label>
                    <Input id="occupation" placeholder="Profesión u ocupación" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="relation">Relación con el Estudiante</Label>
                    <Select>
                      <SelectTrigger id="relation">
                        <SelectValue placeholder="Seleccionar relación" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="madre">Madre</SelectItem>
                        <SelectItem value="padre">Padre</SelectItem>
                        <SelectItem value="abuelo">Abuelo/a</SelectItem>
                        <SelectItem value="tutor">Tutor Legal</SelectItem>
                        <SelectItem value="otro">Otro</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="address">Dirección</Label>
                  <Textarea id="address" placeholder="Dirección completa" />
                </div>

                <div className="space-y-2">
                  <Label>Estado Civil</Label>
                  <RadioGroup defaultValue="casado" className="flex space-x-4">
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="casado" id="casado" />
                      <Label htmlFor="casado">Casado/a</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="soltero" id="soltero" />
                      <Label htmlFor="soltero">Soltero/a</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="divorciado" id="divorciado" />
                      <Label htmlFor="divorciado">Divorciado/a</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="viudo" id="viudo" />
                      <Label htmlFor="viudo">Viudo/a</Label>
                    </div>
                  </RadioGroup>
                </div>

                <div className="space-y-2">
                  <Label>Convivencia con el Estudiante</Label>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="convive" />
                    <Label htmlFor="convive">Convive con el estudiante</Label>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Asociar Estudiante(s)</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Seleccionar estudiante" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="est1">Carlos Rodríguez (3° Primaria)</SelectItem>
                      <SelectItem value="est2">Laura Rodríguez (1° Primaria)</SelectItem>
                      <SelectItem value="est3">Miguel Sánchez (5° Primaria)</SelectItem>
                      <SelectItem value="est4">José Martínez (2° Secundaria)</SelectItem>
                    </SelectContent>
                  </Select>
                  <div className="flex items-center mt-2">
                    <Dialog open={isStudentSearchOpen} onOpenChange={setIsStudentSearchOpen}>
                      <DialogTrigger asChild>
                        <Button variant="outline" size="sm" className="text-xs bg-transparent">
                          <Plus className="h-3 w-3 mr-1" />
                          Asociar otro estudiante
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="sm:max-w-[500px]">
                        <DialogHeader>
                          <DialogTitle>Asociar Estudiante</DialogTitle>
                          <DialogDescription>
                            Busque y seleccione un estudiante para asociar con este padre/tutor.
                          </DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4">
                          <div className="relative">
                            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
                            <Input
                              placeholder="Buscar estudiante por nombre..."
                              className="pl-8"
                              value={studentSearchTerm}
                              onChange={(e) => setStudentSearchTerm(e.target.value)}
                            />
                          </div>
                          <div className="max-h-60 overflow-y-auto space-y-2">
                            {filteredStudents.length > 0 ? (
                              filteredStudents.map((student) => (
                                <div
                                  key={student.id}
                                  className="flex items-center justify-between p-3 border rounded-lg hover:bg-gray-50 cursor-pointer"
                                  onClick={() => {
                                    setAssociatedStudents([...associatedStudents, student])
                                    setStudentSearchTerm("")
                                    setIsStudentSearchOpen(false)
                                  }}
                                >
                                  <div>
                                    <div className="font-medium">{student.name}</div>
                                    <div className="text-sm text-gray-500">
                                      {student.grade} - Sección {student.section}
                                    </div>
                                  </div>
                                  <Button size="sm" variant="ghost" className="text-indigo-600">
                                    <Plus className="h-4 w-4" />
                                  </Button>
                                </div>
                              ))
                            ) : (
                              <div className="text-center py-4 text-gray-500">
                                {studentSearchTerm
                                  ? "No se encontraron estudiantes"
                                  : "Escriba para buscar estudiantes"}
                              </div>
                            )}
                          </div>
                        </div>
                        <DialogFooter>
                          <Button variant="outline" onClick={() => setIsStudentSearchOpen(false)}>
                            Cancelar
                          </Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setOpenDialog(false)}>
                  Cancelar
                </Button>
                <Button className="bg-indigo-600 hover:bg-indigo-700 text-white">Guardar</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="mb-6 flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
          <Input
            placeholder="Buscar por nombre o estudiante..."
            className="pl-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <Select value={filterRelation} onValueChange={setFilterRelation}>
          <SelectTrigger className="w-full sm:w-[180px]">
            <div className="flex items-center">
              <Filter className="mr-2 h-4 w-4" />
              <span>Relación</span>
            </div>
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todas las relaciones</SelectItem>
            <SelectItem value="Madre">Madre</SelectItem>
            <SelectItem value="Padre">Padre</SelectItem>
            <SelectItem value="Abuela">Abuelo/a</SelectItem>
            <SelectItem value="Tutor Legal">Tutor Legal</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <Tabs defaultValue="list" className="w-full">
        <TabsList className="mb-4">
          <TabsTrigger value="list">Lista de Padres</TabsTrigger>
          <TabsTrigger value="pending">Pendientes de Contacto</TabsTrigger>
          <TabsTrigger value="financial">Estado Financiero</TabsTrigger>
        </TabsList>

        <TabsContent value="list">
          <div className="grid gap-4">
            {filteredParents.map((parent) => (
              <Card key={parent.id} className="overflow-hidden">
                <CardContent className="p-0">
                  <div className="flex flex-col md:flex-row">
                    <div className="flex-1 p-6">
                      <div className="flex items-start justify-between">
                        <div>
                          <div className="flex items-center gap-2">
                            <h3 className="text-lg font-semibold">{parent.name}</h3>
                            <Badge variant="outline" className="bg-indigo-50 text-indigo-700 border-indigo-200">
                              {parent.relation}
                            </Badge>
                          </div>
                          <div className="mt-2 space-y-1 text-sm text-gray-500">
                            <div className="flex items-center gap-2">
                              <Users className="h-4 w-4" />
                              <span>Hijos: {parent.children.join(", ")}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Phone className="h-4 w-4" />
                              <span>{parent.phone}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Mail className="h-4 w-4" />
                              <span>{parent.email}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Briefcase className="h-4 w-4" />
                              <span>{parent.occupation}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Home className="h-4 w-4" />
                              <span>{parent.address}</span>
                            </div>
                          </div>
                        </div>
                        <div className="flex flex-col items-end">
                          <div className="text-sm text-gray-500">Último contacto: {parent.lastContact}</div>
                          {parent.hasDebt && (
                            <Badge variant="outline" className="mt-2 bg-red-50 text-red-700 border-red-200">
                              <AlertCircle className="mr-1 h-3 w-3" />
                              Deuda: {parent.debtAmount}
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                    <div className="flex flex-row md:flex-col justify-between border-t md:border-t-0 md:border-l border-gray-100 bg-gray-50 p-4">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-indigo-600 hover:text-indigo-700 hover:bg-indigo-50"
                          >
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuLabel>Acciones</DropdownMenuLabel>
                          <DropdownMenuItem
                            onClick={() => {
                              setSelectedParentForEdit(parent)
                              setIsEditDialogOpen(true)
                            }}
                          >
                            <Edit className="mr-2 h-4 w-4" />
                            Editar Información
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <User className="mr-2 h-4 w-4" />
                            Ver Perfil Completo
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem>
                            <Bell className="mr-2 h-4 w-4" />
                            Enviar Notificación
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <FileText className="mr-2 h-4 w-4" />
                            Ver Documentos
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="pending">
          <Card>
            <CardHeader>
              <CardTitle>Padres Pendientes de Contacto</CardTitle>
              <CardDescription>Padres que requieren seguimiento o contacto</CardDescription>
            </CardHeader>
            <CardContent>
              <p>Lista de padres que necesitan ser contactados próximamente.</p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="financial">
          <Card>
            <CardHeader>
              <CardTitle>Estado Financiero Familiar</CardTitle>
              <CardDescription>Resumen de pagos y deudas por familia</CardDescription>
            </CardHeader>
            <CardContent>
              <p>Información financiera de las familias registradas.</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Editar Información del Padre/Tutor</DialogTitle>
            <DialogDescription>Modifique la información del padre, madre o tutor legal seleccionado.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-name">Nombre Completo</Label>
                <Input
                  id="edit-name"
                  placeholder="Nombre y apellidos"
                  defaultValue={selectedParentForEdit?.name || ""}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-relation">Relación</Label>
                <Select defaultValue={selectedParentForEdit?.relation?.toLowerCase() || ""}>
                  <SelectTrigger id="edit-relation">
                    <SelectValue placeholder="Seleccionar relación" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="madre">Madre</SelectItem>
                    <SelectItem value="padre">Padre</SelectItem>
                    <SelectItem value="abuela">Abuelo/a</SelectItem>
                    <SelectItem value="tutor legal">Tutor Legal</SelectItem>
                    <SelectItem value="otro">Otro</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-phone">Teléfono</Label>
                <Input
                  id="edit-phone"
                  placeholder="Número de contacto"
                  type="tel"
                  defaultValue={selectedParentForEdit?.phone || ""}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-email">Correo Electrónico</Label>
                <Input
                  id="edit-email"
                  placeholder="ejemplo@correo.com"
                  type="email"
                  defaultValue={selectedParentForEdit?.email || ""}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-occupation">Ocupación</Label>
                <Input
                  id="edit-occupation"
                  placeholder="Profesión u ocupación"
                  defaultValue={selectedParentForEdit?.occupation || ""}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-address">Dirección</Label>
                <Input
                  id="edit-address"
                  placeholder="Dirección completa"
                  defaultValue={selectedParentForEdit?.address || ""}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label>Estudiantes Asociados</Label>
              <div className="space-y-2">
                {selectedParentForEdit?.children?.map((child, index) => (
                  <div key={index} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                    <span className="text-sm">{child}</span>
                    <Button variant="ghost" size="sm" className="text-red-600 hover:text-red-700">
                      Desvincular
                    </Button>
                  </div>
                ))}
                {associatedStudents.map((student) => (
                  <div
                    key={student.id}
                    className="flex items-center justify-between p-2 bg-green-50 rounded border border-green-200"
                  >
                    <span className="text-sm">
                      {student.name} ({student.grade} - Sección {student.section})
                    </span>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-red-600 hover:text-red-700"
                      onClick={() => setAssociatedStudents(associatedStudents.filter((s) => s.id !== student.id))}
                    >
                      Desvincular
                    </Button>
                  </div>
                ))}
              </div>
              <Dialog open={isStudentSearchOpen} onOpenChange={setIsStudentSearchOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm" className="text-xs bg-transparent">
                    <Plus className="h-3 w-3 mr-1" />
                    Asociar otro estudiante
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[500px]">
                  <DialogHeader>
                    <DialogTitle>Asociar Estudiante</DialogTitle>
                    <DialogDescription>
                      Busque y seleccione un estudiante para asociar con este padre/tutor.
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div className="relative">
                      <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
                      <Input
                        placeholder="Buscar estudiante por nombre..."
                        className="pl-8"
                        value={studentSearchTerm}
                        onChange={(e) => setStudentSearchTerm(e.target.value)}
                      />
                    </div>
                    <div className="max-h-60 overflow-y-auto space-y-2">
                      {filteredStudents.length > 0 ? (
                        filteredStudents.map((student) => (
                          <div
                            key={student.id}
                            className="flex items-center justify-between p-3 border rounded-lg hover:bg-gray-50 cursor-pointer"
                            onClick={() => {
                              setAssociatedStudents([...associatedStudents, student])
                              setStudentSearchTerm("")
                              setIsStudentSearchOpen(false)
                            }}
                          >
                            <div>
                              <div className="font-medium">{student.name}</div>
                              <div className="text-sm text-gray-500">
                                {student.grade} - Sección {student.section}
                              </div>
                            </div>
                            <Button size="sm" variant="ghost" className="text-indigo-600">
                              <Plus className="h-4 w-4" />
                            </Button>
                          </div>
                        ))
                      ) : (
                        <div className="text-center py-4 text-gray-500">
                          {studentSearchTerm ? "No se encontraron estudiantes" : "Escriba para buscar estudiantes"}
                        </div>
                      )}
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setIsStudentSearchOpen(false)}>
                      Cancelar
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              Cancelar
            </Button>
            <Button
              className="bg-indigo-600 hover:bg-indigo-700 text-white"
              onClick={() => {
                // Aquí iría la lógica para guardar los cambios
                setIsEditDialogOpen(false)
                setSelectedParentForEdit(null)
              }}
            >
              Guardar Cambios
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
