"use client"

import { useState, useEffect } from "react"
import { Header } from "@/components/dashboard/header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Textarea } from "@/components/ui/textarea"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import {
  UserPlus,
  FileText,
  CheckCircle,
  Calendar,
  Search,
  Filter,
  Download,
  AlertTriangle,
  Eye,
  Edit,
  Phone,
  Mail,
  X,
  Check,
  User,
  FileCheck,
  Clock,
  Users,
  RefreshCw,
} from "lucide-react"

// Tipos de datos
interface Student {
  id: string
  name: string
  birthDate: string
  age: number
  grade: string
  section: string
  status: "Pendiente" | "En Revisión" | "Completo" | "Rechazado"
  documents: "Completo" | "Incompleto" | "En Revisión"
  payment: "Al día" | "Pendiente" | "Vencido"
  ageStatus: "Dentro" | "Fuera" | "Autorizado"
  ageRange: string
  phone: string
  email: string
  address: string
  parentName: string
  parentPhone: string
  enrollmentDate: string
  notes?: string
  enrollmentType?: string
  parentEmail?: string
  parentCedula?: string
  parentAddress?: string
  parentOccupation?: string
  parentRelationship?: string
}

interface Parent {
  id: string
  name: string
  phone: string
  email: string
  cedula: string
  address: string
  occupation: string
  relationship: string
}

interface DocumentFile {
  name: string
  file: File | null
  uploaded: boolean
  required: boolean
}

// Rangos de edad por grado según MINERD
const AGE_RANGES = {
  "1° Primaria": { min: 5, max: 7 },
  "2° Primaria": { min: 6, max: 8 },
  "3° Primaria": { min: 7, max: 9 },
  "4° Primaria": { min: 8, max: 10 },
  "5° Primaria": { min: 9, max: 11 },
  "6° Primaria": { min: 10, max: 12 },
  "1° Secundaria": { min: 11, max: 13 },
  "2° Secundaria": { min: 12, max: 14 },
  "3° Secundaria": { min: 13, max: 15 },
  "4° Secundaria": { min: 14, max: 16 },
  "5° Secundaria": { min: 15, max: 17 },
  "6° Secundaria": { min: 16, max: 18 },
}

// Documentos requeridos según tipo de inscripción
const REQUIRED_DOCUMENTS = {
  "nuevo-ingreso": [
    { name: "Acta de nacimiento original y copia", required: true },
    { name: "Fotocopia de la cédula del padre, madre o tutor legal", required: true },
    { name: "2 fotos recientes del estudiante (2x2 pulgadas)", required: true },
    { name: "Certificado médico general", required: true },
    { name: "Tarjeta de vacunas actualizada", required: true },
    { name: "Certificación de grado aprobado o Boletín de notas del año anterior", required: true },
    { name: "Carta de traslado (si proviene de otro centro)", required: false },
    { name: "Formulario de inscripción completo", required: true },
    { name: "Evaluación psicológica o psicopedagógica", required: false },
  ],
  reinscripcion: [
    { name: "Actualización de datos personales", required: true },
    { name: "Boletín de calificaciones del año anterior", required: true },
    { name: "Fotocopia de cédula del padre, madre o tutor actualizada", required: true },
    { name: "Fotos actualizadas", required: false },
    { name: "Formulario de reinscripción firmado", required: true },
    { name: "Comprobante de pago de reinscripción", required: false },
  ],
  extranjero: [
    { name: "Pasaporte o acta de nacimiento legalizada y traducida", required: true },
    { name: "Documento migratorio vigente del estudiante y del tutor", required: true },
    { name: "Convalidación de estudios anteriores", required: false },
    { name: "Fotocopia de la cédula del padre, madre o tutor legal", required: true },
    { name: "2 fotos recientes del estudiante (2x2 pulgadas)", required: true },
    { name: "Certificado médico general", required: true },
    { name: "Formulario de inscripción completo", required: true },
  ],
}

export default function EnrollmentPage() {
  const [students, setStudents] = useState<Student[]>([])
  const [filteredStudents, setFilteredStudents] = useState<Student[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("Todos")
  const [gradeFilter, setGradeFilter] = useState("Todos")
  const [ageStatusFilter, setAgeStatusFilter] = useState("Todos")
  const [showNewStudentModal, setShowNewStudentModal] = useState(false)
  const [showInterviewModal, setShowInterviewModal] = useState(false)
  const [showViewStudentModal, setShowViewStudentModal] = useState(false)
  const [showEditStudentModal, setShowEditStudentModal] = useState(false)
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null)

  // Estados para el formulario de inscripción
  const [enrollmentType, setEnrollmentType] = useState("nuevo-ingreso")
  const [parentOption, setParentOption] = useState("new") // "new" o "existing"
  const [selectedParent, setSelectedParent] = useState<Parent | null>(null)
  const [documents, setDocuments] = useState<DocumentFile[]>([])
  const [existingParents, setExistingParents] = useState<Parent[]>([])

  // Estados para reinscripción
  const [existingStudentsForReinscription, setExistingStudentsForReinscription] = useState<Student[]>([])
  const [selectedStudentForReinscription, setSelectedStudentForReinscription] = useState<Student | null>(null)
  const [reinscriptionSearchTerm, setReinscriptionSearchTerm] = useState("")

  // Estados para formulario de nueva inscripción
  const [newStudentFormData, setNewStudentFormData] = useState({
    name: "",
    birthDate: "",
    grade: "",
    section: "",
    phone: "",
    email: "",
    address: "",
  })

  // Estados para edición (mantener estados por sesión)
  const [editFormData, setEditFormData] = useState<Student | null>(null)
  const [editEnrollmentType, setEditEnrollmentType] = useState("nuevo-ingreso")
  const [editParentOption, setEditParentOption] = useState("new")
  const [editSelectedParent, setEditSelectedParent] = useState<Parent | null>(null)
  const [editDocuments, setEditDocuments] = useState<DocumentFile[]>([])

  // Datos simulados
  useEffect(() => {
    const mockStudents: Student[] = [
      {
        id: "1",
        name: "Ana María Rodríguez",
        birthDate: "2016-03-15",
        age: 8,
        grade: "1° Primaria",
        section: "A",
        status: "Completo",
        documents: "Completo",
        payment: "Al día",
        ageStatus: "Fuera",
        ageRange: "5-7 años",
        phone: "809-555-0101",
        email: "ana.rodriguez@email.com",
        address: "Calle Principal #123, Santo Domingo",
        parentName: "María Rodríguez",
        parentPhone: "809-555-0102",
        enrollmentDate: "2024-01-15",
        notes: "Estudiante con edad superior al rango. Requiere autorización.",
        enrollmentType: "nuevo-ingreso",
        parentEmail: "maria.rodriguez@email.com",
        parentCedula: "001-1234567-8",
        parentAddress: "Calle Principal #123, Santo Domingo",
        parentOccupation: "Doctora",
        parentRelationship: "Madre",
      },
      {
        id: "2",
        name: "Carlos Eduardo Pérez",
        birthDate: "2018-07-22",
        age: 6,
        grade: "1° Primaria",
        section: "B",
        status: "En Revisión",
        documents: "En Revisión",
        payment: "Pendiente",
        ageStatus: "Dentro",
        ageRange: "5-7 años",
        phone: "809-555-0201",
        email: "carlos.perez@email.com",
        address: "Av. Independencia #456, Santo Domingo",
        parentName: "Eduardo Pérez",
        parentPhone: "809-555-0202",
        enrollmentDate: "2024-01-20",
        enrollmentType: "reinscripcion",
        parentEmail: "eduardo.perez@email.com",
        parentCedula: "001-2345678-9",
        parentAddress: "Av. Independencia #456, Santo Domingo",
        parentOccupation: "Ingeniero",
        parentRelationship: "Padre",
      },
    ]

    const mockParents: Parent[] = [
      {
        id: "1",
        name: "María Rodríguez",
        phone: "809-555-0102",
        email: "maria.rodriguez@email.com",
        cedula: "001-1234567-8",
        address: "Calle Principal #123, Santo Domingo",
        occupation: "Doctora",
        relationship: "Madre",
      },
      {
        id: "2",
        name: "Eduardo Pérez",
        phone: "809-555-0202",
        email: "eduardo.perez@email.com",
        cedula: "001-2345678-9",
        address: "Av. Independencia #456, Santo Domingo",
        occupation: "Ingeniero",
        relationship: "Padre",
      },
    ]

    // Estudiantes existentes para reinscripción (simulando estudiantes del año anterior)
    const mockExistingStudents: Student[] = [
      {
        id: "existing-1",
        name: "Luis Fernando García",
        birthDate: "2017-05-10",
        age: 7,
        grade: "1° Primaria",
        section: "A",
        status: "Completo",
        documents: "Completo",
        payment: "Al día",
        ageStatus: "Dentro",
        ageRange: "5-7 años",
        phone: "809-555-0301",
        email: "luis.garcia@email.com",
        address: "Calle Duarte #789, Santo Domingo",
        parentName: "Carmen García",
        parentPhone: "809-555-0302",
        enrollmentDate: "2023-01-15",
        enrollmentType: "nuevo-ingreso",
        parentEmail: "carmen.garcia@email.com",
        parentCedula: "001-3456789-0",
        parentAddress: "Calle Duarte #789, Santo Domingo",
        parentOccupation: "Profesora",
        parentRelationship: "Madre",
      },
      {
        id: "existing-2",
        name: "Sofía Isabella Martínez",
        birthDate: "2016-11-22",
        age: 8,
        grade: "2° Primaria",
        section: "B",
        status: "Completo",
        documents: "Completo",
        payment: "Al día",
        ageStatus: "Dentro",
        ageRange: "6-8 años",
        phone: "809-555-0401",
        email: "sofia.martinez@email.com",
        address: "Av. 27 de Febrero #456, Santo Domingo",
        parentName: "Roberto Martínez",
        parentPhone: "809-555-0402",
        enrollmentDate: "2023-01-20",
        enrollmentType: "nuevo-ingreso",
        parentEmail: "roberto.martinez@email.com",
        parentCedula: "001-4567890-1",
        parentAddress: "Av. 27 de Febrero #456, Santo Domingo",
        parentOccupation: "Contador",
        parentRelationship: "Padre",
      },
      {
        id: "existing-3",
        name: "Diego Alejandro Jiménez",
        birthDate: "2015-08-15",
        age: 9,
        grade: "3° Primaria",
        section: "A",
        status: "Completo",
        documents: "Completo",
        payment: "Al día",
        ageStatus: "Dentro",
        ageRange: "7-9 años",
        phone: "809-555-0501",
        email: "diego.jimenez@email.com",
        address: "Calle Mella #123, Santo Domingo",
        parentName: "Ana Jiménez",
        parentPhone: "809-555-0502",
        enrollmentDate: "2022-01-15",
        enrollmentType: "nuevo-ingreso",
        parentEmail: "ana.jimenez@email.com",
        parentCedula: "001-5678901-2",
        parentAddress: "Calle Mella #123, Santo Domingo",
        parentOccupation: "Enfermera",
        parentRelationship: "Madre",
      },
    ]

    setStudents(mockStudents)
    setFilteredStudents(mockStudents)
    setExistingParents(mockParents)
    setExistingStudentsForReinscription(mockExistingStudents)
  }, [])

  // Inicializar documentos según tipo de inscripción
  useEffect(() => {
    const requiredDocs = REQUIRED_DOCUMENTS[enrollmentType as keyof typeof REQUIRED_DOCUMENTS] || []
    const initialDocs: DocumentFile[] = requiredDocs.map((doc) => ({
      name: doc.name,
      file: null,
      uploaded: false,
      required: doc.required,
    }))
    setDocuments(initialDocs)
  }, [enrollmentType])

  // Inicializar documentos para edición según tipo de inscripción
  useEffect(() => {
    const requiredDocs = REQUIRED_DOCUMENTS[editEnrollmentType as keyof typeof REQUIRED_DOCUMENTS] || []
    const initialDocs: DocumentFile[] = requiredDocs.map((doc) => ({
      name: doc.name,
      file: null,
      uploaded: Math.random() > 0.5, // Simular algunos documentos ya subidos
      required: doc.required,
    }))
    setEditDocuments(initialDocs)
  }, [editEnrollmentType])

  // Función para calcular edad
  const calculateAge = (birthDate: string): number => {
    const today = new Date()
    const birth = new Date(birthDate)
    let age = today.getFullYear() - birth.getFullYear()
    const monthDiff = today.getMonth() - birth.getMonth()
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
      age--
    }
    return age
  }

  // Función para validar rango de edad
  const validateAgeRange = (age: number, grade: string): "Dentro" | "Fuera" => {
    const range = AGE_RANGES[grade as keyof typeof AGE_RANGES]
    if (!range) return "Dentro"
    return age >= range.min && age <= range.max ? "Dentro" : "Fuera"
  }

  // Filtrar estudiantes
  useEffect(() => {
    let filtered = students

    if (searchTerm) {
      filtered = filtered.filter(
        (student) =>
          student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          student.parentName.toLowerCase().includes(searchTerm.toLowerCase()) ||
          student.phone.includes(searchTerm),
      )
    }

    if (statusFilter !== "Todos") {
      filtered = filtered.filter((student) => student.status === statusFilter)
    }

    if (gradeFilter !== "Todos") {
      filtered = filtered.filter((student) => student.grade === gradeFilter)
    }

    if (ageStatusFilter !== "Todos") {
      filtered = filtered.filter((student) => student.ageStatus === ageStatusFilter)
    }

    setFilteredStudents(filtered)
  }, [students, searchTerm, statusFilter, gradeFilter, ageStatusFilter])

  // Filtrar estudiantes para reinscripción
  const filteredStudentsForReinscription = existingStudentsForReinscription.filter(
    (student) =>
      student.name.toLowerCase().includes(reinscriptionSearchTerm.toLowerCase()) ||
      student.parentName.toLowerCase().includes(reinscriptionSearchTerm.toLowerCase()) ||
      student.phone.includes(reinscriptionSearchTerm),
  )

  // Función para cargar datos del estudiante seleccionado para reinscripción
  const handleSelectStudentForReinscription = (student: Student) => {
    setSelectedStudentForReinscription(student)
    setNewStudentFormData({
      name: student.name,
      birthDate: student.birthDate,
      grade: student.grade,
      section: student.section,
      phone: student.phone,
      email: student.email,
      address: student.address,
    })

    // Cargar información del padre
    const parentInfo = existingParents.find((p) => p.name === student.parentName)
    if (parentInfo) {
      setSelectedParent(parentInfo)
      setParentOption("existing")
    }

    // Simular documentos ya subidos para reinscripción
    const requiredDocs = REQUIRED_DOCUMENTS.reinscripcion
    const initialDocs: DocumentFile[] = requiredDocs.map((doc) => ({
      name: doc.name,
      file: null,
      uploaded: Math.random() > 0.3, // Simular que la mayoría de documentos ya están subidos
      required: doc.required,
    }))
    setDocuments(initialDocs)
  }

  // Función para limpiar selección de reinscripción
  const handleClearReinscriptionSelection = () => {
    setSelectedStudentForReinscription(null)
    setNewStudentFormData({
      name: "",
      birthDate: "",
      grade: "",
      section: "",
      phone: "",
      email: "",
      address: "",
    })
    setSelectedParent(null)
    setParentOption("new")
    setReinscriptionSearchTerm("")
  }

  // Funciones de los botones
  const handleNewEnrollment = () => {
    // Limpiar estados al abrir modal
    setEnrollmentType("nuevo-ingreso")
    setSelectedStudentForReinscription(null)
    setNewStudentFormData({
      name: "",
      birthDate: "",
      grade: "",
      section: "",
      phone: "",
      email: "",
      address: "",
    })
    setSelectedParent(null)
    setParentOption("new")
    setReinscriptionSearchTerm("")
    setShowNewStudentModal(true)
  }

  const handleReviewDocuments = () => {
    setStatusFilter("En Revisión")
  }

  const handleApprovePending = () => {
    setStatusFilter("Pendiente")
  }

  const handleScheduleInterview = (student: Student) => {
    setSelectedStudent(student)
    setShowInterviewModal(true)
  }

  const handleViewStudent = (student: Student) => {
    setSelectedStudent(student)
    setShowViewStudentModal(true)
  }

  const handleEditStudent = (student: Student) => {
    setSelectedStudent(student)
    setEditFormData({ ...student })
    setEditEnrollmentType(student.enrollmentType || "nuevo-ingreso")
    setEditParentOption("existing") // Por defecto usar padre existente

    // Buscar padre existente
    const existingParent = existingParents.find((p) => p.name === student.parentName)
    if (existingParent) {
      setEditSelectedParent(existingParent)
    }

    setShowEditStudentModal(true)
  }

  const handleSaveEdit = () => {
    if (editFormData) {
      const updatedStudents = students.map((student) => (student.id === editFormData.id ? editFormData : student))
      setStudents(updatedStudents)
      setShowEditStudentModal(false)
      setEditFormData(null)
      setEditSelectedParent(null)
    }
  }

  const handleExport = () => {
    console.log("Exportando datos...")
  }

  // Función para manejar subida de archivos
  const handleFileUpload = (index: number, file: File) => {
    const updatedDocuments = [...documents]
    updatedDocuments[index] = {
      ...updatedDocuments[index],
      file: file,
      uploaded: true,
    }
    setDocuments(updatedDocuments)
  }

  // Función para remover archivo
  const handleRemoveFile = (index: number) => {
    const updatedDocuments = [...documents]
    updatedDocuments[index] = {
      ...updatedDocuments[index],
      file: null,
      uploaded: false,
    }
    setDocuments(updatedDocuments)
  }

  // Función para manejar subida de archivos en edición
  const handleEditFileUpload = (index: number, file: File) => {
    const updatedDocuments = [...editDocuments]
    updatedDocuments[index] = {
      ...updatedDocuments[index],
      file: file,
      uploaded: true,
    }
    setEditDocuments(updatedDocuments)
  }

  // Función para remover archivo en edición
  const handleEditRemoveFile = (index: number) => {
    const updatedDocuments = [...editDocuments]
    updatedDocuments[index] = {
      ...updatedDocuments[index],
      file: null,
      uploaded: false,
    }
    setEditDocuments(updatedDocuments)
  }

  // Componente para badge de estado de edad
  const AgeStatusBadge = ({ student }: { student: Student }) => {
    const getBadgeColor = () => {
      switch (student.ageStatus) {
        case "Fuera":
          return "bg-red-100 text-red-800 border-red-200"
        case "Autorizado":
          return "bg-green-100 text-green-800 border-green-200"
        default:
          return "bg-blue-100 text-blue-800 border-blue-200"
      }
    }

    const getTooltipText = () => {
      if (student.ageStatus === "Fuera") {
        return `Este estudiante tiene ${student.age} años. El rango permitido para ${student.grade} es de ${student.ageRange}.`
      }
      if (student.ageStatus === "Autorizado") {
        return `Estudiante fuera de rango autorizado por el Director.`
      }
      return `Estudiante dentro del rango de edad permitido.`
    }

    if (student.ageStatus === "Dentro") return null

    return (
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger>
            <Badge className={`text-xs ${getBadgeColor()}`}>
              {student.ageStatus === "Fuera" ? "Fuera de Rango" : "Autorizado"}
            </Badge>
          </TooltipTrigger>
          <TooltipContent>
            <p className="max-w-xs">{getTooltipText()}</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    )
  }

  return (
    <div className="flex-1 flex flex-col">
      <Header title="Inscripción y Reinscripción" />

      <main className="flex-1 overflow-y-auto p-6 bg-gradient-to-br from-futuristic-background via-futuristic-surface to-futuristic-background">
        {/* Botones de Acción */}
        <div className="mb-6">
          <div className="flex flex-wrap gap-4">
            <Button
              onClick={handleNewEnrollment}
              className="bg-gradient-to-r from-futuristic-primary to-futuristic-primary-light hover:from-futuristic-primary-light hover:to-futuristic-primary"
            >
              <UserPlus className="h-4 w-4 mr-2" />
              Nueva Inscripción
            </Button>
            <Button
              variant="outline"
              onClick={handleReviewDocuments}
              className="border-futuristic-info/30 text-futuristic-info hover:bg-futuristic-info/10 bg-transparent"
            >
              <FileText className="h-4 w-4 mr-2" />
              Revisar Documentos
            </Button>
            <Button
              variant="outline"
              onClick={handleApprovePending}
              className="border-futuristic-success/30 text-futuristic-success hover:bg-futuristic-success/10 bg-transparent"
            >
              <CheckCircle className="h-4 w-4 mr-2" />
              Aprobar Solicitudes
            </Button>
            <Button
              variant="outline"
              className="border-futuristic-secondary/30 text-futuristic-secondary hover:bg-futuristic-secondary/10 bg-transparent"
            >
              <Calendar className="h-4 w-4 mr-2" />
              Programar Entrevista
            </Button>
            <Button
              variant="outline"
              onClick={handleExport}
              className="border-futuristic-warning/30 text-futuristic-warning hover:bg-futuristic-warning/10 bg-transparent"
            >
              <Download className="h-4 w-4 mr-2" />
              Exportar
            </Button>
          </div>
        </div>

        {/* Filtros y Búsqueda */}
        <Card className="mb-6 bg-futuristic-surface border-futuristic-primary/10">
          <CardHeader>
            <CardTitle className="text-futuristic-text-primary flex items-center gap-2">
              <Filter className="h-5 w-5" />
              Filtros y Búsqueda
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
              <div>
                <Label htmlFor="search">Buscar</Label>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-futuristic-text-secondary" />
                  <Input
                    id="search"
                    placeholder="Nombre, padre o teléfono..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="status">Estado</Label>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Todos">Todos</SelectItem>
                    <SelectItem value="Pendiente">Pendiente</SelectItem>
                    <SelectItem value="En Revisión">En Revisión</SelectItem>
                    <SelectItem value="Completo">Completo</SelectItem>
                    <SelectItem value="Rechazado">Rechazado</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="grade">Grado</Label>
                <Select value={gradeFilter} onValueChange={setGradeFilter}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Todos">Todos</SelectItem>
                    <SelectItem value="1° Primaria">1° Primaria</SelectItem>
                    <SelectItem value="2° Primaria">2° Primaria</SelectItem>
                    <SelectItem value="3° Primaria">3° Primaria</SelectItem>
                    <SelectItem value="4° Primaria">4° Primaria</SelectItem>
                    <SelectItem value="5° Primaria">5° Primaria</SelectItem>
                    <SelectItem value="6° Primaria">6° Primaria</SelectItem>
                    <SelectItem value="1° Secundaria">1° Secundaria</SelectItem>
                    <SelectItem value="2° Secundaria">2° Secundaria</SelectItem>
                    <SelectItem value="3° Secundaria">3° Secundaria</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="ageStatus">Estado de Edad</Label>
                <Select value={ageStatusFilter} onValueChange={setAgeStatusFilter}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Todos">Todos</SelectItem>
                    <SelectItem value="Dentro">Dentro de rango</SelectItem>
                    <SelectItem value="Fuera">Fuera de rango</SelectItem>
                    <SelectItem value="Autorizado">Autorizado</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-end">
                <Button
                  variant="outline"
                  onClick={() => {
                    setSearchTerm("")
                    setStatusFilter("Todos")
                    setGradeFilter("Todos")
                    setAgeStatusFilter("Todos")
                  }}
                  className="w-full"
                >
                  Limpiar Filtros
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Tabla de Estudiantes */}
        <Card className="bg-futuristic-surface border-futuristic-primary/10">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-futuristic-text-primary">
                Lista de Estudiantes ({filteredStudents.length})
              </CardTitle>
              <div className="flex items-center gap-2">
                <Badge className="bg-red-100 text-red-800 border-red-200">
                  {filteredStudents.filter((s) => s.ageStatus === "Fuera").length} Fuera de Rango
                </Badge>
                <Badge className="bg-green-100 text-green-800 border-green-200">
                  {filteredStudents.filter((s) => s.ageStatus === "Autorizado").length} Autorizados
                </Badge>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Estudiante</TableHead>
                    <TableHead>Edad</TableHead>
                    <TableHead>Grado</TableHead>
                    <TableHead>Estado</TableHead>
                    <TableHead>Documentos</TableHead>
                    <TableHead>Pago</TableHead>
                    <TableHead>Contacto</TableHead>
                    <TableHead>Acciones</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredStudents.map((student) => (
                    <TableRow key={student.id}>
                      <TableCell>
                        <div>
                          <div className="font-medium text-futuristic-text-primary">{student.name}</div>
                          <div className="text-sm text-futuristic-text-secondary">{student.parentName}</div>
                          <AgeStatusBadge student={student} />
                        </div>
                      </TableCell>
                      <TableCell>
                        <div>
                          <div className="font-medium">{student.age} años</div>
                          <div className="text-xs text-futuristic-text-secondary">Rango: {student.ageRange}</div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div>
                          <div className="font-medium">{student.grade}</div>
                          <div className="text-sm text-futuristic-text-secondary">Sección {student.section}</div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge
                          className={
                            student.status === "Completo"
                              ? "bg-futuristic-success/20 text-futuristic-success border-futuristic-success/30"
                              : student.status === "En Revisión"
                                ? "bg-futuristic-info/20 text-futuristic-info border-futuristic-info/30"
                                : student.status === "Pendiente"
                                  ? "bg-futuristic-warning/20 text-futuristic-warning border-futuristic-warning/30"
                                  : "bg-futuristic-error/20 text-futuristic-error border-futuristic-error/30"
                          }
                        >
                          {student.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge
                          className={
                            student.documents === "Completo"
                              ? "bg-futuristic-success/20 text-futuristic-success border-futuristic-success/30"
                              : student.documents === "En Revisión"
                                ? "bg-futuristic-info/20 text-futuristic-info border-futuristic-info/30"
                                : "bg-futuristic-warning/20 text-futuristic-warning border-futuristic-warning/30"
                          }
                        >
                          {student.documents}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge
                          className={
                            student.payment === "Al día"
                              ? "bg-futuristic-success/20 text-futuristic-success border-futuristic-success/30"
                              : student.payment === "Pendiente"
                                ? "bg-futuristic-warning/20 text-futuristic-warning border-futuristic-warning/30"
                                : "bg-futuristic-error/20 text-futuristic-error border-futuristic-error/30"
                          }
                        >
                          {student.payment}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="text-sm">
                          <div className="flex items-center gap-1">
                            <Phone className="h-3 w-3" />
                            {student.phone}
                          </div>
                          <div className="flex items-center gap-1 text-futuristic-text-secondary">
                            <Mail className="h-3 w-3" />
                            {student.email}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleViewStudent(student)}
                            className="hover:bg-futuristic-info/10"
                          >
                            <Eye className="h-3 w-3" />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleEditStudent(student)}
                            className="hover:bg-futuristic-primary/10"
                          >
                            <Edit className="h-3 w-3" />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleScheduleInterview(student)}
                            className="hover:bg-futuristic-warning/10"
                          >
                            <Calendar className="h-3 w-3" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>

        {/* Modal de Ver Estudiante */}
        <Dialog open={showViewStudentModal} onOpenChange={setShowViewStudentModal}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Eye className="h-5 w-5" />
                Ver Información del Estudiante
              </DialogTitle>
            </DialogHeader>

            {selectedStudent && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Información Personal */}
                  <Card className="p-4">
                    <h3 className="text-lg font-semibold mb-4 text-futuristic-text-primary">Información Personal</h3>
                    <div className="space-y-3">
                      <div>
                        <Label className="text-sm font-medium text-futuristic-text-secondary">Nombre Completo</Label>
                        <p className="text-futuristic-text-primary">{selectedStudent.name}</p>
                      </div>
                      <div>
                        <Label className="text-sm font-medium text-futuristic-text-secondary">
                          Fecha de Nacimiento
                        </Label>
                        <p className="text-futuristic-text-primary">{selectedStudent.birthDate}</p>
                      </div>
                      <div>
                        <Label className="text-sm font-medium text-futuristic-text-secondary">Edad</Label>
                        <p className="text-futuristic-text-primary">{selectedStudent.age} años</p>
                      </div>
                      <div>
                        <Label className="text-sm font-medium text-futuristic-text-secondary">Teléfono</Label>
                        <p className="text-futuristic-text-primary">{selectedStudent.phone}</p>
                      </div>
                      <div>
                        <Label className="text-sm font-medium text-futuristic-text-secondary">Email</Label>
                        <p className="text-futuristic-text-primary">{selectedStudent.email}</p>
                      </div>
                      <div>
                        <Label className="text-sm font-medium text-futuristic-text-secondary">Dirección</Label>
                        <p className="text-futuristic-text-primary">{selectedStudent.address}</p>
                      </div>
                    </div>
                  </Card>

                  {/* Información Académica */}
                  <Card className="p-4">
                    <h3 className="text-lg font-semibold mb-4 text-futuristic-text-primary">Información Académica</h3>
                    <div className="space-y-3">
                      <div>
                        <Label className="text-sm font-medium text-futuristic-text-secondary">Grado</Label>
                        <p className="text-futuristic-text-primary">{selectedStudent.grade}</p>
                      </div>
                      <div>
                        <Label className="text-sm font-medium text-futuristic-text-secondary">Sección</Label>
                        <p className="text-futuristic-text-primary">{selectedStudent.section}</p>
                      </div>
                      <div>
                        <Label className="text-sm font-medium text-futuristic-text-secondary">
                          Estado de Inscripción
                        </Label>
                        <Badge
                          className={
                            selectedStudent.status === "Completo"
                              ? "bg-futuristic-success/20 text-futuristic-success border-futuristic-success/30"
                              : selectedStudent.status === "En Revisión"
                                ? "bg-futuristic-info/20 text-futuristic-info border-futuristic-info/30"
                                : selectedStudent.status === "Pendiente"
                                  ? "bg-futuristic-warning/20 text-futuristic-warning border-futuristic-warning/30"
                                  : "bg-futuristic-error/20 text-futuristic-error border-futuristic-error/30"
                          }
                        >
                          {selectedStudent.status}
                        </Badge>
                      </div>
                      <div>
                        <Label className="text-sm font-medium text-futuristic-text-secondary">
                          Estado de Documentos
                        </Label>
                        <Badge
                          className={
                            selectedStudent.documents === "Completo"
                              ? "bg-futuristic-success/20 text-futuristic-success border-futuristic-success/30"
                              : selectedStudent.documents === "En Revisión"
                                ? "bg-futuristic-info/20 text-futuristic-info border-futuristic-info/30"
                                : "bg-futuristic-warning/20 text-futuristic-warning border-futuristic-warning/30"
                          }
                        >
                          {selectedStudent.documents}
                        </Badge>
                      </div>
                      <div>
                        <Label className="text-sm font-medium text-futuristic-text-secondary">Estado de Pago</Label>
                        <Badge
                          className={
                            selectedStudent.payment === "Al día"
                              ? "bg-futuristic-success/20 text-futuristic-success border-futuristic-success/30"
                              : selectedStudent.payment === "Pendiente"
                                ? "bg-futuristic-warning/20 text-futuristic-warning border-futuristic-warning/30"
                                : "bg-futuristic-error/20 text-futuristic-error border-futuristic-error/30"
                          }
                        >
                          {selectedStudent.payment}
                        </Badge>
                      </div>
                      <div>
                        <Label className="text-sm font-medium text-futuristic-text-secondary">
                          Fecha de Inscripción
                        </Label>
                        <p className="text-futuristic-text-primary">{selectedStudent.enrollmentDate}</p>
                      </div>
                    </div>
                  </Card>

                  {/* Información del Padre/Tutor */}
                  <Card className="p-4">
                    <h3 className="text-lg font-semibold mb-4 text-futuristic-text-primary">Padre/Tutor</h3>
                    <div className="space-y-3">
                      <div>
                        <Label className="text-sm font-medium text-futuristic-text-secondary">Nombre</Label>
                        <p className="text-futuristic-text-primary">{selectedStudent.parentName}</p>
                      </div>
                      <div>
                        <Label className="text-sm font-medium text-futuristic-text-secondary">Teléfono</Label>
                        <p className="text-futuristic-text-primary">{selectedStudent.parentPhone}</p>
                      </div>
                    </div>
                  </Card>

                  {/* Notas Adicionales */}
                  <Card className="p-4">
                    <h3 className="text-lg font-semibold mb-4 text-futuristic-text-primary">Notas Adicionales</h3>
                    <div>
                      <p className="text-futuristic-text-primary">
                        {selectedStudent.notes || "No hay notas adicionales"}
                      </p>
                    </div>
                  </Card>
                </div>
              </div>
            )}

            <div className="flex justify-end gap-4 mt-6">
              <Button variant="outline" onClick={() => setShowViewStudentModal(false)}>
                Cerrar
              </Button>
            </div>
          </DialogContent>
        </Dialog>

        {/* Modal de Editar Estudiante - Formato completo como Nueva Inscripción */}
        <Dialog open={showEditStudentModal} onOpenChange={setShowEditStudentModal}>
          <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Edit className="h-5 w-5" />
                Editar Inscripción - {editFormData?.name}
              </DialogTitle>
            </DialogHeader>

            <Tabs defaultValue="student" className="w-full">
              <TabsList className="grid w-full grid-cols-6">
                <TabsTrigger value="student" className="flex items-center gap-2">
                  <User className="h-4 w-4" />
                  Estudiante
                </TabsTrigger>
                <TabsTrigger value="acta" className="flex items-center gap-2">
                  <FileText className="h-4 w-4" />
                  Información del Acta
                </TabsTrigger>
                <TabsTrigger value="emergencia" className="flex items-center gap-2">
                  <AlertTriangle className="h-4 w-4" />
                  Datos de Emergencia
                </TabsTrigger>
                <TabsTrigger value="parent" className="flex items-center gap-2">
                  <Users className="h-4 w-4" />
                  Padre/Tutor
                </TabsTrigger>
                <TabsTrigger value="documents" className="flex items-center gap-2">
                  <FileCheck className="h-4 w-4" />
                  Documentos
                </TabsTrigger>
                <TabsTrigger value="review" className="flex items-center gap-2">
                  <Clock className="h-4 w-4" />
                  Revisión
                </TabsTrigger>
              </TabsList>

              {/* Pestaña de Información del Estudiante */}
              <TabsContent value="student" className="space-y-6">
                {editFormData && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold">Información del Estudiante</h3>
                      <div>
                        <Label htmlFor="editStudentName">Nombre Completo *</Label>
                        <Input
                          id="editStudentName"
                          value={editFormData.name}
                          onChange={(e) => setEditFormData({ ...editFormData, name: e.target.value })}
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="editGrade">Grado *</Label>
                          <Select
                            value={editFormData.grade}
                            onValueChange={(value) => setEditFormData({ ...editFormData, grade: value })}
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="1° Primaria">1° Primaria</SelectItem>
                              <SelectItem value="2° Primaria">2° Primaria</SelectItem>
                              <SelectItem value="3° Primaria">3° Primaria</SelectItem>
                              <SelectItem value="4° Primaria">4° Primaria</SelectItem>
                              <SelectItem value="5° Primaria">5° Primaria</SelectItem>
                              <SelectItem value="6° Primaria">6° Primaria</SelectItem>
                              <SelectItem value="1° Secundaria">1° Secundaria</SelectItem>
                              <SelectItem value="2° Secundaria">2° Secundaria</SelectItem>
                              <SelectItem value="3° Secundaria">3° Secundaria</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label htmlFor="editSection">Sección *</Label>
                          <Select
                            value={editFormData.section}
                            onValueChange={(value) => setEditFormData({ ...editFormData, section: value })}
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="A">A</SelectItem>
                              <SelectItem value="B">B</SelectItem>
                              <SelectItem value="C">C</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      <div>
                        <Label htmlFor="editStudentPhone">Teléfono</Label>
                        <Input
                          id="editStudentPhone"
                          value={editFormData.phone}
                          onChange={(e) => setEditFormData({ ...editFormData, phone: e.target.value })}
                        />
                      </div>
                      <div>
                        <Label htmlFor="editStudentEmail">Email</Label>
                        <Input
                          id="editStudentEmail"
                          type="email"
                          value={editFormData.email}
                          onChange={(e) => setEditFormData({ ...editFormData, email: e.target.value })}
                        />
                      </div>
                      <div>
                        <Label htmlFor="editAddress">Dirección</Label>
                        <Textarea
                          id="editAddress"
                          value={editFormData.address}
                          onChange={(e) => setEditFormData({ ...editFormData, address: e.target.value })}
                        />
                      </div>
                    </div>

                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold">Tipo de Inscripción</h3>
                      <RadioGroup value={editEnrollmentType} onValueChange={setEditEnrollmentType}>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="nuevo-ingreso" id="edit-nuevo-ingreso" />
                          <Label htmlFor="edit-nuevo-ingreso">Nuevo Ingreso (Primera vez)</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="reinscripcion" id="edit-reinscripcion" />
                          <Label htmlFor="edit-reinscripcion">Reinscripción</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="extranjero" id="edit-extranjero" />
                          <Label htmlFor="edit-extranjero">Estudiante Extranjero</Label>
                        </div>
                      </RadioGroup>

                      <div className="space-y-4">
                        <h3 className="text-lg font-semibold">Estados</h3>
                        <div>
                          <Label htmlFor="editStatus">Estado de Inscripción</Label>
                          <Select
                            value={editFormData.status}
                            onValueChange={(value) =>
                              setEditFormData({ ...editFormData, status: value as Student["status"] })
                            }
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="Pendiente">Pendiente</SelectItem>
                              <SelectItem value="En Revisión">En Revisión</SelectItem>
                              <SelectItem value="Completo">Completo</SelectItem>
                              <SelectItem value="Rechazado">Rechazado</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label htmlFor="editDocuments">Estado de Documentos</Label>
                          <Select
                            value={editFormData.documents}
                            onValueChange={(value) =>
                              setEditFormData({ ...editFormData, documents: value as Student["documents"] })
                            }
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="Incompleto">Incompleto</SelectItem>
                              <SelectItem value="En Revisión">En Revisión</SelectItem>
                              <SelectItem value="Completo">Completo</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label htmlFor="editPayment">Estado de Pago</Label>
                          <Select
                            value={editFormData.payment}
                            onValueChange={(value) =>
                              setEditFormData({ ...editFormData, payment: value as Student["payment"] })
                            }
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="Pendiente">Pendiente</SelectItem>
                              <SelectItem value="Al día">Al día</SelectItem>
                              <SelectItem value="Vencido">Vencido</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      {/* Alerta de Validación de Edad */}
                      <div className="mt-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                        <div className="flex items-center gap-2 text-yellow-800 mb-2">
                          <AlertTriangle className="h-4 w-4" />
                          <span className="font-medium">Validación de Edad</span>
                        </div>
                        <p className="text-sm text-yellow-700">
                          El sistema validará automáticamente si la edad del estudiante está dentro del rango permitido
                          por el MINERD para el grado seleccionado.
                        </p>
                        <p className="text-xs text-yellow-600 mt-1">
                          Si está fuera del rango, se requerirá autorización del Director.
                        </p>
                      </div>
                    </div>
                  </div>
                )}
              </TabsContent>

              {/* Pestaña de Información del Acta */}
              <TabsContent value="acta" className="space-y-6">
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Información del Acta de Nacimiento</h3>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="editFechaNacimiento">Fecha de Nacimiento *</Label>
                        <Input
                          id="editFechaNacimiento"
                          type="date"
                          value={editFormData?.birthDate || ""}
                          onChange={(e) =>
                            editFormData && setEditFormData({ ...editFormData, birthDate: e.target.value })
                          }
                        />
                      </div>
                      <div>
                        <Label htmlFor="editLibro">Libro</Label>
                        <Input id="editLibro" placeholder="Número de libro" />
                      </div>
                      <div>
                        <Label htmlFor="editFolio">Folio</Label>
                        <Input id="editFolio" placeholder="Número de folio" />
                      </div>
                      <div>
                        <Label htmlFor="editActa">Acta</Label>
                        <Input id="editActa" placeholder="Número de acta" />
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="editSexo">Sexo *</Label>
                        <Select>
                          <SelectTrigger>
                            <SelectValue placeholder="Seleccionar sexo" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="masculino">Masculino</SelectItem>
                            <SelectItem value="femenino">Femenino</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor="editConQuienReside">¿Con quién reside?</Label>
                        <Select>
                          <SelectTrigger>
                            <SelectValue placeholder="Seleccionar con quién reside" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="ambos-padres">Ambos padres</SelectItem>
                            <SelectItem value="madre">Solo con la madre</SelectItem>
                            <SelectItem value="padre">Solo con el padre</SelectItem>
                            <SelectItem value="abuelos">Con los abuelos</SelectItem>
                            <SelectItem value="tutor">Con tutor legal</SelectItem>
                            <SelectItem value="otros">Otros familiares</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>
                </div>
              </TabsContent>

              {/* Pestaña de Datos de Emergencia */}
              <TabsContent value="emergencia" className="space-y-6">
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Datos de Emergencia y Salud</h3>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="editAlgunaEnfermedad">¿Alguna enfermedad?</Label>
                        <div className="space-y-2">
                          <RadioGroup defaultValue="no">
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="no" id="edit-enfermedad-no" />
                              <Label htmlFor="edit-enfermedad-no">No</Label>
                            </div>
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="si" id="edit-enfermedad-si" />
                              <Label htmlFor="edit-enfermedad-si">Sí</Label>
                            </div>
                          </RadioGroup>
                          <Textarea placeholder="Especificar enfermedad (si aplica)" className="mt-2" />
                        </div>
                      </div>

                      <div>
                        <Label htmlFor="editEsAlergico">¿Es alérgico?</Label>
                        <div className="space-y-2">
                          <RadioGroup defaultValue="no">
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="no" id="edit-alergia-no" />
                              <Label htmlFor="edit-alergia-no">No</Label>
                            </div>
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="si" id="edit-alergia-si" />
                              <Label htmlFor="edit-alergia-si">Sí</Label>
                            </div>
                          </RadioGroup>
                          <Textarea placeholder="Especificar alergias (si aplica)" className="mt-2" />
                        </div>
                      </div>

                      <div>
                        <Label htmlFor="editEsAsegurado">¿Es asegurado?</Label>
                        <RadioGroup defaultValue="no">
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="no" id="edit-seguro-no" />
                            <Label htmlFor="edit-seguro-no">No</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="si" id="edit-seguro-si" />
                            <Label htmlFor="edit-seguro-si">Sí</Label>
                          </div>
                        </RadioGroup>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="editTipoSeguro">Tipo de Seguro</Label>
                        <Select>
                          <SelectTrigger>
                            <SelectValue placeholder="Seleccionar tipo de seguro" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="senasa">SENASA</SelectItem>
                            <SelectItem value="ars-humano">ARS Humano</SelectItem>
                            <SelectItem value="ars-universal">ARS Universal</SelectItem>
                            <SelectItem value="ars-palic">ARS Palic</SelectItem>
                            <SelectItem value="seguro-privado">Seguro Privado</SelectItem>
                            <SelectItem value="otros">Otros</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <Label htmlFor="editTipoSangre">Tipo de Sangre</Label>
                        <Select>
                          <SelectTrigger>
                            <SelectValue placeholder="Seleccionar tipo de sangre" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="a-positivo">A+</SelectItem>
                            <SelectItem value="a-negativo">A-</SelectItem>
                            <SelectItem value="b-positivo">B+</SelectItem>
                            <SelectItem value="b-negativo">B-</SelectItem>
                            <SelectItem value="ab-positivo">AB+</SelectItem>
                            <SelectItem value="ab-negativo">AB-</SelectItem>
                            <SelectItem value="o-positivo">O+</SelectItem>
                            <SelectItem value="o-negativo">O-</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <Label htmlFor="editEmergenciaLlamar">En emergencia llamar a:</Label>
                        <div className="space-y-3">
                          <div>
                            <Label htmlFor="editContactoEmergencia1" className="text-sm">
                              Contacto Principal
                            </Label>
                            <Input id="editContactoEmergencia1" placeholder="Nombre del contacto" className="mb-2" />
                            <Input placeholder="Teléfono" type="tel" className="mb-2" />
                            <Input placeholder="Parentesco" />
                          </div>

                          <div>
                            <Label htmlFor="editContactoEmergencia2" className="text-sm">
                              Contacto Secundario
                            </Label>
                            <Input id="editContactoEmergencia2" placeholder="Nombre del contacto" className="mb-2" />
                            <Input placeholder="Teléfono" type="tel" className="mb-2" />
                            <Input placeholder="Parentesco" />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="mt-6 p-4 bg-red-50 border border-red-200 rounded-lg">
                    <div className="flex items-center gap-2 text-red-800 mb-2">
                      <AlertTriangle className="h-4 w-4" />
                      <span className="font-medium">Información Importante</span>
                    </div>
                    <ul className="text-sm text-red-700 space-y-1">
                      <li>• Esta información es crucial para emergencias médicas</li>
                      <li>• Mantenga actualizados los contactos de emergencia</li>
                      <li>• Notifique cualquier cambio en el estado de salud del estudiante</li>
                      <li>• Los datos médicos son confidenciales y solo para uso del centro educativo</li>
                    </ul>
                  </div>
                </div>
              </TabsContent>

              {/* Pestaña de Padre/Tutor */}
              <TabsContent value="parent" className="space-y-6">
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Información del Padre/Tutor</h3>

                  <RadioGroup value={editParentOption} onValueChange={setEditParentOption}>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="existing" id="edit-existing" />
                      <Label htmlFor="edit-existing">Seleccionar padre existente</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="new" id="edit-new" />
                      <Label htmlFor="edit-new">Registrar nuevo padre/tutor</Label>
                    </div>
                  </RadioGroup>

                  {editParentOption === "existing" && (
                    <div className="space-y-4">
                      <Label htmlFor="editParentSelect">Seleccionar Padre/Tutor</Label>
                      <Select
                        value={editSelectedParent?.id || ""}
                        onValueChange={(value) => {
                          const parent = existingParents.find((p) => p.id === value)
                          setEditSelectedParent(parent || null)
                          if (parent && editFormData) {
                            setEditFormData({
                              ...editFormData,
                              parentName: parent.name,
                              parentPhone: parent.phone,
                              parentEmail: parent.email,
                              parentCedula: parent.cedula,
                              parentAddress: parent.address,
                              parentOccupation: parent.occupation,
                              parentRelationship: parent.relationship,
                            })
                          }
                        }}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Buscar y seleccionar padre/tutor" />
                        </SelectTrigger>
                        <SelectContent>
                          {existingParents.map((parent) => (
                            <SelectItem key={parent.id} value={parent.id}>
                              {parent.name} - {parent.phone} - {parent.cedula}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>

                      {editSelectedParent && (
                        <Card className="p-4 bg-blue-50 border-blue-200">
                          <h4 className="font-medium mb-2">Información del Padre Seleccionado:</h4>
                          <div className="grid grid-cols-2 gap-2 text-sm">
                            <div>
                              <strong>Nombre:</strong> {editSelectedParent.name}
                            </div>
                            <div>
                              <strong>Teléfono:</strong> {editSelectedParent.phone}
                            </div>
                            <div>
                              <strong>Email:</strong> {editSelectedParent.email}
                            </div>
                            <div>
                              <strong>Cédula:</strong> {editSelectedParent.cedula}
                            </div>
                            <div>
                              <strong>Ocupación:</strong> {editSelectedParent.occupation}
                            </div>
                            <div>
                              <strong>Parentesco:</strong> {editSelectedParent.relationship}
                            </div>
                          </div>
                        </Card>
                      )}
                    </div>
                  )}

                  {editParentOption === "new" && editFormData && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="editParentName">Nombre Completo *</Label>
                        <Input
                          id="editParentName"
                          value={editFormData.parentName || ""}
                          onChange={(e) => setEditFormData({ ...editFormData, parentName: e.target.value })}
                        />
                      </div>
                      <div>
                        <Label htmlFor="editParentCedula">Cédula *</Label>
                        <Input
                          id="editParentCedula"
                          value={editFormData.parentCedula || ""}
                          onChange={(e) => setEditFormData({ ...editFormData, parentCedula: e.target.value })}
                        />
                      </div>
                      <div>
                        <Label htmlFor="editParentPhone">Teléfono *</Label>
                        <Input
                          id="editParentPhone"
                          value={editFormData.parentPhone || ""}
                          onChange={(e) => setEditFormData({ ...editFormData, parentPhone: e.target.value })}
                        />
                      </div>
                      <div>
                        <Label htmlFor="editParentEmail">Email</Label>
                        <Input
                          id="editParentEmail"
                          type="email"
                          value={editFormData.parentEmail || ""}
                          onChange={(e) => setEditFormData({ ...editFormData, parentEmail: e.target.value })}
                        />
                      </div>
                      <div>
                        <Label htmlFor="editRelationship">Parentesco</Label>
                        <Select
                          value={editFormData.parentRelationship || ""}
                          onValueChange={(value) => setEditFormData({ ...editFormData, parentRelationship: value })}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Seleccionar parentesco" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="padre">Padre</SelectItem>
                            <SelectItem value="madre">Madre</SelectItem>
                            <SelectItem value="tutor">Tutor Legal</SelectItem>
                            <SelectItem value="abuelo">Abuelo/a</SelectItem>
                            <SelectItem value="tio">Tío/a</SelectItem>
                            <SelectItem value="otro">Otro</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor="editOccupation">Ocupación</Label>
                        <Input
                          id="editOccupation"
                          value={editFormData.parentOccupation || ""}
                          onChange={(e) => setEditFormData({ ...editFormData, parentOccupation: e.target.value })}
                        />
                      </div>
                      <div className="md:col-span-2">
                        <Label htmlFor="editParentAddress">Dirección</Label>
                        <Textarea
                          id="editParentAddress"
                          value={editFormData.parentAddress || ""}
                          onChange={(e) => setEditFormData({ ...editFormData, parentAddress: e.target.value })}
                        />
                      </div>
                    </div>
                  )}
                </div>
              </TabsContent>

              {/* Pestaña de Documentos */}
              <TabsContent value="documents" className="space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-semibold">Documentos Requeridos por el MINERD</h3>
                    <Badge className="bg-blue-100 text-blue-800">
                      {editEnrollmentType === "nuevo-ingreso"
                        ? "Nuevo Ingreso"
                        : editEnrollmentType === "reinscripcion"
                          ? "Reinscripción"
                          : "Estudiante Extranjero"}
                    </Badge>
                  </div>

                  <div className="grid gap-4">
                    {editDocuments.map((doc, index) => (
                      <Card key={index} className="p-4">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <span className="font-medium">{doc.name}</span>
                            {doc.required && <Badge className="bg-red-100 text-red-800 text-xs">Requerido</Badge>}
                          </div>
                          {doc.uploaded && (
                            <div className="flex items-center gap-2 text-green-600">
                              <Check className="h-4 w-4" />
                              <span className="text-sm">Subido</span>
                            </div>
                          )}
                        </div>

                        <div className="flex items-center gap-4">
                          <div className="flex-1">
                            <Input
                              type="file"
                              accept=".pdf,.jpg,.jpeg,.png"
                              onChange={(e) => {
                                const file = e.target.files?.[0]
                                if (file) {
                                  handleEditFileUpload(index, file)
                                }
                              }}
                              className="file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
                            />
                          </div>

                          {doc.uploaded && doc.file && (
                            <div className="flex items-center gap-2">
                              <span className="text-sm text-gray-600">{doc.file.name}</span>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleEditRemoveFile(index)}
                                className="h-8 w-8 p-0"
                              >
                                <X className="h-4 w-4" />
                              </Button>
                            </div>
                          )}
                        </div>
                      </Card>
                    ))}
                  </div>

                  <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <div className="flex items-center gap-2 text-blue-800 mb-2">
                      <FileText className="h-4 w-4" />
                      <span className="font-medium">Información Importante</span>
                    </div>
                    <ul className="text-sm text-blue-700 space-y-1">
                      <li>• Los documentos deben estar en formato PDF, JPG o PNG</li>
                      <li>• Tamaño máximo por archivo: 5MB</li>
                      <li>• Los documentos marcados como "Requerido" son obligatorios</li>
                      <li>• Asegúrese de que los documentos sean legibles y estén completos</li>
                      <li>• Puede actualizar documentos existentes subiendo nuevas versiones</li>
                    </ul>
                  </div>
                </div>
              </TabsContent>

              {/* Pestaña de Revisión */}
              <TabsContent value="review" className="space-y-6">
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Revisión de Cambios</h3>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <Card className="p-4">
                      <h4 className="font-medium mb-3">Resumen del Estudiante</h4>
                      <div className="space-y-2 text-sm">
                        <div>
                          <strong>Nombre:</strong> {editFormData?.name}
                        </div>
                        <div>
                          <strong>Grado:</strong> {editFormData?.grade} - Sección {editFormData?.section}
                        </div>
                        <div>
                          <strong>Tipo:</strong> {editEnrollmentType}
                        </div>
                        <div>
                          <strong>Estado:</strong> {editFormData?.status}
                        </div>
                        <div>
                          <strong>Documentos:</strong> {editDocuments.filter((d) => d.uploaded).length} de{" "}
                          {editDocuments.length} subidos
                        </div>
                      </div>
                    </Card>

                    <Card className="p-4">
                      <h4 className="font-medium mb-3">Estado de Documentos</h4>
                      <div className="space-y-2">
                        {editDocuments.map((doc, index) => (
                          <div key={index} className="flex items-center justify-between text-sm">
                            <span className={doc.required ? "font-medium" : ""}>{doc.name}</span>
                            {doc.uploaded ? (
                              <Check className="h-4 w-4 text-green-600" />
                            ) : (
                              <X className="h-4 w-4 text-red-600" />
                            )}
                          </div>
                        ))}
                      </div>
                    </Card>

                    <Card className="p-4">
                      <h4 className="font-medium mb-3">Información del Padre/Tutor</h4>
                      <div className="space-y-2 text-sm">
                        <div>
                          <strong>Nombre:</strong> {editFormData?.parentName}
                        </div>
                        <div>
                          <strong>Teléfono:</strong> {editFormData?.parentPhone}
                        </div>
                        <div>
                          <strong>Email:</strong> {editFormData?.parentEmail}
                        </div>
                        <div>
                          <strong>Parentesco:</strong> {editFormData?.parentRelationship}
                        </div>
                      </div>
                    </Card>

                    <Card className="p-4">
                      <h4 className="font-medium mb-3">Notas Adicionales</h4>
                      <div>
                        <Label htmlFor="editNotes">Notas</Label>
                        <Textarea
                          id="editNotes"
                          value={editFormData?.notes || ""}
                          onChange={(e) => editFormData && setEditFormData({ ...editFormData, notes: e.target.value })}
                          placeholder="Agregar notas adicionales..."
                        />
                      </div>
                    </Card>
                  </div>

                  <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <div className="flex items-center gap-2 text-yellow-800 mb-2">
                      <AlertTriangle className="h-4 w-4" />
                      <span className="font-medium">Antes de Guardar</span>
                    </div>
                    <ul className="text-sm text-yellow-700 space-y-1">
                      <li>• Verifique que toda la información esté correcta</li>
                      <li>• Revise el estado de los documentos actualizados</li>
                      <li>• Los cambios se aplicarán inmediatamente</li>
                      <li>• Se mantendrá un registro de las modificaciones realizadas</li>
                    </ul>
                  </div>
                </div>
              </TabsContent>
            </Tabs>

            <div className="flex justify-end gap-4 mt-6">
              <Button variant="outline" onClick={() => setShowEditStudentModal(false)}>
                Cancelar
              </Button>
              <Button
                onClick={handleSaveEdit}
                className="bg-gradient-to-r from-futuristic-primary to-futuristic-primary-light"
              >
                Guardar Cambios
              </Button>
            </div>
          </DialogContent>
        </Dialog>

        {/* Modal de Nueva Inscripción */}
        <Dialog open={showNewStudentModal} onOpenChange={setShowNewStudentModal}>
          <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <UserPlus className="h-5 w-5" />
                Nueva Inscripción
              </DialogTitle>
            </DialogHeader>

            <Tabs defaultValue="student" className="w-full">
              <TabsList className="grid w-full grid-cols-6">
                <TabsTrigger value="student" className="flex items-center gap-2">
                  <User className="h-4 w-4" />
                  Estudiante
                </TabsTrigger>
                <TabsTrigger value="acta" className="flex items-center gap-2">
                  <FileText className="h-4 w-4" />
                  Información del Acta
                </TabsTrigger>
                <TabsTrigger value="emergencia" className="flex items-center gap-2">
                  <AlertTriangle className="h-4 w-4" />
                  Datos de Emergencia
                </TabsTrigger>
                <TabsTrigger value="parent" className="flex items-center gap-2">
                  <Users className="h-4 w-4" />
                  Padre/Tutor
                </TabsTrigger>
                <TabsTrigger value="documents" className="flex items-center gap-2">
                  <FileCheck className="h-4 w-4" />
                  Documentos
                </TabsTrigger>
                <TabsTrigger value="review" className="flex items-center gap-2">
                  <Clock className="h-4 w-4" />
                  Revisión
                </TabsTrigger>
              </TabsList>

              {/* Pestaña de Información del Estudiante */}
              <TabsContent value="student" className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Información del Estudiante</h3>

                    {/* Sección de Reinscripción - Solo aparece cuando se selecciona reinscripción */}
                    {enrollmentType === "reinscripcion" && !selectedStudentForReinscription && (
                      <Card className="p-4 bg-blue-50 border-blue-200">
                        <div className="flex items-center gap-2 mb-3">
                          <RefreshCw className="h-4 w-4 text-blue-600" />
                          <h4 className="font-medium text-blue-800">Seleccionar Estudiante para Reinscripción</h4>
                        </div>
                        <div className="space-y-3">
                          <div>
                            <Label htmlFor="reinscriptionSearch">Buscar Estudiante</Label>
                            <div className="relative">
                              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                              <Input
                                id="reinscriptionSearch"
                                placeholder="Buscar por nombre, padre o teléfono..."
                                value={reinscriptionSearchTerm}
                                onChange={(e) => setReinscriptionSearchTerm(e.target.value)}
                                className="pl-10"
                              />
                            </div>
                          </div>

                          {reinscriptionSearchTerm && (
                            <div className="max-h-48 overflow-y-auto border rounded-md">
                              {filteredStudentsForReinscription.length > 0 ? (
                                filteredStudentsForReinscription.map((student) => (
                                  <div
                                    key={student.id}
                                    className="p-3 hover:bg-blue-100 cursor-pointer border-b last:border-b-0"
                                    onClick={() => handleSelectStudentForReinscription(student)}
                                  >
                                    <div className="font-medium text-blue-900">{student.name}</div>
                                    <div className="text-sm text-blue-700">
                                      {student.grade} - Sección {student.section}
                                    </div>
                                    <div className="text-xs text-blue-600">
                                      Padre: {student.parentName} - {student.parentPhone}
                                    </div>
                                  </div>
                                ))
                              ) : (
                                <div className="p-3 text-center text-gray-500">No se encontraron estudiantes</div>
                              )}
                            </div>
                          )}

                          <div className="text-xs text-blue-600">
                            * Busque y seleccione el estudiante que desea reinscribir. Sus datos se cargarán
                            automáticamente.
                          </div>
                        </div>
                      </Card>
                    )}

                    {/* Mostrar información del estudiante seleccionado para reinscripción */}
                    {enrollmentType === "reinscripcion" && selectedStudentForReinscription && (
                      <Card className="p-4 bg-green-50 border-green-200">
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center gap-2">
                            <Check className="h-4 w-4 text-green-600" />
                            <h4 className="font-medium text-green-800">Estudiante Seleccionado para Reinscripción</h4>
                          </div>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={handleClearReinscriptionSelection}
                            className="text-red-600 border-red-300 hover:bg-red-50 bg-transparent"
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                        <div className="grid grid-cols-2 gap-2 text-sm">
                          <div>
                            <strong>Nombre:</strong> {selectedStudentForReinscription.name}
                          </div>
                          <div>
                            <strong>Grado Anterior:</strong> {selectedStudentForReinscription.grade}
                          </div>
                          <div>
                            <strong>Edad:</strong> {selectedStudentForReinscription.age} años
                          </div>
                          <div>
                            <strong>Padre:</strong> {selectedStudentForReinscription.parentName}
                          </div>
                        </div>
                        <div className="mt-2 text-xs text-green-600">
                          * Los datos del estudiante han sido cargados. Puede actualizar la información necesaria.
                        </div>
                      </Card>
                    )}

                    <div>
                      <Label htmlFor="studentName">Nombre Completo *</Label>
                      <Input
                        id="studentName"
                        placeholder="Ingrese el nombre completo"
                        value={newStudentFormData.name}
                        onChange={(e) => setNewStudentFormData({ ...newStudentFormData, name: e.target.value })}
                        disabled={enrollmentType === "reinscripcion" && selectedStudentForReinscription}
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="grade">Grado *</Label>
                        <Select
                          value={newStudentFormData.grade}
                          onValueChange={(value) => setNewStudentFormData({ ...newStudentFormData, grade: value })}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Seleccionar grado" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="1° Primaria">1° Primaria</SelectItem>
                            <SelectItem value="2° Primaria">2° Primaria</SelectItem>
                            <SelectItem value="3° Primaria">3° Primaria</SelectItem>
                            <SelectItem value="4° Primaria">4° Primaria</SelectItem>
                            <SelectItem value="5° Primaria">5° Primaria</SelectItem>
                            <SelectItem value="6° Primaria">6° Primaria</SelectItem>
                            <SelectItem value="1° Secundaria">1° Secundaria</SelectItem>
                            <SelectItem value="2° Secundaria">2° Secundaria</SelectItem>
                            <SelectItem value="3° Secundaria">3° Secundaria</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor="section">Sección *</Label>
                        <Select
                          value={newStudentFormData.section}
                          onValueChange={(value) => setNewStudentFormData({ ...newStudentFormData, section: value })}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Seleccionar sección" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="A">A</SelectItem>
                            <SelectItem value="B">B</SelectItem>
                            <SelectItem value="C">C</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div>
                      <Label htmlFor="studentPhone">Teléfono</Label>
                      <Input
                        id="studentPhone"
                        placeholder="809-000-0000"
                        value={newStudentFormData.phone}
                        onChange={(e) => setNewStudentFormData({ ...newStudentFormData, phone: e.target.value })}
                      />
                    </div>
                    <div>
                      <Label htmlFor="studentEmail">Email</Label>
                      <Input
                        id="studentEmail"
                        type="email"
                        placeholder="estudiante@email.com"
                        value={newStudentFormData.email}
                        onChange={(e) => setNewStudentFormData({ ...newStudentFormData, email: e.target.value })}
                      />
                    </div>
                    <div>
                      <Label htmlFor="address">Dirección</Label>
                      <Textarea
                        id="address"
                        placeholder="Dirección completa"
                        value={newStudentFormData.address}
                        onChange={(e) => setNewStudentFormData({ ...newStudentFormData, address: e.target.value })}
                      />
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Tipo de Inscripción</h3>
                    <RadioGroup value={enrollmentType} onValueChange={setEnrollmentType}>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="nuevo-ingreso" id="nuevo-ingreso" />
                        <Label htmlFor="nuevo-ingreso">Nuevo Ingreso (Primera vez)</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="reinscripcion" id="reinscripcion" />
                        <Label htmlFor="reinscripcion">Reinscripción</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="extranjero" id="extranjero" />
                        <Label htmlFor="extranjero">Estudiante Extranjero</Label>
                      </div>
                    </RadioGroup>

                    {/* Alerta de Validación de Edad */}
                    <div className="mt-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                      <div className="flex items-center gap-2 text-yellow-800 mb-2">
                        <AlertTriangle className="h-4 w-4" />
                        <span className="font-medium">Validación de Edad</span>
                      </div>
                      <p className="text-sm text-yellow-700">
                        El sistema validará automáticamente si la edad del estudiante está dentro del rango permitido
                        por el MINERD para el grado seleccionado.
                      </p>
                      <p className="text-xs text-yellow-600 mt-1">
                        Si está fuera del rango, se requerirá autorización del Director.
                      </p>
                    </div>
                  </div>
                </div>
              </TabsContent>

              {/* Pestaña de Información del Acta */}
              <TabsContent value="acta" className="space-y-6">
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Información del Acta de Nacimiento</h3>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="fechaNacimiento">Fecha de Nacimiento *</Label>
                        <Input
                          id="fechaNacimiento"
                          type="date"
                          value={newStudentFormData.birthDate}
                          onChange={(e) => setNewStudentFormData({ ...newStudentFormData, birthDate: e.target.value })}
                        />
                      </div>
                      <div>
                        <Label htmlFor="libro">Libro</Label>
                        <Input id="libro" placeholder="Número de libro" />
                      </div>
                      <div>
                        <Label htmlFor="folio">Folio</Label>
                        <Input id="folio" placeholder="Número de folio" />
                      </div>
                      <div>
                        <Label htmlFor="acta">Acta</Label>
                        <Input id="acta" placeholder="Número de acta" />
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="sexo">Sexo *</Label>
                        <Select>
                          <SelectTrigger>
                            <SelectValue placeholder="Seleccionar sexo" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="masculino">Masculino</SelectItem>
                            <SelectItem value="femenino">Femenino</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor="conQuienReside">¿Con quién reside?</Label>
                        <Select>
                          <SelectTrigger>
                            <SelectValue placeholder="Seleccionar con quién reside" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="ambos-padres">Ambos padres</SelectItem>
                            <SelectItem value="madre">Solo con la madre</SelectItem>
                            <SelectItem value="padre">Solo con el padre</SelectItem>
                            <SelectItem value="abuelos">Con los abuelos</SelectItem>
                            <SelectItem value="tutor">Con tutor legal</SelectItem>
                            <SelectItem value="otros">Otros familiares</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>
                </div>
              </TabsContent>

              {/* Pestaña de Datos de Emergencia */}
              <TabsContent value="emergencia" className="space-y-6">
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Datos de Emergencia y Salud</h3>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="algunaEnfermedad">¿Alguna enfermedad?</Label>
                        <div className="space-y-2">
                          <RadioGroup defaultValue="no">
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="no" id="enfermedad-no" />
                              <Label htmlFor="enfermedad-no">No</Label>
                            </div>
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="si" id="enfermedad-si" />
                              <Label htmlFor="enfermedad-si">Sí</Label>
                            </div>
                          </RadioGroup>
                          <Textarea placeholder="Especificar enfermedad (si aplica)" className="mt-2" />
                        </div>
                      </div>

                      <div>
                        <Label htmlFor="esAlergico">¿Es alérgico?</Label>
                        <div className="space-y-2">
                          <RadioGroup defaultValue="no">
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="no" id="alergia-no" />
                              <Label htmlFor="alergia-no">No</Label>
                            </div>
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="si" id="alergia-si" />
                              <Label htmlFor="alergia-si">Sí</Label>
                            </div>
                          </RadioGroup>
                          <Textarea placeholder="Especificar alergias (si aplica)" className="mt-2" />
                        </div>
                      </div>

                      <div>
                        <Label htmlFor="esAsegurado">¿Es asegurado?</Label>
                        <RadioGroup defaultValue="no">
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="no" id="seguro-no" />
                            <Label htmlFor="seguro-no">No</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="si" id="seguro-si" />
                            <Label htmlFor="seguro-si">Sí</Label>
                          </div>
                        </RadioGroup>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="tipoSeguro">Tipo de Seguro</Label>
                        <Select>
                          <SelectTrigger>
                            <SelectValue placeholder="Seleccionar tipo de seguro" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="senasa">SENASA</SelectItem>
                            <SelectItem value="ars-humano">ARS Humano</SelectItem>
                            <SelectItem value="ars-universal">ARS Universal</SelectItem>
                            <SelectItem value="ars-palic">ARS Palic</SelectItem>
                            <SelectItem value="seguro-privado">Seguro Privado</SelectItem>
                            <SelectItem value="otros">Otros</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <Label htmlFor="tipoSangre">Tipo de Sangre</Label>
                        <Select>
                          <SelectTrigger>
                            <SelectValue placeholder="Seleccionar tipo de sangre" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="a-positivo">A+</SelectItem>
                            <SelectItem value="a-negativo">A-</SelectItem>
                            <SelectItem value="b-positivo">B+</SelectItem>
                            <SelectItem value="b-negativo">B-</SelectItem>
                            <SelectItem value="ab-positivo">AB+</SelectItem>
                            <SelectItem value="ab-negativo">AB-</SelectItem>
                            <SelectItem value="o-positivo">O+</SelectItem>
                            <SelectItem value="o-negativo">O-</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <Label htmlFor="emergenciaLlamar">En emergencia llamar a:</Label>
                        <div className="space-y-3">
                          <div>
                            <Label htmlFor="contactoEmergencia1" className="text-sm">
                              Contacto Principal
                            </Label>
                            <Input id="contactoEmergencia1" placeholder="Nombre del contacto" className="mb-2" />
                            <Input placeholder="Teléfono" type="tel" className="mb-2" />
                            <Input placeholder="Parentesco" />
                          </div>

                          <div>
                            <Label htmlFor="contactoEmergencia2" className="text-sm">
                              Contacto Secundario
                            </Label>
                            <Input id="contactoEmergencia2" placeholder="Nombre del contacto" className="mb-2" />
                            <Input placeholder="Teléfono" type="tel" className="mb-2" />
                            <Input placeholder="Parentesco" />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="mt-6 p-4 bg-red-50 border border-red-200 rounded-lg">
                    <div className="flex items-center gap-2 text-red-800 mb-2">
                      <AlertTriangle className="h-4 w-4" />
                      <span className="font-medium">Información Importante</span>
                    </div>
                    <ul className="text-sm text-red-700 space-y-1">
                      <li>• Esta información es crucial para emergencias médicas</li>
                      <li>• Mantenga actualizados los contactos de emergencia</li>
                      <li>• Notifique cualquier cambio en el estado de salud del estudiante</li>
                      <li>• Los datos médicos son confidenciales y solo para uso del centro educativo</li>
                    </ul>
                  </div>
                </div>
              </TabsContent>

              {/* Pestaña de Padre/Tutor */}
              <TabsContent value="parent" className="space-y-6">
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Información del Padre/Tutor</h3>

                  <RadioGroup value={parentOption} onValueChange={setParentOption}>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="existing" id="existing" />
                      <Label htmlFor="existing">Seleccionar padre existente</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="new" id="new" />
                      <Label htmlFor="new">Registrar nuevo padre/tutor</Label>
                    </div>
                  </RadioGroup>

                  {parentOption === "existing" && (
                    <div className="space-y-4">
                      <Label htmlFor="parentSelect">Seleccionar Padre/Tutor</Label>
                      <Select
                        value={selectedParent?.id || ""}
                        onValueChange={(value) => {
                          const parent = existingParents.find((p) => p.id === value)
                          setSelectedParent(parent || null)
                        }}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Buscar y seleccionar padre/tutor" />
                        </SelectTrigger>
                        <SelectContent>
                          {existingParents.map((parent) => (
                            <SelectItem key={parent.id} value={parent.id}>
                              {parent.name} - {parent.phone} - {parent.cedula}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>

                      {selectedParent && (
                        <Card className="p-4 bg-blue-50 border-blue-200">
                          <h4 className="font-medium mb-2">Información del Padre Seleccionado:</h4>
                          <div className="grid grid-cols-2 gap-2 text-sm">
                            <div>
                              <strong>Nombre:</strong> {selectedParent.name}
                            </div>
                            <div>
                              <strong>Teléfono:</strong> {selectedParent.phone}
                            </div>
                            <div>
                              <strong>Email:</strong> {selectedParent.email}
                            </div>
                            <div>
                              <strong>Cédula:</strong> {selectedParent.cedula}
                            </div>
                            <div>
                              <strong>Ocupación:</strong> {selectedParent.occupation}
                            </div>
                            <div>
                              <strong>Parentesco:</strong> {selectedParent.relationship}
                            </div>
                          </div>
                        </Card>
                      )}
                    </div>
                  )}

                  {parentOption === "new" && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="parentName">Nombre Completo *</Label>
                        <Input id="parentName" placeholder="Nombre del padre/tutor" />
                      </div>
                      <div>
                        <Label htmlFor="parentCedula">Cédula *</Label>
                        <Input id="parentCedula" placeholder="001-1234567-8" />
                      </div>
                      <div>
                        <Label htmlFor="parentPhone">Teléfono *</Label>
                        <Input id="parentPhone" placeholder="809-000-0000" />
                      </div>
                      <div>
                        <Label htmlFor="parentEmail">Email</Label>
                        <Input id="parentEmail" type="email" placeholder="padre@email.com" />
                      </div>
                      <div>
                        <Label htmlFor="relationship">Parentesco</Label>
                        <Select>
                          <SelectTrigger>
                            <SelectValue placeholder="Seleccionar parentesco" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="padre">Padre</SelectItem>
                            <SelectItem value="madre">Madre</SelectItem>
                            <SelectItem value="tutor">Tutor Legal</SelectItem>
                            <SelectItem value="abuelo">Abuelo/a</SelectItem>
                            <SelectItem value="tio">Tío/a</SelectItem>
                            <SelectItem value="otro">Otro</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor="occupation">Ocupación</Label>
                        <Input id="occupation" placeholder="Ocupación del padre/tutor" />
                      </div>
                      <div className="md:col-span-2">
                        <Label htmlFor="parentAddress">Dirección</Label>
                        <Textarea id="parentAddress" placeholder="Dirección completa" />
                      </div>
                    </div>
                  )}
                </div>
              </TabsContent>

              {/* Pestaña de Documentos */}
              <TabsContent value="documents" className="space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-semibold">Documentos Requeridos por el MINERD</h3>
                    <Badge className="bg-blue-100 text-blue-800">
                      {enrollmentType === "nuevo-ingreso"
                        ? "Nuevo Ingreso"
                        : enrollmentType === "reinscripcion"
                          ? "Reinscripción"
                          : "Estudiante Extranjero"}
                    </Badge>
                  </div>

                  <div className="grid gap-4">
                    {documents.map((doc, index) => (
                      <Card key={index} className="p-4">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <span className="font-medium">{doc.name}</span>
                            {doc.required && <Badge className="bg-red-100 text-red-800 text-xs">Requerido</Badge>}
                          </div>
                          {doc.uploaded && (
                            <div className="flex items-center gap-2 text-green-600">
                              <Check className="h-4 w-4" />
                              <span className="text-sm">Subido</span>
                            </div>
                          )}
                        </div>

                        <div className="flex items-center gap-4">
                          <div className="flex-1">
                            <Input
                              type="file"
                              accept=".pdf,.jpg,.jpeg,.png"
                              onChange={(e) => {
                                const file = e.target.files?.[0]
                                if (file) {
                                  handleFileUpload(index, file)
                                }
                              }}
                              className="file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
                            />
                          </div>

                          {doc.uploaded && doc.file && (
                            <div className="flex items-center gap-2">
                              <span className="text-sm text-gray-600">{doc.file.name}</span>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleRemoveFile(index)}
                                className="h-8 w-8 p-0"
                              >
                                <X className="h-4 w-4" />
                              </Button>
                            </div>
                          )}
                        </div>
                      </Card>
                    ))}
                  </div>

                  <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <div className="flex items-center gap-2 text-blue-800 mb-2">
                      <FileText className="h-4 w-4" />
                      <span className="font-medium">Información Importante</span>
                    </div>
                    <ul className="text-sm text-blue-700 space-y-1">
                      <li>• Los documentos deben estar en formato PDF, JPG o PNG</li>
                      <li>• Tamaño máximo por archivo: 5MB</li>
                      <li>• Los documentos marcados como "Requerido" son obligatorios</li>
                      <li>• Asegúrese de que los documentos sean legibles y estén completos</li>
                      {enrollmentType === "reinscripcion" && (
                        <li>• Para reinscripción, se mantendrá el historial académico del estudiante</li>
                      )}
                    </ul>
                  </div>
                </div>
              </TabsContent>

              {/* Pestaña de Revisión */}
              <TabsContent value="review" className="space-y-6">
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Revisión Final</h3>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <Card className="p-4">
                      <h4 className="font-medium mb-3">Resumen del Estudiante</h4>
                      <div className="space-y-2 text-sm">
                        <div>
                          <strong>Nombre:</strong> {newStudentFormData.name || "No especificado"}
                        </div>
                        <div>
                          <strong>Grado:</strong> {newStudentFormData.grade || "No especificado"} - Sección{" "}
                          {newStudentFormData.section || "No especificada"}
                        </div>
                        <div>
                          <strong>Tipo:</strong> {enrollmentType}
                        </div>
                        <div>
                          <strong>Estado:</strong> Pendiente de revisión
                        </div>
                        <div>
                          <strong>Documentos:</strong> {documents.filter((d) => d.uploaded).length} de{" "}
                          {documents.length} subidos
                        </div>
                        {selectedStudentForReinscription && (
                          <div className="mt-2 p-2 bg-green-100 rounded">
                            <strong>Reinscripción de:</strong> {selectedStudentForReinscription.name}
                          </div>
                        )}
                      </div>
                    </Card>

                    <Card className="p-4">
                      <h4 className="font-medium mb-3">Estado de Documentos</h4>
                      <div className="space-y-2">
                        {documents.map((doc, index) => (
                          <div key={index} className="flex items-center justify-between text-sm">
                            <span className={doc.required ? "font-medium" : ""}>{doc.name}</span>
                            {doc.uploaded ? (
                              <Check className="h-4 w-4 text-green-600" />
                            ) : (
                              <X className="h-4 w-4 text-red-600" />
                            )}
                          </div>
                        ))}
                      </div>
                    </Card>

                    <Card className="p-4">
                      <h4 className="font-medium mb-3">Información del Padre/Tutor</h4>
                      <div className="space-y-2 text-sm">
                        {selectedParent ? (
                          <>
                            <div>
                              <strong>Nombre:</strong> {selectedParent.name}
                            </div>
                            <div>
                              <strong>Teléfono:</strong> {selectedParent.phone}
                            </div>
                            <div>
                              <strong>Email:</strong> {selectedParent.email}
                            </div>
                            <div>
                              <strong>Parentesco:</strong> {selectedParent.relationship}
                            </div>
                          </>
                        ) : (
                          <div className="text-gray-500">Padre/tutor no seleccionado</div>
                        )}
                      </div>
                    </Card>
                  </div>

                  <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <div className="flex items-center gap-2 text-yellow-800 mb-2">
                      <AlertTriangle className="h-4 w-4" />
                      <span className="font-medium">Antes de Enviar</span>
                    </div>
                    <ul className="text-sm text-yellow-700 space-y-1">
                      <li>• Verifique que toda la información esté correcta</li>
                      <li>• Asegúrese de haber subido todos los documentos requeridos</li>
                      <li>• La solicitud será enviada para revisión del equipo administrativo</li>
                      <li>• Recibirá una notificación sobre el estado de la solicitud</li>
                      {enrollmentType === "reinscripcion" && (
                        <li>• Para reinscripción, se mantendrá el historial académico del estudiante</li>
                      )}
                    </ul>
                  </div>
                </div>
              </TabsContent>
            </Tabs>

            <div className="flex justify-end gap-4 mt-6">
              <Button variant="outline" onClick={() => setShowNewStudentModal(false)}>
                Cancelar
              </Button>
              <Button className="bg-gradient-to-r from-futuristic-primary to-futuristic-primary-light">
                Guardar Inscripción
              </Button>
            </div>
          </DialogContent>
        </Dialog>

        {/* Modal de Programar Entrevista */}
        <Dialog open={showInterviewModal} onOpenChange={setShowInterviewModal}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Programar Entrevista - {selectedStudent?.name}
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="interviewDate">Fecha de Entrevista</Label>
                  <Input id="interviewDate" type="date" />
                </div>
                <div>
                  <Label htmlFor="interviewTime">Hora</Label>
                  <Input id="interviewTime" type="time" />
                </div>
              </div>
              <div>
                <Label htmlFor="interviewer">Entrevistador</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Seleccionar entrevistador" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="director">Director</SelectItem>
                    <SelectItem value="coordinador">Coordinador Académico</SelectItem>
                    <SelectItem value="psicologo">Psicólogo</SelectItem>
                    <SelectItem value="secretario">Secretario</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="interviewType">Tipo de Entrevista</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Seleccionar tipo" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="inicial">Entrevista Inicial</SelectItem>
                    <SelectItem value="seguimiento">Seguimiento</SelectItem>
                    <SelectItem value="edad">Validación de Edad</SelectItem>
                    <SelectItem value="documentos">Revisión de Documentos</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="interviewNotes">Notas de la Entrevista</Label>
                <Textarea id="interviewNotes" placeholder="Propósito y observaciones de la entrevista" />
              </div>
            </div>
            <div className="flex justify-end gap-4 mt-6">
              <Button variant="outline" onClick={() => setShowInterviewModal(false)}>
                Cancelar
              </Button>
              <Button className="bg-gradient-to-r from-futuristic-secondary to-futuristic-info">
                Programar Entrevista
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </main>
    </div>
  )
}
