"use client"

import { useState } from "react"
import { useAuth } from "@/contexts/auth-context"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  FileText,
  Download,
  Calendar,
  Users,
  GraduationCap,
  BarChart3,
  Filter,
  Plus,
  ClipboardList,
  UserCheck,
  Printer,
  FileSpreadsheet,
  AlertTriangle,
  CheckCircle,
  Clock,
  Archive,
  Settings,
  Eye,
  Share2,
  History,
} from "lucide-react"

export default function CoordinadorReportsPage() {
  const { user } = useAuth()
  const [isNewReportModalOpen, setIsNewReportModalOpen] = useState(false)
  const [selectedReportType, setSelectedReportType] = useState("")
  const [currentStep, setCurrentStep] = useState(1)
  const [reportParams, setReportParams] = useState({
    course: "",
    section: "",
    period: "",
    dateRange: { start: "", end: "" },
    academicArea: "",
    studentType: "",
    educationLevel: "",
    exportFormat: "pdf",
    sendEmail: false,
    print: false,
    includeSignatures: true,
    includeInstitutionalHeader: true,
  })

  const [selectedReportForAction, setSelectedReportForAction] = useState<string | null>(null)
  const [isActionModalOpen, setIsActionModalOpen] = useState(false)
  const [actionType, setActionType] = useState<"print" | "whatsapp" | "email" | "view" | null>(null)
  const [isConfigModalOpen, setIsConfigModalOpen] = useState(false)

  if (!user) return null

  // Estadísticas del dashboard
  const dashboardStats = {
    totalReports: 342,
    pendingReports: 12,
    completedReports: 330,
    monthlyReports: 45,
    studentsOutOfAge: 8,
    closedPeriods: 16,
    activeCourses: 24,
    reportDownloads: 1247,
  }

  // Tipos de reportes disponibles
  const reportTypes = [
    {
      id: "students",
      name: "📄 Reporte de Estudiantes",
      icon: <Users className="h-6 w-6 text-blue-600" />,
      description: "Lista completa de estudiantes por curso con filtros avanzados",
      color: "bg-blue-50 border-blue-200",
    },
    {
      id: "academic",
      name: "🧠 Reporte Académico",
      icon: <GraduationCap className="h-6 w-6 text-purple-600" />,
      description: "Consolidado de calificaciones por período y evaluaciones finales",
      color: "bg-purple-50 border-purple-200",
    },
    {
      id: "attendance",
      name: "📆 Reporte de Asistencia",
      icon: <UserCheck className="h-6 w-6 text-green-600" />,
      description: "Registro de asistencia diaria, semanal o mensual",
      color: "bg-green-50 border-green-200",
    },
    {
      id: "statistics",
      name: "📈 Estadísticas Generales",
      icon: <BarChart3 className="h-6 w-6 text-orange-600" />,
      description: "Métricas y análisis del rendimiento institucional",
      color: "bg-orange-50 border-orange-200",
    },
    {
      id: "bulletin",
      name: "📝 Boletín de Calificaciones",
      icon: <ClipboardList className="h-6 w-6 text-indigo-600" />,
      description: "Boletín oficial MINERD individual o por grupo",
      color: "bg-indigo-50 border-indigo-200",
    },
    {
      id: "consolidated-act",
      name: "🗃 Acta Consolidada por Curso",
      icon: <Archive className="h-6 w-6 text-teal-600" />,
      description: "Consolidación oficial de calificaciones por curso",
      color: "bg-teal-50 border-teal-200",
    },
    {
      id: "age-range",
      name: "🔍 Alumnos fuera del rango MINERD",
      icon: <AlertTriangle className="h-6 w-6 text-red-600" />,
      description: "Estudiantes que exceden el rango de edad establecido",
      color: "bg-red-50 border-red-200",
    },
  ]

  // Reportes generados recientemente
  const recentReports = [
    {
      id: "1",
      name: "Boletín 6to A - Primer Período",
      type: "Boletín de Calificaciones",
      course: "6to A",
      period: "P1 2024",
      status: "Completado",
      generatedDate: "2024-01-15",
      format: "PDF",
      size: "2.4 MB",
      downloads: 12,
      canRegenerate: true,
    },
    {
      id: "2",
      name: "Acta Consolidada 5to B",
      type: "Acta Consolidada",
      course: "5to B",
      period: "Anual 2024",
      status: "Completado",
      generatedDate: "2024-01-14",
      format: "PDF",
      size: "1.8 MB",
      downloads: 8,
      canRegenerate: true,
    },
    {
      id: "3",
      name: "Reporte de Asistencia Enero",
      type: "Asistencia",
      course: "Todos",
      period: "Enero 2024",
      status: "En Proceso",
      generatedDate: "2024-01-16",
      format: "Excel",
      size: "3.2 MB",
      downloads: 0,
      canRegenerate: false,
    },
    {
      id: "4",
      name: "Estudiantes fuera de rango",
      type: "Alerta MINERD",
      course: "Todos",
      period: "2024",
      status: "Completado",
      generatedDate: "2024-01-10",
      format: "PDF",
      size: "856 KB",
      downloads: 15,
      canRegenerate: true,
    },
  ]

  // Alertas importantes
  const alerts = [
    {
      id: 1,
      type: "warning",
      title: "Estudiantes fuera de rango de edad",
      description: "8 estudiantes exceden el rango de edad MINERD",
      priority: "high",
      action: "Ver Reporte",
    },
    {
      id: 2,
      type: "info",
      title: "Períodos pendientes de cierre",
      description: "3 cursos tienen períodos sin validar",
      priority: "medium",
      action: "Revisar",
    },
    {
      id: 3,
      type: "success",
      title: "Boletines generados",
      description: "45 boletines generados este mes",
      priority: "low",
      action: "Ver Historial",
    },
  ]

  const getStatusBadge = (status: string) => {
    const variants = {
      Completado: "bg-green-100 text-green-800",
      "En Proceso": "bg-yellow-100 text-yellow-800",
      Programado: "bg-blue-100 text-blue-800",
      Error: "bg-red-100 text-red-800",
    }
    return variants[status as keyof typeof variants] || "bg-gray-100 text-gray-800"
  }

  const getTypeIcon = (type: string) => {
    const icons = {
      "Boletín de Calificaciones": <ClipboardList className="h-5 w-5 text-indigo-500" />,
      "Acta Consolidada": <Archive className="h-5 w-5 text-teal-500" />,
      Asistencia: <UserCheck className="h-5 w-5 text-green-500" />,
      "Alerta MINERD": <AlertTriangle className="h-5 w-5 text-red-500" />,
      Académico: <GraduationCap className="h-5 w-5 text-purple-500" />,
      Estudiantes: <Users className="h-5 w-5 text-blue-500" />,
      Estadísticas: <BarChart3 className="h-5 w-5 text-orange-500" />,
    }
    return icons[type as keyof typeof icons] || <FileText className="h-5 w-5 text-gray-500" />
  }

  const handleReportTypeSelect = (typeId: string) => {
    setSelectedReportType(typeId)
    setCurrentStep(2)
  }

  const handleGenerateReport = () => {
    console.log("Generando reporte:", { selectedReportType, reportParams })
    setIsNewReportModalOpen(false)
    setCurrentStep(1)
    setSelectedReportType("")
    // Reset params
    setReportParams({
      course: "",
      section: "",
      period: "",
      dateRange: { start: "", end: "" },
      academicArea: "",
      studentType: "",
      educationLevel: "",
      exportFormat: "pdf",
      sendEmail: false,
      print: false,
      includeSignatures: true,
      includeInstitutionalHeader: true,
    })
  }

  const handleQuickReport = (type: string) => {
    setSelectedReportType(type)
    setIsNewReportModalOpen(true)
    setCurrentStep(2)
  }

  const handleReportAction = (reportId: string, action: "print" | "whatsapp" | "email" | "view") => {
    setSelectedReportForAction(reportId)
    setActionType(action)
    setIsActionModalOpen(true)
  }

  const renderReportConfiguration = () => {
    const selectedType = reportTypes.find((t) => t.id === selectedReportType)

    return (
      <div className="space-y-6">
        <div className="flex items-center space-x-3">
          {selectedType?.icon}
          <div>
            <h3 className="text-lg font-semibold">{selectedType?.name}</h3>
            <p className="text-sm text-gray-600">{selectedType?.description}</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Configuraciones comunes */}
          <div className="space-y-2">
            <Label htmlFor="course">Curso</Label>
            <Select
              value={reportParams.course}
              onValueChange={(value) => setReportParams({ ...reportParams, course: value })}
            >
              <SelectTrigger>
                <SelectValue placeholder="Seleccionar curso" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos los cursos</SelectItem>
                <SelectItem value="1-primaria">1° Primaria</SelectItem>
                <SelectItem value="2-primaria">2° Primaria</SelectItem>
                <SelectItem value="3-primaria">3° Primaria</SelectItem>
                <SelectItem value="4-primaria">4° Primaria</SelectItem>
                <SelectItem value="5-primaria">5° Primaria</SelectItem>
                <SelectItem value="6-primaria">6° Primaria</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="section">Sección</Label>
            <Select
              value={reportParams.section}
              onValueChange={(value) => setReportParams({ ...reportParams, section: value })}
            >
              <SelectTrigger>
                <SelectValue placeholder="Seleccionar sección" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas las secciones</SelectItem>
                <SelectItem value="A">Sección A</SelectItem>
                <SelectItem value="B">Sección B</SelectItem>
                <SelectItem value="C">Sección C</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Configuraciones específicas por tipo de reporte */}
          {(selectedReportType === "academic" || selectedReportType === "bulletin") && (
            <div className="space-y-2">
              <Label htmlFor="period">Período Académico</Label>
              <Select
                value={reportParams.period}
                onValueChange={(value) => setReportParams({ ...reportParams, period: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Seleccionar período" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="P1">Primer Período (P1)</SelectItem>
                  <SelectItem value="P2">Segundo Período (P2)</SelectItem>
                  <SelectItem value="P3">Tercer Período (P3)</SelectItem>
                  <SelectItem value="P4">Cuarto Período (P4)</SelectItem>
                  <SelectItem value="final">Calificación Final</SelectItem>
                  <SelectItem value="annual">Año Completo</SelectItem>
                </SelectContent>
              </Select>
            </div>
          )}

          {selectedReportType === "attendance" && (
            <>
              <div className="space-y-2">
                <Label htmlFor="startDate">Fecha Inicio</Label>
                <Input
                  id="startDate"
                  type="date"
                  value={reportParams.dateRange.start}
                  onChange={(e) =>
                    setReportParams({
                      ...reportParams,
                      dateRange: { ...reportParams.dateRange, start: e.target.value },
                    })
                  }
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="endDate">Fecha Fin</Label>
                <Input
                  id="endDate"
                  type="date"
                  value={reportParams.dateRange.end}
                  onChange={(e) =>
                    setReportParams({
                      ...reportParams,
                      dateRange: { ...reportParams.dateRange, end: e.target.value },
                    })
                  }
                />
              </div>
            </>
          )}

          {selectedReportType === "students" && (
            <div className="space-y-2">
              <Label htmlFor="studentType">Filtro de Estudiantes</Label>
              <Select
                value={reportParams.studentType}
                onValueChange={(value) => setReportParams({ ...reportParams, studentType: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Seleccionar filtro" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos</SelectItem>
                  <SelectItem value="active">Activos</SelectItem>
                  <SelectItem value="inactive">Retirados</SelectItem>
                  <SelectItem value="suspended">Suspendidos</SelectItem>
                  <SelectItem value="age-range">Fuera de rango de edad</SelectItem>
                  <SelectItem value="new-enrollment">Nuevos ingresos</SelectItem>
                  <SelectItem value="re-enrollment">Reinscripciones</SelectItem>
                </SelectContent>
              </Select>
            </div>
          )}
        </div>

        {/* Opciones de formato y distribución */}
        <div className="space-y-4 border-t pt-4">
          <h4 className="font-semibold text-gray-900">Opciones de Exportación</h4>

          <div className="space-y-3">
            <div className="space-y-2">
              <Label>Formato de exportación</Label>
              <div className="flex space-x-4">
                <div className="flex items-center space-x-2">
                  <input
                    type="radio"
                    id="pdf"
                    name="exportFormat"
                    value="pdf"
                    checked={reportParams.exportFormat === "pdf"}
                    onChange={(e) => setReportParams({ ...reportParams, exportFormat: e.target.value })}
                  />
                  <Label htmlFor="pdf" className="flex items-center space-x-2">
                    <FileText className="h-4 w-4" />
                    <span>PDF</span>
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <input
                    type="radio"
                    id="excel"
                    name="exportFormat"
                    value="excel"
                    checked={reportParams.exportFormat === "excel"}
                    onChange={(e) => setReportParams({ ...reportParams, exportFormat: e.target.value })}
                  />
                  <Label htmlFor="excel" className="flex items-center space-x-2">
                    <FileSpreadsheet className="h-4 w-4" />
                    <span>Excel</span>
                  </Label>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="includeHeader"
                  checked={reportParams.includeInstitutionalHeader}
                  onCheckedChange={(checked) =>
                    setReportParams({ ...reportParams, includeInstitutionalHeader: checked as boolean })
                  }
                />
                <Label htmlFor="includeHeader">Incluir encabezado institucional</Label>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="includeSignatures"
                  checked={reportParams.includeSignatures}
                  onCheckedChange={(checked) =>
                    setReportParams({ ...reportParams, includeSignatures: checked as boolean })
                  }
                />
                <Label htmlFor="includeSignatures">Incluir firmas digitales</Label>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="sendEmail"
                  checked={reportParams.sendEmail}
                  onCheckedChange={(checked) => setReportParams({ ...reportParams, sendEmail: checked as boolean })}
                />
                <Label htmlFor="sendEmail">Enviar por correo al Director</Label>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="print"
                  checked={reportParams.print}
                  onCheckedChange={(checked) => setReportParams({ ...reportParams, print: checked as boolean })}
                />
                <Label htmlFor="print">Enviar a impresión</Label>
              </div>
            </div>
          </div>
        </div>

        {/* Resumen de configuración */}
        <div className="bg-blue-50 p-4 rounded-lg">
          <h4 className="font-semibold text-blue-900 mb-2">Resumen de Configuración</h4>
          <div className="text-sm text-blue-800 space-y-1">
            <p>
              <strong>Tipo:</strong> {selectedType?.name}
            </p>
            <p>
              <strong>Curso:</strong> {reportParams.course || "No especificado"}
            </p>
            <p>
              <strong>Sección:</strong> {reportParams.section || "No especificado"}
            </p>
            <p>
              <strong>Período:</strong> {reportParams.period || "No especificado"}
            </p>
            <p>
              <strong>Formato:</strong> {reportParams.exportFormat.toUpperCase()}
            </p>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="flex flex-col gap-6 p-8 bg-gray-50 min-h-screen">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-gray-900">📊 Reportes Académicos y Administrativos</h1>
          <p className="text-gray-500">Gestión de reportes oficiales e institucionales</p>
        </div>
        <div className="flex space-x-3">
          <Button variant="outline" onClick={() => setIsConfigModalOpen(true)}>
            <Settings className="h-4 w-4 mr-2" />
            Configuración
          </Button>
          <Dialog open={isNewReportModalOpen} onOpenChange={setIsNewReportModalOpen}>
            <DialogTrigger asChild>
              <Button className="bg-indigo-600 hover:bg-indigo-700">
                <Plus className="h-4 w-4 mr-2" />➕ Nuevo Reporte
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Crear Nuevo Reporte</DialogTitle>
                <DialogDescription>Selecciona el tipo de reporte y configura los parámetros</DialogDescription>
              </DialogHeader>

              <div className="space-y-6">
                {currentStep === 1 ? (
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Selecciona el tipo de reporte</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {reportTypes.map((type) => (
                        <div
                          key={type.id}
                          className={`border rounded-lg p-4 hover:bg-gray-50 cursor-pointer transition-colors ${type.color}`}
                          onClick={() => handleReportTypeSelect(type.id)}
                        >
                          <div className="flex items-start space-x-4">
                            <div>{type.icon}</div>
                            <div className="flex-1">
                              <h4 className="font-semibold text-gray-900">{type.name}</h4>
                              <p className="text-sm text-gray-600 mt-1">{type.description}</p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : (
                  renderReportConfiguration()
                )}

                {/* Navigation Buttons */}
                <div className="flex justify-between pt-6 border-t">
                  <Button
                    variant="outline"
                    onClick={() => {
                      if (currentStep === 1) {
                        setIsNewReportModalOpen(false)
                      } else {
                        setCurrentStep(1)
                        setSelectedReportType("")
                      }
                    }}
                  >
                    {currentStep === 1 ? "Cancelar" : "Atrás"}
                  </Button>
                  {currentStep === 2 && (
                    <Button onClick={handleGenerateReport} className="bg-green-600 hover:bg-green-700">
                      <FileText className="h-4 w-4 mr-2" />
                      Generar Reporte
                    </Button>
                  )}
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Stats Dashboard */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500 flex items-center">
              <FileText className="h-4 w-4 mr-2" />
              Total Reportes
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{dashboardStats.totalReports}</div>
            <div className="text-xs text-green-600">+{dashboardStats.monthlyReports} este mes</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500 flex items-center">
              <Clock className="h-4 w-4 mr-2" />
              En Proceso
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{dashboardStats.pendingReports}</div>
            <div className="text-xs text-yellow-600">Generándose</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500 flex items-center">
              <AlertTriangle className="h-4 w-4 mr-2" />
              Fuera de Rango
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{dashboardStats.studentsOutOfAge}</div>
            <div className="text-xs text-red-600">Estudiantes MINERD</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500 flex items-center">
              <Download className="h-4 w-4 mr-2" />
              Descargas
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{dashboardStats.reportDownloads}</div>
            <div className="text-xs text-blue-600">Total este año</div>
          </CardContent>
        </Card>
      </div>

      {/* Alertas Importantes */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-orange-500" />
            Alertas Importantes
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {alerts.map((alert) => (
            <div
              key={alert.id}
              className={`flex items-start space-x-3 p-3 rounded-lg border ${
                alert.type === "warning"
                  ? "bg-yellow-50 border-yellow-200"
                  : alert.type === "info"
                    ? "bg-blue-50 border-blue-200"
                    : "bg-green-50 border-green-200"
              }`}
            >
              <div className="flex-shrink-0">
                {alert.type === "warning" ? (
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                ) : alert.type === "info" ? (
                  <Clock className="h-5 w-5 text-blue-600" />
                ) : (
                  <CheckCircle className="h-5 w-5 text-green-600" />
                )}
              </div>
              <div className="flex-1">
                <h4 className="font-medium">{alert.title}</h4>
                <p className="text-sm text-muted-foreground">{alert.description}</p>
              </div>
              <Button variant="outline" size="sm">
                {alert.action}
              </Button>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Generación Rápida de Reportes */}
      <Card>
        <CardHeader>
          <CardTitle>Generar Reporte Rápido</CardTitle>
          <CardDescription>Crear reportes comunes con configuración predefinida</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Button
              variant="outline"
              className="h-24 flex-col bg-transparent hover:bg-blue-50"
              onClick={() => handleQuickReport("bulletin")}
            >
              <ClipboardList className="h-8 w-8 mb-2 text-indigo-500" />
              <span className="text-center">📝 Boletín de Calificaciones</span>
            </Button>
            <Button
              variant="outline"
              className="h-24 flex-col bg-transparent hover:bg-teal-50"
              onClick={() => handleQuickReport("consolidated-act")}
            >
              <Archive className="h-8 w-8 mb-2 text-teal-500" />
              <span className="text-center">🗃 Acta Consolidada</span>
            </Button>
            <Button
              variant="outline"
              className="h-24 flex-col bg-transparent hover:bg-red-50"
              onClick={() => handleQuickReport("age-range")}
            >
              <AlertTriangle className="h-8 w-8 mb-2 text-red-500" />
              <span className="text-center">🔍 Fuera de Rango</span>
            </Button>
            <Button
              variant="outline"
              className="h-24 flex-col bg-transparent hover:bg-green-50"
              onClick={() => handleQuickReport("attendance")}
            >
              <UserCheck className="h-8 w-8 mb-2 text-green-500" />
              <span className="text-center">📆 Asistencia</span>
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Filtros de Reportes */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="h-5 w-5" />
            Filtros de Reportes
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            <Select>
              <SelectTrigger>
                <SelectValue placeholder="Tipo de Reporte" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos los tipos</SelectItem>
                <SelectItem value="bulletin">Boletín</SelectItem>
                <SelectItem value="act">Acta</SelectItem>
                <SelectItem value="attendance">Asistencia</SelectItem>
                <SelectItem value="academic">Académico</SelectItem>
                <SelectItem value="students">Estudiantes</SelectItem>
              </SelectContent>
            </Select>

            <Select>
              <SelectTrigger>
                <SelectValue placeholder="Estado" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos</SelectItem>
                <SelectItem value="completed">Completado</SelectItem>
                <SelectItem value="processing">En Proceso</SelectItem>
                <SelectItem value="scheduled">Programado</SelectItem>
              </SelectContent>
            </Select>

            <Select>
              <SelectTrigger>
                <SelectValue placeholder="Curso" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos</SelectItem>
                <SelectItem value="1">1° Primaria</SelectItem>
                <SelectItem value="2">2° Primaria</SelectItem>
                <SelectItem value="3">3° Primaria</SelectItem>
                <SelectItem value="4">4° Primaria</SelectItem>
                <SelectItem value="5">5° Primaria</SelectItem>
                <SelectItem value="6">6° Primaria</SelectItem>
              </SelectContent>
            </Select>

            <Select>
              <SelectTrigger>
                <SelectValue placeholder="Período" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos</SelectItem>
                <SelectItem value="2024">2024</SelectItem>
                <SelectItem value="2023">2023</SelectItem>
                <SelectItem value="current">Período Actual</SelectItem>
              </SelectContent>
            </Select>

            <Button variant="outline">
              <Filter className="h-4 w-4 mr-2" />
              Aplicar
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Lista de Reportes Recientes */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span className="flex items-center gap-2">
              <History className="h-5 w-5" />🗃 Historial de Reportes
            </span>
            <Button variant="outline" size="sm">
              <Eye className="h-4 w-4 mr-2" />
              Ver Todos
            </Button>
          </CardTitle>
          <CardDescription>Reportes generados recientemente</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {recentReports.map((report) => (
              <div key={report.id} className="border rounded-lg p-4 hover:bg-gray-50">
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-4">
                    <div className="mt-1">{getTypeIcon(report.type)}</div>
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-2">
                        <h3 className="font-semibold text-gray-900">{report.name}</h3>
                        <Badge variant="outline">{report.type}</Badge>
                        <Badge className={getStatusBadge(report.status)}>{report.status}</Badge>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-5 gap-4 text-sm text-gray-600">
                        <div className="flex items-center space-x-2">
                          <GraduationCap className="h-4 w-4" />
                          <span>{report.course}</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Calendar className="h-4 w-4" />
                          <span>{report.period}</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <FileText className="h-4 w-4" />
                          <span>
                            {report.format} - {report.size}
                          </span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Download className="h-4 w-4" />
                          <span>{report.downloads} descargas</span>
                        </div>
                        <div>
                          <span>Generado: {report.generatedDate}</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="flex space-x-2 ml-4">
                    {report.status === "Completado" && (
                      <>
                        <Button variant="outline" size="sm" onClick={() => handleReportAction(report.id, "view")}>
                          <Eye className="h-4 w-4 mr-2" />
                          Ver
                        </Button>
                        <Button variant="outline" size="sm">
                          <Download className="h-4 w-4 mr-2" />
                          Descargar
                        </Button>
                        <Button variant="outline" size="sm">
                          <Printer className="h-4 w-4 mr-2" />
                          Imprimir
                        </Button>
                        <Button variant="outline" size="sm">
                          <Share2 className="h-4 w-4 mr-2" />
                          Compartir
                        </Button>
                        {report.canRegenerate && (
                          <Button variant="outline" size="sm" className="text-blue-600 bg-transparent">
                            <FileText className="h-4 w-4 mr-2" />
                            Regenerar
                          </Button>
                        )}
                      </>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Modal de Configuración */}
      <Dialog open={isConfigModalOpen} onOpenChange={setIsConfigModalOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Configuración de Reportes</DialogTitle>
            <DialogDescription>Configurar opciones generales para la generación de reportes</DialogDescription>
          </DialogHeader>

          <div className="space-y-6">
            <div className="space-y-4">
              <h4 className="font-semibold text-gray-900">Encabezado Institucional</h4>
              <div className="text-sm text-blue-600 bg-blue-50 p-3 rounded-lg mb-4">
                <p className="font-medium">ℹ️ Información del Centro</p>
                <p>
                  Estos datos fueron configurados por el administrador del sistema y solo pueden ser modificados por él.
                </p>
              </div>
              <div className="space-y-3">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Dirección Regional</Label>
                    <Input value="10 DE SANTO DOMINGO II" disabled className="bg-gray-50" />
                  </div>
                  <div className="space-y-2">
                    <Label>Distrito</Label>
                    <Input value="1006 DE MENDOZA" disabled className="bg-gray-50" />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Nombre del Centro</Label>
                  <Input value="Politécnico Kelbyn Obreros de Paz" disabled className="bg-gray-50" />
                </div>

                <div className="space-y-2">
                  <Label>Dirección</Label>
                  <Input
                    value="C/ 27 de febrero # 31, Francisco del Rosario Sánchez, Los Frailes II, Santo Domingo Este, R.D."
                    disabled
                    className="bg-gray-50"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Correo Electrónico</Label>
                    <Input value="Liceokelbynobrerosdepazje@gmail.com" disabled className="bg-gray-50" />
                  </div>
                  <div className="space-y-2">
                    <Label>Teléfono</Label>
                    <Input value="809-234-9187" disabled className="bg-gray-50" />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Código de Gestión SIGERD</Label>
                    <Input value="05657" disabled className="bg-gray-50" />
                  </div>
                  <div className="space-y-2">
                    <Label>Código de Cartografía</Label>
                    <Input value="01148835" disabled className="bg-gray-50" />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label>Sector</Label>
                    <Input value="Público" disabled className="bg-gray-50" />
                  </div>
                  <div className="space-y-2">
                    <Label>Zona</Label>
                    <Input value="Urbana" disabled className="bg-gray-50" />
                  </div>
                  <div className="space-y-2">
                    <Label>Jornada</Label>
                    <Input value="Extendida" disabled className="bg-gray-50" />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="schoolYear">Año Escolar</Label>
                  <Input id="schoolYear" defaultValue="2024-2025" className="border-blue-300 focus:border-blue-500" />
                  <p className="text-xs text-gray-500">Este es el único campo que puedes modificar</p>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="font-semibold text-gray-900">Firmas Digitales</h4>
              <div className="space-y-3">
                <div className="flex items-center space-x-2">
                  <Checkbox id="directorSignature" defaultChecked />
                  <Label htmlFor="directorSignature">Incluir firma del Director</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox id="coordinatorSignature" defaultChecked />
                  <Label htmlFor="coordinatorSignature">Incluir firma del Coordinador</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox id="teacherSignature" />
                  <Label htmlFor="teacherSignature">Incluir firma del Docente (cuando aplique)</Label>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="font-semibold text-gray-900">Configuraciones de Seguridad</h4>
              <div className="space-y-3">
                <div className="flex items-center space-x-2">
                  <Checkbox id="onlyClosedPeriods" defaultChecked />
                  <Label htmlFor="onlyClosedPeriods">Solo mostrar reportes de períodos cerrados</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox id="watermark" defaultChecked />
                  <Label htmlFor="watermark">Incluir marca de agua en documentos</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox id="auditLog" defaultChecked />
                  <Label htmlFor="auditLog">Registrar log de generación de reportes</Label>
                </div>
              </div>
            </div>
          </div>

          <div className="flex justify-between pt-6 border-t">
            <Button variant="outline" onClick={() => setIsConfigModalOpen(false)}>
              Cancelar
            </Button>
            <Button className="bg-green-600 hover:bg-green-700">
              <Settings className="h-4 w-4 mr-2" />
              Guardar Configuración
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Modal de Acciones de Reporte */}
      <Dialog open={isActionModalOpen} onOpenChange={setIsActionModalOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>
              {actionType === "view" && "Vista Previa del Reporte"}
              {actionType === "print" && "Configurar Impresión"}
              {actionType === "email" && "Enviar por Correo"}
              {actionType === "whatsapp" && "Compartir por WhatsApp"}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            {actionType === "view" && (
              <div className="bg-gray-50 p-4 rounded-lg">
                <p className="text-center text-gray-600">Vista previa del reporte seleccionado</p>
                <div className="mt-4 bg-white p-6 rounded border min-h-[300px]">
                  <div className="text-center mb-4">
                    <h3 className="text-lg font-bold">Centro Educativo San José</h3>
                    <p className="text-sm text-gray-600">Año Escolar 2024-2025</p>
                  </div>
                  <div className="space-y-2">
                    <p>
                      <strong>Reporte:</strong> {recentReports.find((r) => r.id === selectedReportForAction)?.name}
                    </p>
                    <p>
                      <strong>Tipo:</strong> {recentReports.find((r) => r.id === selectedReportForAction)?.type}
                    </p>
                    <p>
                      <strong>Curso:</strong> {recentReports.find((r) => r.id === selectedReportForAction)?.course}
                    </p>
                    <p>
                      <strong>Período:</strong> {recentReports.find((r) => r.id === selectedReportForAction)?.period}
                    </p>
                  </div>
                </div>
              </div>
            )}

            {actionType === "print" && (
              <div className="space-y-4">
                <h4 className="font-semibold">Opciones de Impresión</h4>
                <div className="space-y-3">
                  <div className="flex items-center space-x-2">
                    <Checkbox id="printHeader" defaultChecked />
                    <Label htmlFor="printHeader">Incluir encabezado institucional</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="printSignatures" defaultChecked />
                    <Label htmlFor="printSignatures">Incluir firmas</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="printColor" />
                    <Label htmlFor="printColor">Impresión a color</Label>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Número de copias</Label>
                  <Select defaultValue="1">
                    <SelectTrigger className="w-32">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1">1 copia</SelectItem>
                      <SelectItem value="2">2 copias</SelectItem>
                      <SelectItem value="3">3 copias</SelectItem>
                      <SelectItem value="5">5 copias</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            )}
          </div>

          <div className="flex justify-between pt-4 border-t">
            <Button variant="outline" onClick={() => setIsActionModalOpen(false)}>
              Cancelar
            </Button>
            <Button className="bg-blue-600 hover:bg-blue-700">
              {actionType === "view" && "Cerrar Vista Previa"}
              {actionType === "print" && "Imprimir"}
              {actionType === "email" && "Enviar Email"}
              {actionType === "whatsapp" && "Compartir"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
