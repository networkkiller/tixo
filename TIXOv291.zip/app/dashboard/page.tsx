"use client"

import { useAuth } from "@/contexts/auth-context"
import { useRouter } from "next/navigation"
import { useEffect } from "react"

export default function DashboardPage() {
  const { user, isLoading } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (!isLoading && user) {
      // Redirect based on user role
      const roleRedirects = {
        "super-admin": "/dashboard/super-admin",
        director: "/dashboard/director",
        profesor: "/dashboard/profesor",
        padre: "/dashboard/padre",
        contable: "/dashboard/contable",
        coordinador: "/dashboard/coordinador",
        "coordinador-academico": "/dashboard/coordinador-academico",
        secretario: "/dashboard/secretario",
      }

      const redirectPath = roleRedirects[user.role as keyof typeof roleRedirects]
      if (redirectPath) {
        console.log("🔄 Redirecting to:", redirectPath)
        router.push(redirectPath)
      }
    }
  }, [user, isLoading, router])

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex items-center justify-center">
        <div className="w-16 h-16 border-4 border-purple-500 border-t-transparent rounded-full animate-spin"></div>
      </div>
    )
  }

  if (!user) {
    return null
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex items-center justify-center">
      <div className="w-16 h-16 border-4 border-purple-500 border-t-transparent rounded-full animate-spin"></div>
    </div>
  )
}
