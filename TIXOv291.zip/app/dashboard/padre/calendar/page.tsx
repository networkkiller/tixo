"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import {
  Calendar,
  Clock,
  MapPin,
  Users,
  BookOpen,
  GraduationCap,
  AlertCircle,
  CheckCircle,
  Bell,
  Filter,
  ChevronLeft,
  ChevronRight,
  Download,
  Eye,
  CalendarDays,
} from "lucide-react"

const CalendarPage = () => {
  const [selectedChild, setSelectedChild] = useState(0)
  const [currentMonth, setCurrentMonth] = useState(new Date(2024, 0)) // Enero 2024
  const [selectedView, setSelectedView] = useState("month") // month, list, upcoming

  // Datos simulados de los hijos
  const children = [
    {
      id: 1,
      name: "Mariana Alcántara",
      course: "5to B",
      shift: "Mañana",
      photo: "/placeholder.svg?height=60&width=60&text=MA",
    },
    {
      id: 2,
      name: "Daniel Alcántara",
      course: "3ro A",
      shift: "Tarde",
      photo: "/placeholder.svg?height=60&width=60&text=DA",
    },
  ]

  // Eventos del calendario escolar definidos por el coordinador de registro
  const schoolEvents = [
    {
      id: 1,
      title: "Inicio del Período P1",
      date: "2024-01-15",
      time: "8:00 a.m.",
      type: "academic",
      description: "Inicio oficial del primer período académico del año escolar 2024",
      location: "Todas las aulas",
      affectedCourses: ["Todos los cursos"],
      priority: "high",
      status: "confirmed",
    },
    {
      id: 2,
      title: "Reunión de Padres - 5to Grado",
      date: "2024-01-18",
      time: "2:00 p.m.",
      type: "meeting",
      description: "Reunión informativa sobre el progreso académico del primer trimestre",
      location: "Aula Magna",
      affectedCourses: ["5to A", "5to B", "5to C"],
      priority: "medium",
      status: "confirmed",
    },
    {
      id: 3,
      title: "Evaluaciones Nacionales - Matemáticas",
      date: "2024-01-22",
      time: "9:00 a.m.",
      type: "exam",
      description: "Pruebas nacionales de matemáticas para estudiantes de 3ro y 6to",
      location: "Aulas asignadas",
      affectedCourses: ["3ro A", "3ro B", "6to A", "6to B"],
      priority: "high",
      status: "confirmed",
    },
    {
      id: 4,
      title: "Día de la Paz Escolar",
      date: "2024-01-30",
      time: "Todo el día",
      type: "celebration",
      description: "Actividades especiales para promover la paz y convivencia escolar",
      location: "Patio central y aulas",
      affectedCourses: ["Todos los cursos"],
      priority: "medium",
      status: "confirmed",
    },
    {
      id: 5,
      title: "Cierre del Período P1",
      date: "2024-02-15",
      time: "5:00 p.m.",
      type: "academic",
      description: "Fecha límite para el registro de calificaciones del período P1",
      location: "Sistema académico",
      affectedCourses: ["Todos los cursos"],
      priority: "high",
      status: "pending",
    },
    {
      id: 6,
      title: "Entrega de Boletines P1",
      date: "2024-02-20",
      time: "8:00 a.m. - 4:00 p.m.",
      type: "administrative",
      description: "Entrega de boletines del primer período a padres y tutores",
      location: "Secretaría Académica",
      affectedCourses: ["Todos los cursos"],
      priority: "medium",
      status: "pending",
    },
    {
      id: 7,
      title: "Inicio Recuperaciones RP1",
      date: "2024-02-22",
      time: "8:00 a.m.",
      type: "academic",
      description: "Inicio del período de recuperaciones del primer período",
      location: "Aulas asignadas",
      affectedCourses: ["Según necesidad"],
      priority: "medium",
      status: "pending",
    },
  ]

  const currentChild = children[selectedChild]

  // Filtrar eventos relevantes para el hijo seleccionado
  const getRelevantEvents = () => {
    return schoolEvents.filter(
      (event) =>
        event.affectedCourses.includes("Todos los cursos") ||
        event.affectedCourses.includes(currentChild.course) ||
        (currentChild.course.includes("5to") && event.affectedCourses.some((course) => course.includes("5to"))) ||
        (currentChild.course.includes("3ro") && event.affectedCourses.some((course) => course.includes("3ro"))),
    )
  }

  const getEventTypeIcon = (type: string) => {
    switch (type) {
      case "academic":
        return <BookOpen className="h-4 w-4" />
      case "meeting":
        return <Users className="h-4 w-4" />
      case "exam":
        return <GraduationCap className="h-4 w-4" />
      case "celebration":
        return <Bell className="h-4 w-4" />
      case "administrative":
        return <CalendarDays className="h-4 w-4" />
      default:
        return <Calendar className="h-4 w-4" />
    }
  }

  const getEventTypeColor = (type: string) => {
    switch (type) {
      case "academic":
        return "bg-blue-100 text-blue-800 border-blue-200"
      case "meeting":
        return "bg-purple-100 text-purple-800 border-purple-200"
      case "exam":
        return "bg-red-100 text-red-800 border-red-200"
      case "celebration":
        return "bg-green-100 text-green-800 border-green-200"
      case "administrative":
        return "bg-orange-100 text-orange-800 border-orange-200"
      default:
        return "bg-gray-100 text-gray-800 border-gray-200"
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "bg-red-500"
      case "medium":
        return "bg-yellow-500"
      case "low":
        return "bg-green-500"
      default:
        return "bg-gray-500"
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "confirmed":
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case "pending":
        return <AlertCircle className="h-4 w-4 text-yellow-500" />
      default:
        return <Clock className="h-4 w-4 text-gray-500" />
    }
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("es-ES", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  const getEventsForDate = (date: Date) => {
    const dateString = date.toISOString().split("T")[0]
    return getRelevantEvents().filter((event) => event.date === dateString)
  }

  const generateCalendarDays = () => {
    const year = currentMonth.getFullYear()
    const month = currentMonth.getMonth()
    const firstDay = new Date(year, month, 1)
    const lastDay = new Date(year, month + 1, 0)
    const startDate = new Date(firstDay)
    startDate.setDate(startDate.getDate() - firstDay.getDay())

    const days = []
    const currentDate = new Date(startDate)

    for (let i = 0; i < 42; i++) {
      const isCurrentMonth = currentDate.getMonth() === month
      const events = getEventsForDate(currentDate)
      const hasEvents = events.length > 0

      days.push({
        date: new Date(currentDate),
        isCurrentMonth,
        events,
        hasEvents,
      })

      currentDate.setDate(currentDate.getDate() + 1)
    }

    return days
  }

  const navigateMonth = (direction: "prev" | "next") => {
    const newMonth = new Date(currentMonth)
    if (direction === "prev") {
      newMonth.setMonth(newMonth.getMonth() - 1)
    } else {
      newMonth.setMonth(newMonth.getMonth() + 1)
    }
    setCurrentMonth(newMonth)
  }

  const upcomingEvents = getRelevantEvents()
    .filter((event) => new Date(event.date) >= new Date())
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
    .slice(0, 5)

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 p-4 md:p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="bg-white rounded-xl shadow-sm border p-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h1 className="text-2xl font-bold text-gray-900 mb-2">Calendario Escolar</h1>
              <p className="text-gray-600">Eventos y fechas importantes del año académico</p>
            </div>

            {/* Selector de hijos */}
            <div className="flex gap-3">
              {children.map((child, index) => (
                <button
                  key={child.id}
                  onClick={() => setSelectedChild(index)}
                  className={`flex items-center gap-3 p-3 rounded-lg border-2 transition-all ${
                    selectedChild === index ? "border-blue-500 bg-blue-50" : "border-gray-200 hover:border-gray-300"
                  }`}
                >
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={child.photo || "/placeholder.svg"} alt={child.name} />
                    <AvatarFallback>
                      {child.name
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </AvatarFallback>
                  </Avatar>
                  <div className="text-left">
                    <p className="font-medium text-sm">{child.name}</p>
                    <p className="text-xs text-gray-500">
                      {child.course} - {child.shift}
                    </p>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Estadísticas rápidas */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-500">Eventos Este Mes</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {
                  getRelevantEvents().filter(
                    (event) =>
                      new Date(event.date).getMonth() === currentMonth.getMonth() &&
                      new Date(event.date).getFullYear() === currentMonth.getFullYear(),
                  ).length
                }
              </div>
              <div className="text-xs text-blue-600">Relevantes para {currentChild.course}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-500">Próximos Eventos</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{upcomingEvents.length}</div>
              <div className="text-xs text-green-600">En los próximos 30 días</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-500">Reuniones de Padres</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {getRelevantEvents().filter((event) => event.type === "meeting").length}
              </div>
              <div className="text-xs text-purple-600">Programadas</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-500">Evaluaciones</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {getRelevantEvents().filter((event) => event.type === "exam").length}
              </div>
              <div className="text-xs text-red-600">Programadas</div>
            </CardContent>
          </Card>
        </div>

        {/* Tabs de visualización */}
        <Tabs value={selectedView} onValueChange={setSelectedView} className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="month">Vista Mensual</TabsTrigger>
            <TabsTrigger value="list">Lista de Eventos</TabsTrigger>
            <TabsTrigger value="upcoming">Próximos Eventos</TabsTrigger>
          </TabsList>

          {/* Vista Mensual */}
          <TabsContent value="month" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <Calendar className="h-5 w-5 text-blue-500" />
                    {currentMonth.toLocaleDateString("es-ES", { month: "long", year: "numeric" })}
                  </CardTitle>
                  <div className="flex items-center gap-2">
                    <Button variant="outline" size="sm" onClick={() => navigateMonth("prev")}>
                      <ChevronLeft className="h-4 w-4" />
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => navigateMonth("next")}>
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {/* Encabezados de días */}
                <div className="grid grid-cols-7 gap-1 mb-4">
                  {["Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"].map((day) => (
                    <div key={day} className="text-center font-medium text-gray-600 p-2 bg-gray-50 rounded">
                      {day}
                    </div>
                  ))}
                </div>

                {/* Días del calendario */}
                <div className="grid grid-cols-7 gap-1">
                  {generateCalendarDays().map((day, index) => (
                    <div
                      key={index}
                      className={`min-h-[100px] p-2 border border-gray-200 rounded relative ${
                        day.isCurrentMonth ? "bg-white hover:bg-gray-50" : "bg-gray-50"
                      } ${day.hasEvents ? "bg-blue-50 border-blue-200" : ""}`}
                    >
                      <div className="text-sm font-medium text-gray-900 mb-1">{day.date.getDate()}</div>
                      {day.events.map((event, eventIndex) => (
                        <Dialog key={eventIndex}>
                          <DialogTrigger asChild>
                            <div
                              className={`text-xs p-1 mb-1 rounded cursor-pointer hover:opacity-80 ${getEventTypeColor(
                                event.type,
                              )}`}
                            >
                              <div className="flex items-center gap-1">
                                {getEventTypeIcon(event.type)}
                                <span className="truncate">{event.title}</span>
                              </div>
                            </div>
                          </DialogTrigger>
                          <DialogContent className="max-w-md">
                            <DialogHeader>
                              <DialogTitle className="flex items-center gap-2">
                                {getEventTypeIcon(event.type)}
                                {event.title}
                              </DialogTitle>
                            </DialogHeader>
                            <div className="space-y-4">
                              <div className="flex items-center gap-2">
                                <Badge className={getEventTypeColor(event.type)}>{event.type}</Badge>
                                <div className={`w-3 h-3 rounded-full ${getPriorityColor(event.priority)}`} />
                                {getStatusIcon(event.status)}
                              </div>

                              <div className="space-y-2">
                                <div className="flex items-center gap-2 text-sm">
                                  <Calendar className="h-4 w-4 text-gray-500" />
                                  <span>{formatDate(event.date)}</span>
                                </div>
                                <div className="flex items-center gap-2 text-sm">
                                  <Clock className="h-4 w-4 text-gray-500" />
                                  <span>{event.time}</span>
                                </div>
                                <div className="flex items-center gap-2 text-sm">
                                  <MapPin className="h-4 w-4 text-gray-500" />
                                  <span>{event.location}</span>
                                </div>
                              </div>

                              <div>
                                <h4 className="font-medium text-gray-900 mb-2">Descripción:</h4>
                                <p className="text-sm text-gray-600">{event.description}</p>
                              </div>

                              <div>
                                <h4 className="font-medium text-gray-900 mb-2">Cursos afectados:</h4>
                                <div className="flex flex-wrap gap-1">
                                  {event.affectedCourses.map((course, index) => (
                                    <Badge key={index} variant="outline" className="text-xs">
                                      {course}
                                    </Badge>
                                  ))}
                                </div>
                              </div>
                            </div>
                          </DialogContent>
                        </Dialog>
                      ))}
                    </div>
                  ))}
                </div>

                {/* Leyenda */}
                <div className="flex flex-wrap gap-4 text-sm mt-6 pt-4 border-t">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-blue-100 rounded"></div>
                    <span>Académico</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-purple-100 rounded"></div>
                    <span>Reuniones</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-red-100 rounded"></div>
                    <span>Evaluaciones</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-green-100 rounded"></div>
                    <span>Celebraciones</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-orange-100 rounded"></div>
                    <span>Administrativo</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Lista de Eventos */}
          <TabsContent value="list" className="space-y-4">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Todos los Eventos Relevantes</CardTitle>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm">
                      <Filter className="h-4 w-4 mr-2" />
                      Filtrar
                    </Button>
                    <Button variant="outline" size="sm">
                      <Download className="h-4 w-4 mr-2" />
                      Exportar
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {getRelevantEvents().map((event) => (
                    <div key={event.id} className="border rounded-lg p-4 hover:bg-gray-50">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <div className="flex items-center gap-2">
                              {getEventTypeIcon(event.type)}
                              <h3 className="font-semibold text-gray-900">{event.title}</h3>
                            </div>
                            <Badge className={getEventTypeColor(event.type)}>{event.type}</Badge>
                            <div className={`w-3 h-3 rounded-full ${getPriorityColor(event.priority)}`} />
                            {getStatusIcon(event.status)}
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-gray-600 mb-3">
                            <div className="flex items-center gap-2">
                              <Calendar className="h-4 w-4" />
                              <span>{formatDate(event.date)}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Clock className="h-4 w-4" />
                              <span>{event.time}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <MapPin className="h-4 w-4" />
                              <span>{event.location}</span>
                            </div>
                          </div>

                          <p className="text-sm text-gray-600 mb-2">{event.description}</p>

                          <div className="flex flex-wrap gap-1">
                            {event.affectedCourses.map((course, index) => (
                              <Badge key={index} variant="outline" className="text-xs">
                                {course}
                              </Badge>
                            ))}
                          </div>
                        </div>

                        <Dialog>
                          <DialogTrigger asChild>
                            <Button variant="outline" size="sm">
                              <Eye className="h-4 w-4 mr-2" />
                              Ver Detalles
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="max-w-md">
                            <DialogHeader>
                              <DialogTitle className="flex items-center gap-2">
                                {getEventTypeIcon(event.type)}
                                {event.title}
                              </DialogTitle>
                            </DialogHeader>
                            <div className="space-y-4">
                              <div className="flex items-center gap-2">
                                <Badge className={getEventTypeColor(event.type)}>{event.type}</Badge>
                                <div className={`w-3 h-3 rounded-full ${getPriorityColor(event.priority)}`} />
                                {getStatusIcon(event.status)}
                              </div>

                              <div className="space-y-2">
                                <div className="flex items-center gap-2 text-sm">
                                  <Calendar className="h-4 w-4 text-gray-500" />
                                  <span>{formatDate(event.date)}</span>
                                </div>
                                <div className="flex items-center gap-2 text-sm">
                                  <Clock className="h-4 w-4 text-gray-500" />
                                  <span>{event.time}</span>
                                </div>
                                <div className="flex items-center gap-2 text-sm">
                                  <MapPin className="h-4 w-4 text-gray-500" />
                                  <span>{event.location}</span>
                                </div>
                              </div>

                              <div>
                                <h4 className="font-medium text-gray-900 mb-2">Descripción:</h4>
                                <p className="text-sm text-gray-600">{event.description}</p>
                              </div>

                              <div>
                                <h4 className="font-medium text-gray-900 mb-2">Cursos afectados:</h4>
                                <div className="flex flex-wrap gap-1">
                                  {event.affectedCourses.map((course, index) => (
                                    <Badge key={index} variant="outline" className="text-xs">
                                      {course}
                                    </Badge>
                                  ))}
                                </div>
                              </div>
                            </div>
                          </DialogContent>
                        </Dialog>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Próximos Eventos */}
          <TabsContent value="upcoming" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Bell className="h-5 w-5 text-orange-500" />
                  Próximos Eventos Importantes
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {upcomingEvents.map((event, index) => (
                    <div
                      key={event.id}
                      className={`border-l-4 p-4 rounded-r-lg ${
                        event.priority === "high"
                          ? "border-l-red-500 bg-red-50"
                          : event.priority === "medium"
                            ? "border-l-yellow-500 bg-yellow-50"
                            : "border-l-green-500 bg-green-50"
                      }`}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            {getEventTypeIcon(event.type)}
                            <h3 className="font-semibold text-gray-900">{event.title}</h3>
                            <Badge className={getEventTypeColor(event.type)}>{event.type}</Badge>
                          </div>

                          <div className="flex items-center gap-4 text-sm text-gray-600 mb-2">
                            <div className="flex items-center gap-1">
                              <Calendar className="h-4 w-4" />
                              <span>{formatDate(event.date)}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <Clock className="h-4 w-4" />
                              <span>{event.time}</span>
                            </div>
                          </div>

                          <p className="text-sm text-gray-600">{event.description}</p>
                        </div>

                        <div className="text-right">
                          <div className="text-sm font-medium text-gray-900">
                            {Math.ceil((new Date(event.date).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))}{" "}
                            días
                          </div>
                          <div className="text-xs text-gray-500">restantes</div>
                        </div>
                      </div>
                    </div>
                  ))}

                  {upcomingEvents.length === 0 && (
                    <div className="text-center py-8">
                      <CheckCircle className="h-12 w-12 text-green-500 mx-auto mb-4" />
                      <h3 className="text-lg font-medium text-gray-900 mb-2">No hay eventos próximos</h3>
                      <p className="text-gray-500">Todos los eventos están al día.</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

export default CalendarPage
