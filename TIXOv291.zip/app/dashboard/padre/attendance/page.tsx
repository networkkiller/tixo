"use client"

import type React from "react"

import { Header } from "@/components/dashboard/header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Calendar } from "@/components/ui/calendar"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { CalendarDays, CheckCircle, XCircle, AlertCircle, TrendingUp, Filter, PlusCircle } from "lucide-react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

export default function PadreAttendance() {
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date())
  const [selectedMonth, setSelectedMonth] = useState("junio")
  const [selectedSubject, setSelectedSubject] = useState("todas")
  const [selectedChild, setSelectedChild] = useState("todos")
  const [showExcuseForm, setShowExcuseForm] = useState(false)

  // Datos de ejemplo para los hijos
  const children = [
    { id: "1", name: "Ana García" },
    { id: "2", name: "Carlos García" },
  ]

  const attendanceData = [
    { date: "2024-06-01", status: "present", subject: "Matemáticas", comment: "", childId: "1" },
    { date: "2024-06-02", status: "present", subject: "Lenguaje", comment: "", childId: "1" },
    { date: "2024-06-03", status: "absent", subject: "Ciencias", comment: "Cita médica", childId: "1" },
    { date: "2024-06-04", status: "justified", subject: "Sociales", comment: "Justificado por padre", childId: "1" },
    { date: "2024-06-05", status: "present", subject: "Inglés", comment: "", childId: "1" },
    { date: "2024-06-06", status: "present", subject: "Ed. Física", comment: "", childId: "1" },
    { date: "2024-06-07", status: "present", subject: "Matemáticas", comment: "", childId: "1" },
    { date: "2024-06-08", status: "absent", subject: "Lenguaje", comment: "Enfermedad", childId: "1" },
    { date: "2024-06-09", status: "present", subject: "Ciencias", comment: "", childId: "1" },
    { date: "2024-06-10", status: "present", subject: "Sociales", comment: "", childId: "1" },
    // Datos para el segundo hijo
    { date: "2024-06-01", status: "present", subject: "Matemáticas", comment: "", childId: "2" },
    { date: "2024-06-02", status: "present", subject: "Lenguaje", comment: "", childId: "2" },
    { date: "2024-06-03", status: "present", subject: "Ciencias", comment: "", childId: "2" },
    { date: "2024-06-04", status: "absent", subject: "Sociales", comment: "Cita dental", childId: "2" },
    { date: "2024-06-05", status: "justified", subject: "Inglés", comment: "Evento familiar", childId: "2" },
  ]

  const monthlyStats = {
    totalDays: 20,
    presentDays: 16,
    absentDays: 2,
    justifiedDays: 2,
    attendancePercentage: 90,
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "present":
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case "absent":
        return <XCircle className="h-4 w-4 text-red-500" />
      case "justified":
        return <AlertCircle className="h-4 w-4 text-yellow-500" />
      default:
        return null
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "present":
        return <Badge className="bg-green-100 text-green-800 border-green-200">🟢 Presente</Badge>
      case "absent":
        return <Badge className="bg-red-100 text-red-800 border-red-200">🔴 Ausente</Badge>
      case "justified":
        return <Badge className="bg-yellow-100 text-yellow-800 border-yellow-200">🟡 Justificado</Badge>
      default:
        return null
    }
  }

  const filteredData = attendanceData.filter((record) => {
    const matchesSubject = selectedSubject === "todas" || record.subject === selectedSubject
    const matchesChild = selectedChild === "todos" || record.childId === selectedChild
    return matchesSubject && matchesChild
  })

  const handleSubmitExcuse = (e: React.FormEvent) => {
    e.preventDefault()
    // Aquí iría la lógica para enviar la excusa
    alert("Excusa enviada correctamente")
    setShowExcuseForm(false)
  }

  return (
    <div className="flex-1 flex flex-col bg-gray-50">
      <Header title="TIXO - Asistencia" />

      <main className="flex-1 overflow-y-auto p-6 space-y-6">
        {/* Resumen Mensual */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="bg-white border border-gray-200 shadow-sm">
            <CardContent className="p-4 text-center">
              <TrendingUp className="h-8 w-8 text-blue-500 mx-auto mb-2" />
              <div className="text-2xl font-bold text-gray-800">{monthlyStats.attendancePercentage}%</div>
              <div className="text-sm text-gray-600">Asistencia del Mes</div>
            </CardContent>
          </Card>

          <Card className="bg-white border border-gray-200 shadow-sm">
            <CardContent className="p-4 text-center">
              <CheckCircle className="h-8 w-8 text-green-500 mx-auto mb-2" />
              <div className="text-2xl font-bold text-gray-800">{monthlyStats.presentDays}</div>
              <div className="text-sm text-gray-600">Días Presente</div>
            </CardContent>
          </Card>

          <Card className="bg-white border border-gray-200 shadow-sm">
            <CardContent className="p-4 text-center">
              <XCircle className="h-8 w-8 text-red-500 mx-auto mb-2" />
              <div className="text-2xl font-bold text-gray-800">{monthlyStats.absentDays}</div>
              <div className="text-sm text-gray-600">Ausencias</div>
            </CardContent>
          </Card>

          <Card className="bg-white border border-gray-200 shadow-sm">
            <CardContent className="p-4 text-center">
              <AlertCircle className="h-8 w-8 text-yellow-500 mx-auto mb-2" />
              <div className="text-2xl font-bold text-gray-800">{monthlyStats.justifiedDays}</div>
              <div className="text-sm text-gray-600">Justificados</div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Calendario */}
          <Card className="bg-white border border-gray-200 shadow-sm">
            <CardHeader>
              <CardTitle className="text-gray-800 flex items-center gap-2">
                <CalendarDays className="h-5 w-5 text-indigo-600" />
                Calendario de Asistencia
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Calendar
                mode="single"
                selected={selectedDate}
                onSelect={setSelectedDate}
                className="rounded-md border-gray-200"
              />
            </CardContent>
          </Card>

          {/* Filtros y Controles */}
          <Card className="bg-white border border-gray-200 shadow-sm">
            <CardHeader>
              <CardTitle className="text-gray-800 flex items-center gap-2">
                <Filter className="h-5 w-5 text-indigo-600" />
                Filtros
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Filtro por hijo */}
              <div>
                <label className="text-sm text-gray-600 mb-2 block">Hijo/a</label>
                <Select value={selectedChild} onValueChange={setSelectedChild}>
                  <SelectTrigger className="bg-white border-gray-300 text-gray-800">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-white border-gray-200">
                    <SelectItem value="todos">Todos los hijos</SelectItem>
                    {children.map((child) => (
                      <SelectItem key={child.id} value={child.id}>
                        {child.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm text-gray-600 mb-2 block">Mes</label>
                <Select value={selectedMonth} onValueChange={setSelectedMonth}>
                  <SelectTrigger className="bg-white border-gray-300 text-gray-800">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-white border-gray-200">
                    <SelectItem value="enero">Enero</SelectItem>
                    <SelectItem value="febrero">Febrero</SelectItem>
                    <SelectItem value="marzo">Marzo</SelectItem>
                    <SelectItem value="abril">Abril</SelectItem>
                    <SelectItem value="mayo">Mayo</SelectItem>
                    <SelectItem value="junio">Junio</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm text-gray-600 mb-2 block">Materia</label>
                <Select value={selectedSubject} onValueChange={setSelectedSubject}>
                  <SelectTrigger className="bg-white border-gray-300 text-gray-800">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-white border-gray-200">
                    <SelectItem value="todas">Todas las materias</SelectItem>
                    <SelectItem value="Matemáticas">Matemáticas</SelectItem>
                    <SelectItem value="Lenguaje">Lenguaje</SelectItem>
                    <SelectItem value="Ciencias">Ciencias</SelectItem>
                    <SelectItem value="Sociales">Sociales</SelectItem>
                    <SelectItem value="Inglés">Inglés</SelectItem>
                    <SelectItem value="Ed. Física">Ed. Física</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="pt-4 space-y-2">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                  <span className="text-sm text-gray-600">Presente</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                  <span className="text-sm text-gray-600">Ausente</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                  <span className="text-sm text-gray-600">Justificado</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Formulario para Excusas */}
        <Card className="bg-white border border-gray-200 shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-gray-800">Justificar Ausencia</CardTitle>
            <Dialog>
              <DialogTrigger asChild>
                <Button className="bg-indigo-600 hover:bg-indigo-700">
                  <PlusCircle className="h-4 w-4 mr-2" />
                  Nueva Excusa
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-white border border-gray-200 text-gray-800">
                <DialogHeader>
                  <DialogTitle>Registrar Excusa o Ausencia</DialogTitle>
                  <DialogDescription className="text-gray-600">
                    Complete el formulario para justificar una ausencia o programar una futura.
                  </DialogDescription>
                </DialogHeader>
                <form onSubmit={handleSubmitExcuse} className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-sm text-gray-600">Hijo/a</label>
                    <Select defaultValue={children[0].id}>
                      <SelectTrigger className="bg-white border-gray-300 text-gray-800">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-white border-gray-200">
                        {children.map((child) => (
                          <SelectItem key={child.id} value={child.id}>
                            {child.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm text-gray-600">Tipo de Excusa</label>
                    <Select defaultValue="futura">
                      <SelectTrigger className="bg-white border-gray-300 text-gray-800">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-white border-gray-200">
                        <SelectItem value="futura">Ausencia Programada</SelectItem>
                        <SelectItem value="pasada">Justificar Ausencia Pasada</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-sm text-gray-600">Fecha de Inicio</label>
                      <Input type="date" className="bg-white border-gray-300 text-gray-800" />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm text-gray-600">Fecha de Fin</label>
                      <Input type="date" className="bg-white border-gray-300 text-gray-800" />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm text-gray-600">Motivo</label>
                    <Select defaultValue="medico">
                      <SelectTrigger className="bg-white border-gray-300 text-gray-800">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-white border-gray-200">
                        <SelectItem value="medico">Cita Médica</SelectItem>
                        <SelectItem value="enfermedad">Enfermedad</SelectItem>
                        <SelectItem value="familiar">Evento Familiar</SelectItem>
                        <SelectItem value="otro">Otro</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm text-gray-600">Descripción</label>
                    <Textarea
                      placeholder="Describa el motivo de la ausencia..."
                      className="bg-white border-gray-300 text-gray-800"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm text-gray-600">Adjuntar Documento (opcional)</label>
                    <Input type="file" className="bg-white border-gray-300 text-gray-800" />
                  </div>

                  <DialogFooter>
                    <Button type="submit" className="bg-indigo-600 hover:bg-indigo-700">
                      Enviar Excusa
                    </Button>
                  </DialogFooter>
                </form>
              </DialogContent>
            </Dialog>
          </CardHeader>
          <CardContent>
            <p className="text-gray-600 mb-4">
              Utilice este formulario para justificar ausencias pasadas o programar ausencias futuras de sus hijos. Las
              justificaciones serán revisadas por el personal docente.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
                <h3 className="text-gray-800 font-medium mb-2">Ausencias Programadas</h3>
                <p className="text-gray-600 text-sm">
                  Notifique con anticipación cuando su hijo/a no podrá asistir a clases por motivos conocidos.
                </p>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
                <h3 className="text-gray-800 font-medium mb-2">Justificación de Ausencias</h3>
                <p className="text-gray-600 text-sm">
                  Justifique ausencias pasadas proporcionando la documentación necesaria.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Tabla de Registros */}
        <Card className="bg-white border border-gray-200 shadow-sm">
          <CardHeader>
            <CardTitle className="text-gray-800">Historial de Asistencia</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-gray-200">
                    <TableHead className="text-gray-600">Fecha</TableHead>
                    {selectedChild === "todos" && <TableHead className="text-gray-600">Hijo/a</TableHead>}
                    <TableHead className="text-gray-600">Materia</TableHead>
                    <TableHead className="text-gray-600">Estado</TableHead>
                    <TableHead className="text-gray-600">Comentario</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredData.map((record, index) => (
                    <TableRow key={index} className="border-gray-200 hover:bg-gray-50">
                      <TableCell className="text-gray-800">
                        {new Date(record.date).toLocaleDateString("es-ES", {
                          day: "2-digit",
                          month: "2-digit",
                          year: "numeric",
                        })}
                      </TableCell>
                      {selectedChild === "todos" && (
                        <TableCell className="text-gray-600">
                          {children.find((c) => c.id === record.childId)?.name}
                        </TableCell>
                      )}
                      <TableCell className="text-gray-600">{record.subject}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          {getStatusIcon(record.status)}
                          {getStatusBadge(record.status)}
                        </div>
                      </TableCell>
                      <TableCell className="text-gray-600">{record.comment || "Sin comentarios"}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
