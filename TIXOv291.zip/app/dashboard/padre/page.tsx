"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import {
  BookOpen,
  FileText,
  AlertTriangle,
  CheckCircle,
  Clock,
  BarChart3,
  Activity,
  Target,
  Users,
  GraduationCap,
  Award,
  AlertCircle,
  MessageSquare,
  CalendarDays,
  ClipboardList,
  Bell,
  MapPin,
  Phone,
  Eye,
  Calendar,
  UserCheck,
} from "lucide-react"

const PadreDashboardPage = () => {
  const [selectedChild, setSelectedChild] = useState(0)

  // Datos simulados de los hijos
  const children = [
    {
      id: 1,
      name: "Mariana Alcántara",
      course: "5to B",
      shift: "Mañana",
      photo: "/placeholder.svg?height=80&width=80&text=MA",
      status: "Meritorio",
      statusColor: "bg-green-500",
      generalAverage: 87.5,
      attendance: 95,
      pendingTasks: 2,
      totalTasks: 15,
      lastGrade: { subject: "Matemáticas", grade: 92, date: "2024-01-15" },
      competencies: {
        comunicativa: 85,
        logica: 90,
        cientifica: 88,
        etica: 86,
      },
      citation: null, // Sin citación
      alerts: [
        { type: "success", message: "Excelente desempeño en Ciencias Naturales", priority: "low" },
        { type: "warning", message: "Tarea pendiente de Lengua Española para el 20 de enero", priority: "medium" },
      ],
    },
    {
      id: 2,
      name: "Daniel Alcántara",
      course: "3ro A",
      shift: "Tarde",
      photo: "/placeholder.svg?height=80&width=80&text=DA",
      status: "En riesgo",
      statusColor: "bg-yellow-500",
      generalAverage: 68.2,
      attendance: 88,
      pendingTasks: 4,
      totalTasks: 12,
      lastGrade: { subject: "Matemáticas", grade: 65, date: "2024-01-14" },
      competencies: {
        comunicativa: 72,
        logica: 65,
        cientifica: 70,
        etica: 75,
      },
      citation: {
        id: 1,
        reason: "Rendimiento",
        description:
          "Su presencia es requerida para tratar temas relacionados con el bajo rendimiento académico del estudiante",
        suggestedDate: "2024-01-25",
        suggestedTime: "2:00 p.m.",
        location: "Departamento de Orientación",
        contact: "Coordinador Académico",
        details:
          "El estudiante presenta 3 materias con calificaciones por debajo de 70 en el período P2. Es necesario establecer un plan de mejora académica.",
        priority: "high",
        status: "pending", // pending, confirmed, completed
      },
      alerts: [
        { type: "error", message: "Bajo rendimiento en Matemáticas (P2: 65)", priority: "high" },
        { type: "warning", message: "3 ausencias injustificadas esta semana", priority: "high" },
        { type: "info", message: "Recuperación RP2 abierta para Lengua Española", priority: "medium" },
      ],
    },
  ]

  const currentChild = children[selectedChild]

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Meritorio":
        return "bg-green-100 text-green-800 border-green-200"
      case "En riesgo":
        return "bg-yellow-100 text-yellow-800 border-yellow-200"
      case "Activo":
        return "bg-blue-100 text-blue-800 border-blue-200"
      default:
        return "bg-gray-100 text-gray-800 border-gray-200"
    }
  }

  const getGradeColor = (grade: number) => {
    if (grade >= 85) return "text-green-600"
    if (grade >= 70) return "text-yellow-600"
    return "text-red-600"
  }

  const getAlertIcon = (type: string) => {
    switch (type) {
      case "error":
        return <AlertTriangle className="h-4 w-4 text-red-500" />
      case "warning":
        return <AlertCircle className="h-4 w-4 text-yellow-500" />
      case "success":
        return <CheckCircle className="h-4 w-4 text-green-500" />
      default:
        return <AlertCircle className="h-4 w-4 text-blue-500" />
    }
  }

  const getAlertStyle = (type: string) => {
    switch (type) {
      case "error":
        return "border-l-red-500 bg-red-50"
      case "warning":
        return "border-l-yellow-500 bg-yellow-50"
      case "success":
        return "border-l-green-500 bg-green-50"
      default:
        return "border-l-blue-500 bg-blue-50"
    }
  }

  const getCitationReasonIcon = (reason: string) => {
    switch (reason) {
      case "Rendimiento":
        return <BookOpen className="h-5 w-5 text-red-500" />
      case "Asistencia":
        return <Users className="h-5 w-5 text-yellow-500" />
      case "Comportamiento":
        return <AlertTriangle className="h-5 w-5 text-orange-500" />
      case "Evaluación Psicológica":
        return <Activity className="h-5 w-5 text-purple-500" />
      case "Reunión General":
        return <MessageSquare className="h-5 w-5 text-blue-500" />
      default:
        return <Bell className="h-5 w-5 text-gray-500" />
    }
  }

  const handleConfirmAttendance = (citationId: number) => {
    // Aquí se implementaría la lógica para confirmar asistencia
    console.log("Confirmando asistencia para citación:", citationId)
  }

  const handleContactCoordinator = () => {
    // Aquí se implementaría la lógica para contactar al coordinador
    console.log("Contactando al coordinador")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 p-4 md:p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header con selector de hijos */}
        <div className="bg-white rounded-xl shadow-sm border p-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h1 className="text-2xl font-bold text-gray-900 mb-2">Dashboard del Padre</h1>
              <p className="text-gray-600">Monitoreo académico en tiempo real</p>
            </div>

            {/* Selector de hijos */}
            <div className="flex gap-3">
              {children.map((child, index) => (
                <button
                  key={child.id}
                  onClick={() => setSelectedChild(index)}
                  className={`relative flex items-center gap-3 p-3 rounded-lg border-2 transition-all ${
                    selectedChild === index ? "border-blue-500 bg-blue-50" : "border-gray-200 hover:border-gray-300"
                  }`}
                >
                  {/* Indicador de citación */}
                  {child.citation && (
                    <div className="absolute -top-2 -right-2 w-5 h-5 bg-red-500 rounded-full flex items-center justify-center">
                      <Bell className="h-3 w-3 text-white" />
                    </div>
                  )}

                  <Avatar className="h-10 w-10">
                    <AvatarImage src={child.photo || "/placeholder.svg"} alt={child.name} />
                    <AvatarFallback>
                      {child.name
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </AvatarFallback>
                  </Avatar>
                  <div className="text-left">
                    <p className="font-medium text-sm">{child.name}</p>
                    <p className="text-xs text-gray-500">
                      {child.course} - {child.shift}
                    </p>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Alerta de Citación - Solo se muestra si existe */}
        {currentChild.citation && (
          <Card className="border-red-200 bg-red-50">
            <CardContent className="p-6">
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0">
                  <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
                    {getCitationReasonIcon(currentChild.citation.reason)}
                  </div>
                </div>

                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <AlertTriangle className="h-5 w-5 text-red-500" />
                    <h3 className="text-lg font-semibold text-red-800">Su presencia es requerida en la escuela</h3>
                    <Badge variant="destructive" className="ml-auto">
                      {currentChild.citation.priority === "high" ? "Urgente" : "Normal"}
                    </Badge>
                  </div>

                  <p className="text-red-700 mb-4">{currentChild.citation.description}</p>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                    <div className="flex items-center gap-2 text-sm text-red-600">
                      <Calendar className="h-4 w-4" />
                      <span>
                        <strong>Fecha:</strong> {currentChild.citation.suggestedDate}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-red-600">
                      <Clock className="h-4 w-4" />
                      <span>
                        <strong>Hora:</strong> {currentChild.citation.suggestedTime}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-red-600">
                      <MapPin className="h-4 w-4" />
                      <span>
                        <strong>Lugar:</strong> {currentChild.citation.location}
                      </span>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-3">
                    <Button
                      onClick={() => handleConfirmAttendance(currentChild.citation.id)}
                      className="bg-green-600 hover:bg-green-700"
                      size="sm"
                    >
                      <UserCheck className="h-4 w-4 mr-2" />
                      Confirmar Asistencia
                    </Button>

                    <Button
                      onClick={handleContactCoordinator}
                      variant="outline"
                      className="border-red-300 text-red-700 hover:bg-red-50 bg-transparent"
                      size="sm"
                    >
                      <Phone className="h-4 w-4 mr-2" />
                      Contactar Coordinador
                    </Button>

                    <Dialog>
                      <DialogTrigger asChild>
                        <Button
                          variant="outline"
                          size="sm"
                          className="border-red-300 text-red-700 hover:bg-red-50 bg-transparent"
                        >
                          <Eye className="h-4 w-4 mr-2" />
                          Ver Detalles
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-md">
                        <DialogHeader>
                          <DialogTitle className="flex items-center gap-2">
                            {getCitationReasonIcon(currentChild.citation.reason)}
                            Detalles de la Citación
                          </DialogTitle>
                        </DialogHeader>
                        <div className="space-y-4">
                          <div>
                            <h4 className="font-medium text-gray-900 mb-2">Motivo:</h4>
                            <p className="text-sm text-gray-600">{currentChild.citation.reason}</p>
                          </div>

                          <div>
                            <h4 className="font-medium text-gray-900 mb-2">Descripción detallada:</h4>
                            <p className="text-sm text-gray-600">{currentChild.citation.details}</p>
                          </div>

                          <div>
                            <h4 className="font-medium text-gray-900 mb-2">Contacto:</h4>
                            <p className="text-sm text-gray-600">{currentChild.citation.contact}</p>
                          </div>

                          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
                            <p className="text-sm text-yellow-800">
                              <strong>Importante:</strong> Su asistencia es fundamental para el bienestar académico de
                              su hijo/a.
                            </p>
                          </div>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Ficha resumen del estudiante seleccionado */}
        <Card className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row items-center gap-6">
              <Avatar className="h-20 w-20 border-4 border-white/20">
                <AvatarImage src={currentChild.photo || "/placeholder.svg"} alt={currentChild.name} />
                <AvatarFallback className="text-blue-600 text-xl font-bold">
                  {currentChild.name
                    .split(" ")
                    .map((n) => n[0])
                    .join("")}
                </AvatarFallback>
              </Avatar>

              <div className="flex-1 text-center md:text-left">
                <h2 className="text-2xl font-bold mb-2">{currentChild.name}</h2>
                <div className="flex flex-wrap gap-4 justify-center md:justify-start">
                  <div className="flex items-center gap-2">
                    <GraduationCap className="h-4 w-4" />
                    <span>{currentChild.course}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4" />
                    <span>Turno {currentChild.shift}</span>
                  </div>
                  <Badge className={`${getStatusColor(currentChild.status)} border`}>{currentChild.status}</Badge>
                </div>
              </div>

              <div className="text-center">
                <div className="text-3xl font-bold mb-1">{currentChild.generalAverage}</div>
                <div className="text-sm opacity-90">Promedio General</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Métricas rápidas */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Calificaciones */}
          <Card className="hover:shadow-md transition-shadow">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <BookOpen className="h-4 w-4 text-blue-500" />
                Calificaciones
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-2xl font-bold text-gray-900">{currentChild.generalAverage}</span>
                  <div
                    className={`w-3 h-3 rounded-full ${
                      currentChild.generalAverage >= 85
                        ? "bg-green-500"
                        : currentChild.generalAverage >= 70
                          ? "bg-yellow-500"
                          : "bg-red-500"
                    }`}
                  />
                </div>
                <div className="text-xs text-gray-500">
                  Última: {currentChild.lastGrade.subject} - {currentChild.lastGrade.grade}
                </div>
                <Progress value={currentChild.generalAverage} className="h-2" />
              </div>
            </CardContent>
          </Card>

          {/* Tareas */}
          <Card className="hover:shadow-md transition-shadow">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <ClipboardList className="h-4 w-4 text-purple-500" />
                Tareas y Actividades
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-2xl font-bold text-gray-900">
                    {currentChild.totalTasks - currentChild.pendingTasks}
                  </span>
                  <span className="text-sm text-gray-500">/{currentChild.totalTasks}</span>
                </div>
                <div className="text-xs text-gray-500">{currentChild.pendingTasks} pendientes</div>
                <Progress
                  value={((currentChild.totalTasks - currentChild.pendingTasks) / currentChild.totalTasks) * 100}
                  className="h-2"
                />
              </div>
            </CardContent>
          </Card>

          {/* Asistencia */}
          <Card className="hover:shadow-md transition-shadow">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Users className="h-4 w-4 text-green-500" />
                Asistencia
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-2xl font-bold text-gray-900">{currentChild.attendance}%</span>
                  <div
                    className={`w-3 h-3 rounded-full ${
                      currentChild.attendance >= 90
                        ? "bg-green-500"
                        : currentChild.attendance >= 80
                          ? "bg-yellow-500"
                          : "bg-red-500"
                    }`}
                  />
                </div>
                <div className="text-xs text-gray-500">Este período</div>
                <Progress value={currentChild.attendance} className="h-2" />
              </div>
            </CardContent>
          </Card>

          {/* Competencias */}
          <Card className="hover:shadow-md transition-shadow">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Target className="h-4 w-4 text-orange-500" />
                Competencias
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-2xl font-bold text-gray-900">
                    {Math.round(
                      (currentChild.competencies.comunicativa +
                        currentChild.competencies.logica +
                        currentChild.competencies.cientifica +
                        currentChild.competencies.etica) /
                        4,
                    )}
                  </span>
                  <Award className="h-5 w-5 text-orange-500" />
                </div>
                <div className="text-xs text-gray-500">Promedio general</div>
                <Progress
                  value={
                    (currentChild.competencies.comunicativa +
                      currentChild.competencies.logica +
                      currentChild.competencies.cientifica +
                      currentChild.competencies.etica) /
                    4
                  }
                  className="h-2"
                />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Contenido principal con tabs */}
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Resumen</TabsTrigger>
            <TabsTrigger value="competencies">Competencias</TabsTrigger>
            <TabsTrigger value="alerts">Alertas</TabsTrigger>
            <TabsTrigger value="actions">Acciones</TabsTrigger>
          </TabsList>

          {/* Tab: Resumen */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Gráfico de rendimiento por período */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="h-5 w-5 text-blue-500" />
                    Rendimiento por Período
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {["P1", "P2", "P3", "P4"].map((period, index) => {
                      const grades = [85, 78, 82, 87]
                      return (
                        <div key={period} className="flex items-center gap-4">
                          <div className="w-8 text-sm font-medium">{period}</div>
                          <div className="flex-1">
                            <Progress value={grades[index]} className="h-3" />
                          </div>
                          <div className={`w-12 text-sm font-medium ${getGradeColor(grades[index])}`}>
                            {grades[index]}
                          </div>
                        </div>
                      )
                    })}
                  </div>
                </CardContent>
              </Card>

              {/* Asistencia semanal */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Activity className="h-5 w-5 text-green-500" />
                    Asistencia Semanal
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {["Lun", "Mar", "Mié", "Jue", "Vie"].map((day, index) => {
                      const attendance = [true, true, false, true, true]
                      return (
                        <div key={day} className="flex items-center gap-4">
                          <div className="w-8 text-sm font-medium">{day}</div>
                          <div className="flex-1 flex items-center gap-2">
                            <div
                              className={`w-4 h-4 rounded-full ${attendance[index] ? "bg-green-500" : "bg-red-500"}`}
                            />
                            <span className="text-sm">{attendance[index] ? "Presente" : "Ausente"}</span>
                          </div>
                        </div>
                      )
                    })}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Tab: Competencias */}
          <TabsContent value="competencies" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {[
                { name: "Comunicativa", value: currentChild.competencies.comunicativa, color: "blue" },
                { name: "Pensamiento Lógico", value: currentChild.competencies.logica, color: "purple" },
                { name: "Científica y Tecnológica", value: currentChild.competencies.cientifica, color: "green" },
                { name: "Ética y Ciudadana", value: currentChild.competencies.etica, color: "orange" },
              ].map((competency) => (
                <Card key={competency.name}>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium">{competency.name}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-2xl font-bold">{competency.value}</span>
                        <div
                          className={`w-3 h-3 rounded-full ${
                            competency.value >= 90
                              ? "bg-green-500"
                              : competency.value >= 70
                                ? "bg-yellow-500"
                                : "bg-red-500"
                          }`}
                        />
                      </div>
                      <Progress value={competency.value} className="h-2" />
                      <div className="text-xs text-gray-500">
                        {competency.value >= 90
                          ? "Excelente (90-100)"
                          : competency.value >= 70
                            ? "Satisfactorio (70-89)"
                            : "Necesita mejora (60-69)"}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Tab: Alertas */}
          <TabsContent value="alerts" className="space-y-4">
            {currentChild.alerts.length > 0 ? (
              currentChild.alerts.map((alert, index) => (
                <div key={index} className={`border-l-4 p-4 rounded-r-lg ${getAlertStyle(alert.type)}`}>
                  <div className="flex items-start gap-3">
                    {getAlertIcon(alert.type)}
                    <div className="flex-1">
                      <p className="text-sm font-medium text-gray-900">{alert.message}</p>
                      <p className="text-xs text-gray-500 mt-1">
                        Prioridad: {alert.priority === "high" ? "Alta" : alert.priority === "medium" ? "Media" : "Baja"}
                      </p>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <Card>
                <CardContent className="p-8 text-center">
                  <CheckCircle className="h-12 w-12 text-green-500 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">¡Todo en orden!</h3>
                  <p className="text-gray-500">No hay alertas pendientes para este estudiante.</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Tab: Acciones rápidas */}
          <TabsContent value="actions" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Button asChild className="h-auto p-4 flex flex-col items-center gap-2 bg-transparent" variant="outline">
                <a href="/dashboard/padre/grades">
                  <FileText className="h-6 w-6 text-blue-500" />
                  <span className="font-medium">Ver Boletín Consolidado</span>
                  <span className="text-xs text-gray-500">Resumen de calificaciones</span>
                </a>
              </Button>

              <Button asChild className="h-auto p-4 flex flex-col items-center gap-2 bg-transparent" variant="outline">
                <a href="/dashboard/padre/grades">
                  <BookOpen className="h-6 w-6 text-purple-500" />
                  <span className="font-medium">Ver Boletín Detallado</span>
                  <span className="text-xs text-gray-500">Por competencias</span>
                </a>
              </Button>

              <Button asChild className="h-auto p-4 flex flex-col items-center gap-2 bg-transparent" variant="outline">
                <a href="/dashboard/padre/calendar">
                  <CalendarDays className="h-6 w-6 text-green-500" />
                  <span className="font-medium">Ver Calendario Escolar</span>
                  <span className="text-xs text-gray-500">Fechas importantes</span>
                </a>
              </Button>

              <Button asChild className="h-auto p-4 flex flex-col items-center gap-2 bg-transparent" variant="outline">
                <a href="/dashboard/padre/tasks">
                  <ClipboardList className="h-6 w-6 text-teal-500" />
                  <span className="font-medium">Ver Tareas Actuales</span>
                  <span className="text-xs text-gray-500">Actividades pendientes</span>
                </a>
              </Button>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

export default PadreDashboardPage
