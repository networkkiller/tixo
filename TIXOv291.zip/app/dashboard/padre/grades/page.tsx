"use client"

import type React from "react"

import { Header } from "@/components/dashboard/header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Calendar } from "@/components/ui/calendar"
import {
  Download,
  Eye,
  RefreshCw,
  FileText,
  BarChart3,
  Award,
  AlertTriangle,
  CheckCircle,
  CalendarIcon,
  Filter,
  User,
  GraduationCap,
  BookOpen,
  TrendingUp,
  FileDown,
  Printer,
} from "lucide-react"
import { useState } from "react"

export default function PadreGrades() {
  const [selectedChild, setSelectedChild] = useState("1")
  const [selectedPeriod, setSelectedPeriod] = useState("todos")
  const [selectedSubject, setSelectedSubject] = useState("Matemática")
  const [activeTab, setActiveTab] = useState("detallado")

  // Datos de ejemplo para los hijos
  const children = [
    {
      id: "1",
      name: "Ana García Rodríguez",
      photo: "/placeholder.svg?height=80&width=80",
      course: "6to",
      section: "A",
      schoolYear: "2024-2025",
      shift: "Mañana",
      enrollment: "2024-001234",
    },
    {
      id: "2",
      name: "Carlos García Rodríguez",
      photo: "/placeholder.svg?height=80&width=80",
      course: "4to",
      section: "B",
      schoolYear: "2024-2025",
      shift: "Tarde",
      enrollment: "2024-001235",
    },
  ]

  // Datos de calificaciones por materia
  const subjects = [
    {
      name: "Matemática",
      p1: 85,
      rp1: null,
      p2: 78,
      rp2: null,
      p3: 92,
      rp3: null,
      p4: 88,
      rp4: null,
      cf: 86,
      ccf: null,
      exf: null,
      status: "Aprobado",
      color: "green",
      competencies: [
        {
          name: "Comunicativa",
          activities: [
            { type: "Ensayo", activity: "Práctica", score: 87, date: "2024-03-15" },
            { type: "Examen corto", activity: "Examen", score: 92, date: "2024-03-20" },
          ],
        },
        {
          name: "Resolución de Problemas",
          activities: [{ type: "Investigación", activity: "Trabajo", score: 75, date: "2024-03-18" }],
        },
      ],
    },
    {
      name: "Lengua Española",
      p1: 90,
      rp1: null,
      p2: 85,
      rp2: null,
      p3: 88,
      rp3: null,
      p4: 92,
      rp4: null,
      cf: 89,
      ccf: null,
      exf: null,
      status: "Aprobado",
      color: "green",
      competencies: [
        {
          name: "Comunicativa",
          activities: [
            { type: "Redacción", activity: "Práctica", score: 90, date: "2024-03-12" },
            { type: "Lectura", activity: "Evaluación", score: 88, date: "2024-03-25" },
          ],
        },
      ],
    },
    {
      name: "Ciencias Naturales",
      p1: 75,
      rp1: null,
      p2: 68,
      rp2: 72,
      p3: 70,
      rp3: null,
      p4: 74,
      rp4: null,
      cf: 72,
      ccf: null,
      exf: null,
      status: "Aprobado",
      color: "yellow",
      competencies: [
        {
          name: "Pensamiento Científico",
          activities: [{ type: "Experimento", activity: "Práctica", score: 75, date: "2024-03-10" }],
        },
      ],
    },
    {
      name: "Ciencias Sociales",
      p1: 65,
      rp1: 70,
      p2: 62,
      rp2: 68,
      p3: 58,
      rp3: 65,
      p4: 60,
      rp4: 68,
      cf: 65,
      ccf: 70,
      exf: null,
      status: "Aprobado",
      color: "yellow",
      competencies: [
        {
          name: "Pensamiento Crítico",
          activities: [{ type: "Ensayo", activity: "Trabajo", score: 65, date: "2024-03-08" }],
        },
      ],
    },
    {
      name: "Inglés",
      p1: 95,
      rp1: null,
      p2: 92,
      rp2: null,
      p3: 94,
      rp3: null,
      p4: 96,
      rp4: null,
      cf: 94,
      ccf: null,
      exf: null,
      status: "Aprobado",
      color: "green",
      competencies: [
        {
          name: "Comunicativa",
          activities: [{ type: "Conversación", activity: "Oral", score: 95, date: "2024-03-14" }],
        },
      ],
    },
    {
      name: "Educación Física",
      p1: 88,
      rp1: null,
      p2: 90,
      rp2: null,
      p3: 85,
      rp3: null,
      p4: 92,
      rp4: null,
      cf: 89,
      ccf: null,
      exf: null,
      status: "Aprobado",
      color: "green",
      competencies: [
        { name: "Motriz", activities: [{ type: "Deporte", activity: "Práctica", score: 88, date: "2024-03-16" }] },
      ],
    },
  ]

  // Calendario de evaluaciones
  const evaluationCalendar = [
    { date: "2024-03-15", subject: "Matemática", type: "Ensayo", evaluation: "Práctica" },
    { date: "2024-03-20", subject: "Matemática", type: "Examen corto", evaluation: "Examen" },
    { date: "2024-03-25", subject: "Lengua Española", type: "Lectura", evaluation: "Evaluación" },
  ]

  const selectedChildData = children.find((child) => child.id === selectedChild)
  const generalAverage = subjects.reduce((sum, subject) => sum + subject.cf, 0) / subjects.length

  const getStatusBadge = (status: string, score: number) => {
    if (score >= 90) {
      return <Badge className="bg-green-100 text-green-800 border-green-200">🏅 Meritorio</Badge>
    } else if (score >= 70) {
      return <Badge className="bg-green-100 text-green-800 border-green-200">✅ Aprobado</Badge>
    } else if (score >= 60) {
      return <Badge className="bg-yellow-100 text-yellow-800 border-yellow-200">⚠️ En riesgo</Badge>
    } else {
      return <Badge className="bg-red-100 text-red-800 border-red-200">🆘 Reprobado</Badge>
    }
  }

  const getScoreColor = (score: number) => {
    if (score >= 70) return "text-green-600"
    if (score >= 60) return "text-yellow-600"
    return "text-red-600"
  }

  const getProgressColor = (score: number) => {
    if (score >= 70) return "bg-green-500"
    if (score >= 60) return "bg-yellow-500"
    return "bg-red-500"
  }

  return (
    <div className="flex-1 flex flex-col bg-gray-50">
      <Header title="TIXO - Calificaciones de mis Hijos" />

      <main className="flex-1 overflow-y-auto p-6 space-y-6">
        {/* Selección de Hijo */}
        <Card className="bg-white border border-gray-200 shadow-sm">
          <CardHeader>
            <CardTitle className="text-gray-800 flex items-center gap-2">
              <User className="h-5 w-5 text-indigo-600" />
              Seleccionar Hijo/a
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {children.map((child) => (
                <div
                  key={child.id}
                  className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                    selectedChild === child.id
                      ? "border-indigo-500 bg-indigo-50"
                      : "border-gray-200 hover:border-gray-300"
                  }`}
                  onClick={() => setSelectedChild(child.id)}
                >
                  <div className="flex items-center space-x-4">
                    <Avatar className="w-16 h-16">
                      <AvatarImage src={child.photo || "/placeholder.svg"} alt={child.name} />
                      <AvatarFallback className="bg-indigo-600 text-white text-lg">
                        {child.name
                          .split(" ")
                          .map((n) => n[0])
                          .join("")}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <h3 className="font-semibold text-gray-800">{child.name}</h3>
                      <p className="text-sm text-gray-600">
                        {child.course} - Sección {child.section}
                      </p>
                      <p className="text-xs text-gray-500">
                        {child.shift} • {child.schoolYear}
                      </p>
                      <p className="text-xs text-gray-400">Mat: {child.enrollment}</p>
                    </div>
                    {selectedChild === child.id && <CheckCircle className="h-6 w-6 text-indigo-600" />}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {selectedChildData && (
          <>
            {/* Información del Estudiante */}
            <Card className="bg-gradient-to-r from-indigo-500 to-purple-600 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <Avatar className="w-20 h-20 border-4 border-white">
                      <AvatarImage src={selectedChildData.photo || "/placeholder.svg"} alt={selectedChildData.name} />
                      <AvatarFallback className="bg-white text-indigo-600 text-xl font-bold">
                        {selectedChildData.name
                          .split(" ")
                          .map((n) => n[0])
                          .join("")}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <h2 className="text-2xl font-bold">{selectedChildData.name}</h2>
                      <p className="text-indigo-100">
                        {selectedChildData.course} - Sección {selectedChildData.section}
                      </p>
                      <p className="text-indigo-200 text-sm">
                        {selectedChildData.shift} • Año Escolar {selectedChildData.schoolYear}
                      </p>
                      <p className="text-indigo-200 text-sm">Matrícula: {selectedChildData.enrollment}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-3xl font-bold">{generalAverage.toFixed(1)}</div>
                    <div className="text-indigo-100">Promedio General</div>
                    <div className="flex items-center gap-2 mt-2">
                      <TrendingUp className="h-4 w-4" />
                      <span className="text-sm">Buen rendimiento</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Estadísticas Rápidas */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card className="bg-white border border-gray-200 shadow-sm">
                <CardContent className="p-4 text-center">
                  <BookOpen className="h-8 w-8 text-blue-500 mx-auto mb-2" />
                  <div className="text-2xl font-bold text-gray-800">{subjects.length}</div>
                  <div className="text-sm text-gray-600">Total Materias</div>
                </CardContent>
              </Card>

              <Card className="bg-white border border-gray-200 shadow-sm">
                <CardContent className="p-4 text-center">
                  <CheckCircle className="h-8 w-8 text-green-500 mx-auto mb-2" />
                  <div className="text-2xl font-bold text-gray-800">{subjects.filter((s) => s.cf >= 70).length}</div>
                  <div className="text-sm text-gray-600">Aprobadas</div>
                </CardContent>
              </Card>

              <Card className="bg-white border border-gray-200 shadow-sm">
                <CardContent className="p-4 text-center">
                  <Award className="h-8 w-8 text-yellow-500 mx-auto mb-2" />
                  <div className="text-2xl font-bold text-gray-800">{subjects.filter((s) => s.cf >= 90).length}</div>
                  <div className="text-sm text-gray-600">Meritorias</div>
                </CardContent>
              </Card>

              <Card className="bg-white border border-gray-200 shadow-sm">
                <CardContent className="p-4 text-center">
                  <AlertTriangle className="h-8 w-8 text-red-500 mx-auto mb-2" />
                  <div className="text-2xl font-bold text-gray-800">{subjects.filter((s) => s.cf < 70).length}</div>
                  <div className="text-sm text-gray-600">En Riesgo</div>
                </CardContent>
              </Card>
            </div>

            {/* Controles y Filtros */}
            <Card className="bg-white border border-gray-200 shadow-sm">
              <CardContent className="p-4">
                <div className="flex flex-wrap items-center justify-between gap-4">
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2">
                      <Filter className="h-4 w-4 text-gray-500" />
                      <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
                        <SelectTrigger className="w-40">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="todos">Todos los períodos</SelectItem>
                          <SelectItem value="p1">Período 1</SelectItem>
                          <SelectItem value="p2">Período 2</SelectItem>
                          <SelectItem value="p3">Período 3</SelectItem>
                          <SelectItem value="p4">Período 4</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <Select value={selectedSubject} onValueChange={setSelectedSubject}>
                      <SelectTrigger className="w-48">
                        <SelectValue placeholder="Filtrar por materia" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Matemática">Todas las materias</SelectItem>
                        {subjects.map((subject) => (
                          <SelectItem key={subject.name} value={subject.name}>
                            {subject.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex items-center gap-2">
                    <Button size="sm" variant="outline" className="border-gray-300 bg-transparent">
                      <RefreshCw className="h-4 w-4 mr-2" />
                      Actualizar
                    </Button>
                    <Button size="sm" className="bg-indigo-600 hover:bg-indigo-700">
                      <FileDown className="h-4 w-4 mr-2" />
                      Exportar Excel
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Tabs de Boletines */}
            <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
              <TabsList className="grid w-full grid-cols-4 bg-white border border-gray-200">
                <TabsTrigger value="detallado" className="flex items-center gap-2">
                  <FileText className="h-4 w-4" />
                  Boletín Detallado
                </TabsTrigger>
                <TabsTrigger value="consolidado" className="flex items-center gap-2">
                  <BarChart3 className="h-4 w-4" />
                  Boletín Consolidado
                </TabsTrigger>
                <TabsTrigger value="oficial" className="flex items-center gap-2">
                  <Download className="h-4 w-4" />
                  Boletín Oficial
                </TabsTrigger>
                <TabsTrigger value="calendario" className="flex items-center gap-2">
                  <CalendarIcon className="h-4 w-4" />
                  Calendario
                </TabsTrigger>
              </TabsList>

              {/* Boletín Detallado */}
              <TabsContent value="detallado">
                <Card className="bg-white border border-gray-200 shadow-sm">
                  <CardHeader>
                    <CardTitle className="text-gray-800">Boletín Detallado por Competencias</CardTitle>
                    <p className="text-sm text-gray-600">
                      Visualiza las evaluaciones por competencia y tipo de actividad
                    </p>
                  </CardHeader>
                  <CardContent>
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow className="border-gray-200">
                            <TableHead className="text-gray-600">Asignatura</TableHead>
                            <TableHead className="text-center text-gray-600">P1</TableHead>
                            <TableHead className="text-center text-gray-600">RP1</TableHead>
                            <TableHead className="text-center text-gray-600">P2</TableHead>
                            <TableHead className="text-center text-gray-600">RP2</TableHead>
                            <TableHead className="text-center text-gray-600">P3</TableHead>
                            <TableHead className="text-center text-gray-600">RP3</TableHead>
                            <TableHead className="text-center text-gray-600">P4</TableHead>
                            <TableHead className="text-center text-gray-600">RP4</TableHead>
                            <TableHead className="text-center text-gray-600">C.F.</TableHead>
                            <TableHead className="text-center text-gray-600">C.C.F.</TableHead>
                            <TableHead className="text-center text-gray-600">C.EX.F.</TableHead>
                            <TableHead className="text-center text-gray-600">Estado</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {subjects.map((subject, index) => (
                            <TableRow key={index} className="border-gray-200 hover:bg-gray-50">
                              <TableCell className="font-medium text-gray-800">
                                <div className="flex items-center gap-2">
                                  <BookOpen className="h-4 w-4 text-indigo-600" />
                                  {subject.name}
                                </div>
                              </TableCell>
                              <TableCell className="text-center">
                                <Dialog>
                                  <DialogTrigger asChild>
                                    <Button variant="ghost" size="sm" className="p-1">
                                      <div className={`font-semibold ${getScoreColor(subject.p1)}`}>{subject.p1}</div>
                                      <Eye className="h-3 w-3 ml-1 text-gray-400" />
                                    </Button>
                                  </DialogTrigger>
                                  <DialogContent className="max-w-2xl">
                                    <DialogHeader>
                                      <DialogTitle>Detalle P1 - {subject.name}</DialogTitle>
                                    </DialogHeader>
                                    <div className="space-y-4">
                                      {subject.competencies.map((competency, idx) => (
                                        <div key={idx} className="border rounded-lg p-4">
                                          <h4 className="font-semibold text-gray-800 mb-3">
                                            Competencia: {competency.name}
                                          </h4>
                                          <Table>
                                            <TableHeader>
                                              <TableRow>
                                                <TableHead>Tipo</TableHead>
                                                <TableHead>Actividad</TableHead>
                                                <TableHead>Calificación</TableHead>
                                                <TableHead>Fecha</TableHead>
                                              </TableRow>
                                            </TableHeader>
                                            <TableBody>
                                              {competency.activities.map((activity, actIdx) => (
                                                <TableRow key={actIdx}>
                                                  <TableCell>{activity.type}</TableCell>
                                                  <TableCell>{activity.activity}</TableCell>
                                                  <TableCell>
                                                    <span className={`font-semibold ${getScoreColor(activity.score)}`}>
                                                      {activity.score}
                                                    </span>
                                                  </TableCell>
                                                  <TableCell>{activity.date}</TableCell>
                                                </TableRow>
                                              ))}
                                            </TableBody>
                                          </Table>
                                        </div>
                                      ))}
                                    </div>
                                  </DialogContent>
                                </Dialog>
                              </TableCell>
                              <TableCell className="text-center">
                                {subject.rp1 ? (
                                  <span className={`font-semibold ${getScoreColor(subject.rp1)}`}>{subject.rp1}</span>
                                ) : (
                                  <span className="text-gray-400">-</span>
                                )}
                              </TableCell>
                              <TableCell className="text-center">
                                <span className={`font-semibold ${getScoreColor(subject.p2)}`}>{subject.p2}</span>
                              </TableCell>
                              <TableCell className="text-center">
                                {subject.rp2 ? (
                                  <span className={`font-semibold ${getScoreColor(subject.rp2)}`}>{subject.rp2}</span>
                                ) : (
                                  <span className="text-gray-400">-</span>
                                )}
                              </TableCell>
                              <TableCell className="text-center">
                                <span className={`font-semibold ${getScoreColor(subject.p3)}`}>{subject.p3}</span>
                              </TableCell>
                              <TableCell className="text-center">
                                {subject.rp3 ? (
                                  <span className={`font-semibold ${getScoreColor(subject.rp3)}`}>{subject.rp3}</span>
                                ) : (
                                  <span className="text-gray-400">-</span>
                                )}
                              </TableCell>
                              <TableCell className="text-center">
                                <span className={`font-semibold ${getScoreColor(subject.p4)}`}>{subject.p4}</span>
                              </TableCell>
                              <TableCell className="text-center">
                                {subject.rp4 ? (
                                  <span className={`font-semibold ${getScoreColor(subject.rp4)}`}>{subject.rp4}</span>
                                ) : (
                                  <span className="text-gray-400">-</span>
                                )}
                              </TableCell>
                              <TableCell className="text-center">
                                <span className={`font-bold text-lg ${getScoreColor(subject.cf)}`}>{subject.cf}</span>
                              </TableCell>
                              <TableCell className="text-center">
                                {subject.ccf ? (
                                  <span className={`font-semibold ${getScoreColor(subject.ccf)}`}>{subject.ccf}</span>
                                ) : (
                                  <span className="text-gray-400">-</span>
                                )}
                              </TableCell>
                              <TableCell className="text-center">
                                {subject.exf ? (
                                  <span className={`font-semibold ${getScoreColor(subject.exf)}`}>{subject.exf}</span>
                                ) : (
                                  <span className="text-gray-400">-</span>
                                )}
                              </TableCell>
                              <TableCell className="text-center">
                                {getStatusBadge(subject.status, subject.cf)}
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Boletín Consolidado */}
              <TabsContent value="consolidado">
                <Card className="bg-white border border-gray-200 shadow-sm">
                  <CardHeader>
                    <CardTitle className="text-gray-800">Boletín Consolidado</CardTitle>
                    <p className="text-sm text-gray-600">Resumen de promedios por período y estado general</p>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      {/* Indicadores Visuales */}
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        {subjects.map((subject, index) => (
                          <div key={index} className="p-4 border rounded-lg">
                            <div className="flex items-center justify-between mb-2">
                              <h4 className="font-semibold text-gray-800">{subject.name}</h4>
                              {getStatusBadge(subject.status, subject.cf)}
                            </div>
                            <div className="space-y-2">
                              <div className="flex justify-between text-sm">
                                <span>Calificación Final:</span>
                                <span className={`font-bold ${getScoreColor(subject.cf)}`}>{subject.cf}</span>
                              </div>
                              <Progress
                                value={subject.cf}
                                className="h-2"
                                style={
                                  {
                                    "--progress-background": getProgressColor(subject.cf),
                                  } as React.CSSProperties
                                }
                              />
                            </div>
                          </div>
                        ))}
                      </div>

                      {/* Tabla Consolidada */}
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow className="border-gray-200">
                              <TableHead className="text-gray-600">Asignatura</TableHead>
                              <TableHead className="text-center text-gray-600">P1</TableHead>
                              <TableHead className="text-center text-gray-600">P2</TableHead>
                              <TableHead className="text-center text-gray-600">P3</TableHead>
                              <TableHead className="text-center text-gray-600">P4</TableHead>
                              <TableHead className="text-center text-gray-600">C.F.</TableHead>
                              <TableHead className="text-center text-gray-600">Estado Final</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {subjects.map((subject, index) => (
                              <TableRow key={index} className="border-gray-200 hover:bg-gray-50">
                                <TableCell className="font-medium text-gray-800">{subject.name}</TableCell>
                                <TableCell className="text-center">
                                  <span className={`font-semibold ${getScoreColor(subject.p1)}`}>{subject.p1}</span>
                                </TableCell>
                                <TableCell className="text-center">
                                  <span className={`font-semibold ${getScoreColor(subject.p2)}`}>{subject.p2}</span>
                                </TableCell>
                                <TableCell className="text-center">
                                  <span className={`font-semibold ${getScoreColor(subject.p3)}`}>{subject.p3}</span>
                                </TableCell>
                                <TableCell className="text-center">
                                  <span className={`font-semibold ${getScoreColor(subject.p4)}`}>{subject.p4}</span>
                                </TableCell>
                                <TableCell className="text-center">
                                  <span className={`font-bold text-lg ${getScoreColor(subject.cf)}`}>{subject.cf}</span>
                                </TableCell>
                                <TableCell className="text-center">
                                  {getStatusBadge(subject.status, subject.cf)}
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Boletín Oficial */}
              <TabsContent value="oficial">
                <Card className="bg-white border border-gray-200 shadow-sm">
                  <CardHeader>
                    <CardTitle className="text-gray-800">Boletín Oficial Descargable</CardTitle>
                    <p className="text-sm text-gray-600">
                      Formato oficial listo para impresión según estándares del MINERD
                    </p>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      {/* Vista Previa del Boletín */}
                      <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 bg-gray-50">
                        <div className="text-center mb-6">
                          <div className="flex items-center justify-center gap-4 mb-4">
                            <GraduationCap className="h-12 w-12 text-indigo-600" />
                            <div>
                              <h2 className="text-xl font-bold text-gray-800">CENTRO EDUCATIVO TIXO</h2>
                              <p className="text-sm text-gray-600">Año Escolar 2024-2025</p>
                            </div>
                          </div>
                          <div className="border-t border-b border-gray-300 py-4 my-4">
                            <h3 className="text-lg font-semibold text-gray-800">BOLETÍN DE CALIFICACIONES</h3>
                          </div>
                        </div>

                        {/* Información del Estudiante */}
                        <div className="grid grid-cols-2 gap-4 mb-6 text-sm">
                          <div>
                            <p>
                              <strong>Estudiante:</strong> {selectedChildData.name}
                            </p>
                            <p>
                              <strong>Curso:</strong> {selectedChildData.course}
                            </p>
                            <p>
                              <strong>Sección:</strong> {selectedChildData.section}
                            </p>
                          </div>
                          <div>
                            <p>
                              <strong>Matrícula:</strong> {selectedChildData.enrollment}
                            </p>
                            <p>
                              <strong>Turno:</strong> {selectedChildData.shift}
                            </p>
                            <p>
                              <strong>Año Escolar:</strong> {selectedChildData.schoolYear}
                            </p>
                          </div>
                        </div>

                        {/* Tabla de Calificaciones Oficial */}
                        <div className="overflow-x-auto mb-6">
                          <table className="w-full border-collapse border border-gray-400 text-xs">
                            <thead>
                              <tr className="bg-gray-100">
                                <th className="border border-gray-400 p-2 text-left">ASIGNATURA</th>
                                <th className="border border-gray-400 p-2">P1</th>
                                <th className="border border-gray-400 p-2">RP1</th>
                                <th className="border border-gray-400 p-2">P2</th>
                                <th className="border border-gray-400 p-2">RP2</th>
                                <th className="border border-gray-400 p-2">P3</th>
                                <th className="border border-gray-400 p-2">RP3</th>
                                <th className="border border-gray-400 p-2">P4</th>
                                <th className="border border-gray-400 p-2">RP4</th>
                                <th className="border border-gray-400 p-2">C.F.</th>
                                <th className="border border-gray-400 p-2">C.C.F.</th>
                                <th className="border border-gray-400 p-2">C.EX.F.</th>
                                <th className="border border-gray-400 p-2">ESTADO</th>
                              </tr>
                            </thead>
                            <tbody>
                              {subjects.map((subject, index) => (
                                <tr key={index}>
                                  <td className="border border-gray-400 p-2 font-medium">{subject.name}</td>
                                  <td className="border border-gray-400 p-2 text-center">{subject.p1}</td>
                                  <td className="border border-gray-400 p-2 text-center">{subject.rp1 || "-"}</td>
                                  <td className="border border-gray-400 p-2 text-center">{subject.p2}</td>
                                  <td className="border border-gray-400 p-2 text-center">{subject.rp2 || "-"}</td>
                                  <td className="border border-gray-400 p-2 text-center">{subject.p3}</td>
                                  <td className="border border-gray-400 p-2 text-center">{subject.rp3 || "-"}</td>
                                  <td className="border border-gray-400 p-2 text-center">{subject.p4}</td>
                                  <td className="border border-gray-400 p-2 text-center">{subject.rp4 || "-"}</td>
                                  <td className="border border-gray-400 p-2 text-center font-bold">{subject.cf}</td>
                                  <td className="border border-gray-400 p-2 text-center">{subject.ccf || "-"}</td>
                                  <td className="border border-gray-400 p-2 text-center">{subject.exf || "-"}</td>
                                  <td className="border border-gray-400 p-2 text-center">
                                    {subject.cf >= 70 ? "A" : "R"}
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>

                        {/* Firmas */}
                        <div className="grid grid-cols-3 gap-8 mt-8 text-xs text-center">
                          <div>
                            <div className="border-t border-gray-400 pt-2">
                              <p className="font-semibold">PROFESOR(A)</p>
                            </div>
                          </div>
                          <div>
                            <div className="border-t border-gray-400 pt-2">
                              <p className="font-semibold">COORDINADOR(A)</p>
                            </div>
                          </div>
                          <div>
                            <div className="border-t border-gray-400 pt-2">
                              <p className="font-semibold">DIRECTOR(A)</p>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Botones de Acción */}
                      <div className="flex justify-center gap-4">
                        <Button className="bg-indigo-600 hover:bg-indigo-700">
                          <Download className="h-4 w-4 mr-2" />
                          Descargar Boletín PDF
                        </Button>
                        <Button variant="outline" className="border-gray-300 bg-transparent">
                          <Printer className="h-4 w-4 mr-2" />
                          Imprimir Boletín
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Calendario de Evaluaciones */}
              <TabsContent value="calendario">
                <Card className="bg-white border border-gray-200 shadow-sm">
                  <CardHeader>
                    <CardTitle className="text-gray-800">Calendario de Evaluaciones</CardTitle>
                    <p className="text-sm text-gray-600">Fechas de evaluaciones registradas y períodos activos</p>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                      {/* Calendario */}
                      <div>
                        <Calendar mode="single" className="rounded-md border" />
                      </div>

                      {/* Lista de Evaluaciones */}
                      <div className="space-y-4">
                        <h4 className="font-semibold text-gray-800">Próximas Evaluaciones</h4>
                        {evaluationCalendar.map((evaluation, index) => (
                          <div key={index} className="flex items-center gap-4 p-3 border rounded-lg">
                            <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center">
                              <CalendarIcon className="h-6 w-6 text-indigo-600" />
                            </div>
                            <div className="flex-1">
                              <h5 className="font-medium text-gray-800">
                                {evaluation.subject} - {evaluation.evaluation}
                              </h5>
                              <p className="text-sm text-gray-600">Tipo: {evaluation.type}</p>
                              <p className="text-xs text-gray-500">{evaluation.date}</p>
                            </div>
                            <Badge variant="outline" className="border-indigo-200 text-indigo-700">
                              Programada
                            </Badge>
                          </div>
                        ))}

                        {/* Estados de Períodos */}
                        <div className="mt-6">
                          <h4 className="font-semibold text-gray-800 mb-3">Estado de Períodos</h4>
                          <div className="space-y-2">
                            <div className="flex items-center justify-between p-2 bg-green-50 rounded">
                              <span className="text-sm font-medium">Período 1</span>
                              <Badge className="bg-green-100 text-green-800">Cerrado</Badge>
                            </div>
                            <div className="flex items-center justify-between p-2 bg-green-50 rounded">
                              <span className="text-sm font-medium">Período 2</span>
                              <Badge className="bg-green-100 text-green-800">Cerrado</Badge>
                            </div>
                            <div className="flex items-center justify-between p-2 bg-blue-50 rounded">
                              <span className="text-sm font-medium">Período 3</span>
                              <Badge className="bg-blue-100 text-blue-800">Activo</Badge>
                            </div>
                            <div className="flex items-center justify-between p-2 bg-gray-50 rounded">
                              <span className="text-sm font-medium">Período 4</span>
                              <Badge variant="outline">Pendiente</Badge>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </>
        )}
      </main>
    </div>
  )
}
