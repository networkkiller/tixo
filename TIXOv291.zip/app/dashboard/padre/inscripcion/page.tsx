"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/contexts/auth-context"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  UserPlus,
  School,
  Upload,
  FileText,
  CheckCircle,
  AlertCircle,
  Clock,
  Eye,
  Send,
  RefreshCw,
  X,
  User,
  Phone,
  Mail,
  MapPin,
  BookOpen,
  Info,
} from "lucide-react"

interface Colegio {
  id: number
  nombre: string
  direccion: string
  telefono: string
  email: string
  logo?: string
}

interface Curso {
  id: number
  nombre: string
  grado: string
  seccion: string
  edadMinima: number
  edadMaxima: number
}

interface DocumentoRequerido {
  tipo: string
  nombre: string
  obligatorio: boolean
  descripcion: string
}

interface SolicitudInscripcion {
  id: string
  tipo: "inscripcion" | "reinscripcion"
  colegioId: number
  nombreColegio: string
  estudiante: {
    nombre: string
    apellido: string
    fechaNacimiento: string
    genero: "M" | "F" | "Otro"
    direccion: string
    telefono: string
    nacionalidad: string
    libro: string
    folio: string
    acta: string
    conQuienReside: string
    algunaEnfermedad: string
    esAlergico: string
    esAsegurado: string
    tipoSeguro: string
    tipoSangre: string
    emergenciaLlamarA: string
  }
  documentos: Array<{
    tipo: string
    archivo: string
    fechaCarga: string
  }>
  observaciones?: string
  estado: "Iniciada" | "DocumentosEntregados" | "EnRevisión" | "Aprobada" | "Rechazada" | "Confirmada"
  fechaCreacion: string
  fechaActualizacion: string
}

const colegiosDisponibles: Colegio[] = [
  {
    id: 1,
    nombre: "Colegio San José",
    direccion: "Av. Principal 123, Ciudad",
    telefono: "+57 1 234-5678",
    email: "info@colegiosanjose.edu.co",
  },
  {
    id: 2,
    nombre: "Instituto María Auxiliadora",
    direccion: "Calle 45 #12-34, Centro",
    telefono: "+57 1 345-6789",
    email: "admisiones@mariaauxiliadora.edu.co",
  },
  {
    id: 3,
    nombre: "Colegio Técnico Industrial",
    direccion: "Carrera 15 #67-89, Norte",
    telefono: "+57 1 456-7890",
    email: "secretaria@tecnicoindustrial.edu.co",
  },
]

const cursosDisponibles: Record<number, Curso[]> = {
  1: [
    { id: 101, nombre: "Preescolar A", grado: "Preescolar", seccion: "A", edadMinima: 3, edadMaxima: 5 },
    { id: 102, nombre: "Primero A", grado: "1°", seccion: "A", edadMinima: 6, edadMaxima: 7 },
    { id: 103, nombre: "Segundo B", grado: "2°", seccion: "B", edadMinima: 7, edadMaxima: 8 },
    { id: 104, nombre: "Tercero A", grado: "3°", seccion: "A", edadMinima: 8, edadMaxima: 9 },
  ],
  2: [
    { id: 201, nombre: "Jardín A", grado: "Jardín", seccion: "A", edadMinima: 4, edadMaxima: 5 },
    { id: 202, nombre: "Transición B", grado: "Transición", seccion: "B", edadMinima: 5, edadMaxima: 6 },
    { id: 203, nombre: "Primero A", grado: "1°", seccion: "A", edadMinima: 6, edadMaxima: 7 },
  ],
  3: [
    { id: 301, nombre: "Sexto A", grado: "6°", seccion: "A", edadMinima: 11, edadMaxima: 12 },
    { id: 302, nombre: "Séptimo B", grado: "7°", seccion: "B", edadMinima: 12, edadMaxima: 13 },
    { id: 303, nombre: "Octavo A", grado: "8°", seccion: "A", edadMinima: 13, edadMaxima: 14 },
  ],
}

const documentosInscripcion: DocumentoRequerido[] = [
  {
    tipo: "acta_nacimiento",
    nombre: "Acta de nacimiento original y copia",
    obligatorio: true,
    descripcion: "Documento oficial de registro civil (original y fotocopia)",
  },
  {
    tipo: "cedula_tutor",
    nombre: "Fotocopia de la cédula del padre, madre o tutor legal",
    obligatorio: true,
    descripcion: "Cédula de ciudadanía del responsable legal del estudiante",
  },
  {
    tipo: "fotos_estudiante",
    nombre: "2 fotos recientes del estudiante (2x2 pulgadas)",
    obligatorio: true,
    descripcion: "Fotografías recientes tamaño 2x2 pulgadas con fondo blanco",
  },
  {
    tipo: "certificado_medico",
    nombre: "Certificado médico general",
    obligatorio: true,
    descripcion: "Certificado médico de aptitud física emitido por profesional de la salud",
  },
  {
    tipo: "tarjeta_vacunas",
    nombre: "Tarjeta de vacunas actualizada",
    obligatorio: true,
    descripcion: "Carnet de vacunación con esquema completo y actualizado",
  },
  {
    tipo: "certificacion_grado",
    nombre: "Certificación de grado aprobado o Boletín de notas del año anterior",
    obligatorio: true,
    descripcion: "Documento que certifique la aprobación del grado anterior",
  },
  {
    tipo: "carta_traslado",
    nombre: "Carta de traslado (si proviene de otro centro)",
    obligatorio: false,
    descripcion: "Documento oficial de traslado del centro educativo anterior (solo si aplica)",
  },
  {
    tipo: "evaluacion_psicologica",
    nombre: "Evaluación psicológica o psicopedagógica",
    obligatorio: false,
    descripcion: "Evaluación realizada por profesional en psicología o psicopedagogía",
  },
]

const documentosReinscripcion: DocumentoRequerido[] = [
  {
    tipo: "certificado_medico",
    nombre: "Certificado médico general actualizado",
    obligatorio: true,
    descripcion: "Certificado médico con vigencia no mayor a 6 meses",
  },
  {
    tipo: "fotos_estudiante",
    nombre: "2 fotos recientes del estudiante (2x2 pulgadas)",
    obligatorio: true,
    descripcion: "Fotografías recientes tamaño 2x2 pulgadas con fondo blanco",
  },
  {
    tipo: "tarjeta_vacunas",
    nombre: "Tarjeta de vacunas actualizada",
    obligatorio: true,
    descripcion: "Carnet de vacunación con esquema completo y actualizado",
  },
]

export default function InscripcionPage() {
  const { user } = useAuth()
  const [tipoSolicitud, setTipoSolicitud] = useState<"inscripcion" | "reinscripcion">("inscripcion")
  const [colegioSeleccionado, setColegioSeleccionado] = useState<number | null>(null)
  const [cursoSeleccionado, setCursoSeleccionado] = useState<number | null>(null)
  const [documentosSubidos, setDocumentosSubidos] = useState<Record<string, File>>({})
  const [solicitudesExistentes, setSolicitudesExistentes] = useState<SolicitudInscripcion[]>([])
  const [mostrarSeguimiento, setMostrarSeguimiento] = useState(false)
  const [progreso, setProgreso] = useState(0)
  const [formData, setFormData] = useState({
    estudiante: {
      nombre: "",
      apellido: "",
      direccion: "",
      telefono: "",
      nacionalidad: "",
      // Información del acta
      fechaNacimiento: "",
      libro: "",
      folio: "",
      acta: "",
      genero: "" as "M" | "F" | "Otro",
      // Datos de emergencia
      conQuienReside: "",
      algunaEnfermedad: "",
      esAlergico: "",
      esAsegurado: "",
      tipoSeguro: "",
      tipoSangre: "",
      emergenciaLlamarA: "",
    },
    observaciones: "",
  })

  const [hijosRegistrados, setHijosRegistrados] = useState<
    Array<{
      id: string
      nombre: string
      apellido: string
      colegio: string
      colegioId: number
      grado: string
      datos: any
    }>
  >([])
  const [hijoSeleccionado, setHijoSeleccionado] = useState<string | null>(null)
  const [documentosVencidos, setDocumentosVencidos] = useState<string[]>([])

  const documentosRequeridos = tipoSolicitud === "inscripcion" ? documentosInscripcion : documentosReinscripcion
  const cursosDisponiblesActuales = colegioSeleccionado ? cursosDisponibles[colegioSeleccionado] || [] : []
  const colegioInfo = colegiosDisponibles.find((c) => c.id === colegioSeleccionado)
  const cursoInfo = cursosDisponiblesActuales.find((c) => c.id === cursoSeleccionado)

  // Calcular progreso del formulario
  useEffect(() => {
    let completedSteps = 0
    const totalSteps = 5

    if (colegioSeleccionado) completedSteps++
    if (cursoSeleccionado) completedSteps++
    if (formData.estudiante.nombre && formData.estudiante.apellido && formData.estudiante.fechaNacimiento)
      completedSteps++
    if (Object.keys(documentosSubidos).length >= documentosRequeridos.filter((d) => d.obligatorio).length)
      completedSteps++
    if (
      formData.estudiante.genero &&
      formData.estudiante.direccion &&
      formData.estudiante.telefono &&
      formData.estudiante.nacionalidad &&
      formData.estudiante.libro &&
      formData.estudiante.folio &&
      formData.estudiante.acta &&
      formData.estudiante.conQuienReside &&
      formData.estudiante.emergenciaLlamarA &&
      formData.estudiante.esAsegurado &&
      formData.estudiante.tipoSangre &&
      (tipoSolicitud === "inscripcion" || hijoSeleccionado)
    )
      completedSteps++

    setProgreso((completedSteps / totalSteps) * 100)
  }, [
    colegioSeleccionado,
    cursoSeleccionado,
    formData,
    documentosSubidos,
    documentosRequeridos,
    tipoSolicitud,
    hijoSeleccionado,
  ])

  // Simular carga de solicitudes existentes
  useEffect(() => {
    const solicitudesSimuladas: SolicitudInscripcion[] = [
      {
        id: "SOL-001",
        tipo: "inscripcion",
        colegioId: 1,
        nombreColegio: "Colegio San José",
        estudiante: {
          nombre: "Ana",
          apellido: "García",
          fechaNacimiento: "2015-03-15",
          genero: "F",
          direccion: "Calle 123 #45-67",
          telefono: "",
          nacionalidad: "",
          libro: "",
          folio: "",
          acta: "",
          conQuienReside: "",
          algunaEnfermedad: "",
          esAlergico: "",
          esAsegurado: "",
          tipoSeguro: "",
          tipoSangre: "",
          emergenciaLlamarA: "",
        },
        cursoSolicitado: 101,
        nombreCurso: "Preescolar A",
        documentos: [],
        estado: "EnRevisión",
        fechaCreacion: "2024-01-15",
        fechaActualizacion: "2024-01-20",
      },
    ]
    setSolicitudesExistentes(solicitudesSimuladas)
  }, [])

  // Simular carga de hijos registrados cuando se selecciona reinscripción
  useEffect(() => {
    if (tipoSolicitud === "reinscripcion") {
      // Simular datos de hijos registrados
      const hijosSimulados = [
        {
          id: "hijo-001",
          nombre: "Ana María",
          apellido: "García López",
          colegio: "Colegio San José",
          colegioId: 1,
          grado: "3° A",
          datos: {
            nombre: "Ana María",
            apellido: "García López",
            direccion: "Calle 123 #45-67",
            telefono: "3001234567",
            nacionalidad: "colombiana",
            fechaNacimiento: "2015-03-15",
            libro: "12",
            folio: "345",
            acta: "67890",
            genero: "F",
            conQuienReside: "Padres",
            algunaEnfermedad: "Ninguna",
            esAlergico: "No presenta alergias",
            esAsegurado: "si",
            tipoSeguro: "eps-sura",
            tipoSangre: "O+",
            emergenciaLlamarA: "María López - 3009876543",
          },
        },
        {
          id: "hijo-002",
          nombre: "Carlos",
          apellido: "García López",
          colegio: "Instituto María Auxiliadora",
          colegioId: 2,
          grado: "1° A",
          datos: {
            nombre: "Carlos",
            apellido: "García López",
            direccion: "Calle 123 #45-67",
            telefono: "3001234567",
            nacionalidad: "colombiana",
            fechaNacimiento: "2017-08-22",
            libro: "15",
            folio: "678",
            acta: "12345",
            genero: "M",
            conQuienReside: "Padres",
            algunaEnfermedad: "Asma leve",
            esAlergico: "Alérgico al polen",
            esAsegurado: "si",
            tipoSeguro: "eps-sanitas",
            tipoSangre: "A+",
            emergenciaLlamarA: "María López - 3009876543",
          },
        },
      ]
      setHijosRegistrados(hijosSimulados)
    } else {
      setHijosRegistrados([])
      setHijoSeleccionado(null)
    }
  }, [tipoSolicitud])

  // Cargar datos del hijo seleccionado
  useEffect(() => {
    if (hijoSeleccionado && hijosRegistrados.length > 0) {
      const hijo = hijosRegistrados.find((h) => h.id === hijoSeleccionado)
      if (hijo) {
        setFormData((prev) => ({
          ...prev,
          estudiante: hijo.datos,
        }))
        setColegioSeleccionado(hijo.colegioId)

        // Verificar documentos vencidos (simulado)
        const documentosVencidosSimulados = ["certificado_medico", "tarjeta_vacunas"]
        setDocumentosVencidos(documentosVencidosSimulados)
      }
    }
  }, [hijoSeleccionado, hijosRegistrados])

  const handleFileUpload = (tipoDocumento: string, file: File) => {
    if (file.size > 5 * 1024 * 1024) {
      alert("El archivo no puede superar los 5MB")
      return
    }

    const allowedTypes = ["application/pdf", "image/jpeg", "image/png"]
    if (!allowedTypes.includes(file.type)) {
      alert("Solo se permiten archivos PDF, JPG o PNG")
      return
    }

    setDocumentosSubidos((prev) => ({
      ...prev,
      [tipoDocumento]: file,
    }))
  }

  const calcularEdad = (fechaNacimiento: string): number => {
    const hoy = new Date()
    const nacimiento = new Date(fechaNacimiento)
    let edad = hoy.getFullYear() - nacimiento.getFullYear()
    const mes = hoy.getMonth() - nacimiento.getMonth()
    if (mes < 0 || (mes === 0 && hoy.getDate() < nacimiento.getDate())) {
      edad--
    }
    return edad
  }

  const validarEdad = (): boolean => {
    if (!formData.estudiante.fechaNacimiento || !cursoInfo) return true
    const edad = calcularEdad(formData.estudiante.fechaNacimiento)
    return edad >= cursoInfo.edadMinima && edad <= cursoInfo.edadMaxima
  }

  const verificarSolicitudExistente = (): boolean => {
    const colegioParaValidar =
      tipoSolicitud === "reinscripcion" && hijoSeleccionado
        ? hijosRegistrados.find((h) => h.id === hijoSeleccionado)?.colegioId
        : colegioSeleccionado

    return solicitudesExistentes.some(
      (solicitud) =>
        solicitud.colegioId === colegioParaValidar &&
        solicitud.estudiante.nombre.toLowerCase() === formData.estudiante.nombre.toLowerCase() &&
        solicitud.estudiante.apellido.toLowerCase() === formData.estudiante.apellido.toLowerCase() &&
        ["Iniciada", "DocumentosEntregados", "EnRevisión"].includes(solicitud.estado),
    )
  }

  const handleSubmit = () => {
    // Para reinscripción, usar el colegio del hijo seleccionado
    const colegioParaValidar =
      tipoSolicitud === "reinscripcion" && hijoSeleccionado
        ? hijosRegistrados.find((h) => h.id === hijoSeleccionado)?.colegioId
        : colegioSeleccionado

    if (!colegioParaValidar || !cursoSeleccionado) {
      alert("Por favor seleccione un colegio y curso")
      return
    }

    if (
      !formData.estudiante.nombre ||
      !formData.estudiante.apellido ||
      !formData.estudiante.fechaNacimiento ||
      !formData.estudiante.telefono ||
      !formData.estudiante.nacionalidad ||
      !formData.estudiante.libro ||
      !formData.estudiante.folio ||
      !formData.estudiante.acta ||
      !formData.estudiante.genero ||
      !formData.estudiante.conQuienReside ||
      !formData.estudiante.emergenciaLlamarA ||
      !formData.estudiante.esAsegurado ||
      !formData.estudiante.tipoSangre
    ) {
      alert("Por favor complete todos los datos obligatorios del estudiante")
      return
    }

    const documentosObligatoriosFaltantes = documentosRequeridos
      .filter((doc) => doc.obligatorio && !documentosSubidos[doc.tipo])
      .map((doc) => doc.nombre)

    if (documentosObligatoriosFaltantes.length > 0) {
      alert(`Faltan documentos obligatorios: ${documentosObligatoriosFaltantes.join(", ")}`)
      return
    }

    if (verificarSolicitudExistente()) {
      alert("Ya existe una solicitud activa para este estudiante en el colegio seleccionado")
      return
    }

    // Usar el colegio correcto para la solicitud
    const colegioInfoParaSolicitud = colegiosDisponibles.find((c) => c.id === colegioParaValidar)

    // Simular envío de solicitud
    const nuevaSolicitud: SolicitudInscripcion = {
      id: `SOL-${Date.now()}`,
      tipo: tipoSolicitud,
      colegioId: colegioParaValidar,
      nombreColegio: colegioInfoParaSolicitud?.nombre || "",
      estudiante: formData.estudiante,
      cursoSolicitado: cursoSeleccionado,
      nombreCurso: cursoInfo?.nombre || "",
      documentos: Object.entries(documentosSubidos).map(([tipo, file]) => ({
        tipo,
        archivo: file.name,
        fechaCarga: new Date().toISOString(),
      })),
      observaciones: formData.observaciones,
      estado: "Iniciada",
      fechaCreacion: new Date().toISOString(),
      fechaActualizacion: new Date().toISOString(),
    }

    setSolicitudesExistentes((prev) => [...prev, nuevaSolicitud])
    alert("Solicitud enviada exitosamente. Recibirá una notificación cuando sea revisada.")

    // Limpiar formulario
    setFormData({
      estudiante: {
        nombre: "",
        apellido: "",
        direccion: "",
        telefono: "",
        nacionalidad: "",
        fechaNacimiento: "",
        libro: "",
        folio: "",
        acta: "",
        genero: "" as "M" | "F" | "Otro",
        conQuienReside: "",
        algunaEnfermedad: "",
        esAlergico: "",
        esAsegurado: "",
        tipoSeguro: "",
        tipoSangre: "",
        emergenciaLlamarA: "",
      },
      observaciones: "",
    })
    setColegioSeleccionado(null)
    setCursoSeleccionado(null)
    setDocumentosSubidos({})
    setHijoSeleccionado(null)
  }

  const getEstadoBadge = (estado: string) => {
    const colores = {
      Iniciada: "bg-blue-100 text-blue-800",
      DocumentosEntregados: "bg-yellow-100 text-yellow-800",
      EnRevisión: "bg-orange-100 text-orange-800",
      Aprobada: "bg-green-100 text-green-800",
      Rechazada: "bg-red-100 text-red-800",
      Confirmada: "bg-purple-100 text-purple-800",
    }
    return colores[estado as keyof typeof colores] || "bg-gray-100 text-gray-800"
  }

  if (!user) {
    return <div>Cargando...</div>
  }

  return (
    <div className="container mx-auto p-6 max-w-4xl">
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Inscripción y Reinscripción</h1>
        <p className="text-gray-600">Gestiona las solicitudes de inscripción para tus hijos</p>
      </div>

      <Tabs defaultValue="formulario" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="formulario" className="flex items-center gap-2">
            <UserPlus className="w-4 h-4" />
            Nueva Solicitud
          </TabsTrigger>
          <TabsTrigger value="seguimiento" className="flex items-center gap-2">
            <Eye className="w-4 h-4" />
            Seguimiento ({solicitudesExistentes.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="formulario" className="space-y-6">
          {/* Barra de progreso */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-green-600" />
                Progreso del Formulario
              </CardTitle>
              <Progress value={progreso} className="w-full" />
              <p className="text-sm text-gray-600">{Math.round(progreso)}% completado</p>
            </CardHeader>
          </Card>

          {/* Tipo de solicitud */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <RefreshCw className="w-5 h-5" />
                Tipo de Solicitud
              </CardTitle>
              <CardDescription>Selecciona si es una inscripción nueva o una reinscripción</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  <Switch
                    id="tipo-solicitud"
                    checked={tipoSolicitud === "reinscripcion"}
                    onCheckedChange={(checked) => setTipoSolicitud(checked ? "reinscripcion" : "inscripcion")}
                  />
                  <Label htmlFor="tipo-solicitud" className="font-medium">
                    {tipoSolicitud === "inscripcion" ? "Inscripción Nueva" : "Reinscripción"}
                  </Label>
                </div>
                <Badge variant={tipoSolicitud === "inscripcion" ? "default" : "secondary"}>
                  {tipoSolicitud === "inscripcion" ? "Nueva" : "Renovación"}
                </Badge>
              </div>
              <Alert className="mt-4">
                <Info className="h-4 w-4" />
                <AlertDescription>
                  {tipoSolicitud === "inscripcion"
                    ? "Para estudiantes que ingresan por primera vez al colegio"
                    : "Para estudiantes que ya estuvieron matriculados y desean continuar"}
                </AlertDescription>
              </Alert>

              {/* Selector de hijo para reinscripción */}
              {tipoSolicitud === "reinscripcion" && hijosRegistrados.length > 0 && (
                <div className="mt-4 space-y-4">
                  <div>
                    <Label htmlFor="hijo-selector">Selecciona el hijo para reinscribir *</Label>
                    <Select value={hijoSeleccionado || ""} onValueChange={(value) => setHijoSeleccionado(value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecciona un hijo registrado" />
                      </SelectTrigger>
                      <SelectContent>
                        {hijosRegistrados.map((hijo) => (
                          <SelectItem key={hijo.id} value={hijo.id}>
                            {hijo.nombre} {hijo.apellido} - {hijo.colegio} ({hijo.grado})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Alerta de documentos vencidos */}
                  {hijoSeleccionado && documentosVencidos.length > 0 && (
                    <Alert>
                      <AlertCircle className="h-4 w-4" />
                      <AlertDescription>
                        <strong>Documentos que requieren renovación:</strong>
                        <ul className="mt-2 list-disc list-inside">
                          {documentosVencidos.map((doc) => {
                            const docInfo = documentosRequeridos.find((d) => d.tipo === doc)
                            return (
                              <li key={doc} className="text-sm">
                                {docInfo?.nombre || doc}
                              </li>
                            )
                          })}
                        </ul>
                      </AlertDescription>
                    </Alert>
                  )}
                </div>
              )}

              {tipoSolicitud === "reinscripcion" && hijosRegistrados.length === 0 && (
                <Alert className="mt-4">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    No se encontraron hijos registrados en el sistema. Contacte con la administración del colegio.
                  </AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>

          {/* Selección de colegio */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <School className="w-5 h-5" />
                Selección de Colegio
              </CardTitle>
              <CardDescription>Elige el colegio donde deseas inscribir al estudiante</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Select
                value={colegioSeleccionado?.toString()}
                onValueChange={(value) => setColegioSeleccionado(Number(value))}
                disabled={tipoSolicitud === "reinscripcion"}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecciona un colegio" />
                </SelectTrigger>
                <SelectContent>
                  {colegiosDisponibles.map((colegio) => (
                    <SelectItem key={colegio.id} value={colegio.id.toString()}>
                      {colegio.nombre}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {tipoSolicitud === "reinscripcion" && (
                <Alert>
                  <Info className="h-4 w-4" />
                  <AlertDescription>
                    El colegio se selecciona automáticamente basado en el registro actual del estudiante.
                  </AlertDescription>
                </Alert>
              )}

              {colegioInfo && (
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-blue-900 mb-2">{colegioInfo.nombre}</h4>
                  <div className="space-y-1 text-sm text-blue-800">
                    <div className="flex items-center gap-2">
                      <MapPin className="w-4 h-4" />
                      {colegioInfo.direccion}
                    </div>
                    <div className="flex items-center gap-2">
                      <Phone className="w-4 h-4" />
                      {colegioInfo.telefono}
                    </div>
                    <div className="flex items-center gap-2">
                      <Mail className="w-4 h-4" />
                      {colegioInfo.email}
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Datos del estudiante */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="w-5 h-5" />
                Datos del Estudiante
              </CardTitle>
              <CardDescription>Información personal básica del estudiante</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="nombre">Nombre *</Label>
                  <Input
                    id="nombre"
                    value={formData.estudiante.nombre}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        estudiante: { ...prev.estudiante, nombre: e.target.value },
                      }))
                    }
                    placeholder="Nombre del estudiante"
                  />
                </div>
                <div>
                  <Label htmlFor="apellido">Apellido *</Label>
                  <Input
                    id="apellido"
                    value={formData.estudiante.apellido}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        estudiante: { ...prev.estudiante, apellido: e.target.value },
                      }))
                    }
                    placeholder="Apellido del estudiante"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="telefono">Teléfono *</Label>
                  <Input
                    id="telefono"
                    value={formData.estudiante.telefono}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        estudiante: { ...prev.estudiante, telefono: e.target.value },
                      }))
                    }
                    placeholder="Número de teléfono"
                  />
                </div>
                <div>
                  <Label htmlFor="nacionalidad">Nacionalidad *</Label>
                  <Select
                    value={formData.estudiante.nacionalidad}
                    onValueChange={(value) =>
                      setFormData((prev) => ({
                        ...prev,
                        estudiante: { ...prev.estudiante, nacionalidad: value },
                      }))
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecciona nacionalidad" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="colombiana">Colombiana</SelectItem>
                      <SelectItem value="venezolana">Venezolana</SelectItem>
                      <SelectItem value="ecuatoriana">Ecuatoriana</SelectItem>
                      <SelectItem value="peruana">Peruana</SelectItem>
                      <SelectItem value="argentina">Argentina</SelectItem>
                      <SelectItem value="chilena">Chilena</SelectItem>
                      <SelectItem value="brasileña">Brasileña</SelectItem>
                      <SelectItem value="mexicana">Mexicana</SelectItem>
                      <SelectItem value="estadounidense">Estadounidense</SelectItem>
                      <SelectItem value="española">Española</SelectItem>
                      <SelectItem value="otra">Otra</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label htmlFor="direccion">Dirección *</Label>
                <Input
                  id="direccion"
                  value={formData.estudiante.direccion}
                  onChange={(e) =>
                    setFormData((prev) => ({
                      ...prev,
                      estudiante: { ...prev.estudiante, direccion: e.target.value },
                    }))
                  }
                  placeholder="Dirección de residencia"
                />
              </div>
            </CardContent>
          </Card>

          {/* Información del Acta */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="w-5 h-5" />
                Información del Acta
              </CardTitle>
              <CardDescription>Datos del acta de nacimiento del estudiante</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="fechaNacimiento">Fecha de Nacimiento *</Label>
                  <Input
                    id="fechaNacimiento"
                    type="date"
                    value={formData.estudiante.fechaNacimiento}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        estudiante: { ...prev.estudiante, fechaNacimiento: e.target.value },
                      }))
                    }
                  />
                  {formData.estudiante.fechaNacimiento && (
                    <p className="text-sm text-gray-600 mt-1">
                      Edad: {calcularEdad(formData.estudiante.fechaNacimiento)} años
                    </p>
                  )}
                </div>
                <div>
                  <Label htmlFor="genero">Sexo *</Label>
                  <Select
                    value={formData.estudiante.genero}
                    onValueChange={(value) =>
                      setFormData((prev) => ({
                        ...prev,
                        estudiante: { ...prev.estudiante, genero: value as "M" | "F" | "Otro" },
                      }))
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecciona sexo" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="M">Masculino</SelectItem>
                      <SelectItem value="F">Femenino</SelectItem>
                      <SelectItem value="Otro">Otro</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="libro">Libro *</Label>
                  <Input
                    id="libro"
                    value={formData.estudiante.libro}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        estudiante: { ...prev.estudiante, libro: e.target.value },
                      }))
                    }
                    placeholder="Número de libro"
                  />
                </div>
                <div>
                  <Label htmlFor="folio">Folio *</Label>
                  <Input
                    id="folio"
                    value={formData.estudiante.folio}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        estudiante: { ...prev.estudiante, folio: e.target.value },
                      }))
                    }
                    placeholder="Número de folio"
                  />
                </div>
                <div>
                  <Label htmlFor="acta">Acta *</Label>
                  <Input
                    id="acta"
                    value={formData.estudiante.acta}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        estudiante: { ...prev.estudiante, acta: e.target.value },
                      }))
                    }
                    placeholder="Número de acta"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Datos de Emergencia */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertCircle className="w-5 h-5" />
                Datos de Emergencia
              </CardTitle>
              <CardDescription>Información médica y de contacto de emergencia</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="conQuienReside">¿Con quién reside? *</Label>
                  <Input
                    id="conQuienReside"
                    value={formData.estudiante.conQuienReside}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        estudiante: { ...prev.estudiante, conQuienReside: e.target.value },
                      }))
                    }
                    placeholder="Con quién vive el estudiante"
                  />
                </div>
                <div>
                  <Label htmlFor="emergenciaLlamarA">Emergencia llamar a *</Label>
                  <Input
                    id="emergenciaLlamarA"
                    value={formData.estudiante.emergenciaLlamarA}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        estudiante: { ...prev.estudiante, emergenciaLlamarA: e.target.value },
                      }))
                    }
                    placeholder="Contacto de emergencia"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="algunaEnfermedad">¿Alguna enfermedad?</Label>
                  <Textarea
                    id="algunaEnfermedad"
                    value={formData.estudiante.algunaEnfermedad}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        estudiante: { ...prev.estudiante, algunaEnfermedad: e.target.value },
                      }))
                    }
                    placeholder="Describa enfermedades o condiciones médicas"
                    rows={3}
                  />
                </div>
                <div>
                  <Label htmlFor="esAlergico">¿Es alérgico?</Label>
                  <Textarea
                    id="esAlergico"
                    value={formData.estudiante.esAlergico}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        estudiante: { ...prev.estudiante, esAlergico: e.target.value },
                      }))
                    }
                    placeholder="Describa alergias conocidas"
                    rows={3}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="esAsegurado">¿Es asegurado? *</Label>
                  <Select
                    value={formData.estudiante.esAsegurado}
                    onChange={(value) =>
                      setFormData((prev) => ({
                        ...prev,
                        estudiante: { ...prev.estudiante, esAsegurado: value },
                      }))
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecciona" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="si">Sí</SelectItem>
                      <SelectItem value="no">No</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="tipoSeguro">Tipo de Seguro</Label>
                  <Select
                    value={formData.estudiante.tipoSeguro}
                    onChange={(value) =>
                      setFormData((prev) => ({
                        ...prev,
                        estudiante: { ...prev.estudiante, tipoSeguro: value },
                      }))
                    }
                    disabled={formData.estudiante.esAsegurado !== "si"}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecciona seguro" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="eps-sura">EPS Sura</SelectItem>
                      <SelectItem value="eps-sanitas">EPS Sanitas</SelectItem>
                      <SelectItem value="eps-compensar">EPS Compensar</SelectItem>
                      <SelectItem value="eps-famisanar">EPS Famisanar</SelectItem>
                      <SelectItem value="eps-salud-total">Salud Total</SelectItem>
                      <SelectItem value="eps-nueva">Nueva EPS</SelectItem>
                      <SelectItem value="sisben">Sisben</SelectItem>
                      <SelectItem value="otro">Otro</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="tipoSangre">Tipo de Sangre *</Label>
                  <Select
                    value={formData.estudiante.tipoSangre}
                    onChange={(value) =>
                      setFormData((prev) => ({
                        ...prev,
                        estudiante: { ...prev.estudiante, tipoSangre: value },
                      }))
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecciona tipo" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="A+">A+</SelectItem>
                      <SelectItem value="A-">A-</SelectItem>
                      <SelectItem value="B+">B+</SelectItem>
                      <SelectItem value="B-">B-</SelectItem>
                      <SelectItem value="AB+">AB+</SelectItem>
                      <SelectItem value="AB-">AB-</SelectItem>
                      <SelectItem value="O+">O+</SelectItem>
                      <SelectItem value="O-">O-</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Curso solicitado */}
          {colegioSeleccionado && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BookOpen className="w-5 h-5" />
                  Curso Solicitado
                </CardTitle>
                <CardDescription>Selecciona el curso para el estudiante</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Select value={cursoSeleccionado?.toString()} onChange={(value) => setCursoSeleccionado(Number(value))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecciona un curso" />
                  </SelectTrigger>
                  <SelectContent>
                    {cursosDisponiblesActuales.map((curso) => (
                      <SelectItem key={curso.id} value={curso.id.toString()}>
                        {curso.nombre} - {curso.grado} (Edades: {curso.edadMinima}-{curso.edadMaxima} años)
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                {cursoInfo && (
                  <div className="bg-green-50 p-4 rounded-lg">
                    <h4 className="font-semibold text-green-900 mb-2">{cursoInfo.nombre}</h4>
                    <div className="space-y-1 text-sm text-green-800">
                      <p>Grado: {cursoInfo.grado}</p>
                      <p>Sección: {cursoInfo.seccion}</p>
                      <p>
                        Edad requerida: {cursoInfo.edadMinima} - {cursoInfo.edadMaxima} años
                      </p>
                    </div>
                  </div>
                )}

                {formData.estudiante.fechaNacimiento && cursoInfo && !validarEdad() && (
                  <Alert>
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>
                      La edad del estudiante ({calcularEdad(formData.estudiante.fechaNacimiento)} años) no es apropiada
                      para este curso (requiere {cursoInfo.edadMinima}-{cursoInfo.edadMaxima} años)
                    </AlertDescription>
                  </Alert>
                )}
              </CardContent>
            </Card>
          )}

          {/* Documentos */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Upload className="w-5 h-5" />
                Documentos Requeridos
              </CardTitle>
              <CardDescription>
                Sube los documentos necesarios para la{" "}
                {tipoSolicitud === "inscripcion" ? "inscripción" : "reinscripción"}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {documentosRequeridos.map((documento) => (
                <div key={documento.tipo} className="border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <FileText className="w-4 h-4" />
                      <span className="font-medium">{documento.nombre}</span>
                      {documento.obligatorio && <Badge variant="destructive">Obligatorio</Badge>}
                    </div>
                    {documentosSubidos[documento.tipo] && <CheckCircle className="w-5 h-5 text-green-600" />}
                  </div>
                  <p className="text-sm text-gray-600 mb-3">{documento.descripcion}</p>
                  <div className="flex items-center gap-2">
                    <Input
                      type="file"
                      accept=".pdf,.jpg,.jpeg,.png"
                      onChange={(e) => {
                        const file = e.target.files?.[0]
                        if (file) handleFileUpload(documento.tipo, file)
                      }}
                      className="flex-1"
                    />
                    {documentosSubidos[documento.tipo] && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setDocumentosSubidos((prev) => {
                            const newDocs = { ...prev }
                            delete newDocs[documento.tipo]
                            return newDocs
                          })
                        }}
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                  {documentosSubidos[documento.tipo] && (
                    <p className="text-sm text-green-600 mt-2">✓ {documentosSubidos[documento.tipo].name}</p>
                  )}
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Observaciones */}
          <Card>
            <CardHeader>
              <CardTitle>Observaciones (Opcional)</CardTitle>
              <CardDescription>Comentarios adicionales sobre la solicitud</CardDescription>
            </CardHeader>
            <CardContent>
              <Textarea
                value={formData.observaciones}
                onChange={(e) => setFormData((prev) => ({ ...prev, observaciones: e.target.value }))}
                placeholder="Escribe cualquier información adicional que consideres relevante..."
                rows={4}
              />
            </CardContent>
          </Card>

          {/* Botón de envío */}
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div className="text-sm text-gray-600">
                  <p>Revisa toda la información antes de enviar</p>
                  <p>Una vez enviada, la solicitud será procesada por el colegio seleccionado</p>
                </div>
                <Button onClick={handleSubmit} className="flex items-center gap-2" size="lg">
                  <Send className="w-4 h-4" />
                  Enviar Solicitud
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="seguimiento" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Eye className="w-5 h-5" />
                Seguimiento de Solicitudes
              </CardTitle>
              <CardDescription>Revisa el estado de todas tus solicitudes de inscripción</CardDescription>
            </CardHeader>
            <CardContent>
              {solicitudesExistentes.length === 0 ? (
                <div className="text-center py-8">
                  <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600">No tienes solicitudes registradas</p>
                  <p className="text-sm text-gray-500">Crea tu primera solicitud en la pestaña "Nueva Solicitud"</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {solicitudesExistentes.map((solicitud) => (
                    <div key={solicitud.id} className="border rounded-lg p-4">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-2">
                          <h3 className="font-semibold">
                            {solicitud.estudiante.nombre} {solicitud.estudiante.apellido}
                          </h3>
                          <Badge className={getEstadoBadge(solicitud.estado)}>{solicitud.estado}</Badge>
                        </div>
                        <span className="text-sm text-gray-500">#{solicitud.id}</span>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                        <div>
                          <p className="text-gray-600">Colegio:</p>
                          <p className="font-medium">{solicitud.nombreColegio}</p>
                        </div>
                        <div>
                          <p className="text-gray-600">Curso:</p>
                          <p className="font-medium">{solicitud.nombreCurso}</p>
                        </div>
                        <div>
                          <p className="text-gray-600">Tipo:</p>
                          <p className="font-medium capitalize">{solicitud.tipo}</p>
                        </div>
                        <div>
                          <p className="text-gray-600">Fecha de solicitud:</p>
                          <p className="font-medium">{new Date(solicitud.fechaCreacion).toLocaleDateString()}</p>
                        </div>
                      </div>

                      {solicitud.observaciones && (
                        <div className="mt-3 p-3 bg-gray-50 rounded">
                          <p className="text-sm text-gray-600">Observaciones:</p>
                          <p className="text-sm">{solicitud.observaciones}</p>
                        </div>
                      )}

                      <div className="mt-3 flex items-center gap-2">
                        <Clock className="w-4 h-4 text-gray-400" />
                        <span className="text-sm text-gray-600">
                          Última actualización: {new Date(solicitud.fechaActualizacion).toLocaleDateString()}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
