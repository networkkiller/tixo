"use client"

import { Header } from "@/components/dashboard/header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts"
import { Download, Printer, TrendingUp, BookOpen, Filter, Bell, AlertTriangle, AlertCircle } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function PadreHistory() {
  // Nuevo estado para filtro por hijo
  const [selectedChild, setSelectedChild] = useState("todos")
  const [selectedYear, setSelectedYear] = useState("2024")
  const [selectedGrade, setSelectedGrade] = useState("todos")
  const [selectedPeriod, setSelectedPeriod] = useState("P1")
  const [selectedCompetency, setSelectedCompetency] = useState("all")

  // Datos de ejemplo para los hijos
  const children = [
    { id: "1", name: "Ana García" },
    { id: "2", name: "Carlos García" },
  ]

  // Replace the existing historicalData with this new structure
  const historicalData = [
    {
      year: "2024",
      grade: "6° Primaria",
      subjects: [
        {
          name: "Matemáticas",
          periods: {
            P1: {
              competencias: {
                comunicativa: { activities: [85, 88, 90], average: 88, weight: 100 },
                pensamiento: { activities: [82, 85, 88], average: 85, weight: 100 },
                cientifica: { activities: [90, 92, 88], average: 90, weight: 100 },
                ambiental: { activities: [85, 87, 89], average: 87, weight: 100 },
                etica: { activities: [88, 90, 85], average: 88, weight: 100 },
                personal: { activities: [86, 89, 91], average: 89, weight: 100 },
              },
              finalGrade: 88,
            },
            P2: {
              competencias: {
                comunicativa: { activities: [90, 88, 92], average: 90, weight: 100 },
                pensamiento: { activities: [85, 87, 90], average: 87, weight: 100 },
                cientifica: { activities: [92, 90, 94], average: 92, weight: 100 },
                ambiental: { activities: [88, 90, 87], average: 88, weight: 100 },
                etica: { activities: [90, 92, 89], average: 90, weight: 100 },
                personal: { activities: [89, 91, 93], average: 91, weight: 100 },
              },
              finalGrade: 90,
            },
            P3: null,
            P4: null,
          },
          teacher: "Prof. Martínez",
          childId: "1",
        },
        {
          name: "Lenguaje",
          periods: {
            P1: {
              competencias: {
                comunicativa: { activities: [92, 90, 94], average: 92, weight: 100 },
                pensamiento: { activities: [78, 80, 82], average: 80, weight: 100 },
                cientifica: { activities: [85, 83, 87], average: 85, weight: 100 },
                ambiental: { activities: [80, 82, 85], average: 82, weight: 100 },
                etica: { activities: [88, 85, 90], average: 88, weight: 100 },
                personal: { activities: [85, 87, 89], average: 87, weight: 100 },
              },
              finalGrade: 86,
            },
            P2: {
              competencias: {
                comunicativa: { activities: [94, 92, 96], average: 94, weight: 100 },
                pensamiento: { activities: [82, 85, 88], average: 85, weight: 100 },
                cientifica: { activities: [87, 85, 89], average: 87, weight: 100 },
                ambiental: { activities: [85, 87, 90], average: 87, weight: 100 },
                etica: { activities: [90, 88, 92], average: 90, weight: 100 },
                personal: { activities: [89, 91, 88], average: 89, weight: 100 },
              },
              finalGrade: 89,
            },
            P3: null,
            P4: null,
          },
          teacher: "Prof. Rodríguez",
          childId: "1",
        },
      ],
    },
  ]

  // Add the competencias MINERD definition
  const competenciasMinerd = [
    {
      id: "comunicativa",
      name: "Comunicativa",
      description: "Capacidad de comunicarse efectivamente",
      icon: "💬",
      color: "bg-blue-500",
    },
    {
      id: "pensamiento",
      name: "Pensamiento Lógico, Creativo y Crítico",
      description: "Resolución de problemas y pensamiento crítico",
      icon: "🧠",
      color: "bg-purple-500",
    },
    {
      id: "cientifica",
      name: "Científica y Tecnológica",
      description: "Comprensión científica y tecnológica",
      icon: "🔬",
      color: "bg-green-500",
    },
    {
      id: "ambiental",
      name: "Ambiental y de la Salud",
      description: "Conciencia ambiental y cuidado de la salud",
      icon: "🌱",
      color: "bg-emerald-500",
    },
    {
      id: "etica",
      name: "Ética y Ciudadana",
      description: "Valores éticos y ciudadanos",
      icon: "❤️",
      color: "bg-red-500",
    },
    {
      id: "personal",
      name: "Desarrollo Personal y Espiritual",
      description: "Crecimiento personal y espiritual",
      icon: "👤",
      color: "bg-orange-500",
    },
  ]

  // Filtrar datos según los filtros seleccionados
  const filteredData = historicalData.filter((data) => {
    return selectedYear === "todos" || data.year === selectedYear
  })

  const filteredGrades = filteredData.filter((data) => {
    return selectedGrade === "todos" || data.grade === selectedGrade
  })

  // Obtener las materias filtradas por hijo
  const getFilteredSubjects = (yearData: any) => {
    return yearData.subjects.filter((subject: any) => {
      return selectedChild === "todos" || subject.childId === selectedChild
    })
  }

  // Replace the chartData preparation with this new version
  const chartData = filteredGrades.flatMap((yearData) => {
    const subjects = getFilteredSubjects(yearData)
    return subjects.flatMap((subject) => {
      const periodData = subject.periods[selectedPeriod]
      if (!periodData) return []

      if (selectedCompetency === "all") {
        return Object.entries(periodData.competencias).map(([compId, compData]) => ({
          name: `${subject.name} - ${competenciasMinerd.find((c) => c.id === compId)?.name}`,
          value: compData.average,
          subject: subject.name,
          competency: compId,
          childName: children.find((c) => c.id === subject.childId)?.name,
        }))
      } else {
        const compData = periodData.competencias[selectedCompetency]
        if (!compData) return []

        return [
          {
            name: subject.name,
            value: compData.average,
            subject: subject.name,
            competency: selectedCompetency,
            childName: children.find((c) => c.id === subject.childId)?.name,
          },
        ]
      }
    })
  })

  // Calcular promedio general
  const calculateAverage = (subjects: any[]) => {
    if (subjects.length === 0) return 0
    const validSubjects = subjects.filter((subject) => subject.periods[selectedPeriod])
    if (validSubjects.length === 0) return 0
    const sum = validSubjects.reduce((acc, subject) => acc + subject.periods[selectedPeriod].finalGrade, 0)
    return sum / validSubjects.length
  }

  const getStatusBadge = (score: number) => {
    if (score >= 90) {
      return <Badge className="bg-green-100 text-green-800 border-green-200">Excelente</Badge>
    } else if (score >= 80) {
      return <Badge className="bg-blue-100 text-blue-800 border-blue-200">Bueno</Badge>
    } else if (score >= 70) {
      return <Badge className="bg-yellow-100 text-yellow-800 border-yellow-200">Regular</Badge>
    } else {
      return <Badge className="bg-red-100 text-red-800 border-red-200">Necesita Mejorar</Badge>
    }
  }

  const getGradeColor = (score: number) => {
    if (score >= 90) {
      return "bg-green-100 text-green-800 border-green-200"
    } else if (score >= 80) {
      return "bg-blue-100 text-blue-800 border-blue-200"
    } else if (score >= 70) {
      return "bg-yellow-100 text-yellow-800 border-yellow-200"
    } else {
      return "bg-red-100 text-red-800 border-red-200"
    }
  }

  // Métricas de mejora por desempeño
  const performanceMetrics = [
    {
      childId: "1",
      status: "improvement",
      icon: "🟢",
      label: "Mejora notable",
      description: "Ana ha mejorado su rendimiento en 3 materias desde el último período",
    },
    {
      childId: "2",
      status: "stable",
      icon: "🟡",
      label: "Mantenimiento estable",
      description: "Carlos mantiene un rendimiento estable en la mayoría de materias",
    },
  ]

  // Alertas inteligentes
  const intelligentAlerts = [
    {
      childId: "1",
      type: "success",
      message: "Tu hijo ha mejorado en 3 materias desde el último período.",
      date: "Hace 2 días",
    },
    {
      childId: "1",
      type: "warning",
      message: "Se detecta descenso en Lengua Española. Revisa recomendaciones del docente.",
      date: "Hace 5 días",
    },
    {
      childId: "2",
      type: "success",
      message: "Carlos mantiene un excelente desempeño en Matemáticas.",
      date: "Hace 3 días",
    },
  ]

  return (
    <div className="flex-1 flex flex-col bg-gray-50">
      <Header title="TIXO - Historial Académico" />

      <main className="flex-1 overflow-y-auto p-6 space-y-6">
        {/* Filtros */}
        <Card className="bg-white border border-gray-200 shadow-sm">
          <CardHeader>
            <CardTitle className="text-gray-800 flex items-center gap-2">
              <Filter className="h-5 w-5 text-indigo-600" />
              Filtros
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
              {/* Filtro por hijo */}
              <div>
                <label className="text-sm text-gray-600 mb-2 block">Hijo/a</label>
                <Select value={selectedChild} onValueChange={setSelectedChild}>
                  <SelectTrigger className="bg-white border-gray-300 text-gray-800">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-white border-gray-200">
                    <SelectItem value="todos">Todos los hijos</SelectItem>
                    {children.map((child) => (
                      <SelectItem key={child.id} value={child.id}>
                        {child.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm text-gray-600 mb-2 block">Año</label>
                <Select value={selectedYear} onValueChange={setSelectedYear}>
                  <SelectTrigger className="bg-white border-gray-300 text-gray-800">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-white border-gray-200">
                    <SelectItem value="todos">Todos los años</SelectItem>
                    <SelectItem value="2024">2024</SelectItem>
                    <SelectItem value="2023">2023</SelectItem>
                    <SelectItem value="2022">2022</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm text-gray-600 mb-2 block">Grado</label>
                <Select value={selectedGrade} onValueChange={setSelectedGrade}>
                  <SelectTrigger className="bg-white border-gray-300 text-gray-800">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-white border-gray-200">
                    <SelectItem value="todos">Todos los grados</SelectItem>
                    <SelectItem value="6° Primaria">6° Primaria</SelectItem>
                    <SelectItem value="5° Primaria">5° Primaria</SelectItem>
                    <SelectItem value="4° Primaria">4° Primaria</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm text-gray-600 mb-2 block">Período</label>
                <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
                  <SelectTrigger className="bg-white border-gray-300 text-gray-800">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-white border-gray-200">
                    <SelectItem value="P1">Período 1</SelectItem>
                    <SelectItem value="P2">Período 2</SelectItem>
                    <SelectItem value="P3">Período 3</SelectItem>
                    <SelectItem value="P4">Período 4</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm text-gray-600 mb-2 block">Competencia</label>
                <Select value={selectedCompetency} onValueChange={setSelectedCompetency}>
                  <SelectTrigger className="bg-white border-gray-300 text-gray-800">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-white border-gray-200">
                    <SelectItem value="all">Todas las competencias</SelectItem>
                    {competenciasMinerd.map((comp) => (
                      <SelectItem key={comp.id} value={comp.id}>
                        {comp.icon} {comp.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Métricas de Mejora y Alertas Inteligentes */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Métricas de Mejora */}
          <Card className="bg-white border border-gray-200 shadow-sm">
            <CardHeader>
              <CardTitle className="text-gray-800 flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-indigo-600" />
                Tendencia de Desempeño
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {performanceMetrics
                  .filter((metric) => selectedChild === "todos" || metric.childId === selectedChild)
                  .map((metric, index) => (
                    <div key={index} className="flex items-center gap-3 p-3 rounded-lg bg-gray-50">
                      <div className="text-2xl">{metric.icon}</div>
                      <div className="flex-1">
                        <div className="font-medium text-gray-800">
                          {selectedChild === "todos"
                            ? `${children.find((c) => c.id === metric.childId)?.name}: ${metric.label}`
                            : metric.label}
                        </div>
                        <div className="text-sm text-gray-600">{metric.description}</div>
                      </div>
                    </div>
                  ))}
              </div>
            </CardContent>
          </Card>

          {/* Alertas Inteligentes */}
          <Card className="bg-white border border-gray-200 shadow-sm">
            <CardHeader>
              <CardTitle className="text-gray-800 flex items-center gap-2">
                <Bell className="h-5 w-5 text-indigo-600" />
                Alertas Inteligentes
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {intelligentAlerts
                  .filter((alert) => selectedChild === "todos" || alert.childId === selectedChild)
                  .map((alert, index) => (
                    <div
                      key={index}
                      className={`p-3 rounded-lg border ${
                        alert.type === "success"
                          ? "bg-green-50 border-green-200"
                          : alert.type === "warning"
                            ? "bg-yellow-50 border-yellow-200"
                            : "bg-red-50 border-red-200"
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        <div
                          className={`p-1 rounded-full ${
                            alert.type === "success"
                              ? "bg-green-100 text-green-600"
                              : alert.type === "warning"
                                ? "bg-yellow-100 text-yellow-600"
                                : "bg-red-100 text-red-600"
                          }`}
                        >
                          {alert.type === "success" ? (
                            <TrendingUp className="h-4 w-4" />
                          ) : alert.type === "warning" ? (
                            <AlertTriangle className="h-4 w-4" />
                          ) : (
                            <AlertCircle className="h-4 w-4" />
                          )}
                        </div>
                        <div className="flex-1">
                          <div className="text-sm font-medium text-gray-800">
                            {selectedChild === "todos"
                              ? `${children.find((c) => c.id === alert.childId)?.name}: ${alert.message}`
                              : alert.message}
                          </div>
                          <div className="text-xs text-gray-500 mt-1">{alert.date}</div>
                        </div>
                      </div>
                    </div>
                  ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Resumen General */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredGrades.map((yearData, index) => {
            const subjects = getFilteredSubjects(yearData)
            const average = calculateAverage(subjects)

            return (
              <Card key={index} className="bg-white border border-gray-200 shadow-sm">
                <CardHeader>
                  <CardTitle className="text-gray-800">
                    {yearData.year} - {yearData.grade}
                    {selectedChild !== "todos" && (
                      <Badge className="ml-2 bg-indigo-100 text-indigo-800">
                        {children.find((c) => c.id === selectedChild)?.name}
                      </Badge>
                    )}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <TrendingUp className="h-5 w-5 text-indigo-600" />
                      <span className="text-gray-600">Promedio {selectedPeriod}:</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-xl font-bold text-gray-800">{average.toFixed(1)}</span>
                      {getStatusBadge(average)}
                    </div>
                  </div>

                  <div className="text-sm text-gray-600">
                    Materias evaluadas: {subjects.filter((s) => s.periods[selectedPeriod]).length} de {subjects.length}
                  </div>

                  <div className="flex justify-end gap-2">
                    <Button size="sm" className="bg-indigo-600 hover:bg-indigo-700">
                      <Download className="h-4 w-4 mr-2" />
                      Descargar PDF
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="border-gray-300 text-gray-700 hover:bg-gray-100 bg-transparent"
                    >
                      <Printer className="h-4 w-4 mr-2" />
                      Imprimir
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>

        {/* Gráfico de Evolución */}
        <Card className="bg-white border border-gray-200 shadow-sm">
          <CardHeader>
            <CardTitle className="text-gray-800">Evolución Académica</CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="line">
              <TabsList className="mb-4">
                <TabsTrigger value="line">Línea</TabsTrigger>
                <TabsTrigger value="bar">Barras</TabsTrigger>
              </TabsList>
              <TabsContent value="line">
                <ResponsiveContainer width="100%" height={400}>
                  <LineChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                    <XAxis dataKey="name" stroke="#6b7280" />
                    <YAxis stroke="#6b7280" domain={[0, 100]} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "#ffffff",
                        border: "1px solid #e5e7eb",
                        borderRadius: "8px",
                      }}
                      formatter={(value, name, props) => {
                        // Mostrar el nombre del hijo si estamos mostrando todos
                        if (selectedChild === "todos" && props.payload.childName) {
                          return [`${value} (${props.payload.childName})`, name]
                        }
                        return [value, name]
                      }}
                    />
                    <Legend />
                    <Line
                      type="monotone"
                      dataKey="value"
                      stroke="#3b82f6"
                      strokeWidth={2}
                      dot={{ r: 4 }}
                      activeDot={{ r: 6 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </TabsContent>
              <TabsContent value="bar">
                <div className="text-center py-8 text-gray-600">Gráfico de barras disponible próximamente</div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        {/* Tabla de Calificaciones Históricas */}
        {filteredGrades.map((yearData, yearIndex) => {
          const subjects = getFilteredSubjects(yearData)

          return (
            <Card key={yearIndex} className="bg-white border border-gray-200 shadow-sm">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="text-gray-800">
                  {yearData.year} - {yearData.grade} - {selectedPeriod}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="grades" className="w-full">
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="grades">Calificaciones por Período</TabsTrigger>
                    <TabsTrigger value="competencies">Detalle por Competencias</TabsTrigger>
                  </TabsList>

                  <TabsContent value="grades">
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow className="border-gray-200">
                            <TableHead className="text-gray-600">Materia</TableHead>
                            {selectedChild === "todos" && <TableHead className="text-gray-600">Hijo/a</TableHead>}
                            <TableHead className="text-gray-600 text-center">P1</TableHead>
                            <TableHead className="text-gray-600 text-center">P2</TableHead>
                            <TableHead className="text-gray-600 text-center">P3</TableHead>
                            <TableHead className="text-gray-600 text-center">P4</TableHead>
                            <TableHead className="text-gray-600">Profesor</TableHead>
                            <TableHead className="text-gray-600 text-center">Estado</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {subjects.map((subject, index) => (
                            <TableRow key={index} className="border-gray-200 hover:bg-gray-50">
                              <TableCell className="font-medium text-gray-800">
                                <div className="flex items-center gap-2">
                                  <BookOpen className="h-4 w-4" />
                                  {subject.name}
                                </div>
                              </TableCell>
                              {selectedChild === "todos" && (
                                <TableCell className="text-gray-600">
                                  {children.find((c) => c.id === subject.childId)?.name}
                                </TableCell>
                              )}
                              <TableCell className="text-center text-gray-600">
                                {subject.periods.P1 ? (
                                  <Badge className={getGradeColor(subject.periods.P1.finalGrade)}>
                                    {subject.periods.P1.finalGrade}
                                  </Badge>
                                ) : (
                                  <span className="text-gray-400">-</span>
                                )}
                              </TableCell>
                              <TableCell className="text-center text-gray-600">
                                {subject.periods.P2 ? (
                                  <Badge className={getGradeColor(subject.periods.P2.finalGrade)}>
                                    {subject.periods.P2.finalGrade}
                                  </Badge>
                                ) : (
                                  <span className="text-gray-400">-</span>
                                )}
                              </TableCell>
                              <TableCell className="text-center text-gray-600">
                                {subject.periods.P3 ? (
                                  <Badge className={getGradeColor(subject.periods.P3.finalGrade)}>
                                    {subject.periods.P3.finalGrade}
                                  </Badge>
                                ) : (
                                  <span className="text-gray-400">-</span>
                                )}
                              </TableCell>
                              <TableCell className="text-center text-gray-600">
                                {subject.periods.P4 ? (
                                  <Badge className={getGradeColor(subject.periods.P4.finalGrade)}>
                                    {subject.periods.P4.finalGrade}
                                  </Badge>
                                ) : (
                                  <span className="text-gray-400">-</span>
                                )}
                              </TableCell>
                              <TableCell className="text-gray-600">{subject.teacher}</TableCell>
                              <TableCell className="text-center">
                                {subject.periods[selectedPeriod] ? (
                                  getStatusBadge(subject.periods[selectedPeriod].finalGrade)
                                ) : (
                                  <Badge className="bg-gray-100 text-gray-600">Pendiente</Badge>
                                )}
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  </TabsContent>

                  <TabsContent value="competencies">
                    <div className="space-y-4">
                      {subjects.map((subject, subjectIndex) => {
                        const periodData = subject.periods[selectedPeriod]
                        if (!periodData) return null

                        return (
                          <Card key={subjectIndex} className="border border-gray-200">
                            <CardHeader>
                              <CardTitle className="text-lg flex items-center gap-2">
                                <BookOpen className="h-5 w-5" />
                                {subject.name} - {selectedPeriod}
                                {selectedChild === "todos" && (
                                  <Badge className="ml-2">{children.find((c) => c.id === subject.childId)?.name}</Badge>
                                )}
                              </CardTitle>
                            </CardHeader>
                            <CardContent>
                              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                                {competenciasMinerd.map((competencia) => {
                                  const compData = periodData.competencias[competencia.id]
                                  if (!compData) return null

                                  return (
                                    <div key={competencia.id} className="p-4 border rounded-lg bg-gray-50">
                                      <div className="flex items-center gap-2 mb-2">
                                        <span className="text-lg">{competencia.icon}</span>
                                        <div>
                                          <div className="font-medium text-sm">{competencia.name}</div>
                                          <div className="text-xs text-gray-600">{competencia.description}</div>
                                        </div>
                                      </div>
                                      <div className="flex items-center justify-between">
                                        <div className="text-2xl font-bold">{compData.average}</div>
                                        <Badge className={getGradeColor(compData.average)}>
                                          {compData.average >= 90
                                            ? "Excelente"
                                            : compData.average >= 80
                                              ? "Bueno"
                                              : compData.average >= 70
                                                ? "Regular"
                                                : "Necesita Mejorar"}
                                        </Badge>
                                      </div>
                                      <div className="mt-2 text-xs text-gray-600">
                                        Actividades: {compData.activities.join(", ")}
                                      </div>
                                    </div>
                                  )
                                })}
                              </div>
                            </CardContent>
                          </Card>
                        )
                      })}
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          )
        })}
      </main>
    </div>
  )
}
