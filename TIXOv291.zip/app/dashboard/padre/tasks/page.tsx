"use client"

import { Header } from "@/components/dashboard/header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  BookOpen,
  CheckCircle,
  Clock,
  Eye,
  Download,
  FileText,
  BarChart3,
  TrendingUp,
  Calendar,
  User,
  GraduationCap,
  Target,
  Award,
  AlertTriangle,
} from "lucide-react"
import { useState } from "react"
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  PieChart as RechartsPieChart,
  Pie,
  Cell,
} from "recharts"

export default function PadreTasks() {
  const [selectedChild, setSelectedChild] = useState("1")
  const [selectedPeriod, setSelectedPeriod] = useState("P3")
  const [selectedSubject, setSelectedSubject] = useState("todas")

  // Datos de ejemplo para los hijos
  const children = [
    {
      id: "1",
      name: "Mariana Alcántara",
      course: "5to B",
      section: "B",
      shift: "Mañana",
      photo: "/placeholder.svg?height=60&width=60&text=MA",
    },
    {
      id: "2",
      name: "Daniel Alcántara",
      course: "3ro A",
      section: "A",
      shift: "Tarde",
      photo: "/placeholder.svg?height=60&width=60&text=DA",
    },
  ]

  const selectedChildData = children.find((child) => child.id === selectedChild)

  // Datos de ejemplo para las tareas
  const tasks = [
    {
      id: 1,
      subject: "Matemáticas",
      date: "2024-09-02",
      title: "Maqueta de fracciones",
      type: "Maqueta",
      competence: "Resolución de Problemas",
      score: 85,
      maxScore: 100,
      period: "P3",
      status: "delivered",
      teacher: "Prof. Ana Rodríguez",
      deliveryDate: "2024-09-05",
      gradeDate: "2024-09-07",
      instructions:
        "Crear una maqueta que represente fracciones equivalentes usando materiales reciclables. Debe incluir al menos 5 ejemplos diferentes de fracciones equivalentes.",
      attachments: ["guia_maqueta_fracciones.pdf", "ejemplos_fracciones.jpg"],
      studentWork:
        "La estudiante presentó una maqueta creativa usando cartón y colores. Demostró comprensión clara del concepto de fracciones equivalentes.",
      teacherComments: "Excelente trabajo creativo. La maqueta muestra dominio del tema. Mejorar la presentación oral.",
      contribution: 15,
      childId: "1",
    },
    {
      id: 2,
      subject: "Ciencias",
      date: "2024-09-05",
      title: "Ensayo sobre hábitats",
      type: "Ensayo",
      competence: "Ambiental y de la Salud",
      score: 92,
      maxScore: 100,
      period: "P3",
      status: "delivered",
      teacher: "Prof. Carlos Méndez",
      deliveryDate: "2024-09-10",
      gradeDate: "2024-09-12",
      instructions:
        "Escribir un ensayo de 500 palabras sobre los diferentes tipos de hábitats y su importancia para la biodiversidad.",
      attachments: ["formato_ensayo.docx", "recursos_habitats.pdf"],
      studentWork:
        "Ensayo bien estructurado con introducción, desarrollo y conclusión. Incluyó ejemplos locales de hábitats.",
      teacherComments: "Muy buen análisis y uso de ejemplos. Excelente redacción y ortografía.",
      contribution: 20,
      childId: "1",
    },
    {
      id: 3,
      subject: "Lenguaje",
      date: "2024-09-08",
      title: "Análisis literario - El Quijote",
      type: "Ensayo",
      competence: "Comunicativa",
      score: 78,
      maxScore: 100,
      period: "P3",
      status: "delivered",
      teacher: "Prof. María González",
      deliveryDate: "2024-09-15",
      gradeDate: "2024-09-17",
      instructions:
        "Realizar un análisis literario de los primeros 3 capítulos de Don Quijote de la Mancha, enfocándose en los personajes principales.",
      attachments: ["capitulos_quijote.pdf", "guia_analisis.docx"],
      studentWork:
        "Análisis detallado de los personajes principales. Identificó correctamente las características de Don Quijote y Sancho Panza.",
      teacherComments: "Buen análisis de personajes. Mejorar la profundidad en el análisis del contexto histórico.",
      contribution: 25,
      childId: "1",
    },
    {
      id: 4,
      subject: "Sociales",
      date: "2024-09-12",
      title: "Mapa conceptual - Independencia",
      type: "Mapa Conceptual",
      competence: "Ética y Ciudadana",
      score: 88,
      maxScore: 100,
      period: "P3",
      status: "delivered",
      teacher: "Prof. Luis Fernández",
      deliveryDate: "2024-09-18",
      gradeDate: "2024-09-20",
      instructions:
        "Crear un mapa conceptual sobre los eventos principales de la Independencia Dominicana, incluyendo fechas, personajes y consecuencias.",
      attachments: ["plantilla_mapa.pdf", "cronologia_independencia.docx"],
      studentWork:
        "Mapa conceptual bien organizado con conexiones claras entre eventos. Incluyó fechas importantes y personajes clave.",
      teacherComments: "Excelente organización visual. Demostró comprensión de la secuencia histórica.",
      contribution: 18,
      childId: "1",
    },
    {
      id: 5,
      subject: "Inglés",
      date: "2024-09-15",
      title: "Presentación oral - My Family",
      type: "Presentación",
      competence: "Comunicativa",
      score: 0,
      maxScore: 100,
      period: "P3",
      status: "pending",
      teacher: "Prof. Jennifer Smith",
      deliveryDate: "2024-09-22",
      gradeDate: null,
      instructions:
        "Preparar una presentación oral de 3 minutos sobre tu familia usando vocabulario y estructuras aprendidas en clase.",
      attachments: ["vocabulary_family.pdf", "presentation_rubric.pdf"],
      studentWork: null,
      teacherComments: null,
      contribution: 20,
      childId: "1",
    },
    // Tareas para el segundo hijo
    {
      id: 6,
      subject: "Matemáticas",
      date: "2024-09-03",
      title: "Ejercicios de suma y resta",
      type: "Práctica",
      competence: "Resolución de Problemas",
      score: 95,
      maxScore: 100,
      period: "P3",
      status: "delivered",
      teacher: "Prof. Carmen Jiménez",
      deliveryDate: "2024-09-05",
      gradeDate: "2024-09-06",
      instructions: "Resolver 20 ejercicios de suma y resta con números de hasta 3 dígitos.",
      attachments: ["ejercicios_suma_resta.pdf"],
      studentWork: "Completó todos los ejercicios correctamente. Mostró buen dominio de las operaciones básicas.",
      teacherComments: "Excelente trabajo. Muy ordenado y preciso en los cálculos.",
      contribution: 25,
      childId: "2",
    },
    {
      id: 7,
      subject: "Ciencias",
      date: "2024-09-07",
      title: "Experimento - Estados del agua",
      type: "Experimento",
      competence: "Pensamiento Lógico",
      score: 90,
      maxScore: 100,
      period: "P3",
      status: "delivered",
      teacher: "Prof. Roberto Pérez",
      deliveryDate: "2024-09-10",
      gradeDate: "2024-09-11",
      instructions: "Realizar experimento casero para observar los tres estados del agua y documentar los cambios.",
      attachments: ["guia_experimento.pdf", "hoja_observacion.docx"],
      studentWork: "Realizó el experimento correctamente y documentó las observaciones con dibujos y descripciones.",
      teacherComments: "Muy buen trabajo de observación. Excelente documentación del proceso.",
      contribution: 30,
      childId: "2",
    },
  ]

  const filteredTasks = tasks.filter((task) => {
    const matchesChild = task.childId === selectedChild
    const matchesPeriod = selectedPeriod === "todos" || task.period === selectedPeriod
    const matchesSubject = selectedSubject === "todas" || task.subject === selectedSubject
    return matchesChild && matchesPeriod && matchesSubject
  })

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "delivered":
        return <Badge className="bg-green-100 text-green-800 border-green-200">✅ Entregado</Badge>
      case "pending":
        return <Badge className="bg-yellow-100 text-yellow-800 border-yellow-200">⏳ Pendiente</Badge>
      case "late":
        return <Badge className="bg-red-100 text-red-800 border-red-200">🔴 Atrasado</Badge>
      default:
        return null
    }
  }

  const getScoreColor = (score: number, maxScore: number) => {
    if (score === 0) return "text-gray-500"
    const percentage = (score / maxScore) * 100
    if (percentage >= 90) return "text-green-600 font-bold"
    if (percentage >= 80) return "text-blue-600 font-bold"
    if (percentage >= 70) return "text-yellow-600 font-bold"
    return "text-red-600 font-bold"
  }

  // Datos para análisis
  const taskStats = {
    total: filteredTasks.length,
    delivered: filteredTasks.filter((t) => t.status === "delivered").length,
    pending: filteredTasks.filter((t) => t.status === "pending").length,
    average:
      filteredTasks.filter((t) => t.score > 0).reduce((acc, t) => acc + t.score, 0) /
        filteredTasks.filter((t) => t.score > 0).length || 0,
  }

  // Datos para gráficos
  const subjectPerformance = [
    { subject: "Matemáticas", average: 85, tasks: 2 },
    { subject: "Ciencias", average: 92, tasks: 1 },
    { subject: "Lenguaje", average: 78, tasks: 1 },
    { subject: "Sociales", average: 88, tasks: 1 },
    { subject: "Inglés", average: 0, tasks: 1 },
  ].filter((item) => item.average > 0)

  const taskTypeDistribution = [
    { name: "Ensayo", value: 2, color: "#8884d8" },
    { name: "Maqueta", value: 1, color: "#82ca9d" },
    { name: "Mapa Conceptual", value: 1, color: "#ffc658" },
    { name: "Presentación", value: 1, color: "#ff7300" },
  ]

  const performanceTrend = [
    { task: "Tarea 1", score: 85 },
    { task: "Tarea 2", score: 92 },
    { task: "Tarea 3", score: 78 },
    { task: "Tarea 4", score: 88 },
  ]

  return (
    <div className="flex-1 flex flex-col bg-gray-50">
      <Header title="📝 Tareas y Actividades" />

      <main className="flex-1 overflow-y-auto p-6 space-y-6">
        {/* Selección de Hijo */}
        <Card className="bg-white border border-gray-200 shadow-sm">
          <CardHeader>
            <CardTitle className="text-gray-800 flex items-center gap-2">
              <User className="h-5 w-5 text-indigo-600" />
              Seleccionar Estudiante
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {children.map((child) => (
                <div
                  key={child.id}
                  className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                    selectedChild === child.id
                      ? "border-indigo-500 bg-indigo-50"
                      : "border-gray-200 bg-white hover:border-gray-300"
                  }`}
                  onClick={() => setSelectedChild(child.id)}
                >
                  <div className="flex items-center gap-4">
                    <img
                      src={child.photo || "/placeholder.svg"}
                      alt={child.name}
                      className="w-12 h-12 rounded-full object-cover"
                    />
                    <div>
                      <h3 className="font-semibold text-gray-800">{child.name}</h3>
                      <p className="text-sm text-gray-600">
                        {child.course} - Turno: {child.shift}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {selectedChildData && (
          <>
            {/* Encabezado del Estudiante */}
            <Card className="bg-gradient-to-r from-indigo-500 to-purple-600 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <img
                      src={selectedChildData.photo || "/placeholder.svg"}
                      alt={selectedChildData.name}
                      className="w-16 h-16 rounded-full object-cover border-4 border-white"
                    />
                    <div>
                      <h2 className="text-2xl font-bold">{selectedChildData.name}</h2>
                      <p className="text-indigo-100">
                        {selectedChildData.course} - Sección {selectedChildData.section} - Turno:{" "}
                        {selectedChildData.shift}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-3xl font-bold">{taskStats.average.toFixed(1)}</div>
                    <div className="text-indigo-100">Promedio General</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Filtros y Controles */}
            <Card className="bg-white border border-gray-200 shadow-sm">
              <CardContent className="p-4">
                <div className="flex flex-wrap items-center gap-4">
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-gray-500" />
                    <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
                      <SelectTrigger className="w-32 bg-white border-gray-300">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-white border-gray-200">
                        <SelectItem value="todos">Todos</SelectItem>
                        <SelectItem value="P1">P1</SelectItem>
                        <SelectItem value="P2">P2</SelectItem>
                        <SelectItem value="P3">P3</SelectItem>
                        <SelectItem value="P4">P4</SelectItem>
                        <SelectItem value="RP1">RP1</SelectItem>
                        <SelectItem value="RP2">RP2</SelectItem>
                        <SelectItem value="RP3">RP3</SelectItem>
                        <SelectItem value="RP4">RP4</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex items-center gap-2">
                    <BookOpen className="h-4 w-4 text-gray-500" />
                    <Select value={selectedSubject} onValueChange={setSelectedSubject}>
                      <SelectTrigger className="w-40 bg-white border-gray-300">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-white border-gray-200">
                        <SelectItem value="todas">Todas las materias</SelectItem>
                        <SelectItem value="Matemáticas">Matemáticas</SelectItem>
                        <SelectItem value="Ciencias">Ciencias</SelectItem>
                        <SelectItem value="Lenguaje">Lenguaje</SelectItem>
                        <SelectItem value="Sociales">Sociales</SelectItem>
                        <SelectItem value="Inglés">Inglés</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="ml-auto flex gap-2">
                    <Button variant="outline" size="sm" className="flex items-center gap-2 bg-transparent">
                      <Download className="h-4 w-4" />
                      Exportar PDF
                    </Button>
                    <Button variant="outline" size="sm" className="flex items-center gap-2 bg-transparent">
                      <FileText className="h-4 w-4" />
                      Exportar Excel
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Estadísticas Rápidas */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card className="bg-white border border-gray-200 shadow-sm">
                <CardContent className="p-4 text-center">
                  <FileText className="h-8 w-8 text-blue-500 mx-auto mb-2" />
                  <div className="text-2xl font-bold text-gray-800">{taskStats.total}</div>
                  <div className="text-sm text-gray-600">Total Tareas</div>
                </CardContent>
              </Card>

              <Card className="bg-white border border-gray-200 shadow-sm">
                <CardContent className="p-4 text-center">
                  <CheckCircle className="h-8 w-8 text-green-500 mx-auto mb-2" />
                  <div className="text-2xl font-bold text-gray-800">{taskStats.delivered}</div>
                  <div className="text-sm text-gray-600">Entregadas</div>
                </CardContent>
              </Card>

              <Card className="bg-white border border-gray-200 shadow-sm">
                <CardContent className="p-4 text-center">
                  <Clock className="h-8 w-8 text-yellow-500 mx-auto mb-2" />
                  <div className="text-2xl font-bold text-gray-800">{taskStats.pending}</div>
                  <div className="text-sm text-gray-600">Pendientes</div>
                </CardContent>
              </Card>

              <Card className="bg-white border border-gray-200 shadow-sm">
                <CardContent className="p-4 text-center">
                  <Award className="h-8 w-8 text-purple-500 mx-auto mb-2" />
                  <div className="text-2xl font-bold text-gray-800">{taskStats.average.toFixed(1)}</div>
                  <div className="text-sm text-gray-600">Promedio</div>
                </CardContent>
              </Card>
            </div>

            {/* Tabla de Tareas */}
            <Card className="bg-white border border-gray-200 shadow-sm">
              <CardHeader>
                <CardTitle className="text-gray-800">Lista de Tareas y Actividades</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow className="border-gray-200">
                        <TableHead className="text-gray-600">Materia</TableHead>
                        <TableHead className="text-gray-600">Fecha</TableHead>
                        <TableHead className="text-gray-600">Actividad</TableHead>
                        <TableHead className="text-gray-600">Tipo</TableHead>
                        <TableHead className="text-gray-600">Competencia</TableHead>
                        <TableHead className="text-gray-600">Calificación</TableHead>
                        <TableHead className="text-gray-600">Estado</TableHead>
                        <TableHead className="text-gray-600">Acción</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredTasks.map((task) => (
                        <TableRow key={task.id} className="border-gray-200 hover:bg-gray-50">
                          <TableCell className="font-medium text-gray-800">
                            <div className="flex items-center gap-2">
                              <BookOpen className="h-4 w-4 text-gray-500" />
                              {task.subject}
                            </div>
                          </TableCell>
                          <TableCell className="text-gray-600">
                            {new Date(task.date).toLocaleDateString("es-ES")}
                          </TableCell>
                          <TableCell className="text-gray-800 font-medium">{task.title}</TableCell>
                          <TableCell>
                            <Badge variant="outline" className="text-xs">
                              {task.type}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-gray-600 text-sm">{task.competence}</TableCell>
                          <TableCell>
                            <span className={getScoreColor(task.score, task.maxScore)}>
                              {task.score > 0 ? `${task.score}/${task.maxScore}` : "Sin calificar"}
                            </span>
                          </TableCell>
                          <TableCell>{getStatusBadge(task.status)}</TableCell>
                          <TableCell>
                            <Dialog>
                              <DialogTrigger asChild>
                                <Button variant="ghost" size="sm" className="flex items-center gap-1">
                                  <Eye className="h-4 w-4" />
                                  Ver detalle
                                </Button>
                              </DialogTrigger>
                              <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto bg-white">
                                <DialogHeader>
                                  <DialogTitle className="text-xl text-gray-800">Detalle de la Actividad</DialogTitle>
                                </DialogHeader>

                                <div className="space-y-6">
                                  {/* Información General */}
                                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-gray-50 rounded-lg">
                                    <div>
                                      <h4 className="font-semibold text-gray-800 mb-2">📘 Información General</h4>
                                      <div className="space-y-1 text-sm">
                                        <p>
                                          <span className="font-medium">Profesor:</span> {task.teacher}
                                        </p>
                                        <p>
                                          <span className="font-medium">Materia:</span> {task.subject}
                                        </p>
                                        <p>
                                          <span className="font-medium">Período:</span> {task.period}
                                        </p>
                                        <p>
                                          <span className="font-medium">Competencia:</span> {task.competence}
                                        </p>
                                        <p>
                                          <span className="font-medium">Tipo:</span> {task.type}
                                        </p>
                                      </div>
                                    </div>
                                    <div>
                                      <h4 className="font-semibold text-gray-800 mb-2">📅 Fechas Importantes</h4>
                                      <div className="space-y-1 text-sm">
                                        <p>
                                          <span className="font-medium">Fecha de asignación:</span>{" "}
                                          {new Date(task.date).toLocaleDateString("es-ES")}
                                        </p>
                                        <p>
                                          <span className="font-medium">Fecha de entrega:</span>{" "}
                                          {new Date(task.deliveryDate).toLocaleDateString("es-ES")}
                                        </p>
                                        {task.gradeDate && (
                                          <p>
                                            <span className="font-medium">Fecha de calificación:</span>{" "}
                                            {new Date(task.gradeDate).toLocaleDateString("es-ES")}
                                          </p>
                                        )}
                                      </div>
                                    </div>
                                  </div>

                                  {/* Instrucciones del Profesor */}
                                  <div className="p-4 border border-blue-200 rounded-lg bg-blue-50">
                                    <h4 className="font-semibold text-gray-800 mb-3 flex items-center gap-2">
                                      <GraduationCap className="h-5 w-5 text-blue-600" />📑 Instrucciones del Profesor
                                    </h4>
                                    <div className="space-y-3">
                                      <div>
                                        <h5 className="font-medium text-gray-700">Título:</h5>
                                        <p className="text-gray-600">{task.title}</p>
                                      </div>
                                      <div>
                                        <h5 className="font-medium text-gray-700">Descripción:</h5>
                                        <p className="text-gray-600">{task.instructions}</p>
                                      </div>
                                      {task.attachments && task.attachments.length > 0 && (
                                        <div>
                                          <h5 className="font-medium text-gray-700">Recursos adjuntos:</h5>
                                          <div className="flex flex-wrap gap-2 mt-1">
                                            {task.attachments.map((attachment, index) => (
                                              <Badge key={index} variant="outline" className="text-xs">
                                                📎 {attachment}
                                              </Badge>
                                            ))}
                                          </div>
                                        </div>
                                      )}
                                    </div>
                                  </div>

                                  {/* Trabajo del Estudiante */}
                                  {task.studentWork && (
                                    <div className="p-4 border border-green-200 rounded-lg bg-green-50">
                                      <h4 className="font-semibold text-gray-800 mb-3 flex items-center gap-2">
                                        <User className="h-5 w-5 text-green-600" />
                                        🧑‍🎓 Trabajo del Estudiante
                                      </h4>
                                      <p className="text-gray-600">{task.studentWork}</p>
                                    </div>
                                  )}

                                  {/* Calificación y Comentarios */}
                                  <div className="p-4 border border-purple-200 rounded-lg bg-purple-50">
                                    <h4 className="font-semibold text-gray-800 mb-3 flex items-center gap-2">
                                      <Target className="h-5 w-5 text-purple-600" />🧮 Calificación y Retroalimentación
                                    </h4>
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                      <div>
                                        <h5 className="font-medium text-gray-700">Calificación:</h5>
                                        <div className="flex items-center gap-2">
                                          <span
                                            className={`text-2xl font-bold ${getScoreColor(task.score, task.maxScore)}`}
                                          >
                                            {task.score > 0 ? `${task.score}/${task.maxScore}` : "Sin calificar"}
                                          </span>
                                          {task.score > 0 && (
                                            <span className="text-sm text-gray-500">
                                              ({((task.score / task.maxScore) * 100).toFixed(1)}%)
                                            </span>
                                          )}
                                        </div>
                                        <p className="text-sm text-gray-600 mt-1">
                                          Contribución al período: {task.contribution}%
                                        </p>
                                      </div>
                                      <div>
                                        <h5 className="font-medium text-gray-700">Estado:</h5>
                                        <div className="mt-1">{getStatusBadge(task.status)}</div>
                                      </div>
                                    </div>
                                    {task.teacherComments && (
                                      <div className="mt-4">
                                        <h5 className="font-medium text-gray-700">Comentarios del profesor:</h5>
                                        <p className="text-gray-600 italic">"{task.teacherComments}"</p>
                                      </div>
                                    )}
                                  </div>
                                </div>
                              </DialogContent>
                            </Dialog>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>

            {/* Análisis y Visualizaciones */}
            <Card className="bg-white border border-gray-200 shadow-sm">
              <CardHeader>
                <CardTitle className="text-gray-800 flex items-center gap-2">
                  <BarChart3 className="h-5 w-5 text-indigo-600" />📈 Análisis de Rendimiento por Tareas
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="performance" className="w-full">
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="performance">Rendimiento por Materia</TabsTrigger>
                    <TabsTrigger value="distribution">Distribución de Tipos</TabsTrigger>
                    <TabsTrigger value="trend">Tendencia de Notas</TabsTrigger>
                  </TabsList>

                  <TabsContent value="performance" className="space-y-4">
                    <div className="h-80">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={subjectPerformance}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="subject" />
                          <YAxis domain={[0, 100]} />
                          <Tooltip />
                          <Bar dataKey="average" fill="#8884d8" />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </TabsContent>

                  <TabsContent value="distribution" className="space-y-4">
                    <div className="h-80">
                      <ResponsiveContainer width="100%" height="100%">
                        <RechartsPieChart>
                          <Pie
                            data={taskTypeDistribution}
                            cx="50%"
                            cy="50%"
                            outerRadius={80}
                            fill="#8884d8"
                            dataKey="value"
                            label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                          >
                            {taskTypeDistribution.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={entry.color} />
                            ))}
                          </Pie>
                          <Tooltip />
                        </RechartsPieChart>
                      </ResponsiveContainer>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">
                      {taskTypeDistribution.map((item, index) => (
                        <div key={index} className="flex items-center gap-2">
                          <div className="w-4 h-4 rounded-full" style={{ backgroundColor: item.color }} />
                          <span className="text-sm text-gray-600">
                            {item.name}: {item.value}
                          </span>
                        </div>
                      ))}
                    </div>
                  </TabsContent>

                  <TabsContent value="trend" className="space-y-4">
                    <div className="h-80">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={performanceTrend}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="task" />
                          <YAxis domain={[0, 100]} />
                          <Tooltip />
                          <Line type="monotone" dataKey="score" stroke="#8884d8" strokeWidth={2} />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                  </TabsContent>
                </Tabs>

                {/* Indicadores Clave */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mt-6">
                  <div className="p-4 bg-blue-50 rounded-lg text-center">
                    <TrendingUp className="h-8 w-8 text-blue-500 mx-auto mb-2" />
                    <div className="text-2xl font-bold text-blue-700">{taskStats.average.toFixed(1)}</div>
                    <div className="text-sm text-blue-600">Promedio General</div>
                  </div>

                  <div className="p-4 bg-green-50 rounded-lg text-center">
                    <CheckCircle className="h-8 w-8 text-green-500 mx-auto mb-2" />
                    <div className="text-2xl font-bold text-green-700">
                      {Math.round((taskStats.delivered / taskStats.total) * 100)}%
                    </div>
                    <div className="text-sm text-green-600">Tareas Entregadas</div>
                  </div>

                  <div className="p-4 bg-purple-50 rounded-lg text-center">
                    <Award className="h-8 w-8 text-purple-500 mx-auto mb-2" />
                    <div className="text-2xl font-bold text-purple-700">
                      {filteredTasks.filter((t) => t.score >= 90).length}
                    </div>
                    <div className="text-sm text-purple-600">Calificaciones ≥90</div>
                  </div>

                  <div className="p-4 bg-yellow-50 rounded-lg text-center">
                    <AlertTriangle className="h-8 w-8 text-yellow-500 mx-auto mb-2" />
                    <div className="text-2xl font-bold text-yellow-700">
                      {filteredTasks.filter((t) => t.score > 0 && t.score < 70).length}
                    </div>
                    <div className="text-sm text-yellow-600">Necesitan Mejora</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </>
        )}
      </main>
    </div>
  )
}
