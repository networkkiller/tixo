import { Skeleton } from "@/components/ui/skeleton"

export default function Loading() {
  return (
    <div className="flex flex-col gap-5 p-8 bg-[#f0f4f8]">
      <div className="flex items-center justify-between">
        <div>
          <Skeleton className="h-8 w-64" />
          <Skeleton className="h-4 w-96 mt-2" />
        </div>
      </div>

      <div className="w-full">
        <Skeleton className="h-10 w-[500px]" />

        <div className="mt-4">
          <Skeleton className="h-[500px] w-full" />
        </div>
      </div>
    </div>
  )
}
