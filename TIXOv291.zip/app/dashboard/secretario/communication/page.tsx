"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, Send, Mail, Users, Copy, Smartphone } from "lucide-react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

// Datos de ejemplo
const messages = [
  {
    id: "MSG001",
    subject: "Reunión de padres - 3° Primaria",
    content:
      "Estimados padres, les recordamos la reunión programada para el día 15 de mayo a las 18:00 horas en el salón de actos.",
    recipients: "Padres de 3° Primaria",
    recipientCount: 28,
    sentDate: "10/05/2023",
    status: "Enviado",
    readCount: 22,
    channel: "Email y WhatsApp",
  },
  {
    id: "MSG002",
    subject: "Entrega de calificaciones - Fin de trimestre",
    content:
      "Se informa a todos los padres que las calificaciones del primer trimestre estarán disponibles en la plataforma a partir del 20 de junio.",
    recipients: "Todos los padres",
    recipientCount: 145,
    sentDate: "12/06/2023",
    status: "Enviado",
    readCount: 98,
    channel: "Email",
  },
  {
    id: "MSG003",
    subject: "Recordatorio de documentación pendiente",
    content:
      "Estimados padres, les recordamos que aún hay documentos pendientes por entregar para completar el expediente de su hijo/a.",
    recipients: "Padres seleccionados",
    recipientCount: 12,
    sentDate: "05/07/2023",
    status: "Enviado",
    readCount: 8,
    channel: "WhatsApp",
  },
  {
    id: "MSG004",
    subject: "Circular informativa - Actividades extracurriculares",
    content:
      "Les informamos sobre las nuevas actividades extracurriculares disponibles para el próximo semestre. Inscripciones abiertas hasta el 30 de agosto.",
    recipients: "Todos los padres",
    recipientCount: 145,
    sentDate: "15/08/2023",
    status: "Borrador",
    readCount: 0,
    channel: "Pendiente",
  },
  {
    id: "MSG005",
    subject: "Convocatoria a docentes - Reunión pedagógica",
    content:
      "Se convoca a todos los docentes a la reunión pedagógica que se llevará a cabo el día 25 de agosto a las 14:00 horas en la sala de profesores.",
    recipients: "Todos los docentes",
    recipientCount: 18,
    sentDate: "20/08/2023",
    status: "Enviado",
    readCount: 18,
    channel: "Email y WhatsApp",
  },
]

const templates = [
  {
    id: "TPL001",
    name: "Reunión de padres",
    subject: "Reunión de padres - [GRADO]",
    content:
      "Estimados padres, les recordamos la reunión programada para el día [FECHA] a las [HORA] horas en el [LUGAR]. Agradecemos su puntual asistencia.",
    lastUsed: "10/05/2023",
  },
  {
    id: "TPL002",
    name: "Entrega de calificaciones",
    subject: "Entrega de calificaciones - [PERIODO]",
    content:
      "Se informa a todos los padres que las calificaciones del [PERIODO] estarán disponibles en la plataforma a partir del [FECHA].",
    lastUsed: "12/06/2023",
  },
  {
    id: "TPL003",
    name: "Documentación pendiente",
    subject: "Recordatorio de documentación pendiente",
    content:
      "Estimados padres, les recordamos que aún hay documentos pendientes ([DOCUMENTOS]) por entregar para completar el expediente de su hijo/a [NOMBRE].",
    lastUsed: "05/07/2023",
  },
  {
    id: "TPL004",
    name: "Actividades extracurriculares",
    subject: "Circular informativa - Actividades extracurriculares",
    content:
      "Les informamos sobre las nuevas actividades extracurriculares disponibles para el próximo semestre. Inscripciones abiertas hasta el [FECHA].",
    lastUsed: "15/08/2023",
  },
  {
    id: "TPL005",
    name: "Reunión docentes",
    subject: "Convocatoria a docentes - [TIPO_REUNION]",
    content:
      "Se convoca a todos los docentes a la [TIPO_REUNION] que se llevará a cabo el día [FECHA] a las [HORA] horas en [LUGAR].",
    lastUsed: "20/08/2023",
  },
]

export default function CommunicationPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedTab, setSelectedTab] = useState("new")
  const [messageSubject, setMessageSubject] = useState("")
  const [messageContent, setMessageContent] = useState("")
  const [selectedTemplate, setSelectedTemplate] = useState("none")
  const [selectedRecipients, setSelectedRecipients] = useState("all-parents")
  const [selectedChannel, setSelectedChannel] = useState("both")

  // Filtrar mensajes
  const filteredMessages = messages.filter((message) => {
    return (
      message.subject.toLowerCase().includes(searchTerm.toLowerCase()) ||
      message.recipients.toLowerCase().includes(searchTerm.toLowerCase())
    )
  })

  // Manejar selección de plantilla
  const handleTemplateSelect = (templateId) => {
    const template = templates.find((t) => t.id === templateId)
    if (template) {
      setMessageSubject(template.subject)
      setMessageContent(template.content)
      setSelectedTemplate(templateId)
    }
  }

  return (
    <div className="flex flex-col gap-5 p-8 bg-[#f0f4f8]">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-gray-900">Comunicación</h1>
          <p className="text-gray-500">Gestiona la comunicación con padres, docentes y personal administrativo</p>
        </div>
      </div>

      <Tabs value={selectedTab} onValueChange={setSelectedTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3 lg:w-[500px]">
          <TabsTrigger value="new">Nuevo mensaje</TabsTrigger>
          <TabsTrigger value="sent">Mensajes enviados</TabsTrigger>
          <TabsTrigger value="templates">Plantillas</TabsTrigger>
        </TabsList>

        <TabsContent value="new" className="mt-4">
          <Card className="bg-white">
            <CardHeader>
              <CardTitle>Crear nuevo mensaje</CardTitle>
              <CardDescription>
                Envía circulares, notas y avisos a padres, docentes o personal administrativo
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <label htmlFor="template" className="text-sm font-medium">
                  Usar plantilla (opcional)
                </label>
                <Select value={selectedTemplate} onValueChange={handleTemplateSelect}>
                  <SelectTrigger>
                    <SelectValue placeholder="Seleccionar plantilla" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">Ninguna</SelectItem>
                    {templates.map((template) => (
                      <SelectItem key={template.id} value={template.id}>
                        {template.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <label htmlFor="subject" className="text-sm font-medium">
                  Asunto
                </label>
                <Input
                  id="subject"
                  placeholder="Ingrese el asunto del mensaje"
                  value={messageSubject}
                  onChange={(e) => setMessageSubject(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <label htmlFor="content" className="text-sm font-medium">
                  Contenido
                </label>
                <Textarea
                  id="content"
                  placeholder="Escriba el contenido del mensaje"
                  rows={6}
                  value={messageContent}
                  onChange={(e) => setMessageContent(e.target.value)}
                />
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <label htmlFor="recipients" className="text-sm font-medium">
                    Destinatarios
                  </label>
                  <Select value={selectedRecipients} onValueChange={setSelectedRecipients}>
                    <SelectTrigger>
                      <SelectValue placeholder="Seleccionar destinatarios" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all-parents">Todos los padres</SelectItem>
                      <SelectItem value="primary-parents">Padres de Primaria</SelectItem>
                      <SelectItem value="secondary-parents">Padres de Secundaria</SelectItem>
                      <SelectItem value="all-teachers">Todos los docentes</SelectItem>
                      <SelectItem value="admin-staff">Personal administrativo</SelectItem>
                      <SelectItem value="custom">Selección personalizada</SelectItem>
                    </SelectContent>
                  </Select>
                  {selectedRecipients === "custom" && (
                    <Button variant="outline" size="sm" className="mt-2">
                      <Users className="mr-2 h-4 w-4" />
                      Seleccionar destinatarios
                    </Button>
                  )}
                </div>

                <div className="space-y-2">
                  <label htmlFor="channel" className="text-sm font-medium">
                    Canal de envío
                  </label>
                  <Select value={selectedChannel} onValueChange={setSelectedChannel}>
                    <SelectTrigger>
                      <SelectValue placeholder="Seleccionar canal" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="both">Email y WhatsApp</SelectItem>
                      <SelectItem value="email">Solo Email</SelectItem>
                      <SelectItem value="whatsapp">Solo WhatsApp</SelectItem>
                    </SelectContent>
                  </Select>
                  <div className="flex items-center gap-2 mt-2">
                    {selectedChannel === "both" || selectedChannel === "email" ? (
                      <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                        <Mail className="mr-1 h-3 w-3" />
                        Email
                      </Badge>
                    ) : null}
                    {selectedChannel === "both" || selectedChannel === "whatsapp" ? (
                      <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                        <Smartphone className="mr-1 h-3 w-3" />
                        WhatsApp
                      </Badge>
                    ) : null}
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between border-t p-4">
              <Button variant="outline">Guardar como borrador</Button>
              <div className="flex gap-2">
                <Button variant="outline">Vista previa</Button>
                <Button className="bg-indigo-600 hover:bg-indigo-700">
                  <Send className="mr-2 h-4 w-4" />
                  Enviar mensaje
                </Button>
              </div>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="sent" className="mt-4">
          <Card className="bg-white">
            <CardHeader className="pb-2">
              <CardTitle>Mensajes enviados</CardTitle>
              <CardDescription>Historial de mensajes enviados y su estado</CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              <div className="p-4 pb-0">
                <div className="relative">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
                  <Input
                    placeholder="Buscar por asunto o destinatarios..."
                    className="pl-9"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
              </div>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Asunto</TableHead>
                    <TableHead>Destinatarios</TableHead>
                    <TableHead>Fecha</TableHead>
                    <TableHead>Estado</TableHead>
                    <TableHead>Canal</TableHead>
                    <TableHead>Acciones</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredMessages.map((message) => (
                    <TableRow key={message.id}>
                      <TableCell className="font-medium">{message.subject}</TableCell>
                      <TableCell>
                        {message.recipients}
                        <span className="ml-1 text-xs text-gray-500">({message.recipientCount})</span>
                      </TableCell>
                      <TableCell>{message.sentDate}</TableCell>
                      <TableCell>
                        {message.status === "Enviado" ? (
                          <div className="flex items-center">
                            <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                              Enviado
                            </Badge>
                            <span className="ml-2 text-xs text-gray-500">
                              {message.readCount}/{message.recipientCount} leídos
                            </span>
                          </div>
                        ) : (
                          <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
                            Borrador
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          {message.channel.includes("Email") && (
                            <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200 text-xs">
                              <Mail className="mr-1 h-3 w-3" />
                              Email
                            </Badge>
                          )}
                          {message.channel.includes("WhatsApp") && (
                            <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200 text-xs">
                              <Smartphone className="mr-1 h-3 w-3" />
                              WhatsApp
                            </Badge>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <span className="sr-only">Abrir menú</span>
                              <svg
                                xmlns="http://www.w3.org/2000/svg"
                                width="24"
                                height="24"
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                strokeWidth="2"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="h-4 w-4"
                              >
                                <circle cx="12" cy="12" r="1" />
                                <circle cx="12" cy="5" r="1" />
                                <circle cx="12" cy="19" r="1" />
                              </svg>
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem>Ver detalles</DropdownMenuItem>
                            <DropdownMenuItem>Ver lecturas</DropdownMenuItem>
                            <DropdownMenuItem>Reenviar</DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem>Guardar como plantilla</DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
            <CardFooter className="flex items-center justify-between border-t p-4">
              <div className="text-sm text-gray-500">
                Mostrando {filteredMessages.length} de {messages.length} mensajes
              </div>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm" disabled>
                  Anterior
                </Button>
                <Button variant="outline" size="sm">
                  Siguiente
                </Button>
              </div>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="templates" className="mt-4">
          <Card className="bg-white">
            <CardHeader>
              <CardTitle>Plantillas de mensajes</CardTitle>
              <CardDescription>Plantillas predefinidas para mensajes frecuentes</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2">
                {templates.map((template) => (
                  <Card key={template.id} className="overflow-hidden">
                    <CardHeader className="bg-gray-50 p-4">
                      <CardTitle className="text-lg">{template.name}</CardTitle>
                      <CardDescription className="line-clamp-1">{template.subject}</CardDescription>
                    </CardHeader>
                    <CardContent className="p-4">
                      <p className="text-sm text-gray-500 line-clamp-3">{template.content}</p>
                      <p className="mt-2 text-xs text-gray-400">Último uso: {template.lastUsed}</p>
                    </CardContent>
                    <CardFooter className="flex justify-between border-t p-4">
                      <Button variant="ghost" size="sm">
                        <Copy className="mr-2 h-4 w-4" />
                        Editar
                      </Button>
                      <Button
                        size="sm"
                        className="bg-indigo-600 hover:bg-indigo-700"
                        onClick={() => handleTemplateSelect(template.id)}
                      >
                        Usar plantilla
                      </Button>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            </CardContent>
            <CardFooter className="flex justify-between border-t p-4">
              <div></div>
              <Button className="bg-indigo-600 hover:bg-indigo-700">
                <span className="mr-2">+</span>
                Nueva plantilla
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
