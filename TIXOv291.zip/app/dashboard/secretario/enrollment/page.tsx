"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Search,
  UserPlus,
  Download,
  Filter,
  FileText,
  User,
  Calendar,
  CheckCircle,
  XCircle,
  Clock,
  AlertCircle,
  FileCheck,
  Eye,
  Edit,
  Printer,
  MoreHorizontal,
} from "lucide-react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Progress } from "@/components/ui/progress"

// Datos de ejemplo
const enrollments = [
  {
    id: "ENR001",
    studentName: "Carlos Eduardo Ramírez",
    grade: "2° Secundaria",
    status: "En revisión",
    progress: 75,
    submissionDate: "15/07/2023",
    documents: [
      { name: "Acta de nacimiento", status: "Aprobado" },
      { name: "Foto", status: "Aprobado" },
      { name: "Vacunación", status: "Pendiente" },
      { name: "Récord académico", status: "Aprobado" },
    ],
    type: "Nuevo ingreso",
  },
  {
    id: "ENR002",
    studentName: "María Fernanda López",
    grade: "1° Primaria",
    status: "Incompleta",
    progress: 40,
    submissionDate: "10/07/2023",
    documents: [
      { name: "Acta de nacimiento", status: "Aprobado" },
      { name: "Foto", status: "Pendiente" },
      { name: "Vacunación", status: "Pendiente" },
      { name: "Récord académico", status: "No aplica" },
    ],
    type: "Nuevo ingreso",
  },
  {
    id: "ENR003",
    studentName: "Ana María González",
    grade: "4° Primaria",
    status: "Confirmada",
    progress: 100,
    submissionDate: "05/07/2023",
    documents: [
      { name: "Acta de nacimiento", status: "Aprobado" },
      { name: "Foto", status: "Aprobado" },
      { name: "Vacunación", status: "Aprobado" },
      { name: "Récord académico", status: "Aprobado" },
    ],
    type: "Reinscripción",
  },
  {
    id: "ENR004",
    studentName: "Luis Fernando Martínez",
    grade: "6° Primaria",
    status: "Confirmada",
    progress: 100,
    submissionDate: "08/07/2023",
    documents: [
      { name: "Acta de nacimiento", status: "Aprobado" },
      { name: "Foto", status: "Aprobado" },
      { name: "Vacunación", status: "Aprobado" },
      { name: "Récord académico", status: "Aprobado" },
    ],
    type: "Reinscripción",
  },
  {
    id: "ENR005",
    studentName: "Sofía Alejandra Pérez",
    grade: "2° Secundaria",
    status: "En revisión",
    progress: 80,
    submissionDate: "12/07/2023",
    documents: [
      { name: "Acta de nacimiento", status: "Aprobado" },
      { name: "Foto", status: "Aprobado" },
      { name: "Vacunación", status: "Aprobado" },
      { name: "Récord académico", status: "Pendiente" },
    ],
    type: "Reinscripción",
  },
]

export default function EnrollmentPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedStatus, setSelectedStatus] = useState("all")
  const [selectedType, setSelectedType] = useState("all")
  const [selectedEnrollment, setSelectedEnrollment] = useState(null)

  // Filtrar inscripciones
  const filteredEnrollments = enrollments.filter((enrollment) => {
    const matchesSearch = enrollment.studentName.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = selectedStatus === "all" || enrollment.status === selectedStatus
    const matchesType = selectedType === "all" || enrollment.type === selectedType

    return matchesSearch && matchesStatus && matchesType
  })

  // Estadísticas
  const stats = {
    total: enrollments.length,
    confirmed: enrollments.filter((e) => e.status === "Confirmada").length,
    inReview: enrollments.filter((e) => e.status === "En revisión").length,
    incomplete: enrollments.filter((e) => e.status === "Incompleta").length,
    newStudents: enrollments.filter((e) => e.type === "Nuevo ingreso").length,
    returning: enrollments.filter((e) => e.type === "Reinscripción").length,
  }

  return (
    <div className="flex flex-col gap-5 p-8 bg-[#f0f4f8]">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-gray-900">Registro de Inscripción y Reinscripción</h1>
          <p className="text-gray-500">Gestiona los procesos de admisión, inscripción y reinscripción de estudiantes</p>
        </div>
        <div className="flex items-center gap-2">
          <Button className="gap-2 bg-indigo-600 hover:bg-indigo-700">
            <UserPlus className="h-4 w-4" />
            <span>Nueva Inscripción</span>
          </Button>
          <Button variant="outline" className="gap-2">
            <Download className="h-4 w-4" />
            <span>Exportar</span>
          </Button>
        </div>
      </div>

      {/* Estadísticas */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card className="bg-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-500">Total de inscripciones</p>
                <h3 className="text-3xl font-bold">{stats.total}</h3>
              </div>
              <div className="h-12 w-12 rounded-full bg-indigo-100 flex items-center justify-center">
                <FileText className="h-6 w-6 text-indigo-600" />
              </div>
            </div>
            <div className="mt-4 flex items-center justify-between text-sm">
              <div>
                <span className="text-green-600 font-medium">{stats.confirmed}</span> confirmadas
              </div>
              <div>
                <span className="text-amber-600 font-medium">{stats.inReview + stats.incomplete}</span> pendientes
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-500">Nuevos ingresos</p>
                <h3 className="text-3xl font-bold">{stats.newStudents}</h3>
              </div>
              <div className="h-12 w-12 rounded-full bg-green-100 flex items-center justify-center">
                <UserPlus className="h-6 w-6 text-green-600" />
              </div>
            </div>
            <div className="mt-4">
              <Progress value={(stats.newStudents / stats.total) * 100} className="h-2" />
              <p className="mt-2 text-sm text-gray-500">
                {Math.round((stats.newStudents / stats.total) * 100)}% del total de inscripciones
              </p>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-500">Reinscripciones</p>
                <h3 className="text-3xl font-bold">{stats.returning}</h3>
              </div>
              <div className="h-12 w-12 rounded-full bg-blue-100 flex items-center justify-center">
                <Calendar className="h-6 w-6 text-blue-600" />
              </div>
            </div>
            <div className="mt-4">
              <Progress value={(stats.returning / stats.total) * 100} className="h-2" />
              <p className="mt-2 text-sm text-gray-500">
                {Math.round((stats.returning / stats.total) * 100)}% del total de inscripciones
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="all" className="w-full">
        <TabsList className="grid w-full grid-cols-4 lg:w-[600px]">
          <TabsTrigger value="all">Todas</TabsTrigger>
          <TabsTrigger value="pending">Pendientes</TabsTrigger>
          <TabsTrigger value="confirmed">Confirmadas</TabsTrigger>
          <TabsTrigger value="new">Nuevos ingresos</TabsTrigger>
        </TabsList>

        <div className="mt-4 flex flex-col gap-4 md:flex-row md:items-center">
          <div className="relative flex-1">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
            <Input
              placeholder="Buscar por nombre..."
              className="pl-9"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="flex gap-2">
            <Select value={selectedStatus} onValueChange={setSelectedStatus}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Filtrar por estado" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos los estados</SelectItem>
                <SelectItem value="Confirmada">Confirmada</SelectItem>
                <SelectItem value="En revisión">En revisión</SelectItem>
                <SelectItem value="Incompleta">Incompleta</SelectItem>
              </SelectContent>
            </Select>

            <Select value={selectedType} onValueChange={setSelectedType}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Filtrar por tipo" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos los tipos</SelectItem>
                <SelectItem value="Nuevo ingreso">Nuevo ingreso</SelectItem>
                <SelectItem value="Reinscripción">Reinscripción</SelectItem>
              </SelectContent>
            </Select>

            <Button variant="outline" size="icon">
              <Filter className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <TabsContent value="all" className="mt-4">
          <Card className="bg-white">
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>ID</TableHead>
                    <TableHead>Estudiante</TableHead>
                    <TableHead>Grado</TableHead>
                    <TableHead>Tipo</TableHead>
                    <TableHead>Estado</TableHead>
                    <TableHead>Progreso</TableHead>
                    <TableHead>Fecha</TableHead>
                    <TableHead>Acciones</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredEnrollments.map((enrollment) => (
                    <TableRow key={enrollment.id}>
                      <TableCell className="font-medium">{enrollment.id}</TableCell>
                      <TableCell>{enrollment.studentName}</TableCell>
                      <TableCell>{enrollment.grade}</TableCell>
                      <TableCell>
                        <Badge
                          variant="outline"
                          className={
                            enrollment.type === "Nuevo ingreso"
                              ? "bg-green-50 text-green-700 border-green-200"
                              : "bg-blue-50 text-blue-700 border-blue-200"
                          }
                        >
                          {enrollment.type}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant="outline"
                          className={
                            enrollment.status === "Confirmada"
                              ? "bg-green-50 text-green-700 border-green-200"
                              : enrollment.status === "En revisión"
                                ? "bg-amber-50 text-amber-700 border-amber-200"
                                : "bg-red-50 text-red-700 border-red-200"
                          }
                        >
                          {enrollment.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Progress value={enrollment.progress} className="h-2 w-[100px]" />
                          <span className="text-xs text-gray-500">{enrollment.progress}%</span>
                        </div>
                      </TableCell>
                      <TableCell>{enrollment.submissionDate}</TableCell>
                      <TableCell>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => setSelectedEnrollment(enrollment)}>
                              Ver detalles
                            </DropdownMenuItem>
                            <DropdownMenuItem>Validar documentos</DropdownMenuItem>
                            <DropdownMenuItem>Editar información</DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem>Generar contrato</DropdownMenuItem>
                            <DropdownMenuItem>Confirmar inscripción</DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
            <CardFooter className="flex items-center justify-between border-t p-4">
              <div className="text-sm text-gray-500">
                Mostrando {filteredEnrollments.length} de {enrollments.length} inscripciones
              </div>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm" disabled>
                  Anterior
                </Button>
                <Button variant="outline" size="sm">
                  Siguiente
                </Button>
              </div>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="pending" className="mt-4">
          <Card className="bg-white">
            <CardContent className="p-6">
              <p className="text-center text-gray-500">Mostrando inscripciones pendientes</p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="confirmed" className="mt-4">
          <Card className="bg-white">
            <CardContent className="p-6">
              <p className="text-center text-gray-500">Mostrando inscripciones confirmadas</p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="new" className="mt-4">
          <Card className="bg-white">
            <CardContent className="p-6">
              <p className="text-center text-gray-500">Mostrando nuevos ingresos</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Detalle de inscripción */}
      {selectedEnrollment && (
        <Card className="mt-4 bg-white">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Detalle de Inscripción</CardTitle>
              <CardDescription>ID: {selectedEnrollment.id}</CardDescription>
            </div>
            <Button variant="ghost" size="icon" onClick={() => setSelectedEnrollment(null)}>
              <XCircle className="h-4 w-4" />
            </Button>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex flex-col gap-6 md:flex-row">
              <div className="flex-1">
                <div className="flex items-center gap-4">
                  <div className="h-16 w-16 rounded-full bg-indigo-100 flex items-center justify-center">
                    <User className="h-8 w-8 text-indigo-600" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold">{selectedEnrollment.studentName}</h3>
                    <p className="text-gray-500">
                      {selectedEnrollment.grade} • {selectedEnrollment.type}
                    </p>
                    <Badge
                      variant="outline"
                      className={
                        selectedEnrollment.status === "Confirmada"
                          ? "mt-1 bg-green-50 text-green-700 border-green-200"
                          : selectedEnrollment.status === "En revisión"
                            ? "mt-1 bg-amber-50 text-amber-700 border-amber-200"
                            : "mt-1 bg-red-50 text-red-700 border-red-200"
                      }
                    >
                      {selectedEnrollment.status}
                    </Badge>
                  </div>
                </div>

                <div className="mt-6">
                  <h4 className="font-medium mb-2">Progreso de inscripción</h4>
                  <Progress value={selectedEnrollment.progress} className="h-2" />
                  <p className="mt-2 text-sm text-gray-500">{selectedEnrollment.progress}% completado</p>
                </div>

                <div className="mt-6">
                  <h4 className="font-medium mb-2">Información adicional</h4>
                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4 text-gray-500" />
                      <div>
                        <p className="text-sm text-gray-500">Fecha de solicitud</p>
                        <p className="font-medium">{selectedEnrollment.submissionDate}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4 text-gray-500" />
                      <div>
                        <p className="text-sm text-gray-500">Tiempo en proceso</p>
                        <p className="font-medium">5 días</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex-1">
                <h4 className="font-medium mb-4">Documentación</h4>

                <div className="space-y-3">
                  {selectedEnrollment.documents.map((doc, index) => (
                    <div
                      key={index}
                      className={`flex items-center justify-between rounded-lg border p-3 ${
                        doc.status === "Aprobado"
                          ? "border-green-200 bg-green-50"
                          : doc.status === "Pendiente"
                            ? "border-amber-200 bg-amber-50"
                            : "border-gray-200 bg-gray-50"
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <FileText
                          className={`h-4 w-4 ${
                            doc.status === "Aprobado"
                              ? "text-green-600"
                              : doc.status === "Pendiente"
                                ? "text-amber-600"
                                : "text-gray-600"
                          }`}
                        />
                        <span
                          className={
                            doc.status === "Aprobado"
                              ? "text-green-700"
                              : doc.status === "Pendiente"
                                ? "text-amber-700"
                                : "text-gray-700"
                          }
                        >
                          {doc.name}
                        </span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Badge
                          variant="outline"
                          className={
                            doc.status === "Aprobado"
                              ? "border-green-200 bg-green-100 text-green-700"
                              : doc.status === "Pendiente"
                                ? "border-amber-200 bg-amber-100 text-amber-700"
                                : "border-gray-200 bg-gray-100 text-gray-700"
                          }
                        >
                          {doc.status}
                        </Badge>
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <Eye className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-6">
                  <h4 className="font-medium mb-2">Acciones requeridas</h4>
                  {selectedEnrollment.status !== "Confirmada" ? (
                    <div className="space-y-2">
                      {selectedEnrollment.documents.some((doc) => doc.status === "Pendiente") && (
                        <div className="flex items-center gap-2 text-amber-700">
                          <AlertCircle className="h-4 w-4" />
                          <span className="text-sm">Documentos pendientes por validar</span>
                        </div>
                      )}
                      <div className="flex items-center gap-2 text-blue-700">
                        <FileCheck className="h-4 w-4" />
                        <span className="text-sm">Generar contrato de inscripción</span>
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center gap-2 text-green-700">
                      <CheckCircle className="h-4 w-4" />
                      <span className="text-sm">Inscripción completada correctamente</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex justify-between border-t p-4">
            <Button variant="outline">
              <Edit className="mr-2 h-4 w-4" />
              Editar información
            </Button>
            <div className="flex gap-2">
              <Button variant="outline">
                <Printer className="mr-2 h-4 w-4" />
                Imprimir expediente
              </Button>
              {selectedEnrollment.status !== "Confirmada" ? (
                <Button className="bg-indigo-600 hover:bg-indigo-700">
                  <CheckCircle className="mr-2 h-4 w-4" />
                  Confirmar inscripción
                </Button>
              ) : (
                <Button className="bg-green-600 hover:bg-green-700" disabled>
                  <CheckCircle className="mr-2 h-4 w-4" />
                  Inscripción confirmada
                </Button>
              )}
            </div>
          </CardFooter>
        </Card>
      )}
    </div>
  )
}
