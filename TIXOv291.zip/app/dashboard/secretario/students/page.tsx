"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Search,
  UserPlus,
  Download,
  Filter,
  FileText,
  User,
  Mail,
  Phone,
  Calendar,
  MapPin,
  BookOpen,
  MoreHorizontal,
} from "lucide-react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

// Datos de ejemplo
const students = [
  {
    id: "ST001",
    name: "Ana María González",
    grade: "3° Primaria",
    section: "A",
    status: "Activo",
    gender: "Femenino",
    birthdate: "12/05/2014",
    address: "Calle Principal 123",
    parentName: "Carlos González",
    phone: "555-1234",
    email: "carlos@example.com",
    documents: ["Acta de nacimiento", "Foto", "Vacunación"],
    missingDocuments: [],
  },
  {
    id: "ST002",
    name: "Luis Fernando Martínez",
    grade: "5° Primaria",
    section: "B",
    status: "Activo",
    gender: "Masculino",
    birthdate: "23/08/2012",
    address: "Av. Central 456",
    parentName: "María Martínez",
    phone: "555-5678",
    email: "maria@example.com",
    documents: ["Acta de nacimiento", "Foto"],
    missingDocuments: ["Vacunación"],
  },
  {
    id: "ST003",
    name: "Sofía Alejandra Pérez",
    grade: "1° Secundaria",
    section: "A",
    status: "Activo",
    gender: "Femenino",
    birthdate: "05/03/2011",
    address: "Calle Norte 789",
    parentName: "Roberto Pérez",
    phone: "555-9012",
    email: "roberto@example.com",
    documents: ["Foto", "Vacunación"],
    missingDocuments: ["Acta de nacimiento"],
  },
  {
    id: "ST004",
    name: "Carlos Eduardo Ramírez",
    grade: "2° Secundaria",
    section: "C",
    status: "Proceso de inscripción",
    gender: "Masculino",
    birthdate: "17/11/2010",
    address: "Av. Sur 321",
    parentName: "Laura Ramírez",
    phone: "555-3456",
    email: "laura@example.com",
    documents: [],
    missingDocuments: ["Acta de nacimiento", "Foto", "Vacunación"],
  },
  {
    id: "ST005",
    name: "Valentina López",
    grade: "4° Primaria",
    section: "A",
    status: "Activo",
    gender: "Femenino",
    birthdate: "30/07/2013",
    address: "Calle Este 654",
    parentName: "Miguel López",
    phone: "555-7890",
    email: "miguel@example.com",
    documents: ["Acta de nacimiento", "Foto", "Vacunación"],
    missingDocuments: [],
  },
]

export default function StudentsPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedGrade, setSelectedGrade] = useState("all")
  const [selectedStatus, setSelectedStatus] = useState("all")

  // Filtrar estudiantes
  const filteredStudents = students.filter((student) => {
    const matchesSearch =
      student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      student.id.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesGrade = selectedGrade === "all" || student.grade === selectedGrade
    const matchesStatus = selectedStatus === "all" || student.status === selectedStatus

    return matchesSearch && matchesGrade && matchesStatus
  })

  return (
    <div className="flex flex-col gap-5 p-8 bg-[#f0f4f8]">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-gray-900">Gestión de Estudiantes</h1>
          <p className="text-gray-500">Administra el registro y seguimiento de estudiantes</p>
        </div>
        <div className="flex items-center gap-2">
          <Button className="gap-2 bg-indigo-600 hover:bg-indigo-700">
            <UserPlus className="h-4 w-4" />
            <span>Nuevo Estudiante</span>
          </Button>
          <Button variant="outline" className="gap-2">
            <Download className="h-4 w-4" />
            <span>Exportar</span>
          </Button>
        </div>
      </div>

      <Tabs defaultValue="all" className="w-full">
        <TabsList className="grid w-full grid-cols-4 lg:w-[600px]">
          <TabsTrigger value="all">Todos</TabsTrigger>
          <TabsTrigger value="active">Activos</TabsTrigger>
          <TabsTrigger value="pending">Pendientes</TabsTrigger>
          <TabsTrigger value="inactive">Inactivos</TabsTrigger>
        </TabsList>

        <div className="mt-4 flex flex-col gap-4 md:flex-row md:items-center">
          <div className="relative flex-1">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
            <Input
              placeholder="Buscar por nombre o ID..."
              className="pl-9"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="flex gap-2">
            <Select value={selectedGrade} onValueChange={setSelectedGrade}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Filtrar por grado" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos los grados</SelectItem>
                <SelectItem value="3° Primaria">3° Primaria</SelectItem>
                <SelectItem value="4° Primaria">4° Primaria</SelectItem>
                <SelectItem value="5° Primaria">5° Primaria</SelectItem>
                <SelectItem value="1° Secundaria">1° Secundaria</SelectItem>
                <SelectItem value="2° Secundaria">2° Secundaria</SelectItem>
              </SelectContent>
            </Select>

            <Select value={selectedStatus} onValueChange={setSelectedStatus}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Filtrar por estado" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos los estados</SelectItem>
                <SelectItem value="Activo">Activo</SelectItem>
                <SelectItem value="Proceso de inscripción">En inscripción</SelectItem>
                <SelectItem value="Inactivo">Inactivo</SelectItem>
              </SelectContent>
            </Select>

            <Button variant="outline" size="icon">
              <Filter className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <TabsContent value="all" className="mt-4">
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>ID</TableHead>
                    <TableHead>Nombre</TableHead>
                    <TableHead>Grado</TableHead>
                    <TableHead>Estado</TableHead>
                    <TableHead>Documentos</TableHead>
                    <TableHead>Acciones</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredStudents.map((student) => (
                    <TableRow key={student.id}>
                      <TableCell className="font-medium">{student.id}</TableCell>
                      <TableCell>{student.name}</TableCell>
                      <TableCell>
                        {student.grade} "{student.section}"
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant="outline"
                          className={
                            student.status === "Activo"
                              ? "bg-green-50 text-green-700 border-green-200"
                              : student.status === "Proceso de inscripción"
                                ? "bg-amber-50 text-amber-700 border-amber-200"
                                : "bg-gray-50 text-gray-700 border-gray-200"
                          }
                        >
                          {student.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {student.missingDocuments.length > 0 ? (
                          <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
                            {student.missingDocuments.length} pendientes
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                            Completos
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Acciones</DropdownMenuLabel>
                            <DropdownMenuItem>Ver perfil</DropdownMenuItem>
                            <DropdownMenuItem>Editar información</DropdownMenuItem>
                            <DropdownMenuItem>Documentos</DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem>Cambiar de curso</DropdownMenuItem>
                            <DropdownMenuItem>Generar certificado</DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
            <CardFooter className="flex items-center justify-between border-t p-4">
              <div className="text-sm text-gray-500">
                Mostrando {filteredStudents.length} de {students.length} estudiantes
              </div>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm" disabled>
                  Anterior
                </Button>
                <Button variant="outline" size="sm">
                  Siguiente
                </Button>
              </div>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="active" className="mt-4">
          <Card>
            <CardContent className="p-6">
              <p className="text-center text-gray-500">Mostrando estudiantes con estado activo</p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="pending" className="mt-4">
          <Card>
            <CardContent className="p-6">
              <p className="text-center text-gray-500">Mostrando estudiantes en proceso de inscripción</p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="inactive" className="mt-4">
          <Card>
            <CardContent className="p-6">
              <p className="text-center text-gray-500">Mostrando estudiantes inactivos</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Vista detallada de un estudiante */}
      <Card className="mt-4">
        <CardHeader>
          <CardTitle>Perfil del Estudiante</CardTitle>
          <CardDescription>Información detallada del estudiante seleccionado</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex flex-col gap-6 md:flex-row">
            <div className="flex-1">
              <div className="flex items-center gap-4">
                <div className="h-20 w-20 rounded-full bg-indigo-100 flex items-center justify-center">
                  <User className="h-10 w-10 text-indigo-600" />
                </div>
                <div>
                  <h3 className="text-xl font-bold">Ana María González</h3>
                  <p className="text-gray-500">ID: ST001 • 3° Primaria "A"</p>
                  <Badge variant="outline" className="mt-1 bg-green-50 text-green-700 border-green-200">
                    Activo
                  </Badge>
                </div>
              </div>

              <div className="mt-6 grid gap-4 md:grid-cols-2">
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4 text-gray-500" />
                  <div>
                    <p className="text-sm text-gray-500">Fecha de nacimiento</p>
                    <p className="font-medium">12/05/2014</p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <User className="h-4 w-4 text-gray-500" />
                  <div>
                    <p className="text-sm text-gray-500">Género</p>
                    <p className="font-medium">Femenino</p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-gray-500" />
                  <div>
                    <p className="text-sm text-gray-500">Dirección</p>
                    <p className="font-medium">Calle Principal 123</p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <BookOpen className="h-4 w-4 text-gray-500" />
                  <div>
                    <p className="text-sm text-gray-500">Año de ingreso</p>
                    <p className="font-medium">2020</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex-1">
              <h4 className="font-medium mb-4">Información del Tutor</h4>

              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <User className="h-4 w-4 text-gray-500" />
                  <div>
                    <p className="text-sm text-gray-500">Nombre del tutor</p>
                    <p className="font-medium">Carlos González</p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <Phone className="h-4 w-4 text-gray-500" />
                  <div>
                    <p className="text-sm text-gray-500">Teléfono</p>
                    <p className="font-medium">555-1234</p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <Mail className="h-4 w-4 text-gray-500" />
                  <div>
                    <p className="text-sm text-gray-500">Correo electrónico</p>
                    <p className="font-medium">carlos@example.com</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div>
            <h4 className="font-medium mb-4">Documentación</h4>
            <div className="grid gap-2 md:grid-cols-3">
              <div className="flex items-center gap-2 rounded-lg border border-green-200 bg-green-50 p-3">
                <FileText className="h-4 w-4 text-green-600" />
                <span className="text-sm text-green-700">Acta de nacimiento</span>
              </div>

              <div className="flex items-center gap-2 rounded-lg border border-green-200 bg-green-50 p-3">
                <FileText className="h-4 w-4 text-green-600" />
                <span className="text-sm text-green-700">Foto</span>
              </div>

              <div className="flex items-center gap-2 rounded-lg border border-green-200 bg-green-50 p-3">
                <FileText className="h-4 w-4 text-green-600" />
                <span className="text-sm text-green-700">Vacunación</span>
              </div>
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex justify-between border-t p-4">
          <Button variant="outline">Editar información</Button>
          <div className="flex gap-2">
            <Button variant="outline">Generar certificado</Button>
            <Button className="bg-indigo-600 hover:bg-indigo-700">Cambiar de curso</Button>
          </div>
        </CardFooter>
      </Card>
    </div>
  )
}
