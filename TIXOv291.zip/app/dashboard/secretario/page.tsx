"use client"

import { useAuth } from "@/contexts/auth-context"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import {
  Bell,
  Calendar,
  CheckCircle2,
  ClipboardList,
  Clock,
  FileText,
  Users,
  AlertTriangle,
  BookOpen,
  UserPlus,
  FolderArchive,
} from "lucide-react"
import Link from "next/link"

export default function SecretarioDashboard() {
  const { user } = useAuth()

  if (!user) return null

  return (
    <div className="flex flex-col gap-5 p-8 bg-[#f0f4f8]">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-gray-900">
            Dashboard Coordinador de Registro y Control Académico
          </h1>
          <p className="text-gray-500">Bienvenido(a) de nuevo, {user.name}</p>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            className="gap-1 bg-white text-indigo-700 border-indigo-200 hover:bg-indigo-50"
          >
            <Calendar className="h-4 w-4" />
            <span>Hoy</span>
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="relative bg-white text-indigo-700 border-indigo-200 hover:bg-indigo-50"
          >
            <Bell className="h-4 w-4" />
            <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-indigo-600 text-[10px] text-white">
              3
            </span>
          </Button>
        </div>
      </div>

      {/* Alertas y tareas pendientes */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Alert className="border-l-4 border-amber-500 bg-white">
          <AlertTriangle className="h-5 w-5 text-amber-500" />
          <AlertTitle className="text-amber-800">Documentos pendientes</AlertTitle>
          <AlertDescription className="text-amber-700">
            5 estudiantes tienen documentación incompleta para inscripción
          </AlertDescription>
          <Button variant="link" className="mt-2 h-auto p-0 text-amber-700">
            Ver detalles
          </Button>
        </Alert>

        <Alert className="border-l-4 border-indigo-500 bg-white">
          <Calendar className="h-5 w-5 text-indigo-500" />
          <AlertTitle className="text-indigo-800">Eventos próximos</AlertTitle>
          <AlertDescription className="text-indigo-700">
            Reunión de padres programada para mañana, 15:00
          </AlertDescription>
          <Button variant="link" className="mt-2 h-auto p-0 text-indigo-700">
            Ver calendario
          </Button>
        </Alert>

        <Alert className="border-l-4 border-green-500 bg-white">
          <CheckCircle2 className="h-5 w-5 text-green-500" />
          <AlertTitle className="text-green-800">Cumpleaños del día</AlertTitle>
          <AlertDescription className="text-green-700">2 estudiantes y 1 profesor cumplen años hoy</AlertDescription>
          <Button variant="link" className="mt-2 h-auto p-0 text-green-700">
            Ver lista
          </Button>
        </Alert>
      </div>

      {/* Estadísticas principales */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Total Estudiantes</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-2xl font-bold">1,248</div>
              <Users className="h-5 w-5 text-indigo-600" />
            </div>
            <div className="mt-2 flex items-center text-xs">
              <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                +24 este mes
              </Badge>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Inscripciones Pendientes</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-2xl font-bold">32</div>
              <ClipboardList className="h-5 w-5 text-amber-500" />
            </div>
            <div className="mt-2">
              <Progress value={65} className="h-1.5 bg-amber-100" indicatorClassName="bg-amber-500" />
              <div className="mt-1 text-xs text-gray-500">65% completado</div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Documentos Procesados</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-2xl font-bold">187</div>
              <FileText className="h-5 w-5 text-indigo-600" />
            </div>
            <div className="mt-2 flex items-center text-xs">
              <Badge variant="outline" className="bg-indigo-50 text-indigo-700 border-indigo-200">
                +43 esta semana
              </Badge>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Citas Programadas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-2xl font-bold">8</div>
              <Clock className="h-5 w-5 text-indigo-600" />
            </div>
            <div className="mt-2 flex items-center text-xs">
              <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                Hoy
              </Badge>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Accesos rápidos */}
      <Card>
        <CardHeader>
          <CardTitle>Accesos Rápidos</CardTitle>
          <CardDescription>Funciones frecuentes para agilizar tu trabajo</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
            <Link
              href="/dashboard/secretario/students"
              className="flex flex-col items-center gap-2 rounded-lg border border-gray-200 bg-white p-4 text-center transition-all hover:border-indigo-200 hover:bg-indigo-50"
            >
              <div className="rounded-full bg-indigo-100 p-2">
                <Users className="h-5 w-5 text-indigo-600" />
              </div>
              <span className="text-sm font-medium">Nuevo Estudiante</span>
            </Link>

            <Link
              href="/dashboard/secretario/teachers"
              className="flex flex-col items-center gap-2 rounded-lg border border-gray-200 bg-white p-4 text-center transition-all hover:border-indigo-200 hover:bg-indigo-50"
            >
              <div className="rounded-full bg-indigo-100 p-2">
                <BookOpen className="h-5 w-5 text-indigo-600" />
              </div>
              <span className="text-sm font-medium">Nuevo Docente</span>
            </Link>

            <Link
              href="/dashboard/secretario/parents"
              className="flex flex-col items-center gap-2 rounded-lg border border-gray-200 bg-white p-4 text-center transition-all hover:border-indigo-200 hover:bg-indigo-50"
            >
              <div className="rounded-full bg-indigo-100 p-2">
                <UserPlus className="h-5 w-5 text-indigo-600" />
              </div>
              <span className="text-sm font-medium">Nuevo Padre</span>
            </Link>

            <Link
              href="/dashboard/secretario/reports"
              className="flex flex-col items-center gap-2 rounded-lg border border-gray-200 bg-white p-4 text-center transition-all hover:border-indigo-200 hover:bg-indigo-50"
            >
              <div className="rounded-full bg-indigo-100 p-2">
                <FileText className="h-5 w-5 text-indigo-600" />
              </div>
              <span className="text-sm font-medium">Generar Reporte</span>
            </Link>

            <Link
              href="/dashboard/secretario/archive"
              className="flex flex-col items-center gap-2 rounded-lg border border-gray-200 bg-white p-4 text-center transition-all hover:border-indigo-200 hover:bg-indigo-50"
            >
              <div className="rounded-full bg-indigo-100 p-2">
                <FolderArchive className="h-5 w-5 text-indigo-600" />
              </div>
              <span className="text-sm font-medium">Archivo Digital</span>
            </Link>
          </div>
        </CardContent>
      </Card>

      {/* Tareas pendientes y actividad reciente */}
      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Tareas Pendientes</CardTitle>
            <CardDescription>Actividades que requieren tu atención</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-start gap-4 rounded-lg border border-gray-100 bg-white p-3">
              <div className="rounded-full bg-amber-100 p-1.5">
                <AlertTriangle className="h-4 w-4 text-amber-500" />
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <h4 className="font-medium">Documentos faltantes</h4>
                  <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
                    Alta
                  </Badge>
                </div>
                <p className="text-sm text-gray-500">Solicitar acta de nacimiento a 3 estudiantes nuevos</p>
              </div>
            </div>

            <div className="flex items-start gap-4 rounded-lg border border-gray-100 bg-white p-3">
              <div className="rounded-full bg-indigo-100 p-1.5">
                <Calendar className="h-4 w-4 text-indigo-600" />
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <h4 className="font-medium">Preparar reunión</h4>
                  <Badge variant="outline" className="bg-indigo-50 text-indigo-700 border-indigo-200">
                    Media
                  </Badge>
                </div>
                <p className="text-sm text-gray-500">Imprimir listas de asistencia para reunión de padres</p>
              </div>
            </div>

            <div className="flex items-start gap-4 rounded-lg border border-gray-100 bg-white p-3">
              <div className="rounded-full bg-blue-100 p-1.5">
                <FileText className="h-4 w-4 text-blue-600" />
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <h4 className="font-medium">Certificaciones</h4>
                  <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                    Normal
                  </Badge>
                </div>
                <p className="text-sm text-gray-500">Emitir 5 certificados de estudios pendientes</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Actividad Reciente</CardTitle>
            <CardDescription>Últimas acciones realizadas en el sistema</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-start gap-4">
              <div className="rounded-full bg-green-100 p-1.5">
                <CheckCircle2 className="h-4 w-4 text-green-600" />
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium">Inscripción completada</p>
                <p className="text-xs text-gray-500">María Rodríguez - 3° Primaria</p>
                <p className="text-xs text-gray-400">Hace 35 minutos</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="rounded-full bg-indigo-100 p-1.5">
                <FileText className="h-4 w-4 text-indigo-600" />
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium">Reporte generado</p>
                <p className="text-xs text-gray-500">Listado de estudiantes - 5° Secundaria</p>
                <p className="text-xs text-gray-400">Hace 1 hora</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="rounded-full bg-blue-100 p-1.5">
                <Calendar className="h-4 w-4 text-blue-600" />
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium">Cita agendada</p>
                <p className="text-xs text-gray-500">Reunión con padre de Carlos Méndez</p>
                <p className="text-xs text-gray-400">Hace 2 horas</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="rounded-full bg-indigo-100 p-1.5">
                <Users className="h-4 w-4 text-indigo-600" />
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium">Nuevo registro</p>
                <p className="text-xs text-gray-500">Profesor de Matemáticas - Juan Pérez</p>
                <p className="text-xs text-gray-400">Hace 3 horas</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
