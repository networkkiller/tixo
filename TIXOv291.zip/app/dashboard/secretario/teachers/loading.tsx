import { Skeleton } from "@/components/ui/skeleton"

export default function Loading() {
  return (
    <div className="flex flex-col gap-5 p-8 bg-gradient-to-br from-indigo-500 to-indigo-700">
      <div className="flex items-center justify-between">
        <div>
          <Skeleton className="h-8 w-64 bg-white/20" />
          <Skeleton className="mt-2 h-4 w-48 bg-white/20" />
        </div>
        <div className="flex items-center gap-2">
          <Skeleton className="h-9 w-28 bg-white/20" />
          <Skeleton className="h-9 w-36 bg-white/20" />
        </div>
      </div>

      <Skeleton className="h-[600px] bg-white/20" />

      <div className="grid gap-4 md:grid-cols-2">
        <Skeleton className="h-80 bg-white/20" />
        <Skeleton className="h-80 bg-white/20" />
      </div>
    </div>
  )
}
