"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Checkbox } from "@/components/ui/checkbox"
import {
  CalendarIcon,
  Clock,
  Plus,
  Users,
  Bell,
  AlertTriangle,
  CheckCircle2,
  CalendarIcon as CalendarFull,
  ChevronLeft,
  ChevronRight,
  Trash2,
  Edit,
} from "lucide-react"

export default function CalendarPage() {
  const [currentMonth, setCurrentMonth] = useState(new Date())
  const [selectedDate, setSelectedDate] = useState<Date | null>(null)
  const [openDialog, setOpenDialog] = useState(false)

  // Datos de ejemplo
  const events = [
    {
      id: 1,
      title: "Reunión de Padres - 3° Primaria",
      date: "2023-06-15",
      time: "15:00",
      type: "reunion",
      location: "Salón de Actos",
      description: "Reunión para discutir el progreso académico del trimestre",
    },
    {
      id: 2,
      title: "Entrega de Notas - 5° Primaria",
      date: "2023-06-20",
      time: "14:00",
      type: "academico",
      location: "Aulas respectivas",
      description: "Entrega de calificaciones del segundo trimestre",
    },
    {
      id: 3,
      title: "Día Feriado - Día de la Independencia",
      date: "2023-06-25",
      type: "feriado",
      description: "No hay clases",
    },
    {
      id: 4,
      title: "Cita con Padre de Carlos Rodríguez",
      date: "2023-06-16",
      time: "10:30",
      type: "cita",
      location: "Oficina de Secretaría",
      description: "Discusión sobre comportamiento en clase",
      parent: "Roberto Rodríguez",
      student: "Carlos Rodríguez (3° Primaria)",
    },
    {
      id: 5,
      title: "Consejo de Profesores",
      date: "2023-06-18",
      time: "16:00",
      type: "reunion",
      location: "Sala de Profesores",
      description: "Evaluación de estrategias pedagógicas",
    },
  ]

  // Citas pendientes
  const appointments = [
    {
      id: 1,
      parent: "Roberto Rodríguez",
      student: "Carlos Rodríguez",
      date: "2023-06-16",
      time: "10:30",
      reason: "Discusión sobre comportamiento en clase",
      status: "confirmed",
    },
    {
      id: 2,
      parent: "María González",
      student: "Ana González",
      date: "2023-06-17",
      time: "14:00",
      reason: "Revisión de calificaciones",
      status: "pending",
    },
    {
      id: 3,
      parent: "Luis Martínez",
      student: "Pedro Martínez",
      date: "2023-06-19",
      time: "09:15",
      reason: "Solicitud de permiso especial",
      status: "confirmed",
    },
  ]

  // Próximos eventos
  const upcomingEvents = events
    .filter((event) => {
      const eventDate = new Date(event.date)
      const today = new Date()
      return eventDate >= today
    })
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())

  // Generar días del mes actual
  const getDaysInMonth = (year: number, month: number) => {
    return new Date(year, month + 1, 0).getDate()
  }

  const getFirstDayOfMonth = (year: number, month: number) => {
    return new Date(year, month, 1).getDay()
  }

  const renderCalendar = () => {
    const year = currentMonth.getFullYear()
    const month = currentMonth.getMonth()
    const daysInMonth = getDaysInMonth(year, month)
    const firstDayOfMonth = getFirstDayOfMonth(year, month)
    const days = []

    // Días del mes anterior
    for (let i = 0; i < firstDayOfMonth; i++) {
      days.push(<div key={`prev-${i}`} className="h-24 border border-gray-100 bg-gray-50 p-2 text-gray-400"></div>)
    }

    // Días del mes actual
    for (let day = 1; day <= daysInMonth; day++) {
      const date = new Date(year, month, day)
      const dateStr = date.toISOString().split("T")[0]
      const dayEvents = events.filter((event) => event.date === dateStr)

      days.push(
        <div
          key={day}
          className={`h-24 border border-gray-100 p-2 ${
            selectedDate?.toDateString() === date.toDateString() ? "bg-indigo-50 border-indigo-200" : "hover:bg-gray-50"
          }`}
          onClick={() => setSelectedDate(date)}
        >
          <div className="flex justify-between">
            <span className="font-medium">{day}</span>
            {dayEvents.length > 0 && (
              <Badge className="bg-indigo-100 text-indigo-800 border-indigo-200">{dayEvents.length}</Badge>
            )}
          </div>
          <div className="mt-1 space-y-1">
            {dayEvents.slice(0, 2).map((event, idx) => (
              <div
                key={idx}
                className={`text-xs truncate rounded px-1 py-0.5 ${
                  event.type === "reunion"
                    ? "bg-blue-100 text-blue-800"
                    : event.type === "academico"
                      ? "bg-green-100 text-green-800"
                      : event.type === "feriado"
                        ? "bg-red-100 text-red-800"
                        : "bg-amber-100 text-amber-800"
                }`}
              >
                {event.title}
              </div>
            ))}
            {dayEvents.length > 2 && <div className="text-xs text-gray-500">+{dayEvents.length - 2} más...</div>}
          </div>
        </div>,
      )
    }

    return days
  }

  const monthNames = [
    "Enero",
    "Febrero",
    "Marzo",
    "Abril",
    "Mayo",
    "Junio",
    "Julio",
    "Agosto",
    "Septiembre",
    "Octubre",
    "Noviembre",
    "Diciembre",
  ]

  const prevMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1, 1))
  }

  const nextMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1, 1))
  }

  return (
    <div className="p-8 bg-[#f0f4f8]">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Control de Calendario y Citas</h1>
          <p className="text-gray-500">Gestiona eventos institucionales y citas con padres</p>
        </div>
        <div className="flex gap-2">
          <Dialog open={openDialog} onOpenChange={setOpenDialog}>
            <DialogTrigger asChild>
              <Button className="bg-indigo-600 hover:bg-indigo-700 text-white gap-1">
                <Plus className="h-4 w-4" />
                <span>Nuevo Evento</span>
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[600px]">
              <DialogHeader>
                <DialogTitle>Crear Nuevo Evento</DialogTitle>
                <DialogDescription>
                  Complete la información para agregar un evento al calendario institucional.
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="event-title">Título del Evento</Label>
                  <Input id="event-title" placeholder="Título descriptivo" />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="event-date">Fecha</Label>
                    <Input id="event-date" type="date" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="event-time">Hora (opcional)</Label>
                    <Input id="event-time" type="time" />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="event-type">Tipo de Evento</Label>
                  <Select>
                    <SelectTrigger id="event-type">
                      <SelectValue placeholder="Seleccionar tipo" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="reunion">Reunión</SelectItem>
                      <SelectItem value="academico">Académico</SelectItem>
                      <SelectItem value="feriado">Día Feriado</SelectItem>
                      <SelectItem value="cita">Cita con Padres</SelectItem>
                      <SelectItem value="otro">Otro</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="event-location">Ubicación (opcional)</Label>
                  <Input id="event-location" placeholder="Lugar del evento" />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="event-description">Descripción</Label>
                  <Textarea id="event-description" placeholder="Detalles del evento" />
                </div>

                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox id="event-notify" />
                    <Label htmlFor="event-notify">Enviar notificación a los involucrados</Label>
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setOpenDialog(false)}>
                  Cancelar
                </Button>
                <Button className="bg-indigo-600 hover:bg-indigo-700 text-white">Guardar</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        {/* Sidebar con eventos y citas */}
        <div className="md:col-span-1 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Próximos Eventos</CardTitle>
              <CardDescription>Eventos programados para los próximos días</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {upcomingEvents.slice(0, 5).map((event) => (
                <div key={event.id} className="flex items-start gap-3 border-b border-gray-100 pb-3 last:border-0">
                  <div
                    className={`rounded-full p-2 ${
                      event.type === "reunion"
                        ? "bg-blue-100"
                        : event.type === "academico"
                          ? "bg-green-100"
                          : event.type === "feriado"
                            ? "bg-red-100"
                            : "bg-amber-100"
                    }`}
                  >
                    {event.type === "reunion" ? (
                      <Users className="h-4 w-4 text-blue-600" />
                    ) : event.type === "academico" ? (
                      <CalendarIcon className="h-4 w-4 text-green-600" />
                    ) : event.type === "feriado" ? (
                      <Bell className="h-4 w-4 text-red-600" />
                    ) : (
                      <Clock className="h-4 w-4 text-amber-600" />
                    )}
                  </div>
                  <div className="flex-1">
                    <h4 className="font-medium text-sm">{event.title}</h4>
                    <p className="text-xs text-gray-500">
                      {new Date(event.date).toLocaleDateString("es-ES", {
                        day: "numeric",
                        month: "long",
                      })}{" "}
                      {event.time && `• ${event.time}`}
                    </p>
                    {event.location && <p className="text-xs text-gray-500">{event.location}</p>}
                  </div>
                </div>
              ))}
              {upcomingEvents.length === 0 && (
                <div className="text-center py-4 text-gray-500">No hay eventos próximos programados</div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Citas Pendientes</CardTitle>
              <CardDescription>Reuniones programadas con padres</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {appointments.map((appointment) => (
                <div
                  key={appointment.id}
                  className="flex items-start gap-3 border-b border-gray-100 pb-3 last:border-0"
                >
                  <div
                    className={`rounded-full p-2 ${
                      appointment.status === "confirmed" ? "bg-green-100" : "bg-amber-100"
                    }`}
                  >
                    {appointment.status === "confirmed" ? (
                      <CheckCircle2 className="h-4 w-4 text-green-600" />
                    ) : (
                      <AlertTriangle className="h-4 w-4 text-amber-600" />
                    )}
                  </div>
                  <div className="flex-1">
                    <h4 className="font-medium text-sm">
                      {appointment.parent} - {appointment.student}
                    </h4>
                    <p className="text-xs text-gray-500">
                      {new Date(appointment.date).toLocaleDateString("es-ES", {
                        day: "numeric",
                        month: "long",
                      })}{" "}
                      • {appointment.time}
                    </p>
                    <p className="text-xs text-gray-500">{appointment.reason}</p>
                  </div>
                  <Badge
                    variant="outline"
                    className={
                      appointment.status === "confirmed"
                        ? "bg-green-50 text-green-700 border-green-200"
                        : "bg-amber-50 text-amber-700 border-amber-200"
                    }
                  >
                    {appointment.status === "confirmed" ? "Confirmada" : "Pendiente"}
                  </Badge>
                </div>
              ))}
              {appointments.length === 0 && (
                <div className="text-center py-4 text-gray-500">No hay citas pendientes</div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Calendario principal */}
        <div className="md:col-span-2">
          <Card>
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle>Calendario</CardTitle>
                <div className="flex items-center gap-2">
                  <Button variant="outline" size="icon" onClick={prevMonth}>
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  <div className="font-medium">
                    {monthNames[currentMonth.getMonth()]} {currentMonth.getFullYear()}
                  </div>
                  <Button variant="outline" size="icon" onClick={nextMonth}>
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-7 gap-0">
                {["Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"].map((day) => (
                  <div key={day} className="text-center font-medium py-2 text-sm">
                    {day}
                  </div>
                ))}
                {renderCalendar()}
              </div>
            </CardContent>
          </Card>

          {/* Detalles del día seleccionado */}
          {selectedDate && (
            <Card className="mt-6">
              <CardHeader>
                <CardTitle>
                  Eventos para el{" "}
                  {selectedDate.toLocaleDateString("es-ES", {
                    weekday: "long",
                    day: "numeric",
                    month: "long",
                    year: "numeric",
                  })}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {events
                    .filter((event) => event.date === selectedDate.toISOString().split("T")[0])
                    .map((event) => (
                      <div
                        key={event.id}
                        className="flex items-start gap-4 border-b border-gray-100 pb-4 last:border-0"
                      >
                        <div
                          className={`rounded-full p-2 ${
                            event.type === "reunion"
                              ? "bg-blue-100"
                              : event.type === "academico"
                                ? "bg-green-100"
                                : event.type === "feriado"
                                  ? "bg-red-100"
                                  : "bg-amber-100"
                          }`}
                        >
                          {event.type === "reunion" ? (
                            <Users className="h-5 w-5 text-blue-600" />
                          ) : event.type === "academico" ? (
                            <CalendarIcon className="h-5 w-5 text-green-600" />
                          ) : event.type === "feriado" ? (
                            <Bell className="h-5 w-5 text-red-600" />
                          ) : (
                            <Clock className="h-5 w-5 text-amber-600" />
                          )}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-start justify-between">
                            <div>
                              <h3 className="font-medium">{event.title}</h3>
                              {event.time && <p className="text-sm text-gray-500">Hora: {event.time}</p>}
                              {event.location && <p className="text-sm text-gray-500">Lugar: {event.location}</p>}
                              <p className="text-sm text-gray-500 mt-1">{event.description}</p>
                              {event.parent && (
                                <div className="mt-2">
                                  <p className="text-sm text-gray-500">Padre/Madre: {event.parent}</p>
                                  <p className="text-sm text-gray-500">Estudiante: {event.student}</p>
                                </div>
                              )}
                            </div>
                            <div className="flex gap-1">
                              <Button variant="ghost" size="icon" className="h-8 w-8">
                                <Edit className="h-4 w-4 text-gray-500" />
                              </Button>
                              <Button variant="ghost" size="icon" className="h-8 w-8">
                                <Trash2 className="h-4 w-4 text-red-500" />
                              </Button>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  {events.filter((event) => event.date === selectedDate.toISOString().split("T")[0]).length === 0 && (
                    <div className="text-center py-8 text-gray-500">
                      <CalendarFull className="h-12 w-12 mx-auto text-gray-300 mb-2" />
                      <p>No hay eventos programados para este día</p>
                      <Button
                        className="mt-4 bg-indigo-600 hover:bg-indigo-700 text-white"
                        onClick={() => setOpenDialog(true)}
                      >
                        <Plus className="h-4 w-4 mr-1" />
                        Agregar Evento
                      </Button>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
