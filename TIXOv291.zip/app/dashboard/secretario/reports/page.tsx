"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import {
  FileText,
  Download,
  Search,
  Filter,
  Printer,
  FileOutput,
  BarChart3,
  Users,
  Calendar,
  CheckCircle2,
  Clock,
  AlertTriangle,
  ChevronRight,
  School,
  GraduationCap,
  UserCheck,
} from "lucide-react"

const stats = {
  totalStudents: 500,
  maleStudents: 250,
  femaleStudents: 250,
  primaryStudents: 300,
  secondaryStudents: 200,
  attendanceRate: 95,
  passRate: 85,
}

export default function ReportsPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [filterType, setFilterType] = useState("all")
  const [openDialog, setOpenDialog] = useState(false)

  // Datos de ejemplo
  const reports = [
    {
      id: 1,
      name: "Constancia de Inscripción - Carlos Rodríguez",
      type: "constancia",
      date: "2023-06-10",
      student: "Carlos Rodríguez",
      grade: "3° Primaria",
      status: "completed",
    },
    {
      id: 2,
      name: "Certificado de Conducta - Laura Martínez",
      type: "certificado",
      date: "2023-06-08",
      student: "Laura Martínez",
      grade: "5° Primaria",
      status: "completed",
    },
    {
      id: 3,
      name: "Récord Académico - Miguel Sánchez",
      type: "record",
      date: "2023-06-05",
      student: "Miguel Sánchez",
      grade: "2° Secundaria",
      status: "pending",
    },
    {
      id: 4,
      name: "Reporte de Matrícula - 3° Primaria",
      type: "reporte",
      date: "2023-05-28",
      grade: "3° Primaria",
      status: "completed",
    },
    {
      id: 5,
      name: "Reporte de Asistencia - Mayo 2023",
      type: "asistencia",
      date: "2023-06-01",
      period: "Mayo 2023",
      status: "completed",
    },
  ]

  // Filtrar reportes
  const filteredReports = reports.filter((report) => {
    const matchesSearch =
      report.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (report.student && report.student.toLowerCase().includes(searchTerm.toLowerCase()))
    const matchesType = filterType === "all" || report.type === filterType

    return matchesSearch && matchesType
  })

  return (
    <div className="p-8 bg-[#f0f4f8]">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Reportes Académicos y Administrativos</h1>
          <p className="text-gray-500">Genera certificaciones, constancias y reportes institucionales</p>
        </div>
        <div className="flex gap-2">
          <Dialog open={openDialog} onOpenChange={setOpenDialog}>
            <DialogTrigger asChild>
              <Button className="bg-indigo-600 hover:bg-indigo-700 text-white gap-1">
                <FileText className="h-4 w-4" />
                <span>Nuevo Documento</span>
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[600px]">
              <DialogHeader>
                <DialogTitle>Generar Nuevo Documento</DialogTitle>
                <DialogDescription>
                  Seleccione el tipo de documento que desea generar y complete la información requerida.
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="doc-type">Tipo de Documento</Label>
                  <Select>
                    <SelectTrigger id="doc-type">
                      <SelectValue placeholder="Seleccionar tipo" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="constancia">Constancia de Inscripción</SelectItem>
                      <SelectItem value="certificado">Certificado de Conducta</SelectItem>
                      <SelectItem value="record">Récord Académico</SelectItem>
                      <SelectItem value="reporte">Reporte de Matrícula</SelectItem>
                      <SelectItem value="asistencia">Reporte de Asistencia</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="student">Estudiante (si aplica)</Label>
                  <Select>
                    <SelectTrigger id="student">
                      <SelectValue placeholder="Seleccionar estudiante" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="est1">Carlos Rodríguez (3° Primaria)</SelectItem>
                      <SelectItem value="est2">Laura Martínez (5° Primaria)</SelectItem>
                      <SelectItem value="est3">Miguel Sánchez (2° Secundaria)</SelectItem>
                      <SelectItem value="est4">Ana García (4° Primaria)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="grade">Grado/Curso (si aplica)</Label>
                  <Select>
                    <SelectTrigger id="grade">
                      <SelectValue placeholder="Seleccionar grado" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1p">1° Primaria</SelectItem>
                      <SelectItem value="2p">2° Primaria</SelectItem>
                      <SelectItem value="3p">3° Primaria</SelectItem>
                      <SelectItem value="4p">4° Primaria</SelectItem>
                      <SelectItem value="5p">5° Primaria</SelectItem>
                      <SelectItem value="6p">6° Primaria</SelectItem>
                      <SelectItem value="1s">1° Secundaria</SelectItem>
                      <SelectItem value="2s">2° Secundaria</SelectItem>
                      <SelectItem value="3s">3° Secundaria</SelectItem>
                      <SelectItem value="4s">4° Secundaria</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Período (si aplica)</Label>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="period-month">Mes</Label>
                      <Select>
                        <SelectTrigger id="period-month">
                          <SelectValue placeholder="Mes" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1">Enero</SelectItem>
                          <SelectItem value="2">Febrero</SelectItem>
                          <SelectItem value="3">Marzo</SelectItem>
                          <SelectItem value="4">Abril</SelectItem>
                          <SelectItem value="5">Mayo</SelectItem>
                          <SelectItem value="6">Junio</SelectItem>
                          <SelectItem value="7">Julio</SelectItem>
                          <SelectItem value="8">Agosto</SelectItem>
                          <SelectItem value="9">Septiembre</SelectItem>
                          <SelectItem value="10">Octubre</SelectItem>
                          <SelectItem value="11">Noviembre</SelectItem>
                          <SelectItem value="12">Diciembre</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="period-year">Año</Label>
                      <Select>
                        <SelectTrigger id="period-year">
                          <SelectValue placeholder="Año" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="2023">2023</SelectItem>
                          <SelectItem value="2022">2022</SelectItem>
                          <SelectItem value="2021">2021</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Opciones adicionales</Label>
                  <RadioGroup defaultValue="digital">
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="digital" id="digital" />
                      <Label htmlFor="digital">Documento digital (PDF)</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="print" id="print" />
                      <Label htmlFor="print">Preparar para impresión</Label>
                    </div>
                  </RadioGroup>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setOpenDialog(false)}>
                  Cancelar
                </Button>
                <Button className="bg-indigo-600 hover:bg-indigo-700 text-white">Generar</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Tabs defaultValue="documents" className="w-full">
        <TabsList className="mb-4">
          <TabsTrigger value="documents">Documentos</TabsTrigger>
          <TabsTrigger value="statistics">Estadísticas</TabsTrigger>
          <TabsTrigger value="exports">Exportaciones</TabsTrigger>
        </TabsList>

        <TabsContent value="documents">
          <div className="mb-6 flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
              <Input
                placeholder="Buscar por nombre o estudiante..."
                className="pl-8"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Select value={filterType} onValueChange={setFilterType}>
              <SelectTrigger className="w-full sm:w-[180px]">
                <div className="flex items-center">
                  <Filter className="mr-2 h-4 w-4" />
                  <span>Tipo</span>
                </div>
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos los tipos</SelectItem>
                <SelectItem value="constancia">Constancias</SelectItem>
                <SelectItem value="certificado">Certificados</SelectItem>
                <SelectItem value="record">Récords Académicos</SelectItem>
                <SelectItem value="reporte">Reportes de Matrícula</SelectItem>
                <SelectItem value="asistencia">Reportes de Asistencia</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="grid gap-4">
            {filteredReports.map((report) => (
              <Card key={report.id} className="overflow-hidden">
                <div className="flex flex-col md:flex-row">
                  <div className="flex-1 p-6">
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="flex items-center gap-2">
                          <FileText className="h-5 w-5 text-indigo-600" />
                          <h3 className="text-lg font-semibold">{report.name}</h3>
                          <Badge
                            variant="outline"
                            className={
                              report.type === "constancia"
                                ? "bg-blue-50 text-blue-700 border-blue-200"
                                : report.type === "certificado"
                                  ? "bg-green-50 text-green-700 border-green-200"
                                  : report.type === "record"
                                    ? "bg-purple-50 text-purple-700 border-purple-200"
                                    : report.type === "reporte"
                                      ? "bg-amber-50 text-amber-700 border-amber-200"
                                      : "bg-indigo-50 text-indigo-700 border-indigo-200"
                            }
                          >
                            {report.type === "constancia"
                              ? "Constancia"
                              : report.type === "certificado"
                                ? "Certificado"
                                : report.type === "record"
                                  ? "Récord Académico"
                                  : report.type === "reporte"
                                    ? "Reporte de Matrícula"
                                    : "Reporte de Asistencia"}
                          </Badge>
                        </div>
                        <div className="mt-2 space-y-1 text-sm text-gray-500">
                          <div className="flex items-center gap-2">
                            <Calendar className="h-4 w-4" />
                            <span>Generado: {report.date}</span>
                          </div>
                          {report.student && (
                            <div className="flex items-center gap-2">
                              <Users className="h-4 w-4" />
                              <span>Estudiante: {report.student}</span>
                            </div>
                          )}
                          {report.grade && (
                            <div className="flex items-center gap-2">
                              <School className="h-4 w-4" />
                              <span>Grado: {report.grade}</span>
                            </div>
                          )}
                          {report.period && (
                            <div className="flex items-center gap-2">
                              <Calendar className="h-4 w-4" />
                              <span>Período: {report.period}</span>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                    <div className="flex flex-row md:flex-col justify-between border-t md:border-t-0 md:border-l border-gray-100 bg-gray-50 p-4">
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-indigo-600 hover:text-indigo-700 hover:bg-indigo-50"
                      >
                        <Download className="mr-1 h-4 w-4" />
                        Descargar
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-indigo-600 hover:text-indigo-700 hover:bg-indigo-50"
                      >
                        <Printer className="mr-1 h-4 w-4" />
                        Imprimir
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-indigo-600 hover:text-indigo-700 hover:bg-indigo-50"
                      >
                        <FileOutput className="mr-1 h-4 w-4" />
                        Enviar
                      </Button>
                    </div>
                  </div>
                </div>
              </Card>
            ))}
            {filteredReports.length === 0 && (
              <Card>
                <CardContent className="flex flex-col items-center justify-center p-6">
                  <FileText className="h-12 w-12 text-gray-300 mb-2" />
                  <p className="text-gray-500">No se encontraron documentos que coincidan con la búsqueda.</p>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>

        <TabsContent value="statistics">
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Estadísticas de Matrícula</CardTitle>
                <CardDescription>Distribución actual de estudiantes</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium">Total de Estudiantes</span>
                      <span className="font-bold">{stats.totalStudents}</span>
                    </div>
                    <div className="h-2 w-full bg-gray-100 rounded-full">
                      <div className="h-2 bg-indigo-600 rounded-full" style={{ width: "100%" }}></div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium">Masculino</span>
                        <span className="font-bold">{stats.maleStudents}</span>
                      </div>
                      <div className="h-2 w-full bg-gray-100 rounded-full">
                        <div
                          className="h-2 bg-blue-500 rounded-full"
                          style={{ width: `${(stats.maleStudents / stats.totalStudents) * 100}%` }}
                        ></div>
                      </div>
                    </div>
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium">Femenino</span>
                        <span className="font-bold">{stats.femaleStudents}</span>
                      </div>
                      <div className="h-2 w-full bg-gray-100 rounded-full">
                        <div
                          className="h-2 bg-pink-500 rounded-full"
                          style={{ width: `${(stats.femaleStudents / stats.totalStudents) * 100}%` }}
                        ></div>
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium">Primaria</span>
                        <span className="font-bold">{stats.primaryStudents}</span>
                      </div>
                      <div className="h-2 w-full bg-gray-100 rounded-full">
                        <div
                          className="h-2 bg-green-500 rounded-full"
                          style={{ width: `${(stats.primaryStudents / stats.totalStudents) * 100}%` }}
                        ></div>
                      </div>
                    </div>
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium">Secundaria</span>
                        <span className="font-bold">{stats.secondaryStudents}</span>
                      </div>
                      <div className="h-2 w-full bg-gray-100 rounded-full">
                        <div
                          className="h-2 bg-amber-500 rounded-full"
                          style={{ width: `${(stats.secondaryStudents / stats.totalStudents) * 100}%` }}
                        ></div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Indicadores Académicos</CardTitle>
                <CardDescription>Rendimiento general del centro educativo</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium">Tasa de Asistencia</span>
                      <span className="font-bold">{stats.attendanceRate}%</span>
                    </div>
                    <div className="h-2 w-full bg-gray-100 rounded-full">
                      <div
                        className="h-2 bg-green-500 rounded-full"
                        style={{ width: `${stats.attendanceRate}%` }}
                      ></div>
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium">Tasa de Aprobación</span>
                      <span className="font-bold">{stats.passRate}%</span>
                    </div>
                    <div className="h-2 w-full bg-gray-100 rounded-full">
                      <div className="h-2 bg-blue-500 rounded-full" style={{ width: `${stats.passRate}%` }}></div>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-4 pt-4">
                    <div className="flex flex-col items-center p-3 bg-green-50 rounded-lg">
                      <div className="rounded-full bg-green-100 p-2 mb-2">
                        <CheckCircle2 className="h-5 w-5 text-green-600" />
                      </div>
                      <span className="text-sm font-medium text-center">Estudiantes Destacados</span>
                      <span className="text-lg font-bold">187</span>
                    </div>
                    <div className="flex flex-col items-center p-3 bg-amber-50 rounded-lg">
                      <div className="rounded-full bg-amber-100 p-2 mb-2">
                        <Clock className="h-5 w-5 text-amber-600" />
                      </div>
                      <span className="text-sm font-medium text-center">En Seguimiento</span>
                      <span className="text-lg font-bold">124</span>
                    </div>
                    <div className="flex flex-col items-center p-3 bg-red-50 rounded-lg">
                      <div className="rounded-full bg-red-100 p-2 mb-2">
                        <AlertTriangle className="h-5 w-5 text-red-600" />
                      </div>
                      <span className="text-sm font-medium text-center">En Riesgo</span>
                      <span className="text-lg font-bold">43</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Distribución por Grado</CardTitle>
                <CardDescription>Cantidad de estudiantes por nivel</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="h-3 w-3 rounded-full bg-indigo-500"></div>
                      <span className="text-sm">1° Primaria</span>
                    </div>
                    <span className="font-medium">128 estudiantes</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="h-3 w-3 rounded-full bg-blue-500"></div>
                      <span className="text-sm">2° Primaria</span>
                    </div>
                    <span className="font-medium">115 estudiantes</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="h-3 w-3 rounded-full bg-green-500"></div>
                      <span className="text-sm">3° Primaria</span>
                    </div>
                    <span className="font-medium">122 estudiantes</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="h-3 w-3 rounded-full bg-yellow-500"></div>
                      <span className="text-sm">4° Primaria</span>
                    </div>
                    <span className="font-medium">118 estudiantes</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="h-3 w-3 rounded-full bg-orange-500"></div>
                      <span className="text-sm">5° Primaria</span>
                    </div>
                    <span className="font-medium">120 estudiantes</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="h-3 w-3 rounded-full bg-red-500"></div>
                      <span className="text-sm">6° Primaria</span>
                    </div>
                    <span className="font-medium">117 estudiantes</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Reportes Generados</CardTitle>
                <CardDescription>Documentos emitidos en los últimos 30 días</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="flex flex-col items-center p-4 bg-blue-50 rounded-lg">
                      <div className="rounded-full bg-blue-100 p-2 mb-2">
                        <FileText className="h-5 w-5 text-blue-600" />
                      </div>
                      <span className="text-sm font-medium">Constancias</span>
                      <span className="text-lg font-bold">42</span>
                    </div>
                    <div className="flex flex-col items-center p-4 bg-green-50 rounded-lg">
                      <div className="rounded-full bg-green-100 p-2 mb-2">
                        <UserCheck className="h-5 w-5 text-green-600" />
                      </div>
                      <span className="text-sm font-medium">Certificados</span>
                      <span className="text-lg font-bold">28</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="flex flex-col items-center p-4 bg-purple-50 rounded-lg">
                      <div className="rounded-full bg-purple-100 p-2 mb-2">
                        <GraduationCap className="h-5 w-5 text-purple-600" />
                      </div>
                      <span className="text-sm font-medium">Récords</span>
                      <span className="text-lg font-bold">15</span>
                    </div>
                    <div className="flex flex-col items-center p-4 bg-amber-50 rounded-lg">
                      <div className="rounded-full bg-amber-100 p-2 mb-2">
                        <BarChart3 className="h-5 w-5 text-amber-600" />
                      </div>
                      <span className="text-sm font-medium">Reportes</span>
                      <span className="text-lg font-bold">23</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="exports">
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Exportar para MINERD (SIACE)</CardTitle>
                <CardDescription>Generar archivos para el Sistema de Información</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 cursor-pointer">
                    <div className="flex items-center gap-3">
                      <div className="rounded-full bg-blue-100 p-2">
                        <Users className="h-5 w-5 text-blue-600" />
                      </div>
                      <div>
                        <h4 className="font-medium">Matrícula Estudiantil</h4>
                        <p className="text-sm text-gray-500">Listado completo de estudiantes activos</p>
                      </div>
                    </div>
                    <ChevronRight className="h-5 w-5 text-gray-400" />
                  </div>

                  <div className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 cursor-pointer">
                    <div className="flex items-center gap-3">
                      <div className="rounded-full bg-green-100 p-2">
                        <School className="h-5 w-5 text-green-600" />
                      </div>
                      <div>
                        <h4 className="font-medium">Distribución por Grado</h4>
                        <p className="text-sm text-gray-500">Cantidad de estudiantes por nivel y sección</p>
                      </div>
                    </div>
                    <ChevronRight className="h-5 w-5 text-gray-400" />
                  </div>

                  <div className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 cursor-pointer">
                    <div className="flex items-center gap-3">
                      <div className="rounded-full bg-amber-100 p-2">
                        <BarChart3 className="h-5 w-5 text-amber-600" />
                      </div>
                      <div>
                        <h4 className="font-medium">Rendimiento Académico</h4>
                        <p className="text-sm text-gray-500">Estadísticas de aprobación y reprobación</p>
                      </div>
                    </div>
                    <ChevronRight className="h-5 w-5 text-gray-400" />
                  </div>

                  <div className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 cursor-pointer">
                    <div className="flex items-center gap-3">
                      <div className="rounded-full bg-red-100 p-2">
                        <Clock className="h-5 w-5 text-red-600" />
                      </div>
                      <div>
                        <h4 className="font-medium">Asistencia General</h4>
                        <p className="text-sm text-gray-500">Reporte de asistencia por período</p>
                      </div>
                    </div>
                    <ChevronRight className="h-5 w-5 text-gray-400" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Exportaciones Recientes</CardTitle>
                <CardDescription>Últimos archivos generados para el MINERD</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <FileText className="h-5 w-5 text-indigo-600" />
                      <div>
                        <h4 className="font-medium">Matrícula_Mayo2023.xlsx</h4>
                        <p className="text-sm text-gray-500">Generado: 01/06/2023</p>
                      </div>
                    </div>
                    <Button variant="ghost" size="sm" className="text-indigo-600">
                      <Download className="h-4 w-4" />
                    </Button>
                  </div>

                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <FileText className="h-5 w-5 text-indigo-600" />
                      <div>
                        <h4 className="font-medium">Asistencia_Abril2023.xlsx</h4>
                        <p className="text-sm text-gray-500">Generado: 05/05/2023</p>
                      </div>
                    </div>
                    <Button variant="ghost" size="sm" className="text-indigo-600">
                      <Download className="h-4 w-4" />
                    </Button>
                  </div>

                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <FileText className="h-5 w-5 text-indigo-600" />
                      <div>
                        <h4 className="font-medium">Rendimiento_Trimestre2.xlsx</h4>
                        <p className="text-sm text-gray-500">Generado: 15/04/2023</p>
                      </div>
                    </div>
                    <Button variant="ghost" size="sm" className="text-indigo-600">
                      <Download className="h-4 w-4" />
                    </Button>
                  </div>

                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <FileText className="h-5 w-5 text-indigo-600" />
                      <div>
                        <h4 className="font-medium">Distribución_Aulas_2023.xlsx</h4>
                        <p className="text-sm text-gray-500">Generado: 10/03/2023</p>
                      </div>
                    </div>
                    <Button variant="ghost" size="sm" className="text-indigo-600">
                      <Download className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
