"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import {
  Search,
  Plus,
  Filter,
  Download,
  FileText,
  File,
  FileIcon as FilePdf,
  FileImage,
  FileArchive,
  Calendar,
  Users,
  School,
  Tag,
  Upload,
  Eye,
  Printer,
  Share2,
  ChevronRight,
  ChevronDown,
} from "lucide-react"

export default function ArchivePage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [filterType, setFilterType] = useState("all")
  const [openDialog, setOpenDialog] = useState(false)
  const [expandedCategories, setExpandedCategories] = useState<string[]>(["actas", "certificaciones"])

  // Datos de ejemplo
  const documents = [
    {
      id: 1,
      name: "Acta de Reunión - Consejo Directivo",
      type: "Acta",
      date: "2023-06-01",
      category: "actas",
      format: "pdf",
      size: "1.2 MB",
      author: "María González",
      tags: ["consejo", "directivo", "acuerdos"],
    },
    {
      id: 2,
      name: "Certificación de Estudios - Carlos Rodríguez",
      type: "Certificación",
      date: "2023-05-28",
      category: "certificaciones",
      format: "pdf",
      size: "0.8 MB",
      author: "Laura Sánchez",
      student: "Carlos Rodríguez",
      tags: ["certificado", "primaria", "3° grado"],
    },
    {
      id: 3,
      name: "Constancia de Retiro - Miguel Sánchez",
      type: "Constancia",
      date: "2023-05-15",
      category: "constancias",
      format: "pdf",
      size: "0.5 MB",
      author: "Laura Sánchez",
      student: "Miguel Sánchez",
      tags: ["retiro", "primaria", "5° grado"],
    },
    {
      id: 4,
      name: "Acta de Entrega de Materiales",
      type: "Acta",
      date: "2023-05-10",
      category: "actas",
      format: "docx",
      size: "0.7 MB",
      author: "Roberto Pérez",
      tags: ["materiales", "inventario", "entrega"],
    },
    {
      id: 5,
      name: "Registro Sanitario Escolar",
      type: "Documento Legal",
      date: "2023-04-20",
      category: "documentos_legales",
      format: "pdf",
      size: "2.1 MB",
      author: "Carmen Martínez",
      tags: ["sanitario", "legal", "permisos"],
    },
    {
      id: 6,
      name: "Certificación de Conducta - Laura Rodríguez",
      type: "Certificación",
      date: "2023-04-15",
      category: "certificaciones",
      format: "pdf",
      size: "0.6 MB",
      author: "Laura Sánchez",
      student: "Laura Rodríguez",
      tags: ["certificado", "conducta", "primaria", "1° grado"],
    },
    {
      id: 7,
      name: "Permiso de Operación Escolar",
      type: "Documento Legal",
      date: "2023-03-10",
      category: "documentos_legales",
      format: "pdf",
      size: "3.5 MB",
      author: "Roberto Pérez",
      tags: ["legal", "operación", "permisos"],
    },
  ]

  const filteredDocuments = documents.filter((doc) => {
    const matchesSearch =
      doc.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      doc.tags.some((tag) => tag.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (doc.student && doc.student.toLowerCase().includes(searchTerm.toLowerCase()))

    const matchesType = filterType === "all" || doc.type === filterType

    return matchesSearch && matchesType
  })

  const toggleCategory = (category: string) => {
    setExpandedCategories((prev) =>
      prev.includes(category) ? prev.filter((c) => c !== category) : [...prev, category],
    )
  }

  const getFileIcon = (format: string) => {
    switch (format) {
      case "pdf":
        return <FilePdf className="h-5 w-5 text-red-500" />
      case "docx":
        return <FileText className="h-5 w-5 text-blue-500" />
      case "jpg":
      case "png":
        return <FileImage className="h-5 w-5 text-purple-500" />
      default:
        return <File className="h-5 w-5 text-gray-500" />
    }
  }

  const categories = [
    { id: "actas", name: "Actas de Reuniones", icon: <Calendar className="h-5 w-5" /> },
    { id: "certificaciones", name: "Certificaciones de Estudio", icon: <FileText className="h-5 w-5" /> },
    { id: "constancias", name: "Constancias de Retiro", icon: <FileArchive className="h-5 w-5" /> },
    { id: "documentos_legales", name: "Documentación Legal", icon: <School className="h-5 w-5" /> },
  ]

  return (
    <div className="p-8 bg-[#f0f4f8]">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Archivo Institucional</h1>
          <p className="text-gray-500">Gestión y organización de documentos digitales</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="gap-1">
            <Download className="h-4 w-4" />
            <span>Exportar</span>
          </Button>
          <Dialog open={openDialog} onOpenChange={setOpenDialog}>
            <DialogTrigger asChild>
              <Button className="bg-indigo-600 hover:bg-indigo-700 text-white gap-1">
                <Plus className="h-4 w-4" />
                <span>Nuevo Documento</span>
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[600px]">
              <DialogHeader>
                <DialogTitle>Registrar Nuevo Documento</DialogTitle>
                <DialogDescription>
                  Complete la información y adjunte el documento para agregarlo al archivo institucional.
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="doc-name">Nombre del Documento</Label>
                    <Input id="doc-name" placeholder="Título del documento" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="doc-type">Tipo de Documento</Label>
                    <Select>
                      <SelectTrigger id="doc-type">
                        <SelectValue placeholder="Seleccionar tipo" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="acta">Acta</SelectItem>
                        <SelectItem value="certificacion">Certificación</SelectItem>
                        <SelectItem value="constancia">Constancia</SelectItem>
                        <SelectItem value="documento_legal">Documento Legal</SelectItem>
                        <SelectItem value="otro">Otro</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="doc-category">Categoría</Label>
                    <Select>
                      <SelectTrigger id="doc-category">
                        <SelectValue placeholder="Seleccionar categoría" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="actas">Actas de Reuniones</SelectItem>
                        <SelectItem value="certificaciones">Certificaciones de Estudio</SelectItem>
                        <SelectItem value="constancias">Constancias de Retiro</SelectItem>
                        <SelectItem value="documentos_legales">Documentación Legal</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="doc-date">Fecha del Documento</Label>
                    <Input id="doc-date" type="date" />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="doc-description">Descripción</Label>
                  <Textarea id="doc-description" placeholder="Breve descripción del contenido" />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="doc-tags">Etiquetas (separadas por coma)</Label>
                  <Input id="doc-tags" placeholder="reunión, acuerdos, consejo..." />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="doc-student">Estudiante Relacionado (opcional)</Label>
                  <Select>
                    <SelectTrigger id="doc-student">
                      <SelectValue placeholder="Seleccionar estudiante" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="est1">Carlos Rodríguez (3° Primaria)</SelectItem>
                      <SelectItem value="est2">Laura Rodríguez (1° Primaria)</SelectItem>
                      <SelectItem value="est3">Miguel Sánchez (5° Primaria)</SelectItem>
                      <SelectItem value="est4">José Martínez (2° Secundaria)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Adjuntar Documento</Label>
                  <div className="flex items-center justify-center w-full">
                    <label
                      htmlFor="dropzone-file"
                      className="flex flex-col items-center justify-center w-full h-32 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100"
                    >
                      <div className="flex flex-col items-center justify-center pt-5 pb-6">
                        <Upload className="w-8 h-8 mb-3 text-gray-400" />
                        <p className="mb-2 text-sm text-gray-500">
                          <span className="font-semibold">Haga clic para cargar</span> o arrastre y suelte
                        </p>
                        <p className="text-xs text-gray-500">PDF, DOCX, JPG, PNG (MAX. 10MB)</p>
                      </div>
                      <input id="dropzone-file" type="file" className="hidden" />
                    </label>
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setOpenDialog(false)}>
                  Cancelar
                </Button>
                <Button className="bg-indigo-600 hover:bg-indigo-700 text-white">Guardar</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="mb-6 flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
          <Input
            placeholder="Buscar por nombre, etiqueta o estudiante..."
            className="pl-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <Select value={filterType} onValueChange={setFilterType}>
          <SelectTrigger className="w-full sm:w-[180px]">
            <div className="flex items-center">
              <Filter className="mr-2 h-4 w-4" />
              <span>Tipo</span>
            </div>
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos los tipos</SelectItem>
            <SelectItem value="Acta">Actas</SelectItem>
            <SelectItem value="Certificación">Certificaciones</SelectItem>
            <SelectItem value="Constancia">Constancias</SelectItem>
            <SelectItem value="Documento Legal">Documentos Legales</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="grid md:grid-cols-4 gap-6">
        {/* Sidebar de categorías */}
        <div className="md:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle>Categorías</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {categories.map((category) => (
                <div key={category.id} className="space-y-2">
                  <button
                    onClick={() => toggleCategory(category.id)}
                    className="flex items-center justify-between w-full p-2 text-left rounded-md hover:bg-gray-100"
                  >
                    <div className="flex items-center">
                      {category.icon}
                      <span className="ml-2">{category.name}</span>
                    </div>
                    {expandedCategories.includes(category.id) ? (
                      <ChevronDown className="h-4 w-4" />
                    ) : (
                      <ChevronRight className="h-4 w-4" />
                    )}
                  </button>

                  {expandedCategories.includes(category.id) && (
                    <div className="pl-7 space-y-1">
                      {documents
                        .filter((doc) => doc.category === category.id)
                        .map((doc) => (
                          <div
                            key={doc.id}
                            className="flex items-center text-sm py-1 px-2 rounded-md hover:bg-gray-100"
                          >
                            <div className="mr-2">{getFileIcon(doc.format)}</div>
                            <span className="truncate">{doc.name}</span>
                          </div>
                        ))}
                    </div>
                  )}
                </div>
              ))}
            </CardContent>
          </Card>
        </div>

        {/* Lista de documentos */}
        <div className="md:col-span-3">
          <Tabs defaultValue="all" className="w-full">
            <TabsList className="mb-4">
              <TabsTrigger value="all">Todos los Documentos</TabsTrigger>
              <TabsTrigger value="recent">Recientes</TabsTrigger>
              <TabsTrigger value="favorites">Favoritos</TabsTrigger>
            </TabsList>

            <TabsContent value="all">
              <div className="grid gap-4">
                {filteredDocuments.length > 0 ? (
                  filteredDocuments.map((doc) => (
                    <Card key={doc.id} className="overflow-hidden">
                      <CardContent className="p-0">
                        <div className="flex flex-col md:flex-row">
                          <div className="flex-1 p-6">
                            <div className="flex items-start justify-between">
                              <div>
                                <div className="flex items-center gap-2">
                                  {getFileIcon(doc.format)}
                                  <h3 className="text-lg font-semibold">{doc.name}</h3>
                                  <Badge variant="outline" className="bg-indigo-50 text-indigo-700 border-indigo-200">
                                    {doc.type}
                                  </Badge>
                                </div>
                                <div className="mt-2 space-y-1 text-sm text-gray-500">
                                  <div className="flex items-center gap-2">
                                    <Calendar className="h-4 w-4" />
                                    <span>Fecha: {doc.date}</span>
                                  </div>
                                  <div className="flex items-center gap-2">
                                    <Users className="h-4 w-4" />
                                    <span>Autor: {doc.author}</span>
                                  </div>
                                  {doc.student && (
                                    <div className="flex items-center gap-2">
                                      <School className="h-4 w-4" />
                                      <span>Estudiante: {doc.student}</span>
                                    </div>
                                  )}
                                  <div className="flex items-center gap-2">
                                    <Tag className="h-4 w-4" />
                                    <span>Etiquetas: {doc.tags.join(", ")}</span>
                                  </div>
                                </div>
                              </div>
                              <div className="text-sm text-gray-500">{doc.size}</div>
                            </div>
                          </div>
                          <div className="flex flex-row md:flex-col justify-between border-t md:border-t-0 md:border-l border-gray-100 bg-gray-50 p-4">
                            <Button
                              variant="ghost"
                              size="sm"
                              className="text-indigo-600 hover:text-indigo-700 hover:bg-indigo-50"
                            >
                              <Eye className="mr-1 h-4 w-4" />
                              Ver
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="text-indigo-600 hover:text-indigo-700 hover:bg-indigo-50"
                            >
                              <Download className="mr-1 h-4 w-4" />
                              Descargar
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="text-indigo-600 hover:text-indigo-700 hover:bg-indigo-50"
                            >
                              <Printer className="mr-1 h-4 w-4" />
                              Imprimir
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="text-indigo-600 hover:text-indigo-700 hover:bg-indigo-50"
                            >
                              <Share2 className="mr-1 h-4 w-4" />
                              Compartir
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                ) : (
                  <Card>
                    <CardContent className="flex flex-col items-center justify-center p-6">
                      <FileText className="h-12 w-12 text-gray-300 mb-2" />
                      <p className="text-gray-500">No se encontraron documentos que coincidan con la búsqueda.</p>
                    </CardContent>
                  </Card>
                )}
              </div>
            </TabsContent>

            <TabsContent value="recent">
              <Card>
                <CardHeader>
                  <CardTitle>Documentos Recientes</CardTitle>
                  <CardDescription>Documentos agregados o modificados recientemente</CardDescription>
                </CardHeader>
                <CardContent>
                  <p>Lista de documentos recientes.</p>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="favorites">
              <Card>
                <CardHeader>
                  <CardTitle>Documentos Favoritos</CardTitle>
                  <CardDescription>Documentos marcados como favoritos</CardDescription>
                </CardHeader>
                <CardContent>
                  <p>Lista de documentos favoritos.</p>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}
