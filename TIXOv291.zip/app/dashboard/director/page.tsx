"use client"

import { Header } from "@/components/dashboard/header"
import { InstitutionalAttendanceSummary } from "@/components/dashboard/institutional-attendance-summary"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  BarChart3,
  BookOpen,
  Users,
  GraduationCap,
  UserCheck,
  UserX,
  Calendar,
  AlertTriangle,
  Download,
  Eye,
  Plus,
  Clock,
  CheckCircle,
  XCircle,
  DollarSign,
  Send,
  Brain,
  School,
  UserPlus,
  AlertCircle,
} from "lucide-react"

export default function DirectorDashboard() {
  // Datos simulados para estudiantes fuera de rango
  const outOfRangeStudents = {
    total: 12,
    byGrade: {
      "1° Primaria": 2,
      "3° Secundaria": 4,
      "5° Primaria": 3,
      "2° Secundaria": 3,
    },
    authorized: 5,
    pending: 7,
  }

  return (
    <div className="flex-1 flex flex-col">
      <Header title="Dashboard Local" />

      <main className="flex-1 overflow-y-auto p-6 bg-gradient-to-br from-futuristic-background via-futuristic-surface to-futuristic-background">
        {/* Resumen Institucional de Asistencia Docente */}
        <div className="mb-8">
          <InstitutionalAttendanceSummary />
        </div>

        {/* Resumen General del Colegio */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 bg-gradient-to-br from-futuristic-primary to-futuristic-creative rounded-xl flex items-center justify-center">
              <School className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-futuristic-text-primary">Resumen General del Colegio</h2>
              <p className="text-futuristic-text-secondary">Vista completa de la actividad institucional</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
            {/* Total de Cursos */}
            <Card className="bg-futuristic-surface border-futuristic-primary/10 hover:border-futuristic-primary/30 transition-all duration-300 hover:shadow-lg hover:shadow-futuristic-primary/10">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-futuristic-text-secondary text-sm font-medium">Total de Cursos</CardTitle>
                <BookOpen className="h-5 w-5 text-futuristic-primary" />
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-futuristic-text-primary">18</div>
                <p className="text-xs text-futuristic-success mt-1">487 alumnos total</p>
              </CardContent>
            </Card>

            {/* Total de Profesores */}
            <Card className="bg-futuristic-surface border-futuristic-primary/10 hover:border-futuristic-primary/30 transition-all duration-300 hover:shadow-lg hover:shadow-futuristic-primary/10">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-futuristic-text-secondary text-sm font-medium">Total Profesores</CardTitle>
                <GraduationCap className="h-5 w-5 text-futuristic-secondary" />
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-futuristic-text-primary">32</div>
                <div className="flex items-center gap-2 mt-1">
                  <div className="flex items-center gap-1">
                    <UserCheck className="h-3 w-3 text-futuristic-success" />
                    <span className="text-xs text-futuristic-success">28 activos</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <UserX className="h-3 w-3 text-futuristic-error" />
                    <span className="text-xs text-futuristic-error">4 inactivos</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Alumnos Matriculados */}
            <Card className="bg-futuristic-surface border-futuristic-primary/10 hover:border-futuristic-primary/30 transition-all duration-300 hover:shadow-lg hover:shadow-futuristic-primary/10">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-futuristic-text-secondary text-sm font-medium">
                  Alumnos Matriculados
                </CardTitle>
                <Users className="h-5 w-5 text-futuristic-info" />
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-futuristic-text-primary">487</div>
                <div className="flex items-center gap-2 mt-1">
                  <div className="flex items-center gap-1">
                    <CheckCircle className="h-3 w-3 text-futuristic-success" />
                    <span className="text-xs text-futuristic-success">456 presentes</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <XCircle className="h-3 w-3 text-futuristic-warning" />
                    <span className="text-xs text-futuristic-warning">31 ausentes</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Personal Especializado */}
            <Card className="bg-futuristic-surface border-futuristic-primary/10 hover:border-futuristic-primary/30 transition-all duration-300 hover:shadow-lg hover:shadow-futuristic-primary/10">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-futuristic-text-secondary text-sm font-medium">
                  Personal Especializado
                </CardTitle>
                <Brain className="h-5 w-5 text-futuristic-creative" />
              </CardHeader>
              <CardContent>
                <div className="space-y-1">
                  <div className="flex justify-between">
                    <span className="text-sm text-futuristic-text-secondary">Psicólogos:</span>
                    <span className="text-sm font-medium text-futuristic-text-primary">3</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-futuristic-text-secondary">Coordinadores:</span>
                    <span className="text-sm font-medium text-futuristic-text-primary">5</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* NUEVO: Widget de Estudiantes Fuera de Rango */}
            <Card className="bg-red-50 border-red-200 hover:border-red-300 transition-all duration-300 hover:shadow-lg hover:shadow-red-200/50 cursor-pointer">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-red-700 text-sm font-medium flex items-center gap-1">
                  <AlertTriangle className="h-4 w-4" />
                  Fuera de Rango
                </CardTitle>
                <AlertCircle className="h-5 w-5 text-red-600" />
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-red-800">{outOfRangeStudents.total}</div>
                <div className="space-y-1 mt-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-red-600">Pendientes:</span>
                    <span className="font-medium text-red-800">{outOfRangeStudents.pending}</span>
                  </div>
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-green-600">Autorizados:</span>
                    <span className="font-medium text-green-800">{outOfRangeStudents.authorized}</span>
                  </div>
                </div>
                <Button
                  size="sm"
                  variant="outline"
                  className="w-full mt-2 border-red-300 text-red-700 hover:bg-red-100 text-xs bg-transparent"
                  onClick={() => {
                    // Redirigir al módulo de inscripción con filtros aplicados
                    window.location.href = "/dashboard/coordinador/enrollment?filter=out-of-range"
                  }}
                >
                  <Eye className="h-3 w-3 mr-1" />
                  Ver Detalles
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Detalle de Estudiantes Fuera de Rango por Grado */}
        <div className="mb-8">
          <Card className="bg-red-50 border-red-200">
            <CardHeader>
              <CardTitle className="text-red-800 flex items-center gap-2">
                <AlertTriangle className="h-5 w-5" />
                Estudiantes Fuera de Rango de Edad - Detalle por Grado
              </CardTitle>
              <p className="text-sm text-red-600">
                Incluye estudiantes con edad menor o mayor al establecido por el MINERD para el grado correspondiente.
              </p>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {Object.entries(outOfRangeStudents.byGrade).map(([grade, count]) => (
                  <div key={grade} className="bg-white rounded-lg p-3 border border-red-200">
                    <div className="text-sm font-medium text-gray-900">{grade}</div>
                    <div className="text-2xl font-bold text-red-800">{count}</div>
                    <div className="text-xs text-red-600">estudiantes</div>
                  </div>
                ))}
              </div>
              <div className="mt-4 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                <div className="flex items-center gap-2 text-yellow-800">
                  <AlertCircle className="h-4 w-4" />
                  <span className="font-medium">Acción Requerida</span>
                </div>
                <p className="text-sm text-yellow-700 mt-1">
                  {outOfRangeStudents.pending} estudiantes requieren autorización del Director para continuar con el
                  proceso de inscripción.
                </p>
                <Button size="sm" className="mt-2 bg-yellow-600 hover:bg-yellow-700">
                  Revisar y Autorizar
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Indicadores de Rendimiento Académico */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 bg-gradient-to-br from-futuristic-secondary to-futuristic-info rounded-xl flex items-center justify-center">
              <BarChart3 className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-futuristic-text-primary">Indicadores de Rendimiento Académico</h2>
              <p className="text-futuristic-text-secondary">Análisis del desempeño estudiantil por categorías</p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Alto Rendimiento (90-100) */}
            <Card className="bg-futuristic-surface border-futuristic-success/20 hover:border-futuristic-success/40 transition-all duration-300">
              <CardHeader>
                <CardTitle className="text-futuristic-success flex items-center gap-2">
                  <CheckCircle className="h-5 w-5" />
                  Alto Rendimiento
                </CardTitle>
                <p className="text-sm text-futuristic-text-secondary">Estudiantes con promedio 90-100 puntos</p>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-futuristic-success mb-4">42</div>
                <div className="space-y-2 max-h-48 overflow-y-auto">
                  {[
                    { name: "Ana María Rodríguez", grade: "11°A", average: "96" },
                    { name: "Carlos Eduardo Pérez", grade: "10°B", average: "94" },
                    { name: "Sofía Alejandra López", grade: "9°A", average: "92" },
                    { name: "Diego Andrés Martín", grade: "11°B", average: "91" },
                    { name: "Valentina Gómez", grade: "10°A", average: "90" },
                    { name: "Santiago Herrera", grade: "9°B", average: "90" },
                  ].map((student, index) => (
                    <div
                      key={index}
                      className="flex items-center justify-between p-2 bg-futuristic-success/10 rounded-md"
                    >
                      <div>
                        <p className="text-sm font-medium text-futuristic-text-primary">{student.name}</p>
                        <p className="text-xs text-futuristic-text-secondary">{student.grade}</p>
                      </div>
                      <Badge className="bg-futuristic-success/20 text-futuristic-success border-futuristic-success/30">
                        {student.average}
                      </Badge>
                    </div>
                  ))}
                </div>
                <Button
                  size="sm"
                  variant="outline"
                  className="w-full mt-3 border-futuristic-success/30 text-futuristic-success hover:bg-futuristic-success/10 bg-transparent"
                  onClick={() => {
                    // Redirigir a vista detallada con filtros aplicados
                    window.location.href = "/dashboard/director/academic?filter=high-performance&score=90-100"
                  }}
                >
                  <Eye className="h-4 w-4 mr-1" />
                  Ver Detalles y Filtrar
                </Button>
              </CardContent>
            </Card>

            {/* Rendimiento Promedio (70-89) */}
            <Card className="bg-futuristic-surface border-futuristic-info/20 hover:border-futuristic-info/40 transition-all duration-300">
              <CardHeader>
                <CardTitle className="text-futuristic-info flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  Rendimiento Promedio
                </CardTitle>
                <p className="text-sm text-futuristic-text-secondary">Estudiantes con promedio 70-89 puntos</p>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-futuristic-info mb-4">298</div>
                <div className="space-y-2 max-h-48 overflow-y-auto">
                  {[
                    { name: "María José Ramírez", grade: "8°A", average: "84" },
                    { name: "Alejandro Torres", grade: "7°B", average: "82" },
                    { name: "Camila Vargas", grade: "9°A", average: "80" },
                    { name: "Sebastián Morales", grade: "8°B", average: "78" },
                    { name: "Isabella Castro", grade: "7°A", average: "76" },
                    { name: "Mateo Jiménez", grade: "6°B", average: "74" },
                  ].map((student, index) => (
                    <div key={index} className="flex items-center justify-between p-2 bg-futuristic-info/10 rounded-md">
                      <div>
                        <p className="text-sm font-medium text-futuristic-text-primary">{student.name}</p>
                        <p className="text-xs text-futuristic-text-secondary">{student.grade}</p>
                      </div>
                      <Badge className="bg-futuristic-info/20 text-futuristic-info border-futuristic-info/30">
                        {student.average}
                      </Badge>
                    </div>
                  ))}
                </div>
                <Button
                  size="sm"
                  variant="outline"
                  className="w-full mt-3 border-futuristic-info/30 text-futuristic-info hover:bg-futuristic-info/10 bg-transparent"
                  onClick={() => {
                    // Redirigir a vista detallada con filtros aplicados
                    window.location.href = "/dashboard/director/academic?filter=average-performance&score=70-89"
                  }}
                >
                  <Eye className="h-4 w-4 mr-1" />
                  Ver Detalles y Filtrar
                </Button>
              </CardContent>
            </Card>

            {/* Bajo Rendimiento (60-69) */}
            <Card className="bg-futuristic-surface border-futuristic-warning/20 hover:border-futuristic-warning/40 transition-all duration-300">
              <CardHeader>
                <CardTitle className="text-futuristic-warning flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5" />
                  Bajo Rendimiento
                </CardTitle>
                <p className="text-sm text-futuristic-text-secondary">
                  Estudiantes con promedio 60-69 puntos (En riesgo)
                </p>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-futuristic-warning mb-4">23</div>
                <div className="space-y-2 max-h-48 overflow-y-auto">
                  {[
                    { name: "Kevin Andrés Silva", grade: "6°A", average: "68", status: "Seguimiento" },
                    { name: "Daniela Ruiz", grade: "7°B", average: "66", status: "Apoyo" },
                    { name: "Nicolás Mendoza", grade: "8°A", average: "64", status: "Refuerzo" },
                    { name: "Gabriela Ortiz", grade: "6°B", average: "62", status: "Urgente" },
                    { name: "Andrés Felipe Cruz", grade: "7°A", average: "61", status: "Urgente" },
                    { name: "Valeria Sánchez", grade: "8°B", average: "60", status: "Crítico" },
                  ].map((student, index) => (
                    <div
                      key={index}
                      className="flex items-center justify-between p-2 bg-futuristic-warning/10 rounded-md"
                    >
                      <div>
                        <p className="text-sm font-medium text-futuristic-text-primary">{student.name}</p>
                        <div className="flex items-center gap-2">
                          <p className="text-xs text-futuristic-text-secondary">{student.grade}</p>
                          <Badge
                            className={`text-xs ${
                              student.status === "Crítico"
                                ? "bg-futuristic-error/20 text-futuristic-error border-futuristic-error/30"
                                : student.status === "Urgente"
                                  ? "bg-futuristic-warning/20 text-futuristic-warning border-futuristic-warning/30"
                                  : "bg-futuristic-info/20 text-futuristic-info border-futuristic-info/30"
                            }`}
                          >
                            {student.status}
                          </Badge>
                        </div>
                      </div>
                      <Badge className="bg-futuristic-warning/20 text-futuristic-warning border-futuristic-warning/30">
                        {student.average}
                      </Badge>
                    </div>
                  ))}
                </div>
                <div className="flex gap-2 mt-3">
                  <Button
                    size="sm"
                    variant="outline"
                    className="flex-1 border-futuristic-warning/30 text-futuristic-warning hover:bg-futuristic-warning/10 bg-transparent"
                    onClick={() => {
                      // Redirigir a vista detallada con filtros aplicados
                      window.location.href = "/dashboard/director/academic?filter=low-performance&score=60-69"
                    }}
                  >
                    <Eye className="h-4 w-4 mr-1" />
                    Ver Detalles
                  </Button>
                  <Button
                    size="sm"
                    className="flex-1 bg-gradient-to-r from-futuristic-warning to-futuristic-warning-light hover:from-futuristic-warning-light hover:to-futuristic-warning"
                    onClick={() => {
                      // Redirigir a plan de mejora académica
                      window.location.href = "/dashboard/director/academic/improvement-plan"
                    }}
                  >
                    <AlertTriangle className="h-4 w-4 mr-1" />
                    Plan de Mejora
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          {/* Alertas de Facturación */}
          <Card className="lg:col-span-1 bg-futuristic-surface border-futuristic-primary/10">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-futuristic-text-primary flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-futuristic-warning" />
                  Alertas Financieras
                </CardTitle>
                <Button
                  size="sm"
                  variant="outline"
                  className="border-futuristic-primary/30 text-futuristic-primary hover:bg-futuristic-primary/10 bg-transparent"
                >
                  <Eye className="h-4 w-4 mr-1" />
                  Ver Todo
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Resumen Financiero */}
              <div className="bg-futuristic-background/30 rounded-lg p-4 space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-futuristic-text-secondary">Ingresos Brutos:</span>
                  <span className="font-bold text-futuristic-success">$48,500</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-futuristic-text-secondary">Ingresos Netos:</span>
                  <span className="font-bold text-futuristic-success">$42,300</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-futuristic-text-secondary">Pendiente Cobro:</span>
                  <span className="font-bold text-futuristic-warning">$12,800</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-futuristic-text-secondary">Gastos Personal:</span>
                  <span className="font-bold text-futuristic-error">$28,500</span>
                </div>
              </div>

              {/* Alertas Específicas */}
              <div className="space-y-2">
                <div className="flex items-center justify-between p-2 bg-futuristic-error/10 rounded-md">
                  <div className="flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4 text-futuristic-error" />
                    <span className="text-sm text-futuristic-text-primary">Facturas Vencidas</span>
                  </div>
                  <Badge className="bg-futuristic-error/20 text-futuristic-error border-futuristic-error/30">8</Badge>
                </div>

                <div className="flex items-center justify-between p-2 bg-futuristic-warning/10 rounded-md">
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 text-futuristic-warning" />
                    <span className="text-sm text-futuristic-text-primary">Alumnos Morosos</span>
                  </div>
                  <Badge className="bg-futuristic-warning/20 text-futuristic-warning border-futuristic-warning/30">
                    24
                  </Badge>
                </div>

                <div className="flex items-center justify-between p-2 bg-futuristic-success/10 rounded-md">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-futuristic-success" />
                    <span className="text-sm text-futuristic-text-primary">Pagos al Día</span>
                  </div>
                  <Badge className="bg-futuristic-success/20 text-futuristic-success border-futuristic-success/30">
                    463
                  </Badge>
                </div>
              </div>

              <div className="flex gap-2">
                <Button
                  size="sm"
                  className="flex-1 bg-gradient-to-r from-futuristic-primary to-futuristic-primary-light hover:from-futuristic-primary-light hover:to-futuristic-primary"
                >
                  <DollarSign className="h-4 w-4 mr-1" />
                  Facturación
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  className="border-futuristic-primary/30 text-futuristic-primary hover:bg-futuristic-primary/10 bg-transparent"
                >
                  <Download className="h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Actividad Reciente Académica */}
          <Card className="lg:col-span-2 bg-futuristic-surface border-futuristic-primary/10">
            <CardHeader>
              <CardTitle className="text-futuristic-text-primary flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-futuristic-info" />
                Actividad Reciente Académica
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  {
                    type: "grade",
                    icon: <CheckCircle className="h-4 w-4 text-futuristic-success" />,
                    title: "Calificaciones ingresadas",
                    description: "María González - 1° A Primaria - Matemáticas",
                    time: "Hace 2 horas",
                    bgColor: "bg-futuristic-success/10",
                  },
                  {
                    type: "event",
                    icon: <Calendar className="h-4 w-4 text-futuristic-info" />,
                    title: "Evento añadido al calendario",
                    description: "Reunión de padres - 15 de Junio",
                    time: "Hace 4 horas",
                    bgColor: "bg-futuristic-info/10",
                  },
                  {
                    type: "communication",
                    icon: <Send className="h-4 w-4 text-futuristic-secondary" />,
                    title: "Comunicado enviado",
                    description: "Recordatorio de pago - Todos los padres",
                    time: "Hace 6 horas",
                    bgColor: "bg-futuristic-secondary/10",
                  },
                  {
                    type: "student",
                    icon: <UserPlus className="h-4 w-4 text-futuristic-primary" />,
                    title: "Nuevo estudiante registrado",
                    description: "Ana Pérez - 2° B Primaria",
                    time: "Hace 8 horas",
                    bgColor: "bg-futuristic-primary/10",
                  },
                ].map((activity, index) => (
                  <div
                    key={index}
                    className={`flex items-start gap-3 p-3 rounded-lg ${activity.bgColor} hover:bg-opacity-80 transition-all cursor-pointer`}
                  >
                    <div className="mt-0.5">{activity.icon}</div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-futuristic-text-primary">{activity.title}</p>
                      <p className="text-xs text-futuristic-text-secondary">{activity.description}</p>
                    </div>
                    <span className="text-xs text-futuristic-text-tertiary">{activity.time}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Calendario de Actividades y Recordatorios */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Calendario de Actividades */}
          <Card className="bg-futuristic-surface border-futuristic-primary/10">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-futuristic-text-primary flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-futuristic-creative" />
                  Calendario de Actividades
                </CardTitle>
                <Button
                  size="sm"
                  className="bg-gradient-to-r from-futuristic-primary to-futuristic-primary-light hover:from-futuristic-primary-light hover:to-futuristic-primary"
                >
                  <Plus className="h-4 w-4 mr-1" />
                  Añadir
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {[
                  {
                    date: "15 Jun",
                    title: "Reunión de Padres",
                    type: "Local",
                    time: "14:00 - 16:00",
                    color: "futuristic-primary",
                  },
                  {
                    date: "18 Jun",
                    title: "Día del Padre",
                    type: "Festivo",
                    time: "Todo el día",
                    color: "futuristic-secondary",
                  },
                  {
                    date: "20 Jun",
                    title: "Capacitación Distrital",
                    type: "Distrital",
                    time: "09:00 - 12:00",
                    color: "futuristic-info",
                  },
                  {
                    date: "25 Jun",
                    title: "Entrega de Boletines",
                    type: "Local",
                    time: "08:00 - 17:00",
                    color: "futuristic-success",
                  },
                ].map((event, index) => (
                  <div
                    key={index}
                    className="flex items-center gap-3 p-3 bg-futuristic-background/30 rounded-lg hover:bg-futuristic-background/50 transition-all cursor-pointer"
                  >
                    <div
                      className={`bg-${event.color}/20 border border-${event.color}/30 rounded-md p-2 text-center min-w-[60px]`}
                    >
                      <p className="text-xs text-futuristic-text-secondary">{event.date.split(" ")[1]}</p>
                      <p className="text-lg font-bold text-futuristic-text-primary">{event.date.split(" ")[0]}</p>
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <p className="font-medium text-futuristic-text-primary">{event.title}</p>
                        <Badge className={`bg-${event.color}/20 text-${event.color} border-${event.color}/30 text-xs`}>
                          {event.type}
                        </Badge>
                      </div>
                      <p className="text-xs text-futuristic-text-secondary">{event.time}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Recordatorios Automáticos */}
          <Card className="bg-futuristic-surface border-futuristic-primary/10">
            <CardHeader>
              <CardTitle className="text-futuristic-text-primary flex items-center gap-2">
                <Clock className="h-5 w-5 text-futuristic-warning" />
                Recordatorios Automáticos
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {[
                  {
                    title: "Reunión de Padres",
                    days: "3 días",
                    type: "Próximo",
                    priority: "high",
                  },
                  {
                    title: "Capacitación Distrital",
                    days: "5 días",
                    type: "Próximo",
                    priority: "medium",
                  },
                  {
                    title: "Entrega de Boletines",
                    days: "1 día",
                    type: "Urgente",
                    priority: "high",
                  },
                  {
                    title: "Fin de Período",
                    days: "15 días",
                    type: "Próximo",
                    priority: "low",
                  },
                ].map((reminder, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-3 bg-futuristic-background/30 rounded-lg"
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-3 h-3 rounded-full ${
                          reminder.priority === "high"
                            ? "bg-futuristic-error"
                            : reminder.priority === "medium"
                              ? "bg-futuristic-warning"
                              : "bg-futuristic-success"
                        }`}
                      ></div>
                      <div>
                        <p className="text-sm font-medium text-futuristic-text-primary">{reminder.title}</p>
                        <p className="text-xs text-futuristic-text-secondary">En {reminder.days}</p>
                      </div>
                    </div>
                    <Badge
                      className={`${
                        reminder.type === "Urgente"
                          ? "bg-futuristic-error/20 text-futuristic-error border-futuristic-error/30"
                          : "bg-futuristic-info/20 text-futuristic-info border-futuristic-info/30"
                      }`}
                    >
                      {reminder.type}
                    </Badge>
                  </div>
                ))}
              </div>

              <div className="mt-4 p-3 bg-futuristic-primary/10 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <Brain className="h-4 w-4 text-futuristic-primary" />
                  <span className="text-sm font-medium text-futuristic-text-primary">Configuración de Alertas</span>
                </div>
                <p className="text-xs text-futuristic-text-secondary mb-2">
                  Notificaciones automáticas: 3 días antes, 1 día antes y el mismo día
                </p>
                <Button
                  size="sm"
                  variant="outline"
                  className="w-full border-futuristic-primary/30 text-futuristic-primary hover:bg-futuristic-primary/10 bg-transparent"
                >
                  Configurar Recordatorios
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
