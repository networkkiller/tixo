export default function Loading() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-futuristic-background via-futuristic-surface to-futuristic-background flex items-center justify-center">
      <div className="w-16 h-16 border-4 border-futuristic-primary border-t-transparent rounded-full animate-spin"></div>
    </div>
  )
}
