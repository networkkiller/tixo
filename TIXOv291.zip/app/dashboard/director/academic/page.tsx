"use client"

import { Header } from "@/components/dashboard/header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { useState } from "react"
import {
  BookOpen,
  Users,
  GraduationCap,
  Calendar,
  Plus,
  Search,
  Download,
  Upload,
  Edit,
  Eye,
  Trash2,
  Copy,
  Settings,
  Clock,
  CheckCircle,
  AlertTriangle,
  School,
  Save,
  X,
} from "lucide-react"
import { CourseStatusCard } from "@/components/course/course-status-card"
import { CourseNotifications } from "@/components/notifications/course-notifications"
import { CourseInteroperabilityService, type Course } from "@/lib/course-interoperability"

interface NewCourseForm {
  name: string
  grade: string
  level: string
  modality: string
  section: string
  turn: string
  capacity: number
  teacher: string
  schoolYear: string
  notes: string
}

export default function AcademicManagement() {
  const [isNewCourseModalOpen, setIsNewCourseModalOpen] = useState(false)
  const [courses, setCourses] = useState<Course[]>([
    {
      id: "course_1",
      name: "1ro A",
      grade: "1ro",
      level: "Primaria",
      modality: "Regular",
      section: "A",
      turn: "Mañana",
      capacity: 30,
      teacher: "María González",
      schoolYear: "2024-2025",
      notes: "",
      createdAt: new Date().toISOString(),
      createdBy: "director_001",
      status: "active",
      studentsCount: 24,
      subjectsCount: 5,
      configurationStatus: {
        hasSubjects: true,
        hasTeacher: true,
        hasSchedule: true,
        hasStudents: true,
        isComplete: true,
        completionPercentage: 100,
      },
    },
    {
      id: "course_2",
      name: "2do B",
      grade: "2do",
      level: "Primaria",
      modality: "Regular",
      section: "B",
      turn: "Tarde",
      capacity: 25,
      teacher: null,
      schoolYear: "2024-2025",
      notes: "",
      createdAt: new Date().toISOString(),
      createdBy: "director_001",
      status: "active",
      studentsCount: 0,
      subjectsCount: 0,
      configurationStatus: {
        hasSubjects: false,
        hasTeacher: false,
        hasSchedule: false,
        hasStudents: false,
        isComplete: false,
        completionPercentage: 0,
      },
    },
  ])

  const [newCourseForm, setNewCourseForm] = useState<NewCourseForm>({
    name: "",
    grade: "",
    level: "",
    modality: "",
    section: "",
    turn: "",
    capacity: 30,
    teacher: "unassigned",
    schoolYear: "2024-2025",
    notes: "",
  })
  const [formErrors, setFormErrors] = useState<string[]>([])
  const [formWarnings, setFormWarnings] = useState<string[]>([])

  // Datos de ejemplo para los dropdowns
  const grades = [
    { value: "inicial-3", label: "Inicial 3 años" },
    { value: "inicial-4", label: "Inicial 4 años" },
    { value: "inicial-5", label: "Inicial 5 años" },
    { value: "1ro", label: "1ro Primaria" },
    { value: "2do", label: "2do Primaria" },
    { value: "3ro", label: "3ro Primaria" },
    { value: "4to", label: "4to Primaria" },
    { value: "5to", label: "5to Primaria" },
    { value: "6to", label: "6to Primaria" },
    { value: "1ro-sec", label: "1ro Secundaria" },
    { value: "2do-sec", label: "2do Secundaria" },
    { value: "3ro-sec", label: "3ro Secundaria" },
    { value: "4to-sec", label: "4to Secundaria" },
  ]

  const levels = [
    { value: "inicial", label: "Inicial" },
    { value: "primaria", label: "Primaria" },
    { value: "secundaria", label: "Secundaria" },
  ]

  const modalities = [
    { value: "regular", label: "Regular" },
    { value: "academica", label: "Académica" },
    { value: "tecnica", label: "Técnica" },
    { value: "artistica", label: "Artística" },
  ]

  const sections = [
    { value: "A", label: "A" },
    { value: "B", label: "B" },
    { value: "C", label: "C" },
    { value: "D", label: "D" },
    { value: "E", label: "E" },
  ]

  const turns = [
    { value: "mañana", label: "Mañana (7:00 AM - 12:00 PM)" },
    { value: "tarde", label: "Tarde (1:00 PM - 6:00 PM)" },
    { value: "extendida", label: "Extendida (7:00 AM - 4:00 PM)" },
  ]

  const teachers = [
    { value: "unassigned", label: "Sin asignar (se puede asignar después)" },
    { value: "teacher_001", label: "María González - Matemáticas" },
    { value: "teacher_002", label: "Roberto Sánchez - Lenguaje" },
    { value: "teacher_003", label: "Ana Martínez - Ciencias" },
    { value: "teacher_004", label: "Carlos López - Historia" },
    { value: "teacher_005", label: "Lucía Fernández - Inglés" },
    { value: "teacher_006", label: "Pedro Ramírez - Educación Física" },
  ]

  const validateForm = () => {
    const errors: string[] = []
    const warnings: string[] = []

    // Validaciones obligatorias
    if (!newCourseForm.grade) errors.push("Debe seleccionar un grado")
    if (!newCourseForm.level) errors.push("Debe seleccionar un nivel")
    if (!newCourseForm.section) errors.push("Debe seleccionar una sección")
    if (!newCourseForm.turn) errors.push("Debe seleccionar un turno")
    if (newCourseForm.capacity <= 0) errors.push("La capacidad debe ser mayor a 0")

    // Validación de duplicados
    const isDuplicate = courses.some(
      (course) =>
        course.grade === newCourseForm.grade &&
        course.section === newCourseForm.section &&
        course.turn === newCourseForm.turn,
    )
    if (isDuplicate) {
      errors.push("Ya existe un curso con el mismo grado, sección y turno")
    }

    // Advertencias
    if (newCourseForm.capacity > 50) {
      warnings.push("La capacidad supera los 50 estudiantes. Se recomienda justificación pedagógica.")
    }

    if (newCourseForm.teacher === "unassigned") {
      warnings.push("No se ha asignado un profesor encargado. Podrá asignarse posteriormente.")
    }

    // Validar si el docente ya está asignado
    if (newCourseForm.teacher && newCourseForm.teacher !== "unassigned") {
      const teacherAlreadyAssigned = courses.some(
        (course) => course.grade === newCourseForm.grade && course.turn === newCourseForm.turn,
      )
      if (teacherAlreadyAssigned) {
        warnings.push("El docente seleccionado ya tiene asignado otro curso en el mismo grado y turno.")
      }
    }

    setFormErrors(errors)
    setFormWarnings(warnings)

    return errors.length === 0
  }

  const handleCreateCourse = async () => {
    if (!validateForm()) return

    // Generar nombre automático si no se proporcionó
    const courseName = `${newCourseForm.grade.replace("-sec", "")} ${newCourseForm.section}`

    const courseData = {
      ...newCourseForm,
      name: courseName,
      createdBy: "director_001",
      studentsCount: 0,
      subjectsCount: 0,
      status: "active" as const,
      teacher: newCourseForm.teacher === "unassigned" ? null : newCourseForm.teacher,
    }

    try {
      // Usar el servicio de interoperabilidad
      const newCourse = await CourseInteroperabilityService.createCourse(courseData)

      // Actualizar lista local
      setCourses((prev) => [...prev, newCourse])

      // Resetear formulario y cerrar modal
      setNewCourseForm({
        name: "",
        grade: "",
        level: "",
        modality: "",
        section: "",
        turn: "",
        capacity: 30,
        teacher: "unassigned",
        schoolYear: "2024-2025",
        notes: "",
      })
      setFormErrors([])
      setFormWarnings([])
      setIsNewCourseModalOpen(false)

      // Mostrar mensaje de éxito
      alert(`✅ Curso "${courseName}" creado exitosamente. Se han enviado notificaciones automáticas.`)
    } catch (error) {
      console.error("Error creando curso:", error)
      alert("❌ Error al crear el curso. Intente nuevamente.")
    }
  }

  const handleInputChange = (field: keyof NewCourseForm, value: string | number) => {
    if (field === "grade" || field === "section") {
      const updatedForm = { ...newCourseForm, [field]: value }
      if (updatedForm.grade && updatedForm.section) {
        const autoName = `${updatedForm.grade.replace("-sec", "")} ${updatedForm.section}`
        setNewCourseForm((prev) => ({
          ...prev,
          [field]: value,
          name: autoName,
        }))
        return
      }
    }

    setNewCourseForm((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  const handleViewDetails = (courseId: string) => {
    window.location.href = `/dashboard/director/academic/courses/${courseId}`
  }

  const handleEditCourse = (courseId: string) => {
    console.log("Editando curso:", courseId)
  }

  const handleRequestConfiguration = (courseId: string) => {
    const course = courses.find((c) => c.id === courseId)
    if (course) {
      alert(`Solicitud de configuración enviada para el curso ${course.name}`)
    }
  }

  // Agrupar cursos por estado
  const completeCourses = courses.filter((c) => c.configurationStatus.isComplete)
  const incompleteCourses = courses.filter(
    (c) => c.configurationStatus.completionPercentage > 0 && c.configurationStatus.completionPercentage < 100,
  )
  const pendingCourses = courses.filter((c) => c.configurationStatus.completionPercentage === 0)

  return (
    <div className="flex-1 flex flex-col">
      <Header title="Gestión Académica" actions={<CourseNotifications userRole="director" />} />

      <main className="flex-1 overflow-y-auto p-6 bg-gradient-to-br from-gray-50 to-white">
        <Tabs defaultValue="courses" className="space-y-6">
          <div className="bg-white/50 backdrop-blur-sm rounded-lg p-1 w-fit border border-gray-200">
            <TabsList className="grid grid-cols-4 w-fit">
              <TabsTrigger value="courses" className="flex items-center gap-2">
                <BookOpen className="h-4 w-4" />
                <span className="hidden md:inline">Cursos</span>
              </TabsTrigger>
              <TabsTrigger value="subjects" className="flex items-center gap-2">
                <GraduationCap className="h-4 w-4" />
                <span className="hidden md:inline">Materias</span>
              </TabsTrigger>
              <TabsTrigger value="assignments" className="flex items-center gap-2">
                <Users className="h-4 w-4" />
                <span className="hidden md:inline">Asignaciones</span>
              </TabsTrigger>
              <TabsTrigger value="periods" className="flex items-center gap-2">
                <Calendar className="h-4 w-4" />
                <span className="hidden md:inline">Períodos</span>
              </TabsTrigger>
            </TabsList>
          </div>

          {/* Gestión de Cursos */}
          <TabsContent value="courses" className="space-y-6">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-2xl font-bold text-gray-900">Gestión de Cursos</h2>
                <p className="text-gray-600">Administra los cursos, grados y secciones del colegio</p>
              </div>
              <div className="flex gap-2">
                {/* Botón Nuevo Curso - IMPLEMENTACIÓN PRINCIPAL */}
                <Dialog open={isNewCourseModalOpen} onOpenChange={setIsNewCourseModalOpen}>
                  <DialogTrigger asChild>
                    <Button
                      className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white"
                      title="Crear un nuevo curso o sección con capacidad estudiantil y configuración básica"
                    >
                      <Plus className="mr-2 h-4 w-4" /> 🆕 Nuevo Curso
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto bg-white border-gray-200">
                    <DialogHeader>
                      <DialogTitle className="text-2xl font-bold text-gray-900 flex items-center gap-2">
                        <School className="h-6 w-6 text-purple-600" />
                        Crear Nuevo Curso
                      </DialogTitle>
                    </DialogHeader>

                    <div className="space-y-6 py-4">
                      {/* Errores de validación */}
                      {formErrors.length > 0 && (
                        <Alert className="border-red-300 bg-red-50">
                          <AlertTriangle className="h-4 w-4 text-red-600" />
                          <AlertDescription className="text-red-700">
                            <ul className="list-disc list-inside space-y-1">
                              {formErrors.map((error, index) => (
                                <li key={index}>{error}</li>
                              ))}
                            </ul>
                          </AlertDescription>
                        </Alert>
                      )}

                      {/* Advertencias */}
                      {formWarnings.length > 0 && (
                        <Alert className="border-yellow-300 bg-yellow-50">
                          <AlertTriangle className="h-4 w-4 text-yellow-600" />
                          <AlertDescription className="text-yellow-700">
                            <ul className="list-disc list-inside space-y-1">
                              {formWarnings.map((warning, index) => (
                                <li key={index}>{warning}</li>
                              ))}
                            </ul>
                          </AlertDescription>
                        </Alert>
                      )}

                      {/* Formulario */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {/* Información Básica */}
                        <div className="space-y-4">
                          <h3 className="text-lg font-semibold text-gray-900 border-b border-gray-200 pb-2">
                            📘 Información Básica
                          </h3>

                          <div className="space-y-2">
                            <Label htmlFor="grade" className="text-gray-700">
                              🎓 Grado/Nivel *
                            </Label>
                            <Select
                              value={newCourseForm.grade}
                              onValueChange={(value) => handleInputChange("grade", value)}
                            >
                              <SelectTrigger className="bg-white border-gray-300 text-gray-900">
                                <SelectValue placeholder="Seleccionar grado" />
                              </SelectTrigger>
                              <SelectContent className="bg-white border-gray-200">
                                {grades.map((grade) => (
                                  <SelectItem key={grade.value} value={grade.value} className="text-gray-900">
                                    {grade.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>

                          <div className="space-y-2">
                            <Label htmlFor="level" className="text-gray-700">
                              📚 Nivel Educativo *
                            </Label>
                            <Select
                              value={newCourseForm.level}
                              onValueChange={(value) => handleInputChange("level", value)}
                            >
                              <SelectTrigger className="bg-white border-gray-300 text-gray-900">
                                <SelectValue placeholder="Seleccionar nivel" />
                              </SelectTrigger>
                              <SelectContent className="bg-white border-gray-200">
                                {levels.map((level) => (
                                  <SelectItem key={level.value} value={level.value} className="text-gray-900">
                                    {level.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>

                          <div className="space-y-2">
                            <Label htmlFor="modality" className="text-gray-700">
                              📚 Modalidad *
                            </Label>
                            <Select
                              value={newCourseForm.modality}
                              onValueChange={(value) => handleInputChange("modality", value)}
                            >
                              <SelectTrigger className="bg-white border-gray-300 text-gray-900">
                                <SelectValue placeholder="Seleccionar modalidad" />
                              </SelectTrigger>
                              <SelectContent className="bg-white border-gray-200">
                                {modalities.map((modality) => (
                                  <SelectItem key={modality.value} value={modality.value} className="text-gray-900">
                                    {modality.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                        </div>

                        {/* Configuración Operativa */}
                        <div className="space-y-4">
                          <h3 className="text-lg font-semibold text-gray-900 border-b border-gray-200 pb-2">
                            ⚙️ Configuración Operativa
                          </h3>

                          <div className="space-y-2">
                            <Label htmlFor="section" className="text-gray-700">
                              🔤 Sección *
                            </Label>
                            <Select
                              value={newCourseForm.section}
                              onValueChange={(value) => handleInputChange("section", value)}
                            >
                              <SelectTrigger className="bg-white border-gray-300 text-gray-900">
                                <SelectValue placeholder="Seleccionar sección" />
                              </SelectTrigger>
                              <SelectContent className="bg-white border-gray-200">
                                {sections.map((section) => (
                                  <SelectItem key={section.value} value={section.value} className="text-gray-900">
                                    {section.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>

                          <div className="space-y-2">
                            <Label htmlFor="turn" className="text-gray-700">
                              🕐 Turno/Tanda *
                            </Label>
                            <Select
                              value={newCourseForm.turn}
                              onValueChange={(value) => handleInputChange("turn", value)}
                            >
                              <SelectTrigger className="bg-white border-gray-300 text-gray-900">
                                <SelectValue placeholder="Seleccionar turno" />
                              </SelectTrigger>
                              <SelectContent className="bg-white border-gray-200">
                                {turns.map((turn) => (
                                  <SelectItem key={turn.value} value={turn.value} className="text-gray-900">
                                    {turn.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>

                          <div className="space-y-2">
                            <Label htmlFor="capacity" className="text-gray-700">
                              👥 Capacidad de Estudiantes *
                            </Label>
                            <Input
                              id="capacity"
                              type="number"
                              value={newCourseForm.capacity}
                              onChange={(e) => handleInputChange("capacity", Number.parseInt(e.target.value) || 0)}
                              min="1"
                              max="60"
                              className="bg-white border-gray-300 text-gray-900"
                            />
                            <p className="text-xs text-gray-500">Recomendado: 25-35 estudiantes por curso</p>
                          </div>

                          <div className="space-y-2">
                            <Label htmlFor="teacher" className="text-gray-700">
                              👨‍🏫 Profesor Encargado (Opcional)
                            </Label>
                            <Select
                              value={newCourseForm.teacher}
                              onValueChange={(value) => handleInputChange("teacher", value)}
                            >
                              <SelectTrigger className="bg-white border-gray-300 text-gray-900">
                                <SelectValue placeholder="Seleccionar profesor" />
                              </SelectTrigger>
                              <SelectContent className="bg-white border-gray-200">
                                {teachers.map((teacher) => (
                                  <SelectItem
                                    key={teacher.value}
                                    value={teacher.value}
                                    className={teacher.value === "unassigned" ? "text-gray-500" : "text-gray-900"}
                                  >
                                    {teacher.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                      </div>

                      {/* Información Adicional */}
                      <div className="space-y-4">
                        <h3 className="text-lg font-semibold text-gray-900 border-b border-gray-200 pb-2">
                          📋 Información Adicional
                        </h3>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="schoolYear" className="text-gray-700">
                              🗓️ Año Escolar
                            </Label>
                            <Input
                              id="schoolYear"
                              value={newCourseForm.schoolYear}
                              onChange={(e) => handleInputChange("schoolYear", e.target.value)}
                              className="bg-white border-gray-300 text-gray-900"
                              readOnly
                            />
                          </div>

                          <div className="space-y-2">
                            <Label className="text-gray-700">🏫 Centro Educativo</Label>
                            <Input
                              value="Colegio San José"
                              className="bg-white border-gray-300 text-gray-900"
                              readOnly
                            />
                          </div>
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="notes" className="text-gray-700">
                            📝 Notas Adicionales
                          </Label>
                          <Textarea
                            id="notes"
                            value={newCourseForm.notes}
                            onChange={(e) => handleInputChange("notes", e.target.value)}
                            placeholder="Observaciones especiales, requisitos particulares, etc."
                            className="bg-white border-gray-300 text-gray-900"
                            rows={3}
                          />
                        </div>
                      </div>

                      {/* Botones de Acción */}
                      <div className="flex justify-end gap-3 pt-6 border-t border-gray-200">
                        <Button
                          variant="outline"
                          onClick={() => setIsNewCourseModalOpen(false)}
                          className="border-gray-300 text-gray-600 hover:bg-gray-50"
                        >
                          <X className="mr-2 h-4 w-4" />
                          Cancelar
                        </Button>
                        <Button
                          onClick={handleCreateCourse}
                          className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white"
                          disabled={formErrors.length > 0}
                        >
                          <Save className="mr-2 h-4 w-4" />✅ Crear Curso
                        </Button>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>

                <Button variant="outline" className="border-gray-300 text-gray-600 hover:bg-gray-50 bg-transparent">
                  <Upload className="mr-2 h-4 w-4" /> Importar
                </Button>
                <Button variant="outline" className="border-gray-300 text-gray-600 hover:bg-gray-50 bg-transparent">
                  <Download className="mr-2 h-4 w-4" /> Exportar
                </Button>
              </div>
            </div>

            {/* Estadísticas de cursos */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <Card className="bg-green-50 border-green-200">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-green-600">Cursos Completos</p>
                      <p className="text-2xl font-bold text-green-700">{completeCourses.length}</p>
                    </div>
                    <CheckCircle className="h-8 w-8 text-green-600" />
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-yellow-50 border-yellow-200">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-yellow-600">En Configuración</p>
                      <p className="text-2xl font-bold text-yellow-700">{incompleteCourses.length}</p>
                    </div>
                    <Clock className="h-8 w-8 text-yellow-600" />
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-red-50 border-red-200">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-red-600">Pendientes</p>
                      <p className="text-2xl font-bold text-red-700">{pendingCourses.length}</p>
                    </div>
                    <AlertTriangle className="h-8 w-8 text-red-600" />
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Filtros */}
            <div className="flex flex-col md:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <Input placeholder="Buscar curso..." className="pl-10 bg-white border-gray-300 text-gray-900" />
              </div>
              <select className="bg-white border-gray-300 text-gray-900 rounded-md px-3 py-2">
                <option value="all">Todos los niveles</option>
                <option value="inicial">Inicial</option>
                <option value="primario">Primario</option>
                <option value="secundario">Secundario</option>
                <option value="tecnico">Técnico</option>
              </select>
              <select className="bg-white border-gray-300 text-gray-900 rounded-md px-3 py-2">
                <option value="all">Todos los turnos</option>
                <option value="mañana">Mañana</option>
                <option value="tarde">Tarde</option>
                <option value="nocturno">Nocturno</option>
              </select>
            </div>

            {/* Lista de Cursos con Estado */}
            <div className="space-y-6">
              {/* Cursos Pendientes */}
              {pendingCourses.length > 0 && (
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
                    <AlertTriangle className="h-5 w-5 text-red-600" />🔴 Cursos Pendientes de Configuración
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {pendingCourses.map((course) => (
                      <CourseStatusCard
                        key={course.id}
                        course={course}
                        userRole="director"
                        onViewDetails={handleViewDetails}
                        onEdit={handleEditCourse}
                        onRequestConfiguration={handleRequestConfiguration}
                      />
                    ))}
                  </div>
                </div>
              )}

              {/* Cursos en Configuración */}
              {incompleteCourses.length > 0 && (
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
                    <Clock className="h-5 w-5 text-yellow-600" />🟡 Cursos en Configuración
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {incompleteCourses.map((course) => (
                      <CourseStatusCard
                        key={course.id}
                        course={course}
                        userRole="director"
                        onViewDetails={handleViewDetails}
                        onEdit={handleEditCourse}
                        onRequestConfiguration={handleRequestConfiguration}
                      />
                    ))}
                  </div>
                </div>
              )}

              {/* Cursos Completos */}
              {completeCourses.length > 0 && (
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
                    <CheckCircle className="h-5 w-5 text-green-600" />🟢 Cursos Completos
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {completeCourses.map((course) => (
                      <CourseStatusCard
                        key={course.id}
                        course={course}
                        userRole="director"
                        onViewDetails={handleViewDetails}
                        onEdit={handleEditCourse}
                        onRequestConfiguration={handleRequestConfiguration}
                      />
                    ))}
                  </div>
                </div>
              )}
            </div>
          </TabsContent>

          {/* Gestión de Materias */}
          <TabsContent value="subjects" className="space-y-6">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-2xl font-bold text-gray-900">Gestión de Materias</h2>
                <p className="text-gray-600">Administra las materias por curso y área académica</p>
              </div>
              <div className="flex gap-2">
                <Button className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white">
                  <Plus className="mr-2 h-4 w-4" /> Nueva Materia
                </Button>
                <Button variant="outline" className="border-gray-300 text-gray-600 hover:bg-gray-50 bg-transparent">
                  <Copy className="mr-2 h-4 w-4" /> Clonar Materias
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Materias por Área */}
              <Card className="bg-white border-gray-200">
                <CardHeader>
                  <CardTitle className="text-gray-900">Materias por Área Académica</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {[
                      {
                        area: "Lenguas",
                        subjects: ["Lenguaje", "Inglés", "Literatura"],
                        color: "purple",
                      },
                      {
                        area: "Ciencias",
                        subjects: ["Matemáticas", "Ciencias Naturales", "Física", "Química"],
                        color: "blue",
                      },
                      {
                        area: "Sociales",
                        subjects: ["Historia", "Geografía", "Cívica"],
                        color: "green",
                      },
                      {
                        area: "Artística",
                        subjects: ["Arte", "Música", "Educación Física"],
                        color: "orange",
                      },
                    ].map((area, index) => (
                      <div key={index} className="space-y-2">
                        <div className="flex items-center justify-between">
                          <h4 className="font-medium text-gray-900">{area.area}</h4>
                          <Badge className={`bg-${area.color}-100 text-${area.color}-800 border-${area.color}-200`}>
                            {area.subjects.length} materias
                          </Badge>
                        </div>
                        <div className="flex flex-wrap gap-1">
                          {area.subjects.map((subject, subIndex) => (
                            <Badge
                              key={subIndex}
                              variant="outline"
                              className="border-gray-300 text-gray-600 hover:bg-gray-50 cursor-pointer"
                            >
                              {subject}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Materias por Curso */}
              <Card className="bg-white border-gray-200">
                <CardHeader>
                  <CardTitle className="text-gray-900">Materias por Curso</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {[
                      {
                        course: "1° Primaria",
                        subjects: 5,
                        required: 5,
                        optional: 0,
                      },
                      {
                        course: "2° Primaria",
                        subjects: 6,
                        required: 5,
                        optional: 1,
                      },
                      {
                        course: "3° Primaria",
                        subjects: 7,
                        required: 6,
                        optional: 1,
                      },
                    ].map((course, index) => (
                      <div key={index} className="p-3 bg-gray-50 rounded-lg">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="font-medium text-gray-900">{course.course}</h4>
                          <div className="flex gap-2">
                            <Button size="sm" variant="ghost" className="h-6 w-6 p-0">
                              <Eye className="h-3 w-3 text-blue-600" />
                            </Button>
                            <Button size="sm" variant="ghost" className="h-6 w-6 p-0">
                              <Edit className="h-3 w-3 text-purple-600" />
                            </Button>
                          </div>
                        </div>
                        <div className="grid grid-cols-3 gap-2 text-xs">
                          <div>
                            <p className="text-gray-500">Total</p>
                            <p className="font-medium text-gray-900">{course.subjects}</p>
                          </div>
                          <div>
                            <p className="text-gray-500">Obligatorias</p>
                            <p className="font-medium text-green-600">{course.required}</p>
                          </div>
                          <div>
                            <p className="text-gray-500">Opcionales</p>
                            <p className="font-medium text-blue-600">{course.optional}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Asignación de Profesores */}
          <TabsContent value="assignments" className="space-y-6">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-2xl font-bold text-gray-900">Asignación de Profesores</h2>
                <p className="text-gray-600">Asigna profesores a cursos y materias específicas</p>
              </div>
              <Button className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white">
                <Plus className="mr-2 h-4 w-4" /> Nueva Asignación
              </Button>
            </div>

            <Card className="bg-white border-gray-200">
              <CardHeader>
                <CardTitle className="text-gray-900">Asignaciones Actuales</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-gray-200">
                        <th className="text-left p-4 text-gray-600 font-medium">Profesor</th>
                        <th className="text-left p-4 text-gray-600 font-medium">Curso</th>
                        <th className="text-left p-4 text-gray-600 font-medium">Materia</th>
                        <th className="text-left p-4 text-gray-600 font-medium">Carga Académica</th>
                        <th className="text-left p-4 text-gray-600 font-medium">Estado</th>
                        <th className="text-right p-4 text-gray-600 font-medium">Acciones</th>
                      </tr>
                    </thead>
                    <tbody>
                      {[
                        {
                          teacher: "María González",
                          course: "1° A Primaria",
                          subject: "Matemáticas",
                          load: "20 hrs/sem",
                          status: "Activo",
                        },
                        {
                          teacher: "Roberto Sánchez",
                          course: "1° B Primaria",
                          subject: "Lenguaje",
                          load: "18 hrs/sem",
                          status: "Activo",
                        },
                        {
                          teacher: "Ana Martínez",
                          course: "2° A Primaria",
                          subject: "Ciencias",
                          load: "15 hrs/sem",
                          status: "Activo",
                        },
                        {
                          teacher: "Carlos López",
                          course: "3° A Primaria",
                          subject: "Historia",
                          load: "12 hrs/sem",
                          status: "Pendiente",
                        },
                      ].map((assignment, index) => (
                        <tr key={index} className="border-b border-gray-100 hover:bg-gray-50">
                          <td className="p-4 text-gray-900">{assignment.teacher}</td>
                          <td className="p-4 text-gray-600">{assignment.course}</td>
                          <td className="p-4 text-gray-600">{assignment.subject}</td>
                          <td className="p-4 text-gray-600">{assignment.load}</td>
                          <td className="p-4">
                            <Badge
                              className={`${
                                assignment.status === "Activo"
                                  ? "bg-green-100 text-green-800 border-green-200"
                                  : "bg-yellow-100 text-yellow-800 border-yellow-200"
                              }`}
                            >
                              {assignment.status}
                            </Badge>
                          </td>
                          <td className="p-4 text-right">
                            <div className="flex justify-end gap-2">
                              <Button size="sm" variant="ghost" className="h-8 w-8 p-0">
                                <Edit className="h-4 w-4 text-purple-600" />
                              </Button>
                              <Button size="sm" variant="ghost" className="h-8 w-8 p-0">
                                <Trash2 className="h-4 w-4 text-red-600" />
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Configuración de Períodos */}
          <TabsContent value="periods" className="space-y-6">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-2xl font-bold text-gray-900">Configuración de Períodos Escolares</h2>
                <p className="text-gray-600">Define los períodos académicos del año escolar</p>
              </div>
              <Button className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white">
                <Plus className="mr-2 h-4 w-4" /> Nuevo Período
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {[
                {
                  name: "2025-T1 (1er Trimestre 2025)",
                  startDate: "01/02/2025",
                  endDate: "30/04/2025",
                  status: "Próximo",
                  type: "Trimestre",
                },
                {
                  name: "2024-T3 (3er Trimestre 2024)",
                  startDate: "01/08/2024",
                  endDate: "30/11/2024",
                  status: "Activo",
                  type: "Trimestre",
                },
                {
                  name: "2024-T2 (2do Trimestre 2024)",
                  startDate: "01/05/2024",
                  endDate: "31/07/2024",
                  status: "Cerrado",
                  type: "Trimestre",
                },
              ].map((period, index) => (
                <Card
                  key={index}
                  className="bg-white border-gray-200 hover:border-purple-300 transition-all duration-300"
                >
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-sm text-gray-900">{period.name}</CardTitle>
                      <Badge
                        className={`${
                          period.status === "Activo"
                            ? "bg-green-100 text-green-800 border-green-200"
                            : period.status === "Próximo"
                              ? "bg-blue-100 text-blue-800 border-blue-200"
                              : "bg-yellow-100 text-yellow-800 border-yellow-200"
                        }`}
                      >
                        {period.status}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div>
                      <p className="text-xs text-gray-500">Tipo de Período</p>
                      <p className="text-sm font-medium text-gray-900">{period.type}</p>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div>
                        <p className="text-gray-500">Inicio</p>
                        <p className="font-medium text-gray-900">{period.startDate}</p>
                      </div>
                      <div>
                        <p className="text-gray-500">Fin</p>
                        <p className="font-medium text-gray-900">{period.endDate}</p>
                      </div>
                    </div>

                    <div className="flex gap-2 pt-2">
                      <Button size="sm" variant="ghost" className="h-8 w-8 p-0 hover:bg-gray-100">
                        <Eye className="h-4 w-4 text-blue-600" />
                      </Button>
                      <Button size="sm" variant="ghost" className="h-8 w-8 p-0 hover:bg-gray-100">
                        <Edit className="h-4 w-4 text-purple-600" />
                      </Button>
                      <Button size="sm" variant="ghost" className="h-8 w-8 p-0 hover:bg-gray-100">
                        <Settings className="h-4 w-4 text-gray-600" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Alertas de Períodos */}
            <Card className="bg-white border-gray-200">
              <CardHeader>
                <CardTitle className="text-gray-900 flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  Alertas de Períodos
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center gap-3 p-3 bg-yellow-50 rounded-lg">
                    <Clock className="h-4 w-4 text-yellow-600" />
                    <div className="flex-1">
                      <p className="text-sm font-medium text-gray-900">Período actual termina pronto</p>
                      <p className="text-xs text-gray-600">El 3er Trimestre 2024 finaliza en 15 días</p>
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      className="border-yellow-300 text-yellow-700 hover:bg-yellow-50 bg-transparent"
                    >
                      Revisar
                    </Button>
                  </div>

                  <div className="flex items-center gap-3 p-3 bg-blue-50 rounded-lg">
                    <CheckCircle className="h-4 w-4 text-blue-600" />
                    <div className="flex-1">
                      <p className="text-sm font-medium text-gray-900">Próximo período configurado</p>
                      <p className="text-xs text-gray-600">1er Trimestre 2025 listo para activar</p>
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      className="border-blue-300 text-blue-700 hover:bg-blue-50 bg-transparent"
                    >
                      Ver Detalles
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}
