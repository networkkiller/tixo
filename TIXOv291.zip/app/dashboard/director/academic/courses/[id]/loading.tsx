import { Card, CardContent, CardHeader } from "@/components/ui/card"

export default function CourseDetailsLoading() {
  return (
    <div className="flex-1 flex flex-col">
      <div className="h-16 bg-futuristic-surface border-b border-futuristic-primary/20 animate-pulse" />

      <main className="flex-1 overflow-y-auto p-6 bg-gradient-to-br from-futuristic-background via-futuristic-surface to-futuristic-background">
        {/* Botón de regreso skeleton */}
        <div className="mb-6">
          <div className="h-10 w-48 bg-futuristic-surface/50 rounded-md animate-pulse" />
        </div>

        {/* Cards de información general skeleton */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          {[...Array(4)].map((_, i) => (
            <Card key={i} className="bg-futuristic-surface border-futuristic-primary/10">
              <CardHeader className="pb-3">
                <div className="h-4 bg-futuristic-background/50 rounded animate-pulse" />
              </CardHeader>
              <CardContent>
                <div className="h-8 bg-futuristic-background/50 rounded animate-pulse mb-2" />
                <div className="h-3 bg-futuristic-background/30 rounded animate-pulse" />
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Tabs skeleton */}
        <div className="space-y-6">
          <div className="bg-futuristic-surface/50 backdrop-blur-sm rounded-lg p-1 w-fit">
            <div className="flex gap-2">
              <div className="h-10 w-32 bg-futuristic-background/50 rounded animate-pulse" />
              <div className="h-10 w-32 bg-futuristic-background/30 rounded animate-pulse" />
            </div>
          </div>

          {/* Content skeleton */}
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <Card key={i} className="bg-futuristic-surface border-futuristic-primary/10">
                <CardHeader>
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-futuristic-background/50 rounded-full animate-pulse" />
                    <div className="flex-1">
                      <div className="h-5 bg-futuristic-background/50 rounded animate-pulse mb-2" />
                      <div className="h-4 bg-futuristic-background/30 rounded animate-pulse w-2/3" />
                    </div>
                    <div className="h-8 w-16 bg-futuristic-background/50 rounded animate-pulse" />
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="grid grid-cols-4 gap-4">
                      {[...Array(4)].map((_, j) => (
                        <div key={j} className="h-12 bg-futuristic-background/30 rounded animate-pulse" />
                      ))}
                    </div>
                    <div className="grid grid-cols-3 gap-3">
                      {[...Array(6)].map((_, j) => (
                        <div key={j} className="h-16 bg-futuristic-background/30 rounded animate-pulse" />
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </main>
    </div>
  )
}
