"use client"

import { Header } from "@/components/dashboard/header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  ArrowLeft,
  Users,
  BookOpen,
  GraduationCap,
  Search,
  Filter,
  Download,
  Edit,
  Mail,
  Phone,
  Calendar,
  Award,
  TrendingUp,
  TrendingDown,
  Minus,
} from "lucide-react"
import { useParams, useRouter } from "next/navigation"

export default function CourseDetails() {
  const params = useParams()
  const router = useRouter()
  const courseId = params.id

  // Datos simulados del curso
  const courseData = {
    "1A": {
      id: "1A",
      level: "Primario",
      grade: "1°",
      section: "A",
      turn: "Mañana",
      students: 24,
      maxStudents: 30,
      teacher: "María González",
      teacherId: "teacher_001",
      status: "Activo",
      subjects: [
        { name: "Matemáticas", teacher: "María González", hours: 6 },
        { name: "Lenguaje", teacher: "Ana Martínez", hours: 5 },
        { name: "Ciencias Naturales", teacher: "Carlos López", hours: 4 },
        { name: "Estudios Sociales", teacher: "Roberto Sánchez", hours: 3 },
        { name: "Educación Física", teacher: "Luis Morales", hours: 2 },
      ],
      students: [
        {
          id: "001",
          name: "Ana García Pérez",
          email: "ana.garcia@email.com",
          phone: "+1234567890",
          birthDate: "2016-03-15",
          grades: {
            Matemáticas: { grade: 85, trend: "up" },
            Lenguaje: { grade: 92, trend: "up" },
            "Ciencias Naturales": { grade: 78, trend: "stable" },
            "Estudios Sociales": { grade: 88, trend: "up" },
            "Educación Física": { grade: 95, trend: "stable" },
          },
          average: 87.6,
          attendance: 95,
          status: "Activo",
        },
        {
          id: "002",
          name: "Carlos Rodríguez López",
          email: "carlos.rodriguez@email.com",
          phone: "+1234567891",
          birthDate: "2016-07-22",
          grades: {
            Matemáticas: { grade: 76, trend: "down" },
            Lenguaje: { grade: 82, trend: "stable" },
            "Ciencias Naturales": { grade: 85, trend: "up" },
            "Estudios Sociales": { grade: 79, trend: "stable" },
            "Educación Física": { grade: 90, trend: "up" },
          },
          average: 82.4,
          attendance: 92,
          status: "Activo",
        },
        {
          id: "003",
          name: "María Fernández Silva",
          email: "maria.fernandez@email.com",
          phone: "+1234567892",
          birthDate: "2016-01-10",
          grades: {
            Matemáticas: { grade: 94, trend: "up" },
            Lenguaje: { grade: 96, trend: "stable" },
            "Ciencias Naturales": { grade: 91, trend: "up" },
            "Estudios Sociales": { grade: 93, trend: "up" },
            "Educación Física": { grade: 98, trend: "stable" },
          },
          average: 94.4,
          attendance: 98,
          status: "Activo",
        },
        {
          id: "004",
          name: "Diego Martínez Ruiz",
          email: "diego.martinez@email.com",
          phone: "+1234567893",
          birthDate: "2016-05-18",
          grades: {
            Matemáticas: { grade: 68, trend: "down" },
            Lenguaje: { grade: 72, trend: "stable" },
            "Ciencias Naturales": { grade: 70, trend: "up" },
            "Estudios Sociales": { grade: 74, trend: "stable" },
            "Educación Física": { grade: 85, trend: "up" },
          },
          average: 73.8,
          attendance: 88,
          status: "Activo",
        },
        {
          id: "005",
          name: "Sofía González Torres",
          email: "sofia.gonzalez@email.com",
          phone: "+1234567894",
          birthDate: "2016-09-03",
          grades: {
            Matemáticas: { grade: 89, trend: "up" },
            Lenguaje: { grade: 87, trend: "stable" },
            "Ciencias Naturales": { grade: 92, trend: "up" },
            "Estudios Sociales": { grade: 86, trend: "stable" },
            "Educación Física": { grade: 94, trend: "up" },
          },
          average: 89.6,
          attendance: 96,
          status: "Activo",
        },
      ],
    },
  }

  const course = courseData[courseId] || courseData["1A"]

  const getTrendIcon = (trend) => {
    switch (trend) {
      case "up":
        return <TrendingUp className="h-4 w-4 text-futuristic-success" />
      case "down":
        return <TrendingDown className="h-4 w-4 text-futuristic-error" />
      default:
        return <Minus className="h-4 w-4 text-futuristic-warning" />
    }
  }

  const getGradeColor = (grade) => {
    if (grade >= 90) return "text-futuristic-success"
    if (grade >= 80) return "text-futuristic-info"
    if (grade >= 70) return "text-futuristic-warning"
    return "text-futuristic-error"
  }

  return (
    <div className="flex-1 flex flex-col">
      <Header title={`Curso ${course.grade} ${course.section} ${course.level}`} />

      <main className="flex-1 overflow-y-auto p-6 bg-gradient-to-br from-futuristic-background via-futuristic-surface to-futuristic-background">
        {/* Botón de regreso */}
        <div className="mb-6">
          <Button
            variant="outline"
            onClick={() => router.back()}
            className="border-futuristic-primary/30 text-futuristic-primary hover:bg-futuristic-primary/10"
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Volver a Gestión Académica
          </Button>
        </div>

        {/* Información del maestro encargado */}
        <div className="mb-8">
          <Card className="bg-futuristic-surface border-futuristic-primary/10">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-futuristic-primary/20 rounded-full flex items-center justify-center">
                    <GraduationCap className="h-6 w-6 text-futuristic-primary" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-futuristic-text-primary">Maestro Encargado</h3>
                    <p className="text-futuristic-text-secondary">
                      {course.teacher && course.teacher !== "unassigned" ? course.teacher : "Sin asignar"}
                    </p>
                    <p className="text-xs text-futuristic-text-tertiary mt-1">
                      Configurado por: Director o Coordinador Académico
                    </p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-futuristic-primary/30 text-futuristic-primary hover:bg-futuristic-primary/10 bg-transparent"
                  >
                    <Edit className="mr-2 h-4 w-4" />
                    Cambiar Maestro
                  </Button>
                  {course.teacher && course.teacher !== "unassigned" && (
                    <Button
                      variant="outline"
                      size="sm"
                      className="border-futuristic-info/30 text-futuristic-info hover:bg-futuristic-info/10 bg-transparent"
                    >
                      <Mail className="mr-2 h-4 w-4" />
                      Contactar
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Información general del curso */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-futuristic-surface border-futuristic-primary/10">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm text-futuristic-text-secondary flex items-center gap-2">
                <Users className="h-4 w-4" />
                Estudiantes
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-futuristic-text-primary">
                {course.students.length}/{course.maxStudents}
              </div>
              <p className="text-xs text-futuristic-text-secondary">
                {((course.students.length / course.maxStudents) * 100).toFixed(1)}% ocupación
              </p>
            </CardContent>
          </Card>

          <Card className="bg-futuristic-surface border-futuristic-primary/10">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm text-futuristic-text-secondary flex items-center gap-2">
                <BookOpen className="h-4 w-4" />
                Materias
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-futuristic-text-primary">{course.subjects.length}</div>
              <p className="text-xs text-futuristic-text-secondary">
                {course.subjects.reduce((acc, subject) => acc + subject.hours, 0)} hrs/semana
              </p>
            </CardContent>
          </Card>

          <Card className="bg-futuristic-surface border-futuristic-primary/10">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm text-futuristic-text-secondary flex items-center gap-2">
                <Award className="h-4 w-4" />
                Promedio General
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-futuristic-text-primary">
                {(course.students.reduce((acc, student) => acc + student.average, 0) / course.students.length).toFixed(
                  1,
                )}
              </div>
              <p className="text-xs text-futuristic-text-secondary">Promedio del curso</p>
            </CardContent>
          </Card>

          <Card className="bg-futuristic-surface border-futuristic-primary/10">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm text-futuristic-text-secondary flex items-center gap-2">
                <Calendar className="h-4 w-4" />
                Asistencia
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-futuristic-text-primary">
                {(
                  course.students.reduce((acc, student) => acc + student.attendance, 0) / course.students.length
                ).toFixed(1)}
                %
              </div>
              <p className="text-xs text-futuristic-text-secondary">Promedio de asistencia</p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="students" className="space-y-6">
          <div className="bg-futuristic-surface/50 backdrop-blur-sm rounded-lg p-1 w-fit">
            <TabsList className="grid grid-cols-2 w-fit">
              <TabsTrigger value="students" className="flex items-center gap-2">
                <Users className="h-4 w-4" />
                <span className="hidden md:inline">Estudiantes</span>
              </TabsTrigger>
              <TabsTrigger value="subjects" className="flex items-center gap-2">
                <BookOpen className="h-4 w-4" />
                <span className="hidden md:inline">Materias</span>
              </TabsTrigger>
            </TabsList>
          </div>

          {/* Lista de Estudiantes */}
          <TabsContent value="students" className="space-y-6">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-2xl font-bold text-futuristic-text-primary">Lista de Estudiantes</h2>
                <p className="text-futuristic-text-secondary">Información detallada de los estudiantes del curso</p>
              </div>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  className="border-futuristic-primary/30 text-futuristic-primary hover:bg-futuristic-primary/10 bg-transparent"
                >
                  <Filter className="mr-2 h-4 w-4" />
                  Filtrar
                </Button>
                <Button
                  variant="outline"
                  className="border-futuristic-primary/30 text-futuristic-primary hover:bg-futuristic-primary/10 bg-transparent"
                >
                  <Download className="mr-2 h-4 w-4" />
                  Exportar
                </Button>
              </div>
            </div>

            {/* Filtros */}
            <div className="flex flex-col md:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-futuristic-text-tertiary" />
                <Input
                  placeholder="Buscar estudiante..."
                  className="pl-10 bg-futuristic-surface border-futuristic-primary/20 text-futuristic-text-primary"
                />
              </div>
              <select className="bg-futuristic-surface border-futuristic-primary/20 text-futuristic-text-primary rounded-md px-3 py-2">
                <option value="all">Todos los estudiantes</option>
                <option value="high">Alto rendimiento (90+)</option>
                <option value="medium">Rendimiento medio (70-89)</option>
                <option value="low">Bajo rendimiento (&lt;70)</option>
              </select>
            </div>

            {/* Lista de estudiantes */}
            <div className="space-y-4">
              {course.students.map((student, index) => (
                <Card
                  key={index}
                  className="bg-futuristic-surface border-futuristic-primary/10 hover:border-futuristic-primary/30 transition-all duration-300"
                >
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-futuristic-primary/20 rounded-full flex items-center justify-center">
                          <span className="text-futuristic-primary font-semibold">
                            {student.name
                              .split(" ")
                              .map((n) => n[0])
                              .join("")
                              .slice(0, 2)}
                          </span>
                        </div>
                        <div>
                          <CardTitle className="text-futuristic-text-primary">{student.name}</CardTitle>
                          <div className="flex items-center gap-4 text-sm text-futuristic-text-secondary">
                            <span className="flex items-center gap-1">
                              <Mail className="h-3 w-3" />
                              {student.email}
                            </span>
                            <span className="flex items-center gap-1">
                              <Phone className="h-3 w-3" />
                              {student.phone}
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className={`text-2xl font-bold ${getGradeColor(student.average)}`}>
                          {student.average.toFixed(1)}
                        </div>
                        <p className="text-xs text-futuristic-text-secondary">Promedio general</p>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                      <div>
                        <p className="text-futuristic-text-secondary">Fecha de nacimiento</p>
                        <p className="font-medium text-futuristic-text-primary">
                          {new Date(student.birthDate).toLocaleDateString()}
                        </p>
                      </div>
                      <div>
                        <p className="text-futuristic-text-secondary">Asistencia</p>
                        <p className="font-medium text-futuristic-text-primary">{student.attendance}%</p>
                      </div>
                      <div>
                        <p className="text-futuristic-text-secondary">Estado</p>
                        <Badge className="bg-futuristic-success/20 text-futuristic-success border-futuristic-success/30">
                          {student.status}
                        </Badge>
                      </div>
                      <div>
                        <p className="text-futuristic-text-secondary">ID Estudiante</p>
                        <p className="font-medium text-futuristic-text-primary">{student.id}</p>
                      </div>
                    </div>

                    {/* Calificaciones por materia */}
                    <div>
                      <h4 className="font-medium text-futuristic-text-primary mb-3">Calificaciones por Materia</h4>
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                        {Object.entries(student.grades).map(([subject, data]) => (
                          <div
                            key={subject}
                            className="p-3 bg-futuristic-background/30 rounded-lg flex items-center justify-between"
                          >
                            <div>
                              <p className="text-sm font-medium text-futuristic-text-primary">{subject}</p>
                              <p className={`text-lg font-bold ${getGradeColor(data.grade)}`}>{data.grade}</p>
                            </div>
                            <div className="flex items-center gap-1">{getTrendIcon(data.trend)}</div>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="flex gap-2 pt-2">
                      <Button
                        size="sm"
                        variant="outline"
                        className="border-futuristic-primary/30 text-futuristic-primary hover:bg-futuristic-primary/10 bg-transparent"
                      >
                        <Edit className="mr-2 h-4 w-4" />
                        Editar
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="border-futuristic-info/30 text-futuristic-info hover:bg-futuristic-info/10 bg-transparent"
                      >
                        <Mail className="mr-2 h-4 w-4" />
                        Contactar
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Materias del Curso */}
          <TabsContent value="subjects" className="space-y-6">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-2xl font-bold text-futuristic-text-primary">Materias del Curso</h2>
                <p className="text-futuristic-text-secondary">Materias asignadas por el coordinador pedagógico</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {course.subjects.map((subject, index) => (
                <Card
                  key={index}
                  className="bg-futuristic-surface border-futuristic-primary/10 hover:border-futuristic-primary/30 transition-all duration-300"
                >
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-futuristic-text-primary">{subject.name}</CardTitle>
                      <Badge className="bg-futuristic-info/20 text-futuristic-info border-futuristic-info/30">
                        {subject.hours} hrs/sem
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div>
                      <p className="text-xs text-futuristic-text-secondary">Profesor Asignado</p>
                      <p className="text-sm font-medium text-futuristic-text-primary">{subject.teacher}</p>
                    </div>

                    <div className="flex gap-2 pt-2">
                      <Button
                        size="sm"
                        variant="outline"
                        className="border-futuristic-primary/30 text-futuristic-primary hover:bg-futuristic-primary/10 bg-transparent"
                      >
                        <GraduationCap className="mr-2 h-4 w-4" />
                        Ver Detalles
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}
