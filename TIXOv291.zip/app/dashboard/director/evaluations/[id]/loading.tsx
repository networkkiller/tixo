export default function Loading() {
  return (
    <div className="flex-1 flex flex-col">
      <div className="h-16 bg-futuristic-surface border-b border-futuristic-primary/10 flex items-center px-6">
        <div className="h-6 bg-futuristic-primary/20 rounded w-48 animate-pulse"></div>
      </div>

      <main className="flex-1 overflow-y-auto p-6 bg-gradient-to-br from-futuristic-background via-futuristic-surface to-futuristic-background">
        <div className="space-y-6">
          {/* Botón de regreso y título */}
          <div className="flex items-center gap-4">
            <div className="h-10 w-20 bg-futuristic-primary/20 rounded animate-pulse"></div>
            <div>
              <div className="h-8 bg-futuristic-primary/20 rounded w-64 animate-pulse mb-2"></div>
              <div className="h-4 bg-futuristic-primary/20 rounded w-48 animate-pulse"></div>
            </div>
          </div>

          {/* Información general */}
          <div className="h-32 bg-futuristic-surface/50 rounded-lg animate-pulse"></div>

          {/* Estadísticas */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="h-24 bg-futuristic-surface/50 rounded-lg animate-pulse"></div>
            <div className="h-24 bg-futuristic-surface/50 rounded-lg animate-pulse"></div>
            <div className="h-24 bg-futuristic-surface/50 rounded-lg animate-pulse"></div>
            <div className="h-24 bg-futuristic-surface/50 rounded-lg animate-pulse"></div>
          </div>

          {/* Tabs */}
          <div className="h-10 bg-futuristic-surface/50 rounded w-64 animate-pulse"></div>

          {/* Contenido principal */}
          <div className="h-96 bg-futuristic-surface/50 rounded-lg animate-pulse"></div>
        </div>
      </main>
    </div>
  )
}
