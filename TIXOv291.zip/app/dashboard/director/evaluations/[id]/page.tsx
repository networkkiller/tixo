"use client"

import { Header } from "@/components/dashboard/header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowLeft, Eye, Download, FileText, Users, TrendingUp, Award, AlertCircle, CheckCircle } from "lucide-react"
import { useRouter } from "next/navigation"

export default function EvaluationDetail() {
  const router = useRouter()

  // Datos simulados de la evaluación
  const evaluation = {
    id: "eval-001",
    title: "Examen Final - Matemáticas",
    course: "3° A Primaria",
    subject: "Matemáticas",
    teacher: "María González",
    date: "15/06/2024",
    type: "Examen Final",
    totalPoints: 100,
    duration: "2 horas",
    status: "Completado",
    studentsCount: 24,
    averageScore: 8.2,
    passRate: 87.5,
  }

  // Datos simulados de estudiantes y calificaciones
  const studentGrades = [
    {
      id: 1,
      name: "Ana María Pérez",
      score: 95,
      grade: "A",
      status: "Aprobado",
      submittedAt: "15/06/2024 10:30",
      timeSpent: "1h 45m",
      answers: { correct: 19, incorrect: 1, blank: 0 },
      observations: "Excelente desempeño en todos los temas",
    },
    {
      id: 2,
      name: "Carlos Martínez",
      score: 88,
      grade: "B+",
      status: "Aprobado",
      submittedAt: "15/06/2024 10:45",
      timeSpent: "1h 55m",
      answers: { correct: 17, incorrect: 2, blank: 1 },
      observations: "Buen rendimiento, mejorar en geometría",
    },
    {
      id: 3,
      name: "Luis González",
      score: 92,
      grade: "A-",
      status: "Aprobado",
      submittedAt: "15/06/2024 10:25",
      timeSpent: "1h 30m",
      answers: { correct: 18, incorrect: 2, blank: 0 },
      observations: "Muy buen manejo de operaciones básicas",
    },
    {
      id: 4,
      name: "Sofia Rodríguez",
      score: 76,
      grade: "B",
      status: "Aprobado",
      submittedAt: "15/06/2024 11:00",
      timeSpent: "2h 00m",
      answers: { correct: 15, incorrect: 4, blank: 1 },
      observations: "Necesita refuerzo en fracciones",
    },
    {
      id: 5,
      name: "Diego Herrera",
      score: 65,
      grade: "C+",
      status: "Aprobado",
      submittedAt: "15/06/2024 11:15",
      timeSpent: "2h 00m",
      answers: { correct: 13, incorrect: 6, blank: 1 },
      observations: "Requiere apoyo adicional en matemáticas",
    },
    {
      id: 6,
      name: "Isabella Torres",
      score: 58,
      grade: "C",
      status: "Reprobado",
      submittedAt: "15/06/2024 11:30",
      timeSpent: "1h 50m",
      answers: { correct: 11, incorrect: 7, blank: 2 },
      observations: "Necesita plan de recuperación",
    },
  ]

  const getGradeColor = (grade: string) => {
    switch (grade) {
      case "A":
      case "A-":
        return "bg-futuristic-success/20 text-futuristic-success border-futuristic-success/30"
      case "B+":
      case "B":
        return "bg-futuristic-info/20 text-futuristic-info border-futuristic-info/30"
      case "C+":
      case "C":
        return "bg-futuristic-warning/20 text-futuristic-warning border-futuristic-warning/30"
      default:
        return "bg-futuristic-error/20 text-futuristic-error border-futuristic-error/30"
    }
  }

  const getStatusColor = (status: string) => {
    return status === "Aprobado"
      ? "bg-futuristic-success/20 text-futuristic-success border-futuristic-success/30"
      : "bg-futuristic-error/20 text-futuristic-error border-futuristic-error/30"
  }

  return (
    <div className="flex-1 flex flex-col">
      <Header title="Detalle de Evaluación" />

      <main className="flex-1 overflow-y-auto p-6 bg-gradient-to-br from-futuristic-background via-futuristic-surface to-futuristic-background">
        <div className="space-y-6">
          {/* Botón de regreso y título */}
          <div className="flex items-center gap-4">
            <Button
              variant="outline"
              onClick={() => router.back()}
              className="border-futuristic-primary/30 text-futuristic-primary hover:bg-futuristic-primary/10"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Volver
            </Button>
            <div>
              <h1 className="text-2xl font-bold text-futuristic-text-primary">{evaluation.title}</h1>
              <p className="text-futuristic-text-secondary">
                {evaluation.course} • {evaluation.subject} • {evaluation.date}
              </p>
            </div>
          </div>

          {/* Información general de la evaluación */}
          <Card className="bg-futuristic-surface border-futuristic-primary/10">
            <CardHeader>
              <CardTitle className="text-futuristic-text-primary">Información de la Evaluación</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
                <div>
                  <p className="text-sm text-futuristic-text-secondary">Profesor</p>
                  <p className="font-medium text-futuristic-text-primary">{evaluation.teacher}</p>
                </div>
                <div>
                  <p className="text-sm text-futuristic-text-secondary">Tipo</p>
                  <p className="font-medium text-futuristic-text-primary">{evaluation.type}</p>
                </div>
                <div>
                  <p className="text-sm text-futuristic-text-secondary">Puntos Totales</p>
                  <p className="font-medium text-futuristic-text-primary">{evaluation.totalPoints}</p>
                </div>
                <div>
                  <p className="text-sm text-futuristic-text-secondary">Duración</p>
                  <p className="font-medium text-futuristic-text-primary">{evaluation.duration}</p>
                </div>
                <div>
                  <p className="text-sm text-futuristic-text-secondary">Estudiantes</p>
                  <p className="font-medium text-futuristic-text-primary">{evaluation.studentsCount}</p>
                </div>
                <div>
                  <p className="text-sm text-futuristic-text-secondary">Estado</p>
                  <Badge className="bg-futuristic-success/20 text-futuristic-success border-futuristic-success/30">
                    {evaluation.status}
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Estadísticas de la evaluación */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <Card className="bg-futuristic-surface border-futuristic-primary/10 hover:border-futuristic-primary/30 transition-all duration-300">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-futuristic-text-secondary text-sm font-medium">Promedio General</CardTitle>
                <TrendingUp className="h-5 w-5 text-futuristic-success" />
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-futuristic-text-primary">{evaluation.averageScore}</div>
                <p className="text-xs text-futuristic-success mt-1">Sobre 10.0</p>
              </CardContent>
            </Card>

            <Card className="bg-futuristic-surface border-futuristic-primary/10 hover:border-futuristic-primary/30 transition-all duration-300">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-futuristic-text-secondary text-sm font-medium">Tasa de Aprobación</CardTitle>
                <Award className="h-5 w-5 text-futuristic-info" />
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-futuristic-text-primary">{evaluation.passRate}%</div>
                <p className="text-xs text-futuristic-info mt-1">21 de 24 estudiantes</p>
              </CardContent>
            </Card>

            <Card className="bg-futuristic-surface border-futuristic-primary/10 hover:border-futuristic-primary/30 transition-all duration-300">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-futuristic-text-secondary text-sm font-medium">Aprobados</CardTitle>
                <CheckCircle className="h-5 w-5 text-futuristic-success" />
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-futuristic-text-primary">21</div>
                <p className="text-xs text-futuristic-success mt-1">Estudiantes</p>
              </CardContent>
            </Card>

            <Card className="bg-futuristic-surface border-futuristic-primary/10 hover:border-futuristic-primary/30 transition-all duration-300">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-futuristic-text-secondary text-sm font-medium">Reprobados</CardTitle>
                <AlertCircle className="h-5 w-5 text-futuristic-error" />
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-futuristic-text-primary">3</div>
                <p className="text-xs text-futuristic-error mt-1">Requieren recuperación</p>
              </CardContent>
            </Card>
          </div>

          {/* Tabs para diferentes vistas */}
          <Tabs defaultValue="students" className="space-y-6">
            <div className="bg-futuristic-surface/50 backdrop-blur-sm rounded-lg p-1 w-fit">
              <TabsList className="grid grid-cols-3 w-fit">
                <TabsTrigger value="students" className="flex items-center gap-2">
                  <Users className="h-4 w-4" />
                  <span className="hidden md:inline">Estudiantes</span>
                </TabsTrigger>
                <TabsTrigger value="statistics" className="flex items-center gap-2">
                  <TrendingUp className="h-4 w-4" />
                  <span className="hidden md:inline">Estadísticas</span>
                </TabsTrigger>
                <TabsTrigger value="analysis" className="flex items-center gap-2">
                  <FileText className="h-4 w-4" />
                  <span className="hidden md:inline">Análisis</span>
                </TabsTrigger>
              </TabsList>
            </div>

            {/* Vista de Estudiantes */}
            <TabsContent value="students" className="space-y-6">
              <div className="flex justify-between items-center">
                <div>
                  <h2 className="text-xl font-bold text-futuristic-text-primary">Calificaciones por Estudiante</h2>
                  <p className="text-futuristic-text-secondary">Resultados detallados de cada estudiante</p>
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    className="border-futuristic-primary/30 text-futuristic-primary hover:bg-futuristic-primary/10 bg-transparent"
                  >
                    <Download className="mr-2 h-4 w-4" />
                    Exportar
                  </Button>
                </div>
              </div>

              <Card className="bg-futuristic-surface border-futuristic-primary/10">
                <CardContent className="p-0">
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b border-futuristic-primary/20">
                          <th className="text-left p-4 text-futuristic-text-secondary font-medium">Estudiante</th>
                          <th className="text-left p-4 text-futuristic-text-secondary font-medium">Puntuación</th>
                          <th className="text-left p-4 text-futuristic-text-secondary font-medium">Calificación</th>
                          <th className="text-left p-4 text-futuristic-text-secondary font-medium">Estado</th>
                          <th className="text-left p-4 text-futuristic-text-secondary font-medium">Tiempo</th>
                          <th className="text-left p-4 text-futuristic-text-secondary font-medium">Respuestas</th>
                          <th className="text-right p-4 text-futuristic-text-secondary font-medium">Acciones</th>
                        </tr>
                      </thead>
                      <tbody>
                        {studentGrades.map((student) => (
                          <tr
                            key={student.id}
                            className="border-b border-futuristic-primary/10 hover:bg-futuristic-primary/5"
                          >
                            <td className="p-4">
                              <div>
                                <p className="font-medium text-futuristic-text-primary">{student.name}</p>
                                <p className="text-sm text-futuristic-text-secondary">
                                  Entregado: {student.submittedAt}
                                </p>
                              </div>
                            </td>
                            <td className="p-4">
                              <div className="flex items-center gap-2">
                                <span className="text-2xl font-bold text-futuristic-text-primary">{student.score}</span>
                                <span className="text-futuristic-text-secondary">/100</span>
                              </div>
                            </td>
                            <td className="p-4">
                              <Badge className={getGradeColor(student.grade)}>{student.grade}</Badge>
                            </td>
                            <td className="p-4">
                              <Badge className={getStatusColor(student.status)}>{student.status}</Badge>
                            </td>
                            <td className="p-4 text-futuristic-text-secondary">{student.timeSpent}</td>
                            <td className="p-4">
                              <div className="text-sm">
                                <div className="flex gap-4">
                                  <span className="text-futuristic-success">✓ {student.answers.correct}</span>
                                  <span className="text-futuristic-error">✗ {student.answers.incorrect}</span>
                                  <span className="text-futuristic-warning">- {student.answers.blank}</span>
                                </div>
                              </div>
                            </td>
                            <td className="p-4 text-right">
                              <Button size="sm" variant="ghost" className="h-8 w-8 p-0">
                                <Eye className="h-4 w-4 text-futuristic-info" />
                              </Button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>

              {/* Observaciones detalladas */}
              <Card className="bg-futuristic-surface border-futuristic-primary/10">
                <CardHeader>
                  <CardTitle className="text-futuristic-text-primary">Observaciones del Profesor</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {studentGrades.map((student) => (
                      <div key={student.id} className="p-3 bg-futuristic-background/30 rounded-lg">
                        <div className="flex items-center justify-between mb-2">
                          <p className="font-medium text-futuristic-text-primary">{student.name}</p>
                          <Badge className={getGradeColor(student.grade)}>
                            {student.grade} - {student.score}/100
                          </Badge>
                        </div>
                        <p className="text-sm text-futuristic-text-secondary">{student.observations}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Vista de Estadísticas */}
            <TabsContent value="statistics" className="space-y-6">
              <div>
                <h2 className="text-xl font-bold text-futuristic-text-primary">Análisis Estadístico</h2>
                <p className="text-futuristic-text-secondary">Distribución de calificaciones y rendimiento</p>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="bg-futuristic-surface border-futuristic-primary/10">
                  <CardHeader>
                    <CardTitle className="text-futuristic-text-primary">Distribución de Calificaciones</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {[
                        { grade: "A (90-100)", count: 3, percentage: 50, color: "bg-futuristic-success" },
                        { grade: "B (80-89)", count: 2, percentage: 33, color: "bg-futuristic-info" },
                        { grade: "C (70-79)", count: 1, percentage: 17, color: "bg-futuristic-warning" },
                        { grade: "D (60-69)", count: 0, percentage: 0, color: "bg-futuristic-error" },
                        { grade: "F (0-59)", count: 0, percentage: 0, color: "bg-futuristic-error" },
                      ].map((item, index) => (
                        <div key={index} className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className={`w-4 h-4 rounded ${item.color}`}></div>
                            <span className="text-futuristic-text-secondary">{item.grade}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <div className="w-20 bg-futuristic-background/50 rounded-full h-2">
                              <div
                                className={`h-2 rounded-full ${item.color}`}
                                style={{ width: `${item.percentage}%` }}
                              ></div>
                            </div>
                            <span className="text-sm text-futuristic-text-primary w-8">{item.count}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-futuristic-surface border-futuristic-primary/10">
                  <CardHeader>
                    <CardTitle className="text-futuristic-text-primary">Métricas de Rendimiento</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="text-center p-3 bg-futuristic-background/30 rounded-lg">
                        <p className="text-2xl font-bold text-futuristic-text-primary">95</p>
                        <p className="text-sm text-futuristic-text-secondary">Puntuación Máxima</p>
                      </div>
                      <div className="text-center p-3 bg-futuristic-background/30 rounded-lg">
                        <p className="text-2xl font-bold text-futuristic-text-primary">58</p>
                        <p className="text-sm text-futuristic-text-secondary">Puntuación Mínima</p>
                      </div>
                      <div className="text-center p-3 bg-futuristic-background/30 rounded-lg">
                        <p className="text-2xl font-bold text-futuristic-text-primary">82</p>
                        <p className="text-sm text-futuristic-text-secondary">Mediana</p>
                      </div>
                      <div className="text-center p-3 bg-futuristic-background/30 rounded-lg">
                        <p className="text-2xl font-bold text-futuristic-text-primary">15.2</p>
                        <p className="text-sm text-futuristic-text-secondary">Desviación Estándar</p>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span className="text-futuristic-text-secondary">Tiempo Promedio</span>
                          <span className="text-futuristic-text-primary">1h 47m</span>
                        </div>
                        <div className="w-full bg-futuristic-background/50 rounded-full h-2">
                          <div className="h-2 rounded-full bg-futuristic-info" style={{ width: "89%" }}></div>
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span className="text-futuristic-text-secondary">Respuestas Correctas</span>
                          <span className="text-futuristic-text-primary">82%</span>
                        </div>
                        <div className="w-full bg-futuristic-background/50 rounded-full h-2">
                          <div className="h-2 rounded-full bg-futuristic-success" style={{ width: "82%" }}></div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* Vista de Análisis */}
            <TabsContent value="analysis" className="space-y-6">
              <div>
                <h2 className="text-xl font-bold text-futuristic-text-primary">Análisis Pedagógico</h2>
                <p className="text-futuristic-text-secondary">Recomendaciones y áreas de mejora</p>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="bg-futuristic-surface border-futuristic-primary/10">
                  <CardHeader>
                    <CardTitle className="text-futuristic-text-primary">Fortalezas Identificadas</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex items-start gap-3 p-3 bg-futuristic-success/10 rounded-lg">
                        <CheckCircle className="h-5 w-5 text-futuristic-success mt-0.5" />
                        <div>
                          <p className="font-medium text-futuristic-text-primary">Operaciones Básicas</p>
                          <p className="text-sm text-futuristic-text-secondary">
                            85% de los estudiantes dominan suma, resta y multiplicación
                          </p>
                        </div>
                      </div>
                      <div className="flex items-start gap-3 p-3 bg-futuristic-success/10 rounded-lg">
                        <CheckCircle className="h-5 w-5 text-futuristic-success mt-0.5" />
                        <div>
                          <p className="font-medium text-futuristic-text-primary">Resolución de Problemas</p>
                          <p className="text-sm text-futuristic-text-secondary">
                            Buen desempeño en problemas de aplicación práctica
                          </p>
                        </div>
                      </div>
                      <div className="flex items-start gap-3 p-3 bg-futuristic-success/10 rounded-lg">
                        <CheckCircle className="h-5 w-5 text-futuristic-success mt-0.5" />
                        <div>
                          <p className="font-medium text-futuristic-text-primary">Comprensión Conceptual</p>
                          <p className="text-sm text-futuristic-text-secondary">
                            Mayoría comprende conceptos fundamentales
                          </p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-futuristic-surface border-futuristic-primary/10">
                  <CardHeader>
                    <CardTitle className="text-futuristic-text-primary">Áreas de Mejora</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex items-start gap-3 p-3 bg-futuristic-warning/10 rounded-lg">
                        <AlertCircle className="h-5 w-5 text-futuristic-warning mt-0.5" />
                        <div>
                          <p className="font-medium text-futuristic-text-primary">Fracciones</p>
                          <p className="text-sm text-futuristic-text-secondary">
                            40% de estudiantes necesitan refuerzo en fracciones
                          </p>
                        </div>
                      </div>
                      <div className="flex items-start gap-3 p-3 bg-futuristic-warning/10 rounded-lg">
                        <AlertCircle className="h-5 w-5 text-futuristic-warning mt-0.5" />
                        <div>
                          <p className="font-medium text-futuristic-text-primary">Geometría</p>
                          <p className="text-sm text-futuristic-text-secondary">
                            Dificultades en cálculo de áreas y perímetros
                          </p>
                        </div>
                      </div>
                      <div className="flex items-start gap-3 p-3 bg-futuristic-error/10 rounded-lg">
                        <AlertCircle className="h-5 w-5 text-futuristic-error mt-0.5" />
                        <div>
                          <p className="font-medium text-futuristic-text-primary">Estudiantes en Riesgo</p>
                          <p className="text-sm text-futuristic-text-secondary">
                            3 estudiantes requieren plan de recuperación inmediato
                          </p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Card className="bg-futuristic-surface border-futuristic-primary/10">
                <CardHeader>
                  <CardTitle className="text-futuristic-text-primary">Recomendaciones Pedagógicas</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="p-4 bg-futuristic-info/10 rounded-lg">
                      <h4 className="font-medium text-futuristic-text-primary mb-2">Para el Grupo</h4>
                      <ul className="space-y-1 text-sm text-futuristic-text-secondary">
                        <li>• Implementar sesiones de refuerzo en fracciones y geometría</li>
                        <li>• Utilizar material manipulativo para conceptos abstractos</li>
                        <li>• Aumentar ejercicios de aplicación práctica</li>
                      </ul>
                    </div>
                    <div className="p-4 bg-futuristic-warning/10 rounded-lg">
                      <h4 className="font-medium text-futuristic-text-primary mb-2">Para Estudiantes en Riesgo</h4>
                      <ul className="space-y-1 text-sm text-futuristic-text-secondary">
                        <li>• Crear plan de recuperación personalizado</li>
                        <li>• Programar tutorías individuales</li>
                        <li>• Involucrar a los padres en el proceso de apoyo</li>
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}
