"use client"

import { useState } from "react"
import { Header } from "@/components/dashboard/header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Textarea } from "@/components/ui/textarea"
import { Progress } from "@/components/ui/progress"
import {
  ClipboardCheck,
  Eye,
  CheckCircle,
  Send,
  Download,
  FileText,
  Clock,
  Star,
  Users,
  Filter,
  Search,
  BarChart3,
  TrendingUp,
  AlertTriangle,
  MessageSquare,
  RefreshCw,
  Target,
  Award,
  BookOpen,
} from "lucide-react"
import { useRouter } from "next/navigation"

// Datos simulados de evaluaciones
const evaluationsData = [
  {
    id: "eval-001",
    course: "1° A Primaria",
    subject: "Matemáticas",
    teacher: "María González",
    students: 24,
    progress: 100,
    average: 8.5,
    status: "Completo",
    period: "P3",
    lastUpdate: "2024-06-20",
    competenciasCompletas: 6,
    totalCompetencias: 6,
    pendingApproval: false,
  },
  {
    id: "eval-002",
    course: "1° A Primaria",
    subject: "Lenguaje",
    teacher: "Roberto Sánchez",
    students: 24,
    progress: 100,
    average: 8.2,
    status: "Completo",
    period: "P3",
    lastUpdate: "2024-06-19",
    competenciasCompletas: 6,
    totalCompetencias: 6,
    pendingApproval: false,
  },
  {
    id: "eval-003",
    course: "2° B Primaria",
    subject: "Ciencias",
    teacher: "Ana Martínez",
    students: 21,
    progress: 75,
    average: 7.8,
    status: "Pendiente",
    period: "P3",
    lastUpdate: "2024-06-18",
    competenciasCompletas: 4,
    totalCompetencias: 6,
    pendingApproval: false,
  },
  {
    id: "eval-004",
    course: "3° A Primaria",
    subject: "Historia",
    teacher: "Carlos López",
    students: 19,
    progress: 50,
    average: 7.5,
    status: "Pendiente",
    period: "P3",
    lastUpdate: "2024-06-17",
    competenciasCompletas: 3,
    totalCompetencias: 6,
    pendingApproval: false,
  },
  {
    id: "eval-005",
    course: "4° A Primaria",
    subject: "Matemáticas",
    teacher: "Laura Pérez",
    students: 22,
    progress: 100,
    average: 8.8,
    status: "Pendiente Validación",
    period: "P3",
    lastUpdate: "2024-06-20",
    competenciasCompletas: 6,
    totalCompetencias: 6,
    pendingApproval: true,
  },
]

// Datos simulados de boletines
const bulletinsData = [
  {
    id: "bol-001",
    course: "1° A Primaria",
    status: "Pendiente",
    generatedDate: "2024-06-15",
    students: 24,
    approvedBy: null,
    period: "P3",
  },
  {
    id: "bol-002",
    course: "2° B Primaria",
    status: "Aprobado",
    generatedDate: "2024-06-13",
    students: 21,
    approvedBy: "Director",
    period: "P3",
  },
  {
    id: "bol-003",
    course: "3° A Primaria",
    status: "Revisión",
    generatedDate: "2024-06-12",
    students: 19,
    approvedBy: null,
    period: "P3",
  },
]

export default function EvaluationsManagement() {
  const router = useRouter()
  const [searchTerm, setSearchTerm] = useState("")
  const [filterCourse, setFilterCourse] = useState("all")
  const [filterSubject, setFilterSubject] = useState("all")
  const [filterStatus, setFilterStatus] = useState("all")
  const [filterPeriod, setFilterPeriod] = useState("P3")
  const [selectedEvaluation, setSelectedEvaluation] = useState(null)
  const [detailModalOpen, setDetailModalOpen] = useState(false)
  const [approvalModalOpen, setApprovalModalOpen] = useState(false)
  const [adjustmentModalOpen, setAdjustmentModalOpen] = useState(false)
  const [adjustmentComment, setAdjustmentComment] = useState("")

  // Filtrar evaluaciones
  const filteredEvaluations = evaluationsData.filter((evaluation) => {
    const matchesSearch =
      evaluation.course.toLowerCase().includes(searchTerm.toLowerCase()) ||
      evaluation.subject.toLowerCase().includes(searchTerm.toLowerCase()) ||
      evaluation.teacher.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCourse = filterCourse === "all" || evaluation.course === filterCourse
    const matchesSubject = filterSubject === "all" || evaluation.subject === filterSubject
    const matchesStatus = filterStatus === "all" || evaluation.status.toLowerCase().includes(filterStatus)
    const matchesPeriod = filterPeriod === "all" || evaluation.period === filterPeriod

    return matchesSearch && matchesCourse && matchesSubject && matchesStatus && matchesPeriod
  })

  // Estadísticas calculadas
  const stats = {
    totalEvaluations: evaluationsData.length,
    completedEvaluations: evaluationsData.filter((e) => e.status === "Completo").length,
    pendingBulletins: bulletinsData.filter((b) => b.status === "Pendiente").length,
    totalStudents: evaluationsData.reduce((sum, e) => sum + e.students, 0),
    averageProgress: Math.round(evaluationsData.reduce((sum, e) => sum + e.progress, 0) / evaluationsData.length),
    pendingApprovals: evaluationsData.filter((e) => e.pendingApproval).length,
  }

  // Función para obtener el color del estado
  const getStatusColor = (status) => {
    switch (status.toLowerCase()) {
      case "completo":
        return "bg-futuristic-success/20 text-futuristic-success border-futuristic-success/30"
      case "pendiente":
        return "bg-futuristic-warning/20 text-futuristic-warning border-futuristic-warning/30"
      case "pendiente validación":
        return "bg-futuristic-info/20 text-futuristic-info border-futuristic-info/30"
      case "en revisión":
        return "bg-futuristic-error/20 text-futuristic-error border-futuristic-error/30"
      default:
        return "bg-futuristic-primary/20 text-futuristic-primary border-futuristic-primary/30"
    }
  }

  // Función para aprobar evaluación
  const handleApproveEvaluation = (evaluation) => {
    if (evaluation.progress < 100) {
      alert("No se puede aprobar una evaluación con progreso menor al 100%")
      return
    }
    alert(`Evaluación de ${evaluation.subject} - ${evaluation.course} aprobada exitosamente`)
    setApprovalModalOpen(false)
  }

  // Función para solicitar ajuste
  const handleRequestAdjustment = () => {
    if (!adjustmentComment.trim()) {
      alert("Por favor ingrese un comentario para el ajuste")
      return
    }
    alert("Solicitud de ajuste enviada al Coordinador Académico y Profesor")
    setAdjustmentModalOpen(false)
    setAdjustmentComment("")
  }

  return (
    <div className="flex-1 flex flex-col">
      <Header title="Gestión de Evaluaciones" />

      <main className="flex-1 overflow-y-auto p-6 bg-gradient-to-br from-futuristic-background via-futuristic-surface to-futuristic-background">
        <Tabs defaultValue="overview" className="space-y-6">
          <div className="bg-futuristic-surface/50 backdrop-blur-sm rounded-lg p-1 w-fit">
            <TabsList className="grid grid-cols-4 w-fit">
              <TabsTrigger value="overview" className="flex items-center gap-2">
                <ClipboardCheck className="h-4 w-4" />
                <span className="hidden md:inline">Vista General</span>
              </TabsTrigger>
              <TabsTrigger value="approval" className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4" />
                <span className="hidden md:inline">Aprobación</span>
              </TabsTrigger>
              <TabsTrigger value="bulletins" className="flex items-center gap-2">
                <FileText className="h-4 w-4" />
                <span className="hidden md:inline">Boletines</span>
              </TabsTrigger>
              <TabsTrigger value="analytics" className="flex items-center gap-2">
                <BarChart3 className="h-4 w-4" />
                <span className="hidden md:inline">Distribución</span>
              </TabsTrigger>
            </TabsList>
          </div>

          {/* Vista General */}
          <TabsContent value="overview" className="space-y-6">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-2xl font-bold text-futuristic-text-primary">Vista General de Evaluaciones</h2>
                <p className="text-futuristic-text-secondary">Supervisa el progreso académico por curso y materia</p>
              </div>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  className="border-futuristic-primary/30 text-futuristic-primary hover:bg-futuristic-primary/10 bg-transparent"
                >
                  <RefreshCw className="mr-2 h-4 w-4" />
                  Actualizar
                </Button>
                <Button className="bg-gradient-to-r from-futuristic-primary to-futuristic-primary-light hover:from-futuristic-primary-light hover:to-futuristic-primary">
                  <Download className="mr-2 h-4 w-4" />
                  Exportar Reporte
                </Button>
              </div>
            </div>

            {/* Estadísticas Generales */}
            <div className="grid grid-cols-1 md:grid-cols-6 gap-6">
              <Card className="bg-futuristic-surface border-futuristic-primary/10 hover:border-futuristic-primary/30 transition-all duration-300">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-futuristic-text-secondary text-sm font-medium">
                    Evaluaciones Completas
                  </CardTitle>
                  <CheckCircle className="h-5 w-5 text-futuristic-success" />
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-futuristic-text-primary">
                    {Math.round((stats.completedEvaluations / stats.totalEvaluations) * 100)}%
                  </div>
                  <p className="text-xs text-futuristic-success mt-1">
                    {stats.completedEvaluations} de {stats.totalEvaluations}
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-futuristic-surface border-futuristic-primary/10 hover:border-futuristic-primary/30 transition-all duration-300">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-futuristic-text-secondary text-sm font-medium">Promedio General</CardTitle>
                  <Star className="h-5 w-5 text-futuristic-warning" />
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-futuristic-text-primary">8.2</div>
                  <p className="text-xs text-futuristic-success mt-1">+0.3 vs período anterior</p>
                </CardContent>
              </Card>

              <Card className="bg-futuristic-surface border-futuristic-primary/10 hover:border-futuristic-primary/30 transition-all duration-300">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-futuristic-text-secondary text-sm font-medium">
                    Boletines Pendientes
                  </CardTitle>
                  <Clock className="h-5 w-5 text-futuristic-warning" />
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-futuristic-text-primary">{stats.pendingBulletins}</div>
                  <p className="text-xs text-futuristic-warning mt-1">Requieren aprobación</p>
                </CardContent>
              </Card>

              <Card className="bg-futuristic-surface border-futuristic-primary/10 hover:border-futuristic-primary/30 transition-all duration-300">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-futuristic-text-secondary text-sm font-medium">Estudiantes</CardTitle>
                  <Users className="h-5 w-5 text-futuristic-info" />
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-futuristic-text-primary">{stats.totalStudents}</div>
                  <p className="text-xs text-futuristic-text-secondary mt-1">Total evaluados</p>
                </CardContent>
              </Card>

              <Card className="bg-futuristic-surface border-futuristic-primary/10 hover:border-futuristic-primary/30 transition-all duration-300">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-futuristic-text-secondary text-sm font-medium">
                    Progreso Promedio
                  </CardTitle>
                  <TrendingUp className="h-5 w-5 text-futuristic-primary" />
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-futuristic-text-primary">{stats.averageProgress}%</div>
                  <Progress value={stats.averageProgress} className="mt-1" />
                </CardContent>
              </Card>

              <Card className="bg-futuristic-surface border-futuristic-primary/10 hover:border-futuristic-primary/30 transition-all duration-300">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-futuristic-text-secondary text-sm font-medium">
                    Pendientes Aprobación
                  </CardTitle>
                  <AlertTriangle className="h-5 w-5 text-futuristic-error" />
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-futuristic-text-primary">{stats.pendingApprovals}</div>
                  <p className="text-xs text-futuristic-error mt-1">Requieren validación</p>
                </CardContent>
              </Card>
            </div>

            {/* Filtros */}
            <Card className="bg-futuristic-surface border-futuristic-primary/10">
              <CardHeader>
                <CardTitle className="text-futuristic-text-primary flex items-center gap-2">
                  <Filter className="h-5 w-5" />
                  Filtros de Supervisión
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-6 gap-4">
                  <div className="relative">
                    <Search className="absolute left-2 top-2.5 h-4 w-4 text-futuristic-text-secondary" />
                    <Input
                      placeholder="Buscar..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-8 bg-futuristic-background/30 border-futuristic-primary/20"
                    />
                  </div>

                  <Select value={filterCourse} onValueChange={setFilterCourse}>
                    <SelectTrigger className="bg-futuristic-background/30 border-futuristic-primary/20">
                      <SelectValue placeholder="Curso" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos los cursos</SelectItem>
                      <SelectItem value="1° A Primaria">1° A Primaria</SelectItem>
                      <SelectItem value="2° B Primaria">2° B Primaria</SelectItem>
                      <SelectItem value="3° A Primaria">3° A Primaria</SelectItem>
                      <SelectItem value="4° A Primaria">4° A Primaria</SelectItem>
                    </SelectContent>
                  </Select>

                  <Select value={filterSubject} onValueChange={setFilterSubject}>
                    <SelectTrigger className="bg-futuristic-background/30 border-futuristic-primary/20">
                      <SelectValue placeholder="Materia" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todas las materias</SelectItem>
                      <SelectItem value="Matemáticas">Matemáticas</SelectItem>
                      <SelectItem value="Lenguaje">Lenguaje</SelectItem>
                      <SelectItem value="Ciencias">Ciencias</SelectItem>
                      <SelectItem value="Historia">Historia</SelectItem>
                    </SelectContent>
                  </Select>

                  <Select value={filterStatus} onValueChange={setFilterStatus}>
                    <SelectTrigger className="bg-futuristic-background/30 border-futuristic-primary/20">
                      <SelectValue placeholder="Estado" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos los estados</SelectItem>
                      <SelectItem value="completo">Completo</SelectItem>
                      <SelectItem value="pendiente">Pendiente</SelectItem>
                      <SelectItem value="validación">Pendiente Validación</SelectItem>
                      <SelectItem value="revisión">En Revisión</SelectItem>
                    </SelectContent>
                  </Select>

                  <Select value={filterPeriod} onValueChange={setFilterPeriod}>
                    <SelectTrigger className="bg-futuristic-background/30 border-futuristic-primary/20">
                      <SelectValue placeholder="Período" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos los períodos</SelectItem>
                      <SelectItem value="P1">P1</SelectItem>
                      <SelectItem value="P2">P2</SelectItem>
                      <SelectItem value="P3">P3</SelectItem>
                      <SelectItem value="P4">P4</SelectItem>
                    </SelectContent>
                  </Select>

                  <Button
                    variant="outline"
                    className="border-futuristic-primary/30 text-futuristic-primary hover:bg-futuristic-primary/10 bg-transparent"
                  >
                    Limpiar Filtros
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Tabla de Evaluaciones */}
            <Card className="bg-futuristic-surface border-futuristic-primary/10">
              <CardHeader>
                <CardTitle className="text-futuristic-text-primary">Calificaciones por Curso y Materia</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-futuristic-primary/20">
                        <th className="text-left p-4 text-futuristic-text-secondary font-medium">Curso</th>
                        <th className="text-left p-4 text-futuristic-text-secondary font-medium">Materia</th>
                        <th className="text-left p-4 text-futuristic-text-secondary font-medium">Profesor</th>
                        <th className="text-left p-4 text-futuristic-text-secondary font-medium">Estudiantes</th>
                        <th className="text-left p-4 text-futuristic-text-secondary font-medium">Progreso</th>
                        <th className="text-left p-4 text-futuristic-text-secondary font-medium">Promedio</th>
                        <th className="text-left p-4 text-futuristic-text-secondary font-medium">Estado</th>
                        <th className="text-right p-4 text-futuristic-text-secondary font-medium">Acciones</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredEvaluations.map((evaluation) => (
                        <tr
                          key={evaluation.id}
                          className="border-b border-futuristic-primary/10 hover:bg-futuristic-primary/5"
                        >
                          <td className="p-4 text-futuristic-text-primary font-medium">{evaluation.course}</td>
                          <td className="p-4 text-futuristic-text-secondary">{evaluation.subject}</td>
                          <td className="p-4 text-futuristic-text-secondary">{evaluation.teacher}</td>
                          <td className="p-4 text-futuristic-text-secondary">{evaluation.students}</td>
                          <td className="p-4">
                            <div className="flex items-center gap-2">
                              <div className="w-20 bg-futuristic-background/50 rounded-full h-2">
                                <div
                                  className={`h-2 rounded-full ${
                                    evaluation.progress === 100
                                      ? "bg-futuristic-success"
                                      : evaluation.progress > 60
                                        ? "bg-futuristic-warning"
                                        : "bg-futuristic-error"
                                  }`}
                                  style={{ width: `${evaluation.progress}%` }}
                                ></div>
                              </div>
                              <span className="text-sm text-futuristic-text-secondary">{evaluation.progress}%</span>
                            </div>
                          </td>
                          <td className="p-4 text-futuristic-text-primary font-medium">{evaluation.average}</td>
                          <td className="p-4">
                            <Badge className={getStatusColor(evaluation.status)}>{evaluation.status}</Badge>
                          </td>
                          <td className="p-4 text-right">
                            <div className="flex justify-end gap-2">
                              <Button
                                size="sm"
                                variant="ghost"
                                className="h-8 w-8 p-0"
                                onClick={() => {
                                  setSelectedEvaluation(evaluation)
                                  setDetailModalOpen(true)
                                }}
                              >
                                <Eye className="h-4 w-4 text-futuristic-info" />
                              </Button>
                              {evaluation.status === "Completo" && (
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  className="h-8 w-8 p-0"
                                  onClick={() => {
                                    setSelectedEvaluation(evaluation)
                                    setApprovalModalOpen(true)
                                  }}
                                >
                                  <CheckCircle className="h-4 w-4 text-futuristic-success" />
                                </Button>
                              )}
                              <Button
                                size="sm"
                                variant="ghost"
                                className="h-8 w-8 p-0"
                                onClick={() => {
                                  setSelectedEvaluation(evaluation)
                                  setAdjustmentModalOpen(true)
                                }}
                              >
                                <MessageSquare className="h-4 w-4 text-futuristic-warning" />
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Aprobación de Boletines */}
          <TabsContent value="approval" className="space-y-6">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-2xl font-bold text-futuristic-text-primary">Aprobación de Boletines</h2>
                <p className="text-futuristic-text-secondary">Revisa y aprueba boletines académicos</p>
              </div>
              <div className="flex gap-2">
                <Button className="bg-gradient-to-r from-futuristic-success to-futuristic-success-light hover:from-futuristic-success-light hover:to-futuristic-success">
                  <CheckCircle className="mr-2 h-4 w-4" />
                  Aprobar Todo
                </Button>
                <Button
                  variant="outline"
                  className="border-futuristic-primary/30 text-futuristic-primary hover:bg-futuristic-primary/10 bg-transparent"
                >
                  <Download className="mr-2 h-4 w-4" />
                  Exportar
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Boletines Pendientes */}
              <Card className="lg:col-span-2 bg-futuristic-surface border-futuristic-primary/10">
                <CardHeader>
                  <CardTitle className="text-futuristic-text-primary">Boletines Pendientes de Aprobación</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {bulletinsData
                      .filter((bulletin) => bulletin.status === "Pendiente")
                      .map((bulletin, index) => (
                        <div
                          key={index}
                          className="flex items-center justify-between p-4 bg-futuristic-background/30 rounded-lg hover:bg-futuristic-background/50 transition-all"
                        >
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <p className="font-medium text-futuristic-text-primary">{bulletin.course}</p>
                              <Badge className="bg-futuristic-warning/20 text-futuristic-warning border-futuristic-warning/30 text-xs">
                                {bulletin.status}
                              </Badge>
                            </div>
                            <p className="text-sm text-futuristic-text-secondary">
                              Período: {bulletin.period} • Generado: {bulletin.generatedDate}
                            </p>
                            <p className="text-sm text-futuristic-text-secondary">Estudiantes: {bulletin.students}</p>
                          </div>
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              className="border-futuristic-info/30 text-futuristic-info hover:bg-futuristic-info/10 bg-transparent"
                            >
                              <Eye className="h-4 w-4 mr-1" />
                              Revisar
                            </Button>
                            <Button
                              size="sm"
                              className="bg-gradient-to-r from-futuristic-success to-futuristic-success-light hover:from-futuristic-success-light hover:to-futuristic-success"
                            >
                              <CheckCircle className="h-4 w-4 mr-1" />
                              Aprobar
                            </Button>
                          </div>
                        </div>
                      ))}
                  </div>
                </CardContent>
              </Card>

              {/* Estadísticas de Aprobación */}
              <Card className="bg-futuristic-surface border-futuristic-primary/10">
                <CardHeader>
                  <CardTitle className="text-futuristic-text-primary">Estado de Aprobaciones</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="text-center">
                    <div className="text-4xl font-bold text-futuristic-text-primary mb-2">
                      {bulletinsData.filter((b) => b.status === "Pendiente").length}
                    </div>
                    <p className="text-sm text-futuristic-text-secondary">Boletines pendientes</p>
                  </div>

                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-futuristic-text-secondary">Aprobados:</span>
                      <span className="font-medium text-futuristic-success">
                        {bulletinsData.filter((b) => b.status === "Aprobado").length}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-futuristic-text-secondary">Pendientes:</span>
                      <span className="font-medium text-futuristic-warning">
                        {bulletinsData.filter((b) => b.status === "Pendiente").length}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-futuristic-text-secondary">En Revisión:</span>
                      <span className="font-medium text-futuristic-error">
                        {bulletinsData.filter((b) => b.status === "Revisión").length}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-futuristic-text-secondary">Total:</span>
                      <span className="font-medium text-futuristic-text-primary">{bulletinsData.length}</span>
                    </div>
                  </div>

                  <div className="w-full bg-futuristic-background/50 rounded-full h-3">
                    <div
                      className="h-3 rounded-full bg-gradient-to-r from-futuristic-success to-futuristic-success-light"
                      style={{
                        width: `${
                          (bulletinsData.filter((b) => b.status === "Aprobado").length / bulletinsData.length) * 100
                        }%`,
                      }}
                    ></div>
                  </div>
                  <p className="text-xs text-center text-futuristic-text-secondary">
                    {Math.round(
                      (bulletinsData.filter((b) => b.status === "Aprobado").length / bulletinsData.length) * 100,
                    )}
                    % completado
                  </p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Boletines */}
          <TabsContent value="bulletins" className="space-y-6">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-2xl font-bold text-futuristic-text-primary">Gestión de Boletines</h2>
                <p className="text-futuristic-text-secondary">Vista histórica y generación de boletines</p>
              </div>
              <Button className="bg-gradient-to-r from-futuristic-primary to-futuristic-primary-light hover:from-futuristic-primary-light hover:to-futuristic-primary">
                <FileText className="mr-2 h-4 w-4" />
                Emitir Boletín Masivo
              </Button>
            </div>

            <Card className="bg-futuristic-surface border-futuristic-primary/10">
              <CardHeader>
                <CardTitle className="text-futuristic-text-primary">Boletines Generados</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {bulletinsData.map((bulletin, index) => (
                    <div
                      key={index}
                      className="flex items-center justify-between p-4 bg-futuristic-background/30 rounded-lg hover:bg-futuristic-background/50 transition-all"
                    >
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <p className="font-medium text-futuristic-text-primary">{bulletin.course}</p>
                          <Badge
                            className={`text-xs ${
                              bulletin.status === "Aprobado"
                                ? "bg-futuristic-success/20 text-futuristic-success border-futuristic-success/30"
                                : bulletin.status === "Pendiente"
                                  ? "bg-futuristic-warning/20 text-futuristic-warning border-futuristic-warning/30"
                                  : "bg-futuristic-error/20 text-futuristic-error border-futuristic-error/30"
                            }`}
                          >
                            {bulletin.status}
                          </Badge>
                        </div>
                        <p className="text-xs text-futuristic-text-secondary">
                          Período: {bulletin.period} • Generado: {bulletin.generatedDate}
                        </p>
                        <p className="text-xs text-futuristic-text-secondary">
                          Estudiantes: {bulletin.students} • Aprobado por: {bulletin.approvedBy || "Pendiente"}
                        </p>
                      </div>
                      <div className="flex gap-1">
                        <Button size="sm" variant="ghost" className="h-8 w-8 p-0">
                          <Eye className="h-4 w-4 text-futuristic-info" />
                        </Button>
                        <Button size="sm" variant="ghost" className="h-8 w-8 p-0">
                          <Download className="h-4 w-4 text-futuristic-primary" />
                        </Button>
                        <Button size="sm" variant="ghost" className="h-8 w-8 p-0">
                          <Send className="h-4 w-4 text-futuristic-success" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Distribución Académica */}
          <TabsContent value="analytics" className="space-y-6">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-2xl font-bold text-futuristic-text-primary">Distribución Académica</h2>
                <p className="text-futuristic-text-secondary">Analítica académica avanzada y alertas</p>
              </div>
              <Button
                variant="outline"
                className="border-futuristic-primary/30 text-futuristic-primary hover:bg-futuristic-primary/10 bg-transparent"
              >
                <Download className="mr-2 h-4 w-4" />
                Exportar Análisis
              </Button>
            </div>

            {/* Gráficos y Análisis */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-futuristic-surface border-futuristic-primary/10">
                <CardHeader>
                  <CardTitle className="text-futuristic-text-primary">Rendimiento por Curso</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {evaluationsData.map((evaluation, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="w-4 h-4 rounded bg-futuristic-primary"></div>
                          <span className="text-futuristic-text-secondary text-sm">{evaluation.course}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="w-20 bg-futuristic-background/50 rounded-full h-2">
                            <div
                              className="h-2 rounded-full bg-futuristic-primary"
                              style={{ width: `${(evaluation.average / 10) * 100}%` }}
                            ></div>
                          </div>
                          <span className="text-sm text-futuristic-text-primary w-8">{evaluation.average}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-futuristic-surface border-futuristic-primary/10">
                <CardHeader>
                  <CardTitle className="text-futuristic-text-primary">Alertas Académicas</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-start gap-3 p-3 bg-futuristic-error/10 rounded-lg">
                      <AlertTriangle className="h-5 w-5 text-futuristic-error mt-0.5" />
                      <div>
                        <p className="font-medium text-futuristic-text-primary">Rendimiento Crítico</p>
                        <p className="text-sm text-futuristic-text-secondary">
                          3 estudiantes con promedio menor a 6.5 en Matemáticas
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 p-3 bg-futuristic-warning/10 rounded-lg">
                      <Clock className="h-5 w-5 text-futuristic-warning mt-0.5" />
                      <div>
                        <p className="font-medium text-futuristic-text-primary">Evaluaciones Pendientes</p>
                        <p className="text-sm text-futuristic-text-secondary">
                          2 cursos con progreso menor al 75% en período actual
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 p-3 bg-futuristic-info/10 rounded-lg">
                      <Target className="h-5 w-5 text-futuristic-info mt-0.5" />
                      <div>
                        <p className="font-medium text-futuristic-text-primary">Competencias Incompletas</p>
                        <p className="text-sm text-futuristic-text-secondary">
                          Competencia Científica requiere configuración en 2° B
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Estadísticas Detalladas */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <Card className="bg-futuristic-surface border-futuristic-primary/10">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-futuristic-text-secondary text-sm font-medium">
                    Promedio Institucional
                  </CardTitle>
                  <Award className="h-5 w-5 text-futuristic-success" />
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-futuristic-text-primary">8.2</div>
                  <p className="text-xs text-futuristic-success mt-1">Excelente desempeño</p>
                </CardContent>
              </Card>

              <Card className="bg-futuristic-surface border-futuristic-primary/10">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-futuristic-text-secondary text-sm font-medium">
                    Tasa de Aprobación
                  </CardTitle>
                  <CheckCircle className="h-5 w-5 text-futuristic-info" />
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-futuristic-text-primary">94%</div>
                  <p className="text-xs text-futuristic-info mt-1">Por encima del promedio</p>
                </CardContent>
              </Card>

              <Card className="bg-futuristic-surface border-futuristic-primary/10">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-futuristic-text-secondary text-sm font-medium">
                    Estudiantes en Riesgo
                  </CardTitle>
                  <AlertTriangle className="h-5 w-5 text-futuristic-error" />
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-futuristic-text-primary">8</div>
                  <p className="text-xs text-futuristic-error mt-1">Requieren atención</p>
                </CardContent>
              </Card>

              <Card className="bg-futuristic-surface border-futuristic-primary/10">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-futuristic-text-secondary text-sm font-medium">
                    Competencias Completas
                  </CardTitle>
                  <BookOpen className="h-5 w-5 text-futuristic-primary" />
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-futuristic-text-primary">89%</div>
                  <p className="text-xs text-futuristic-primary mt-1">En progreso</p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        {/* Modal de Detalle de Evaluación */}
        <Dialog open={detailModalOpen} onOpenChange={setDetailModalOpen}>
          <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-futuristic-text-primary">
                Detalle de Evaluación - {selectedEvaluation?.subject}
              </DialogTitle>
              <DialogDescription>
                {selectedEvaluation?.course} • Profesor: {selectedEvaluation?.teacher}
              </DialogDescription>
            </DialogHeader>
            {selectedEvaluation && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div className="bg-futuristic-background/30 p-4 rounded-lg">
                    <div className="text-sm text-futuristic-text-secondary">Estudiantes</div>
                    <div className="text-2xl font-bold text-futuristic-text-primary">{selectedEvaluation.students}</div>
                  </div>
                  <div className="bg-futuristic-background/30 p-4 rounded-lg">
                    <div className="text-sm text-futuristic-text-secondary">Progreso</div>
                    <div className="text-2xl font-bold text-futuristic-text-primary">
                      {selectedEvaluation.progress}%
                    </div>
                  </div>
                  <div className="bg-futuristic-background/30 p-4 rounded-lg">
                    <div className="text-sm text-futuristic-text-secondary">Promedio</div>
                    <div className="text-2xl font-bold text-futuristic-text-primary">{selectedEvaluation.average}</div>
                  </div>
                  <div className="bg-futuristic-background/30 p-4 rounded-lg">
                    <div className="text-sm text-futuristic-text-secondary">Competencias</div>
                    <div className="text-2xl font-bold text-futuristic-text-primary">
                      {selectedEvaluation.competenciasCompletas}/{selectedEvaluation.totalCompetencias}
                    </div>
                  </div>
                </div>

                <div className="flex justify-end gap-2">
                  <Button
                    variant="outline"
                    className="border-futuristic-primary/30 text-futuristic-primary hover:bg-futuristic-primary/10 bg-transparent"
                  >
                    <Download className="mr-2 h-4 w-4" />
                    Descargar Reporte
                  </Button>
                  <Button
                    onClick={() => router.push(`/dashboard/director/evaluations/${selectedEvaluation.id}`)}
                    className="bg-gradient-to-r from-futuristic-info to-futuristic-info-light hover:from-futuristic-info-light hover:to-futuristic-info"
                  >
                    <Eye className="mr-2 h-4 w-4" />
                    Ver Detalles Completos
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>

        {/* Modal de Aprobación */}
        <Dialog open={approvalModalOpen} onOpenChange={setApprovalModalOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle className="text-futuristic-text-primary">Aprobar Evaluación</DialogTitle>
              <DialogDescription>
                Confirme la aprobación de las calificaciones para {selectedEvaluation?.subject} -{" "}
                {selectedEvaluation?.course}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="bg-futuristic-success/10 p-4 rounded-lg">
                <h4 className="font-medium mb-2 text-futuristic-text-primary">Verificaciones:</h4>
                <ul className="space-y-1 text-sm">
                  <li className="flex items-center text-futuristic-success">
                    <CheckCircle className="h-4 w-4 mr-2" />
                    Progreso completo (100%)
                  </li>
                  <li className="flex items-center text-futuristic-success">
                    <CheckCircle className="h-4 w-4 mr-2" />
                    Todas las competencias configuradas
                  </li>
                  <li className="flex items-center text-futuristic-success">
                    <CheckCircle className="h-4 w-4 mr-2" />
                    Todos los estudiantes calificados
                  </li>
                </ul>
              </div>
              <div className="flex justify-end gap-2">
                <Button
                  variant="outline"
                  onClick={() => setApprovalModalOpen(false)}
                  className="border-futuristic-primary/30 text-futuristic-primary hover:bg-futuristic-primary/10"
                >
                  Cancelar
                </Button>
                <Button
                  onClick={() => handleApproveEvaluation(selectedEvaluation)}
                  className="bg-gradient-to-r from-futuristic-success to-futuristic-success-light hover:from-futuristic-success-light hover:to-futuristic-success"
                >
                  <CheckCircle className="mr-2 h-4 w-4" />
                  Aprobar Evaluación
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Modal de Solicitud de Ajuste */}
        <Dialog open={adjustmentModalOpen} onOpenChange={setAdjustmentModalOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle className="text-futuristic-text-primary">Solicitar Ajuste</DialogTitle>
              <DialogDescription>
                Envíe comentarios al Coordinador Académico y Profesor sobre los ajustes necesarios
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-futuristic-text-secondary">Comentarios para el ajuste</label>
                <Textarea
                  placeholder="Describa los ajustes necesarios en las calificaciones..."
                  value={adjustmentComment}
                  onChange={(e) => setAdjustmentComment(e.target.value)}
                  className="bg-futuristic-background/30 border-futuristic-primary/20 text-futuristic-text-primary min-h-[100px]"
                />
              </div>
              <div className="flex justify-end gap-2">
                <Button
                  variant="outline"
                  onClick={() => setAdjustmentModalOpen(false)}
                  className="border-futuristic-primary/30 text-futuristic-primary hover:bg-futuristic-primary/10"
                >
                  Cancelar
                </Button>
                <Button
                  onClick={handleRequestAdjustment}
                  className="bg-gradient-to-r from-futuristic-warning to-futuristic-warning-light hover:from-futuristic-warning-light hover:to-futuristic-warning"
                >
                  <MessageSquare className="mr-2 h-4 w-4" />
                  Enviar Solicitud
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </main>
    </div>
  )
}
