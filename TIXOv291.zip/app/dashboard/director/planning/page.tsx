"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Calendar, CheckCircle, XCircle, Clock, Edit, Eye, Filter, Search, Download, BookOpen } from "lucide-react"

export default function PlanningPage() {
  const [selectedTab, setSelectedTab] = useState("calendar")
  const [viewMode, setViewMode] = useState("week")
  const [selectedTask, setSelectedTask] = useState<any>(null)
  const [selectedCourse, setSelectedCourse] = useState("all")

  // Planificaciones creadas por profesores organizadas por curso
  const teacherPlannings = {
    "1A": [
      {
        id: 1,
        title: "Examen de Matemáticas - Suma y Resta",
        teacher: "Prof. María González",
        subject: "Matemáticas",
        date: "2024-01-22",
        type: "Examen",
        status: "Pendiente",
        description: "Examen del primer trimestre sobre suma y resta básica",
        objectives: "Evaluar comprensión de operaciones básicas",
        materials: "Calculadora, lápiz, borrador",
        duration: "45 minutos",
      },
      {
        id: 2,
        title: "Lectura Comprensiva - Cuentos Infantiles",
        teacher: "Prof. María González",
        subject: "Lenguaje",
        date: "2024-01-24",
        type: "Actividad",
        status: "Aprobado",
        description: "Actividad de lectura y comprensión de cuentos",
        objectives: "Mejorar comprensión lectora",
        materials: "Libros de cuentos, cuaderno",
        duration: "30 minutos",
      },
    ],
    "2A": [
      {
        id: 3,
        title: "Proyecto de Ciencias - El Agua",
        teacher: "Prof. Ana Martínez",
        subject: "Ciencias",
        date: "2024-01-25",
        type: "Proyecto",
        status: "Aprobado",
        description: "Proyecto sobre los estados del agua",
        objectives: "Comprender los estados de la materia",
        materials: "Agua, recipientes, termómetro",
        duration: "2 horas",
      },
    ],
    "3A": [
      {
        id: 4,
        title: "Ensayo de Historia - Independencia",
        teacher: "Prof. Carlos López",
        subject: "Historia",
        date: "2024-01-26",
        type: "Tarea",
        status: "Rechazado",
        description: "Ensayo sobre la independencia nacional",
        objectives: "Analizar eventos históricos importantes",
        materials: "Libros de historia, computadora",
        duration: "1 semana",
      },
    ],
  }

  const handleTaskAction = (taskId: number, action: string, comment?: string) => {
    console.log(`Task ${taskId} ${action}`, comment)
    // Aquí iría la lógica para aprobar/rechazar/sugerir cambios
  }

  const getFilteredPlannings = () => {
    if (selectedCourse === "all") {
      return Object.entries(teacherPlannings).flatMap(([course, plannings]) =>
        plannings.map((planning) => ({ ...planning, course })),
      )
    }
    return teacherPlannings[selectedCourse]?.map((planning) => ({ ...planning, course: selectedCourse })) || []
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Planificación Escolar</h1>
          <p className="text-gray-600 mt-2">Supervisa las planificaciones académicas creadas por los docentes</p>
        </div>
        <div className="flex items-center space-x-4">
          <Select value={selectedCourse} onValueChange={setSelectedCourse}>
            <SelectTrigger className="w-40 bg-white border-gray-300">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos los Cursos</SelectItem>
              <SelectItem value="1A">1° A Primaria</SelectItem>
              <SelectItem value="2A">2° A Primaria</SelectItem>
              <SelectItem value="3A">3° A Primaria</SelectItem>
            </SelectContent>
          </Select>
          <Button className="bg-green-600 hover:bg-green-700 text-white">
            <Download className="w-4 h-4 mr-2" />
            Exportar
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="bg-white border-0 shadow-sm">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Planificaciones Creadas</p>
                <p className="text-2xl font-bold text-indigo-600">{getFilteredPlannings().length}</p>
              </div>
              <div className="p-3 bg-indigo-100 rounded-lg">
                <BookOpen className="h-6 w-6 text-indigo-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white border-0 shadow-sm">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Aprobadas</p>
                <p className="text-2xl font-bold text-green-600">
                  {getFilteredPlannings().filter((p) => p.status === "Aprobado").length}
                </p>
              </div>
              <div className="p-3 bg-green-100 rounded-lg">
                <CheckCircle className="h-6 w-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white border-0 shadow-sm">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Pendientes</p>
                <p className="text-2xl font-bold text-yellow-600">
                  {getFilteredPlannings().filter((p) => p.status === "Pendiente").length}
                </p>
              </div>
              <div className="p-3 bg-yellow-100 rounded-lg">
                <Clock className="h-6 w-6 text-yellow-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white border-0 shadow-sm">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Rechazadas</p>
                <p className="text-2xl font-bold text-red-600">
                  {getFilteredPlannings().filter((p) => p.status === "Rechazado").length}
                </p>
              </div>
              <div className="p-3 bg-red-100 rounded-lg">
                <XCircle className="h-6 w-6 text-red-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs value={selectedTab} onValueChange={setSelectedTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-2 bg-white border border-gray-200">
          <TabsTrigger value="calendar" className="data-[state=active]:bg-indigo-600 data-[state=active]:text-white">
            <Calendar className="w-4 h-4 mr-2" />
            Planificaciones por Curso
          </TabsTrigger>
          <TabsTrigger value="approval" className="data-[state=active]:bg-indigo-600 data-[state=active]:text-white">
            <CheckCircle className="w-4 h-4 mr-2" />
            Gestión de Aprobaciones
          </TabsTrigger>
        </TabsList>

        {/* Planificaciones por Curso */}
        <TabsContent value="calendar" className="space-y-6">
          <Card className="bg-white border-0 shadow-sm">
            <CardHeader className="border-b border-gray-100">
              <CardTitle className="text-indigo-700">Planificaciones por Curso</CardTitle>
              <CardDescription className="text-gray-600">
                Revisa las planificaciones creadas por los profesores organizadas por curso
              </CardDescription>
            </CardHeader>
            <CardContent className="p-6 space-y-6">
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-gray-900">
                  {selectedCourse === "all"
                    ? "Todas las Planificaciones"
                    : `Planificaciones - ${selectedCourse} Primaria`}
                </h3>
                <div className="grid gap-4">
                  {getFilteredPlannings().map((planning) => (
                    <Card key={planning.id} className="bg-white border border-gray-200">
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-4">
                            <div
                              className={`w-3 h-3 rounded-full ${
                                planning.status === "Aprobado"
                                  ? "bg-green-600"
                                  : planning.status === "Rechazado"
                                    ? "bg-red-600"
                                    : "bg-yellow-600"
                              }`}
                            />
                            <div>
                              <h4 className="font-medium text-gray-900">{planning.title}</h4>
                              <p className="text-sm text-gray-600">
                                {planning.course} Primaria • {planning.subject} • {planning.teacher}
                              </p>
                              <p className="text-xs text-gray-500">
                                Fecha programada: {planning.date} • Duración: {planning.duration}
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center space-x-4">
                            <Badge variant="outline" className="border-indigo-300 text-indigo-700 bg-indigo-50">
                              {planning.type}
                            </Badge>
                            <Badge
                              variant="outline"
                              className={
                                planning.status === "Aprobado"
                                  ? "border-green-300 text-green-700 bg-green-50"
                                  : planning.status === "Rechazado"
                                    ? "border-red-300 text-red-700 bg-red-50"
                                    : "border-yellow-300 text-yellow-700 bg-yellow-50"
                              }
                            >
                              {planning.status}
                            </Badge>
                            <Dialog>
                              <DialogTrigger asChild>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="border-gray-300 text-gray-700"
                                  onClick={() => setSelectedTask(planning)}
                                >
                                  <Eye className="w-4 h-4 mr-1" />
                                  Ver Detalles
                                </Button>
                              </DialogTrigger>
                              <DialogContent className="max-w-2xl">
                                <DialogHeader>
                                  <DialogTitle className="text-indigo-700">{planning.title}</DialogTitle>
                                  <DialogDescription className="text-gray-600">
                                    Detalles de la planificación académica
                                  </DialogDescription>
                                </DialogHeader>
                                <div className="space-y-4">
                                  <div className="grid grid-cols-2 gap-4">
                                    <div>
                                      <Label className="text-gray-700">Profesor</Label>
                                      <p className="text-gray-900">{planning.teacher}</p>
                                    </div>
                                    <div>
                                      <Label className="text-gray-700">Materia</Label>
                                      <p className="text-gray-900">{planning.subject}</p>
                                    </div>
                                    <div>
                                      <Label className="text-gray-700">Fecha</Label>
                                      <p className="text-gray-900">{planning.date}</p>
                                    </div>
                                    <div>
                                      <Label className="text-gray-700">Duración</Label>
                                      <p className="text-gray-900">{planning.duration}</p>
                                    </div>
                                  </div>
                                  <div>
                                    <Label className="text-gray-700">Descripción</Label>
                                    <p className="text-gray-900">{planning.description}</p>
                                  </div>
                                  <div>
                                    <Label className="text-gray-700">Objetivos</Label>
                                    <p className="text-gray-900">{planning.objectives}</p>
                                  </div>
                                  <div>
                                    <Label className="text-gray-700">Materiales Necesarios</Label>
                                    <p className="text-gray-900">{planning.materials}</p>
                                  </div>
                                  {planning.status === "Pendiente" && (
                                    <div className="flex space-x-2 pt-4 border-t border-gray-200">
                                      <Button
                                        className="bg-green-600 hover:bg-green-700 text-white"
                                        onClick={() => handleTaskAction(planning.id, "approve")}
                                      >
                                        <CheckCircle className="w-4 h-4 mr-2" />
                                        Aprobar
                                      </Button>
                                      <Button
                                        variant="outline"
                                        className="border-red-300 text-red-700 hover:bg-red-50"
                                        onClick={() => handleTaskAction(planning.id, "reject")}
                                      >
                                        <XCircle className="w-4 h-4 mr-2" />
                                        Rechazar
                                      </Button>
                                      <Button
                                        variant="outline"
                                        className="border-yellow-300 text-yellow-700 hover:bg-yellow-50"
                                        onClick={() => handleTaskAction(planning.id, "suggest")}
                                      >
                                        <Edit className="w-4 h-4 mr-2" />
                                        Sugerir Cambios
                                      </Button>
                                    </div>
                                  )}
                                </div>
                              </DialogContent>
                            </Dialog>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Gestión de Aprobaciones */}
        <TabsContent value="approval" className="space-y-6">
          <Card className="bg-white border-0 shadow-sm">
            <CardHeader className="border-b border-gray-100">
              <CardTitle className="text-blue-700">Gestión de Aprobaciones</CardTitle>
              <CardDescription className="text-gray-600">
                Aprueba, rechaza o sugiere cambios en las planificaciones de los profesores
              </CardDescription>
            </CardHeader>
            <CardContent className="p-6">
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <div className="flex space-x-4">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                      <Input placeholder="Buscar planificaciones..." className="pl-10 bg-white border-gray-300" />
                    </div>
                    <Button variant="outline" className="border-gray-300 text-gray-700">
                      <Filter className="w-4 h-4 mr-2" />
                      Filtros
                    </Button>
                  </div>
                  <div className="flex space-x-2">
                    <Button className="bg-green-600 hover:bg-green-700 text-white">
                      <CheckCircle className="w-4 h-4 mr-2" />
                      Aprobar Seleccionadas
                    </Button>
                  </div>
                </div>

                <Table>
                  <TableHeader>
                    <TableRow className="border-gray-200">
                      <TableHead className="text-gray-700">Título</TableHead>
                      <TableHead className="text-gray-700">Profesor</TableHead>
                      <TableHead className="text-gray-700">Curso</TableHead>
                      <TableHead className="text-gray-700">Materia</TableHead>
                      <TableHead className="text-gray-700">Fecha</TableHead>
                      <TableHead className="text-gray-700">Estado</TableHead>
                      <TableHead className="text-gray-700">Acciones</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {getFilteredPlannings().map((planning) => (
                      <TableRow key={planning.id} className="border-gray-100">
                        <TableCell className="font-medium text-gray-900">{planning.title}</TableCell>
                        <TableCell className="text-gray-600">{planning.teacher}</TableCell>
                        <TableCell className="text-gray-600">{planning.course} Primaria</TableCell>
                        <TableCell className="text-gray-600">{planning.subject}</TableCell>
                        <TableCell className="text-gray-600">{planning.date}</TableCell>
                        <TableCell>
                          <Badge
                            variant="outline"
                            className={
                              planning.status === "Aprobado"
                                ? "border-green-300 text-green-700 bg-green-50"
                                : planning.status === "Rechazado"
                                  ? "border-red-300 text-red-700 bg-red-50"
                                  : "border-yellow-300 text-yellow-700 bg-yellow-50"
                            }
                          >
                            {planning.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex space-x-1">
                            <Button size="sm" variant="outline" className="border-gray-300 text-gray-700">
                              <Eye className="w-4 h-4" />
                            </Button>
                            {planning.status === "Pendiente" && (
                              <>
                                <Button
                                  size="sm"
                                  className="bg-green-600 hover:bg-green-700 text-white"
                                  onClick={() => handleTaskAction(planning.id, "approve")}
                                >
                                  <CheckCircle className="w-4 h-4" />
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="border-red-300 text-red-700 hover:bg-red-50"
                                  onClick={() => handleTaskAction(planning.id, "reject")}
                                >
                                  <XCircle className="w-4 h-4" />
                                </Button>
                              </>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
