"use client"

import { useState } from "react"
import { Header } from "@/components/dashboard/header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Users, UserPlus, Search, Filter, Eye, Edit, RotateCcw, UserX, GraduationCap, BookOpen, Calculator, FileText, Mail, Phone, Shield, Settings, CheckCircle } from 'lucide-react'

// Datos simulados de personal
const personalData = [
  {
    id: 1,
    name: "Ana María González",
    role: "Coordinador Académico",
    email: "ana.gonzalez@colegio.edu.do",
    phone: "(809) 555-0123",
    cedula: "001-1234567-8",
    status: "Activo",
    createdDate: "2024-01-15",
    lastLogin: "2024-06-20 09:30",
    assignedCourses: 8,
    avatar: "/placeholder.svg?height=40&width=40",
  },
  {
    id: 2,
    name: "Carlos Eduardo Pérez",
    role: "Profesor",
    email: "carlos.perez@colegio.edu.do",
    phone: "(809) 555-0124",
    cedula: "001-2345678-9",
    status: "Activo",
    createdDate: "2024-02-10",
    lastLogin: "2024-06-20 08:15",
    assignedCourses: 3,
    avatar: "/placeholder.svg?height=40&width=40",
  },
  {
    id: 3,
    name: "María José Rodríguez",
    role: "Coordinador de Registro",
    email: "maria.rodriguez@colegio.edu.do",
    phone: "(809) 555-0125",
    cedula: "001-3456789-0",
    status: "Activo",
    createdDate: "2024-01-20",
    lastLogin: "2024-06-19 16:45",
    assignedCourses: 0,
    avatar: "/placeholder.svg?height=40&width=40",
  },
  {
    id: 4,
    name: "Roberto Sánchez",
    role: "Contable",
    email: "roberto.sanchez@colegio.edu.do",
    phone: "(809) 555-0126",
    cedula: "001-4567890-1",
    status: "Inactivo",
    createdDate: "2024-03-05",
    lastLogin: "2024-06-15 14:20",
    assignedCourses: 0,
    avatar: "/placeholder.svg?height=40&width=40",
  },
]

export default function UsersManagement() {
  const [searchTerm, setSearchTerm] = useState("")
  const [filterRole, setFilterRole] = useState("all")
  const [filterStatus, setFilterStatus] = useState("all")
  const [newUserModalOpen, setNewUserModalOpen] = useState(false)
  const [selectedUser, setSelectedUser] = useState(null)
  const [userDetailModalOpen, setUserDetailModalOpen] = useState(false)
  const [advancedConfigOpen, setAdvancedConfigOpen] = useState(false)
  const [editUserModalOpen, setEditUserModalOpen] = useState(false)
  const [editingUser, setEditingUser] = useState(null)

  // Estado del formulario de nuevo usuario
  const [newUserForm, setNewUserForm] = useState({
    role: "",
    firstName: "",
    lastName: "",
    cedula: "",
    email: "",
    phone: "",
    gender: "",
    birthDate: "",
    address: "",
    username: "",
    tempPassword: "",
    status: "Activo",
    educationalCenter: "",
    sendCredentials: true,
  })

  // Filtrar personal
  const filteredPersonal = personalData.filter((person) => {
    const matchesSearch =
      person.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      person.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      person.role.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesRole = filterRole === "all" || person.role === filterRole
    const matchesStatus = filterStatus === "all" || person.status === filterStatus

    return matchesSearch && matchesRole && matchesStatus
  })

  // Estadísticas
  const stats = {
    totalPersonal: personalData.length,
    activeUsers: personalData.filter((p) => p.status === "Activo").length,
    professors: personalData.filter((p) => p.role === "Profesor").length,
    coordinators: personalData.filter((p) => p.role.includes("Coordinador")).length,
  }

  // Función para obtener el icono del rol
  const getRoleIcon = (role) => {
    switch (role) {
      case "Coordinador Académico":
        return <GraduationCap className="h-4 w-4" />
      case "Coordinador de Registro":
        return <FileText className="h-4 w-4" />
      case "Profesor":
        return <BookOpen className="h-4 w-4" />
      case "Contable":
        return <Calculator className="h-4 w-4" />
      default:
        return <Users className="h-4 w-4" />
    }
  }

  // Función para obtener el color del estado
  const getStatusColor = (status) => {
    return status === "Activo"
      ? "bg-futuristic-success/20 text-futuristic-success border-futuristic-success/30"
      : "bg-futuristic-error/20 text-futuristic-error border-futuristic-error/30"
  }

  // Función para manejar el envío del formulario
  const handleCreateUser = () => {
    if (!newUserForm.role || !newUserForm.firstName || !newUserForm.lastName || !newUserForm.email) {
      alert("Por favor complete todos los campos obligatorios")
      return
    }

    // Simular creación de usuario
    const newUser = {
      id: personalData.length + 1,
      name: `${newUserForm.firstName} ${newUserForm.lastName}`,
      role: newUserForm.role,
      email: newUserForm.email,
      phone: newUserForm.phone,
      cedula: newUserForm.cedula,
      status: newUserForm.status,
      createdDate: new Date().toISOString().split("T")[0],
      lastLogin: "Nunca",
      assignedCourses: 0,
      avatar: "/placeholder.svg?height=40&width=40",
    }

    // Aquí se enviaría la información al backend
    console.log("Nuevo usuario creado:", newUser)

    // Mostrar mensaje de éxito
    alert(`Usuario ${newUser.name} creado exitosamente con rol de ${newUser.role}`)

    // Limpiar formulario y cerrar modal
    setNewUserForm({
      role: "",
      firstName: "",
      lastName: "",
      cedula: "",
      email: "",
      phone: "",
      gender: "",
      birthDate: "",
      address: "",
      username: "",
      tempPassword: "",
      status: "Activo",
      educationalCenter: "",
      sendCredentials: true,
    })
    setNewUserModalOpen(false)
  }

  // Función para manejar la edición de usuario
  const handleEditUser = (user) => {
    setEditingUser(user)
    // Pre-populate form with user data
    setNewUserForm({
      role: user.role,
      firstName: user.name.split(' ')[0],
      lastName: user.name.split(' ').slice(1).join(' '),
      cedula: user.cedula,
      email: user.email,
      phone: user.phone,
      gender: "",
      birthDate: "",
      address: "",
      username: user.email,
      tempPassword: "",
      status: user.status,
      educationalCenter: "",
      sendCredentials: false,
    })
    setEditUserModalOpen(true)
  }

  // Función para actualizar usuario
  const handleUpdateUser = () => {
    if (!newUserForm.role || !newUserForm.firstName || !newUserForm.lastName || !newUserForm.email) {
      alert("Por favor complete todos los campos obligatorios")
      return
    }

    // Simular actualización de usuario
    console.log("Usuario actualizado:", {
      ...editingUser,
      name: `${newUserForm.firstName} ${newUserForm.lastName}`,
      role: newUserForm.role,
      email: newUserForm.email,
      phone: newUserForm.phone,
      cedula: newUserForm.cedula,
      status: newUserForm.status,
    })

    alert(`Usuario ${newUserForm.firstName} ${newUserForm.lastName} actualizado exitosamente`)

    // Limpiar formulario y cerrar modal
    setNewUserForm({
      role: "",
      firstName: "",
      lastName: "",
      cedula: "",
      email: "",
      phone: "",
      gender: "",
      birthDate: "",
      address: "",
      username: "",
      tempPassword: "",
      status: "Activo",
      educationalCenter: "",
      sendCredentials: true,
    })
    setEditingUser(null)
    setEditUserModalOpen(false)
  }

  // Función para generar usuario automático
  const generateUsername = () => {
    if (newUserForm.firstName && newUserForm.lastName) {
      const username = `${newUserForm.firstName.toLowerCase()}.${newUserForm.lastName.toLowerCase()}@colegio.edu.do`
      setNewUserForm((prev) => ({ ...prev, username, email: username }))
    }
  }

  // Función para generar contraseña temporal
  const generateTempPassword = () => {
    const password = Math.random().toString(36).slice(-8)
    setNewUserForm((prev) => ({ ...prev, tempPassword: password }))
  }

  return (
    <div className="flex-1 flex flex-col">
      <Header title="Gestión de Usuarios" />

      <main className="flex-1 overflow-y-auto p-6 bg-gradient-to-br from-futuristic-background via-futuristic-surface to-futuristic-background">
        <Tabs defaultValue="personal" className="space-y-6">
          <div className="bg-futuristic-surface/50 backdrop-blur-sm rounded-lg p-1 w-fit">
            <TabsList className="grid grid-cols-3 w-fit">
              <TabsTrigger value="personal" className="flex items-center gap-2">
                <Users className="h-4 w-4" />
                <span className="hidden md:inline">Personal</span>
              </TabsTrigger>
              <TabsTrigger value="students" className="flex items-center gap-2">
                <GraduationCap className="h-4 w-4" />
                <span className="hidden md:inline">Estudiantes</span>
              </TabsTrigger>
              <TabsTrigger value="parents" className="flex items-center gap-2">
                <Users className="h-4 w-4" />
                <span className="hidden md:inline">Padres</span>
              </TabsTrigger>
            </TabsList>
          </div>

          {/* Pestaña Personal */}
          <TabsContent value="personal" className="space-y-6">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-2xl font-bold text-futuristic-text-primary">Personal del Centro</h2>
                <p className="text-futuristic-text-secondary">Gestiona el personal administrativo y docente</p>
              </div>
              <Dialog open={newUserModalOpen} onOpenChange={setNewUserModalOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-gradient-to-r from-futuristic-primary to-futuristic-primary-light hover:from-futuristic-primary-light hover:to-futuristic-primary">
                    <UserPlus className="mr-2 h-4 w-4" />
                    Nuevo Personal
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle className="text-futuristic-text-primary">Crear Nuevo Personal</DialogTitle>
                    <DialogDescription>
                      Complete la información para crear un nuevo miembro del personal
                    </DialogDescription>
                  </DialogHeader>

                  <div className="space-y-6">
                    {/* Rol a asignar */}
                    <Card className="bg-futuristic-surface border-futuristic-primary/10">
                      <CardHeader>
                        <CardTitle className="text-lg text-futuristic-text-primary flex items-center gap-2">
                          <Shield className="h-5 w-5" />
                          Rol a Asignar
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <Select
                          value={newUserForm.role}
                          onValueChange={(value) => setNewUserForm((prev) => ({ ...prev, role: value }))}
                        >
                          <SelectTrigger className="bg-futuristic-background/30 border-futuristic-primary/20">
                            <SelectValue placeholder="Seleccionar rol" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Coordinador Académico">
                              <div className="flex items-center gap-2">
                                <GraduationCap className="h-4 w-4" />
                                Coordinador Académico
                              </div>
                            </SelectItem>
                            <SelectItem value="Coordinador de Registro">
                              <div className="flex items-center gap-2">
                                <FileText className="h-4 w-4" />
                                Coordinador de Registro y Control Académico
                              </div>
                            </SelectItem>
                            <SelectItem value="Profesor">
                              <div className="flex items-center gap-2">
                                <BookOpen className="h-4 w-4" />
                                Profesor
                              </div>
                            </SelectItem>
                            <SelectItem value="Contable">
                              <div className="flex items-center gap-2">
                                <Calculator className="h-4 w-4" />
                                Contable
                              </div>
                            </SelectItem>
                          </SelectContent>
                        </Select>

                        {newUserForm.role && (
                          <div className="mt-3 p-3 bg-futuristic-info/10 rounded-lg">
                            <p className="text-sm text-futuristic-text-secondary">
                              <strong>Permisos automáticos para {newUserForm.role}:</strong>
                            </p>
                            <ul className="text-xs text-futuristic-text-secondary mt-1 space-y-1">
                              {newUserForm.role === "Coordinador Académico" && (
                                <>
                                  <li>• Gestión de cursos y materias</li>
                                  <li>• Asignación de docentes</li>
                                  <li>• Creación de horarios</li>
                                  <li>• Monitoreo de calificaciones</li>
                                </>
                              )}
                              {newUserForm.role === "Coordinador de Registro" && (
                                <>
                                  <li>• Gestión de estudiantes</li>
                                  <li>• Inscripción y reinscripción</li>
                                  <li>• Gestión de padres</li>
                                  <li>• Fichas académicas</li>
                                </>
                              )}
                              {newUserForm.role === "Profesor" && (
                                <>
                                  <li>• Calificaciones de sus materias</li>
                                  <li>• Gestión de actividades</li>
                                  <li>• Comunicación con padres</li>
                                  <li>• Reportes académicos</li>
                                </>
                              )}
                              {newUserForm.role === "Contable" && (
                                <>
                                  <li>• Gestión financiera</li>
                                  <li>• Cuentas por cobrar</li>
                                  <li>• Reportes de pagos</li>
                                  <li>• Estados financieros</li>
                                </>
                              )}
                            </ul>
                          </div>
                        )}
                      </CardContent>
                    </Card>

                    {/* Datos generales */}
                    <Card className="bg-futuristic-surface border-futuristic-primary/10">
                      <CardHeader>
                        <CardTitle className="text-lg text-futuristic-text-primary">Datos Generales</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="firstName" className="text-futuristic-text-secondary">
                              Nombre(s) *
                            </Label>
                            <Input
                              id="firstName"
                              value={newUserForm.firstName}
                              onChange={(e) => setNewUserForm((prev) => ({ ...prev, firstName: e.target.value }))}
                              className="bg-futuristic-background/30 border-futuristic-primary/20"
                              placeholder="Ingrese el nombre"
                            />
                          </div>
                          <div>
                            <Label htmlFor="lastName" className="text-futuristic-text-secondary">
                              Apellido(s) *
                            </Label>
                            <Input
                              id="lastName"
                              value={newUserForm.lastName}
                              onChange={(e) => setNewUserForm((prev) => ({ ...prev, lastName: e.target.value }))}
                              className="bg-futuristic-background/30 border-futuristic-primary/20"
                              placeholder="Ingrese los apellidos"
                            />
                          </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="cedula" className="text-futuristic-text-secondary">
                              Cédula / ID Institucional *
                            </Label>
                            <Input
                              id="cedula"
                              value={newUserForm.cedula}
                              onChange={(e) => setNewUserForm((prev) => ({ ...prev, cedula: e.target.value }))}
                              className="bg-futuristic-background/30 border-futuristic-primary/20"
                              placeholder="001-1234567-8"
                            />
                          </div>
                          <div>
                            <Label htmlFor="phone" className="text-futuristic-text-secondary">
                              Teléfono de Contacto
                            </Label>
                            <Input
                              id="phone"
                              value={newUserForm.phone}
                              onChange={(e) => setNewUserForm((prev) => ({ ...prev, phone: e.target.value }))}
                              className="bg-futuristic-background/30 border-futuristic-primary/20"
                              placeholder="(809) 555-0123"
                            />
                          </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="gender" className="text-futuristic-text-secondary">
                              Sexo
                            </Label>
                            <Select
                              value={newUserForm.gender}
                              onValueChange={(value) => setNewUserForm((prev) => ({ ...prev, gender: value }))}
                            >
                              <SelectTrigger className="bg-futuristic-background/30 border-futuristic-primary/20">
                                <SelectValue placeholder="Seleccionar sexo" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="Masculino">Masculino</SelectItem>
                                <SelectItem value="Femenino">Femenino</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div>
                            <Label htmlFor="birthDate" className="text-futuristic-text-secondary">
                              Fecha de Nacimiento
                            </Label>
                            <Input
                              id="birthDate"
                              type="date"
                              value={newUserForm.birthDate}
                              onChange={(e) => setNewUserForm((prev) => ({ ...prev, birthDate: e.target.value }))}
                              className="bg-futuristic-background/30 border-futuristic-primary/20"
                            />
                          </div>
                        </div>

                        <div>
                          <Label htmlFor="address" className="text-futuristic-text-secondary">
                            Dirección
                          </Label>
                          <Textarea
                            id="address"
                            value={newUserForm.address}
                            onChange={(e) => setNewUserForm((prev) => ({ ...prev, address: e.target.value }))}
                            className="bg-futuristic-background/30 border-futuristic-primary/20"
                            placeholder="Ingrese la dirección completa"
                            rows={2}
                          />
                        </div>
                      </CardContent>
                    </Card>

                    {/* Configuración de cuenta */}
                    <Card className="bg-futuristic-surface border-futuristic-primary/10">
                      <CardHeader>
                        <CardTitle className="text-lg text-futuristic-text-primary">Configuración de Cuenta</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div>
                          <Label htmlFor="email" className="text-futuristic-text-secondary">
                            Correo Electrónico (Usuario) *
                          </Label>
                          <div className="flex gap-2">
                            <Input
                              id="email"
                              type="email"
                              value={newUserForm.email}
                              onChange={(e) => setNewUserForm((prev) => ({ ...prev, email: e.target.value }))}
                              className="bg-futuristic-background/30 border-futuristic-primary/20"
                              placeholder="usuario@colegio.edu.do"
                            />
                            <Button
                              type="button"
                              variant="outline"
                              onClick={generateUsername}
                              className="border-futuristic-primary/30 text-futuristic-primary hover:bg-futuristic-primary/10 bg-transparent"
                            >
                              Auto
                            </Button>
                          </div>
                        </div>

                        <div>
                          <Label htmlFor="tempPassword" className="text-futuristic-text-secondary">
                            Contraseña Temporal
                          </Label>
                          <div className="flex gap-2">
                            <Input
                              id="tempPassword"
                              type="text"
                              value={newUserForm.tempPassword}
                              onChange={(e) => setNewUserForm((prev) => ({ ...prev, tempPassword: e.target.value }))}
                              className="bg-futuristic-background/30 border-futuristic-primary/20"
                              placeholder="Contraseña temporal"
                            />
                            <Button
                              type="button"
                              variant="outline"
                              onClick={generateTempPassword}
                              className="border-futuristic-primary/30 text-futuristic-primary hover:bg-futuristic-primary/10 bg-transparent"
                            >
                              Generar
                            </Button>
                          </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="status" className="text-futuristic-text-secondary">
                              Estado
                            </Label>
                            <Select
                              value={newUserForm.status}
                              onValueChange={(value) => setNewUserForm((prev) => ({ ...prev, status: value }))}
                            >
                              <SelectTrigger className="bg-futuristic-background/30 border-futuristic-primary/20">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="Activo">Activo</SelectItem>
                                <SelectItem value="Inactivo">Inactivo</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div>
                            <Label htmlFor="educationalCenter" className="text-futuristic-text-secondary">
                              Centro Educativo
                            </Label>
                            <Select
                              value={newUserForm.educationalCenter}
                              onValueChange={(value) =>
                                setNewUserForm((prev) => ({ ...prev, educationalCenter: value }))
                              }
                            >
                              <SelectTrigger className="bg-futuristic-background/30 border-futuristic-primary/20">
                                <SelectValue placeholder="Centro principal" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="principal">Centro Principal</SelectItem>
                                <SelectItem value="sucursal1">Sucursal Norte</SelectItem>
                                <SelectItem value="sucursal2">Sucursal Sur</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </div>

                        <div className="flex items-center space-x-2">
                          <Switch
                            id="sendCredentials"
                            checked={newUserForm.sendCredentials}
                            onCheckedChange={(checked) =>
                              setNewUserForm((prev) => ({ ...prev, sendCredentials: checked }))
                            }
                          />
                          <Label htmlFor="sendCredentials" className="text-futuristic-text-secondary">
                            Enviar credenciales por correo electrónico
                          </Label>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Configuración avanzada */}
                    <Card className="bg-futuristic-surface border-futuristic-primary/10">
                      <CardHeader>
                        <CardTitle className="text-lg text-futuristic-text-primary flex items-center justify-between">
                          <span className="flex items-center gap-2">
                            <Settings className="h-5 w-5" />
                            Configuración Avanzada
                          </span>
                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            onClick={() => setAdvancedConfigOpen(!advancedConfigOpen)}
                            className="border-futuristic-primary/30 text-futuristic-primary hover:bg-futuristic-primary/10"
                          >
                            {advancedConfigOpen ? "Ocultar" : "Mostrar"}
                          </Button>
                        </CardTitle>
                      </CardHeader>
                      {advancedConfigOpen && (
                        <CardContent>
                          <div className="space-y-4">
                            <p className="text-sm text-futuristic-text-secondary">
                              Personalice los módulos específicos para este usuario (opcional)
                            </p>
                            <div className="grid grid-cols-2 gap-4">
                              {[
                                "Gestión de Estudiantes",
                                "Calificaciones",
                                "Horarios",
                                "Comunicaciones",
                                "Reportes",
                                "Finanzas",
                                "Configuración",
                                "Usuarios",
                              ].map((module) => (
                                <div key={module} className="flex items-center space-x-2">
                                  <Switch id={module} />
                                  <Label htmlFor={module} className="text-sm text-futuristic-text-secondary">
                                    {module}
                                  </Label>
                                </div>
                              ))}
                            </div>
                          </div>
                        </CardContent>
                      )}
                    </Card>

                    {/* Botones de acción */}
                    <div className="flex justify-end gap-3">
                      <Button
                        variant="outline"
                        onClick={() => setNewUserModalOpen(false)}
                        className="border-futuristic-primary/30 text-futuristic-primary hover:bg-futuristic-primary/10"
                      >
                        Cancelar
                      </Button>
                      <Button
                        onClick={handleCreateUser}
                        className="bg-gradient-to-r from-futuristic-success to-futuristic-success-light hover:from-futuristic-success-light hover:to-futuristic-success"
                      >
                        <CheckCircle className="mr-2 h-4 w-4" />
                        Crear Usuario
                      </Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </div>

            {/* Estadísticas */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <Card className="bg-futuristic-surface border-futuristic-primary/10 hover:border-futuristic-primary/30 transition-all duration-300">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-futuristic-text-secondary text-sm font-medium">Total Personal</CardTitle>
                  <Users className="h-5 w-5 text-futuristic-primary" />
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-futuristic-text-primary">{stats.totalPersonal}</div>
                  <p className="text-xs text-futuristic-text-secondary mt-1">Miembros registrados</p>
                </CardContent>
              </Card>

              <Card className="bg-futuristic-surface border-futuristic-primary/10 hover:border-futuristic-primary/30 transition-all duration-300">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-futuristic-text-secondary text-sm font-medium">Usuarios Activos</CardTitle>
                  <CheckCircle className="h-5 w-5 text-futuristic-success" />
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-futuristic-text-primary">{stats.activeUsers}</div>
                  <p className="text-xs text-futuristic-success mt-1">Con acceso al sistema</p>
                </CardContent>
              </Card>

              <Card className="bg-futuristic-surface border-futuristic-primary/10 hover:border-futuristic-primary/30 transition-all duration-300">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-futuristic-text-secondary text-sm font-medium">Profesores</CardTitle>
                  <BookOpen className="h-5 w-5 text-futuristic-info" />
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-futuristic-text-primary">{stats.professors}</div>
                  <p className="text-xs text-futuristic-info mt-1">Personal docente</p>
                </CardContent>
              </Card>

              <Card className="bg-futuristic-surface border-futuristic-primary/10 hover:border-futuristic-primary/30 transition-all duration-300">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-futuristic-text-secondary text-sm font-medium">Coordinadores</CardTitle>
                  <GraduationCap className="h-5 w-5 text-futuristic-warning" />
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-futuristic-text-primary">{stats.coordinators}</div>
                  <p className="text-xs text-futuristic-warning mt-1">Personal administrativo</p>
                </CardContent>
              </Card>
            </div>

            {/* Filtros */}
            <Card className="bg-futuristic-surface border-futuristic-primary/10">
              <CardHeader>
                <CardTitle className="text-futuristic-text-primary flex items-center gap-2">
                  <Filter className="h-5 w-5" />
                  Filtros de Búsqueda
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div className="relative">
                    <Search className="absolute left-2 top-2.5 h-4 w-4 text-futuristic-text-secondary" />
                    <Input
                      placeholder="Buscar personal..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-8 bg-futuristic-background/30 border-futuristic-primary/20"
                    />
                  </div>

                  <Select value={filterRole} onValueChange={setFilterRole}>
                    <SelectTrigger className="bg-futuristic-background/30 border-futuristic-primary/20">
                      <SelectValue placeholder="Filtrar por rol" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos los roles</SelectItem>
                      <SelectItem value="Coordinador Académico">Coordinador Académico</SelectItem>
                      <SelectItem value="Coordinador de Registro">Coordinador de Registro</SelectItem>
                      <SelectItem value="Profesor">Profesor</SelectItem>
                      <SelectItem value="Contable">Contable</SelectItem>
                    </SelectContent>
                  </Select>

                  <Select value={filterStatus} onValueChange={setFilterStatus}>
                    <SelectTrigger className="bg-futuristic-background/30 border-futuristic-primary/20">
                      <SelectValue placeholder="Filtrar por estado" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos los estados</SelectItem>
                      <SelectItem value="Activo">Activo</SelectItem>
                      <SelectItem value="Inactivo">Inactivo</SelectItem>
                    </SelectContent>
                  </Select>

                  <Button
                    variant="outline"
                    className="border-futuristic-primary/30 text-futuristic-primary hover:bg-futuristic-primary/10 bg-transparent"
                  >
                    Limpiar Filtros
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Lista de personal */}
            <div className="grid gap-4">
              {filteredPersonal.map((person) => (
                <Card
                  key={person.id}
                  className="bg-futuristic-surface border-futuristic-primary/10 hover:border-futuristic-primary/30 transition-all duration-300"
                >
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <div className="w-12 h-12 rounded-full bg-gradient-to-br from-futuristic-primary to-futuristic-creative flex items-center justify-center text-white font-bold">
                          {person.name
                            .split(" ")
                            .map((n) => n[0])
                            .join("")
                            .substring(0, 2)}
                        </div>
                        <div>
                          <h3 className="text-lg font-semibold text-futuristic-text-primary">{person.name}</h3>
                          <div className="flex items-center gap-2 text-sm text-futuristic-text-secondary">
                            {getRoleIcon(person.role)}
                            <span>{person.role}</span>
                          </div>
                          <div className="flex items-center gap-4 text-sm text-futuristic-text-secondary mt-1">
                            <div className="flex items-center gap-1">
                              <Mail className="h-3 w-3" />
                              {person.email}
                            </div>
                            <div className="flex items-center gap-1">
                              <Phone className="h-3 w-3" />
                              {person.phone}
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center space-x-4">
                        <div className="text-right">
                          <Badge className={getStatusColor(person.status)}>{person.status}</Badge>
                          <p className="text-xs text-futuristic-text-secondary mt-1">Creado: {person.createdDate}</p>
                          <p className="text-xs text-futuristic-text-secondary">Último acceso: {person.lastLogin}</p>
                        </div>

                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => {
                              setSelectedUser(person)
                              setUserDetailModalOpen(true)
                            }}
                            className="h-8 w-8 p-0"
                          >
                            <Eye className="h-4 w-4 text-futuristic-info" />
                          </Button>
                          <Button 
                            size="sm" 
                            variant="ghost" 
                            className="h-8 w-8 p-0 hover:bg-futuristic-warning/10"
                            onClick={() => handleEditUser(person)}
                          >
                            <Edit className="h-4 w-4 text-futuristic-warning" />
                          </Button>
                          <Button size="sm" variant="ghost" className="h-8 w-8 p-0">
                            <RotateCcw className="h-4 w-4 text-futuristic-secondary" />
                          </Button>
                          <Button size="sm" variant="ghost" className="h-8 w-8 p-0">
                            <UserX className="h-4 w-4 text-futuristic-error" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Pestaña Estudiantes */}
          <TabsContent value="students" className="space-y-6">
            <div className="text-center py-12">
              <GraduationCap className="h-16 w-16 text-futuristic-text-secondary mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-futuristic-text-primary mb-2">Gestión de Estudiantes</h3>
              <p className="text-futuristic-text-secondary">
                Esta funcionalidad será gestionada por el Coordinador de Registro
              </p>
            </div>
          </TabsContent>

          {/* Pestaña Padres */}
          <TabsContent value="parents" className="space-y-6">
            <div className="text-center py-12">
              <Users className="h-16 w-16 text-futuristic-text-secondary mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-futuristic-text-primary mb-2">Gestión de Padres</h3>
              <p className="text-futuristic-text-secondary">
                Esta funcionalidad será gestionada por el Coordinador de Registro
              </p>
            </div>
          </TabsContent>
        </Tabs>

        {/* Modal de edición de usuario */}
        <Dialog open={editUserModalOpen} onOpenChange={setEditUserModalOpen}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-futuristic-text-primary">
                Editar Usuario: {editingUser?.name}
              </DialogTitle>
              <DialogDescription>
                Modifique la información del miembro del personal
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-6">
              {/* Información actual del usuario */}
              {editingUser && (
                <Card className="bg-futuristic-info/10 border-futuristic-info/20">
                  <CardHeader>
                    <CardTitle className="text-lg text-futuristic-text-primary flex items-center gap-2">
                      <Users className="h-5 w-5" />
                      Información Actual
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                      <div>
                        <Label className="text-futuristic-text-secondary">Rol Actual</Label>
                        <p className="text-futuristic-text-primary font-medium">{editingUser.role}</p>
                      </div>
                      <div>
                        <Label className="text-futuristic-text-secondary">Estado</Label>
                        <Badge className={getStatusColor(editingUser.status)}>{editingUser.status}</Badge>
                      </div>
                      <div>
                        <Label className="text-futuristic-text-secondary">Último Acceso</Label>
                        <p className="text-futuristic-text-primary">{editingUser.lastLogin}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Rol a asignar */}
              <Card className="bg-futuristic-surface border-futuristic-primary/10">
                <CardHeader>
                  <CardTitle className="text-lg text-futuristic-text-primary flex items-center gap-2">
                    <Shield className="h-5 w-5" />
                    Modificar Rol
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <Select
                    value={newUserForm.role}
                    onValueChange={(value) => setNewUserForm((prev) => ({ ...prev, role: value }))}
                  >
                    <SelectTrigger className="bg-futuristic-background/30 border-futuristic-primary/20">
                      <SelectValue placeholder="Seleccionar rol" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Coordinador Académico">
                        <div className="flex items-center gap-2">
                          <GraduationCap className="h-4 w-4" />
                          Coordinador Académico
                        </div>
                      </SelectItem>
                      <SelectItem value="Coordinador de Registro">
                        <div className="flex items-center gap-2">
                          <FileText className="h-4 w-4" />
                          Coordinador de Registro y Control Académico
                        </div>
                      </SelectItem>
                      <SelectItem value="Profesor">
                        <div className="flex items-center gap-2">
                          <BookOpen className="h-4 w-4" />
                          Profesor
                        </div>
                      </SelectItem>
                      <SelectItem value="Contable">
                        <div className="flex items-center gap-2">
                          <Calculator className="h-4 w-4" />
                          Contable
                        </div>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </CardContent>
              </Card>

              {/* Datos generales */}
              <Card className="bg-futuristic-surface border-futuristic-primary/10">
                <CardHeader>
                  <CardTitle className="text-lg text-futuristic-text-primary">Datos Generales</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="editFirstName" className="text-futuristic-text-secondary">
                        Nombre(s) *
                      </Label>
                      <Input
                        id="editFirstName"
                        value={newUserForm.firstName}
                        onChange={(e) => setNewUserForm((prev) => ({ ...prev, firstName: e.target.value }))}
                        className="bg-futuristic-background/30 border-futuristic-primary/20"
                        placeholder="Ingrese el nombre"
                      />
                    </div>
                    <div>
                      <Label htmlFor="editLastName" className="text-futuristic-text-secondary">
                        Apellido(s) *
                      </Label>
                      <Input
                        id="editLastName"
                        value={newUserForm.lastName}
                        onChange={(e) => setNewUserForm((prev) => ({ ...prev, lastName: e.target.value }))}
                        className="bg-futuristic-background/30 border-futuristic-primary/20"
                        placeholder="Ingrese los apellidos"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="editCedula" className="text-futuristic-text-secondary">
                        Cédula / ID Institucional *
                      </Label>
                      <Input
                        id="editCedula"
                        value={newUserForm.cedula}
                        onChange={(e) => setNewUserForm((prev) => ({ ...prev, cedula: e.target.value }))}
                        className="bg-futuristic-background/30 border-futuristic-primary/20"
                        placeholder="001-1234567-8"
                      />
                    </div>
                    <div>
                      <Label htmlFor="editPhone" className="text-futuristic-text-secondary">
                        Teléfono de Contacto
                      </Label>
                      <Input
                        id="editPhone"
                        value={newUserForm.phone}
                        onChange={(e) => setNewUserForm((prev) => ({ ...prev, phone: e.target.value }))}
                        className="bg-futuristic-background/30 border-futuristic-primary/20"
                        placeholder="(809) 555-0123"
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="editEmail" className="text-futuristic-text-secondary">
                      Correo Electrónico *
                    </Label>
                    <Input
                      id="editEmail"
                      type="email"
                      value={newUserForm.email}
                      onChange={(e) => setNewUserForm((prev) => ({ ...prev, email: e.target.value }))}
                      className="bg-futuristic-background/30 border-futuristic-primary/20"
                      placeholder="usuario@colegio.edu.do"
                    />
                  </div>

                  <div>
                    <Label htmlFor="editStatus" className="text-futuristic-text-secondary">
                      Estado
                    </Label>
                    <Select
                      value={newUserForm.status}
                      onValueChange={(value) => setNewUserForm((prev) => ({ ...prev, status: value }))}
                    >
                      <SelectTrigger className="bg-futuristic-background/30 border-futuristic-primary/20">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Activo">Activo</SelectItem>
                        <SelectItem value="Inactivo">Inactivo</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </CardContent>
              </Card>

              {/* Opciones de seguridad */}
              <Card className="bg-futuristic-surface border-futuristic-warning/10">
                <CardHeader>
                  <CardTitle className="text-lg text-futuristic-text-primary flex items-center gap-2">
                    <Shield className="h-5 w-5" />
                    Opciones de Seguridad
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-futuristic-warning/10 rounded-lg">
                    <div>
                      <Label className="text-futuristic-text-primary font-medium">Restablecer Contraseña</Label>
                      <p className="text-sm text-futuristic-text-secondary">
                        Generar nueva contraseña temporal y enviarla por correo
                      </p>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      className="border-futuristic-warning/30 text-futuristic-warning hover:bg-futuristic-warning/10"
                    >
                      Restablecer
                    </Button>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-futuristic-info/10 rounded-lg">
                    <div>
                      <Label className="text-futuristic-text-primary font-medium">Actividad Reciente</Label>
                      <p className="text-sm text-futuristic-text-secondary">
                        Último acceso: {editingUser?.lastLogin}
                      </p>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      className="border-futuristic-info/30 text-futuristic-info hover:bg-futuristic-info/10"
                    >
                      Ver Actividad
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Botones de acción */}
              <div className="flex justify-end gap-3">
                <Button
                  variant="outline"
                  onClick={() => {
                    setEditUserModalOpen(false)
                    setEditingUser(null)
                    setNewUserForm({
                      role: "",
                      firstName: "",
                      lastName: "",
                      cedula: "",
                      email: "",
                      phone: "",
                      gender: "",
                      birthDate: "",
                      address: "",
                      username: "",
                      tempPassword: "",
                      status: "Activo",
                      educationalCenter: "",
                      sendCredentials: true,
                    })
                  }}
                  className="border-futuristic-primary/30 text-futuristic-primary hover:bg-futuristic-primary/10"
                >
                  Cancelar
                </Button>
                <Button
                  onClick={handleUpdateUser}
                  className="bg-gradient-to-r from-futuristic-warning to-futuristic-warning-light hover:from-futuristic-warning-light hover:to-futuristic-warning"
                >
                  <CheckCircle className="mr-2 h-4 w-4" />
                  Actualizar Usuario
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Modal de detalle de usuario */}
        <Dialog open={userDetailModalOpen} onOpenChange={setUserDetailModalOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle className="text-futuristic-text-primary">Detalle del Usuario</DialogTitle>
              <DialogDescription>Información completa del miembro del personal</DialogDescription>
            </DialogHeader>
            {selectedUser && (
              <div className="space-y-6">
                <div className="flex items-center space-x-4">
                  <div className="w-16 h-16 rounded-full bg-gradient-to-br from-futuristic-primary to-futuristic-creative flex items-center justify-center text-white font-bold text-xl">
                    {selectedUser.name
                      .split(" ")
                      .map((n) => n[0])
                      .join("")
                      .substring(0, 2)}
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-futuristic-text-primary">{selectedUser.name}</h3>
                    <div className="flex items-center gap-2 text-futuristic-text-secondary">
                      {getRoleIcon(selectedUser.role)}
                      <span>{selectedUser.role}</span>
                    </div>
                    <Badge className={getStatusColor(selectedUser.status)}>{selectedUser.status}</Badge>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-3">
                    <div>
                      <Label className="text-futuristic-text-secondary">Correo Electrónico</Label>
                      <p className="text-futuristic-text-primary">{selectedUser.email}</p>
                    </div>
                    <div>
                      <Label className="text-futuristic-text-secondary">Teléfono</Label>
                      <p className="text-futuristic-text-primary">{selectedUser.phone}</p>
                    </div>
                    <div>
                      <Label className="text-futuristic-text-secondary">Cédula</Label>
                      <p className="text-futuristic-text-primary">{selectedUser.cedula}</p>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <div>
                      <Label className="text-futuristic-text-secondary">Fecha de Creación</Label>
                      <p className="text-futuristic-text-primary">{selectedUser.createdDate}</p>
                    </div>
                    <div>
                      <Label className="text-futuristic-text-secondary">Último Acceso</Label>
                      <p className="text-futuristic-text-primary">{selectedUser.lastLogin}</p>
                    </div>
                    <div>
                      <Label className="text-futuristic-text-secondary">Cursos Asignados</Label>
                      <p className="text-futuristic-text-primary">{selectedUser.assignedCourses}</p>
                    </div>
                  </div>
                </div>

                <div className="flex justify-end gap-2">
                  <Button
                    variant="outline"
                    className="border-futuristic-primary/30 text-futuristic-primary hover:bg-futuristic-primary/10 bg-transparent"
                  >
                    <Edit className="mr-2 h-4 w-4" />
                    Editar
                  </Button>
                  <Button
                    variant="outline"
                    className="border-futuristic-secondary/30 text-futuristic-secondary hover:bg-futuristic-secondary/10 bg-transparent"
                  >
                    <RotateCcw className="mr-2 h-4 w-4" />
                    Resetear Contraseña
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </main>
    </div>
  )
}
