"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Checkbox } from "@/components/ui/checkbox"
import {
  Send,
  Paperclip,
  Mail,
  MessageSquare,
  AlertTriangle,
  Clock,
  CheckCircle,
  Download,
  Filter,
  Search,
  Bell,
} from "lucide-react"

export default function CommunicationPage() {
  const [selectedTab, setSelectedTab] = useState("compose")
  const [messageType, setMessageType] = useState("")
  const [recipient, setRecipient] = useState("")
  const [channel, setChannel] = useState<string[]>([])
  const [isUrgent, setIsUrgent] = useState(false)

  const messageHistory = [
    {
      id: 1,
      date: "2024-01-15",
      title: "Reunión de Padres - 3ro A",
      recipient: "3ro A",
      type: "Aviso General",
      channel: "Correo + WhatsApp",
      status: "Entregado",
      delivered: 28,
      total: 30,
    },
    {
      id: 2,
      date: "2024-01-14",
      title: "Circular Informativa - Cambio de Horario",
      recipient: "Todos los Padres",
      type: "Aviso General",
      channel: "Correo",
      status: "Pendiente",
      delivered: 145,
      total: 180,
    },
  ]

  const handleChannelChange = (channelType: string, checked: boolean) => {
    if (checked) {
      setChannel([...channel, channelType])
    } else {
      setChannel(channel.filter((c) => c !== channelType))
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Comunicación</h1>
          <p className="text-gray-600 mt-2">Gestiona la comunicación con padres de familia de forma eficiente</p>
        </div>
        <div className="flex items-center space-x-4">
          <Badge variant="outline" className="border-amber-500 text-amber-700 bg-amber-50">
            <Bell className="w-4 h-4 mr-1" />2 Mensajes Pendientes
          </Badge>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="bg-white border-0 shadow-sm">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Mensajes Enviados</p>
                <p className="text-2xl font-bold text-indigo-600">156</p>
              </div>
              <div className="p-3 bg-indigo-100 rounded-lg">
                <Send className="h-6 w-6 text-indigo-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white border-0 shadow-sm">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Tasa de Entrega</p>
                <p className="text-2xl font-bold text-green-600">94.2%</p>
              </div>
              <div className="p-3 bg-green-100 rounded-lg">
                <CheckCircle className="h-6 w-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white border-0 shadow-sm">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Respuestas Recibidas</p>
                <p className="text-2xl font-bold text-blue-600">89</p>
              </div>
              <div className="p-3 bg-blue-100 rounded-lg">
                <MessageSquare className="h-6 w-6 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs value={selectedTab} onValueChange={setSelectedTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-2 bg-white border border-gray-200">
          <TabsTrigger value="compose" className="data-[state=active]:bg-indigo-600 data-[state=active]:text-white">
            <Send className="w-4 h-4 mr-2" />
            Redactar
          </TabsTrigger>
          <TabsTrigger value="history" className="data-[state=active]:bg-indigo-600 data-[state=active]:text-white">
            <Clock className="w-4 h-4 mr-2" />
            Historial
          </TabsTrigger>
        </TabsList>

        {/* Compose Message Tab */}
        <TabsContent value="compose" className="space-y-6">
          <Card className="bg-white border-0 shadow-sm">
            <CardHeader className="border-b border-gray-100">
              <CardTitle className="text-indigo-700">Redactar Mensaje</CardTitle>
              <CardDescription className="text-gray-600">Crea y envía mensajes a padres de familia</CardDescription>
            </CardHeader>
            <CardContent className="p-6 space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="messageType" className="text-gray-700">
                      Tipo de Mensaje
                    </Label>
                    <Select value={messageType} onValueChange={setMessageType}>
                      <SelectTrigger className="bg-white border-gray-300">
                        <SelectValue placeholder="Seleccionar tipo" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="general">Aviso General</SelectItem>
                        <SelectItem value="academic">Comunicado Académico</SelectItem>
                        <SelectItem value="administrative">Aviso Administrativo</SelectItem>
                        <SelectItem value="event">Evento/Actividad</SelectItem>
                        <SelectItem value="urgent">Comunicado Urgente</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="recipient" className="text-gray-700">
                      Destinatario
                    </Label>
                    <Select value={recipient} onValueChange={setRecipient}>
                      <SelectTrigger className="bg-white border-gray-300">
                        <SelectValue placeholder="Seleccionar destinatario" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Todos los Padres</SelectItem>
                        <SelectItem value="1a">1ro A</SelectItem>
                        <SelectItem value="1b">1ro B</SelectItem>
                        <SelectItem value="2a">2do A</SelectItem>
                        <SelectItem value="2b">2do B</SelectItem>
                        <SelectItem value="3a">3ro A</SelectItem>
                        <SelectItem value="individual">Estudiante Individual</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label className="text-gray-700">Canales de Envío</Label>
                    <div className="flex space-x-4 mt-2">
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="email"
                          checked={channel.includes("email")}
                          onCheckedChange={(checked) => handleChannelChange("email", checked as boolean)}
                        />
                        <Label htmlFor="email" className="flex items-center text-gray-700">
                          <Mail className="w-4 h-4 mr-1" />
                          Correo
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="whatsapp"
                          checked={channel.includes("whatsapp")}
                          onCheckedChange={(checked) => handleChannelChange("whatsapp", checked as boolean)}
                        />
                        <Label htmlFor="whatsapp" className="flex items-center text-gray-700">
                          <MessageSquare className="w-4 h-4 mr-1" />
                          WhatsApp
                        </Label>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Checkbox id="urgent" checked={isUrgent} onCheckedChange={setIsUrgent} />
                    <Label htmlFor="urgent" className="flex items-center text-red-600">
                      <AlertTriangle className="w-4 h-4 mr-1" />
                      Marcar como Urgente
                    </Label>
                  </div>
                </div>

                <div className="space-y-4">
                  <div>
                    <Label htmlFor="title" className="text-gray-700">
                      Título del Mensaje
                    </Label>
                    <Input
                      id="title"
                      placeholder="Ej: Reunión de Padres - 3ro A"
                      className="bg-white border-gray-300"
                    />
                  </div>

                  <div>
                    <Label htmlFor="message" className="text-gray-700">
                      Mensaje
                    </Label>
                    <Textarea
                      id="message"
                      placeholder="Escriba su mensaje aquí..."
                      rows={8}
                      className="bg-white border-gray-300"
                    />
                  </div>

                  <div>
                    <Label className="text-gray-700">Adjuntar Archivos</Label>
                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center bg-gray-50">
                      <Paperclip className="w-8 h-8 mx-auto text-gray-400 mb-2" />
                      <p className="text-sm text-gray-600">Arrastra archivos aquí o haz clic para seleccionar</p>
                      <p className="text-xs text-gray-500 mt-1">PDF, Word, Excel, Imágenes (Max 10MB)</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex justify-end space-x-4 pt-4 border-t border-gray-100">
                <Button variant="outline" className="border-gray-300 text-gray-700">
                  Guardar Borrador
                </Button>
                <Button className="bg-indigo-600 hover:bg-indigo-700 text-white">
                  <Send className="w-4 h-4 mr-2" />
                  Enviar Mensaje
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Message History Tab */}
        <TabsContent value="history" className="space-y-6">
          <Card className="bg-white border-0 shadow-sm">
            <CardHeader className="border-b border-gray-100">
              <CardTitle className="text-blue-700">Historial de Mensajes</CardTitle>
              <CardDescription className="text-gray-600">
                Revisa todos los mensajes enviados y su estado de entrega
              </CardDescription>
            </CardHeader>
            <CardContent className="p-6">
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <div className="flex space-x-4">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                      <Input placeholder="Buscar mensajes..." className="pl-10 bg-white border-gray-300" />
                    </div>
                    <Button variant="outline" className="border-gray-300 text-gray-700">
                      <Filter className="w-4 h-4 mr-2" />
                      Filtros
                    </Button>
                  </div>
                  <Button className="bg-green-600 hover:bg-green-700 text-white">
                    <Download className="w-4 h-4 mr-2" />
                    Exportar
                  </Button>
                </div>

                <Table>
                  <TableHeader>
                    <TableRow className="border-gray-200">
                      <TableHead className="text-gray-700">Fecha</TableHead>
                      <TableHead className="text-gray-700">Título</TableHead>
                      <TableHead className="text-gray-700">Destinatario</TableHead>
                      <TableHead className="text-gray-700">Tipo</TableHead>
                      <TableHead className="text-gray-700">Canal</TableHead>
                      <TableHead className="text-gray-700">Estado</TableHead>
                      <TableHead className="text-gray-700">Entrega</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {messageHistory.map((message) => (
                      <TableRow key={message.id} className="border-gray-100">
                        <TableCell className="text-gray-600">{message.date}</TableCell>
                        <TableCell className="font-medium text-gray-900">{message.title}</TableCell>
                        <TableCell className="text-gray-600">{message.recipient}</TableCell>
                        <TableCell>
                          <Badge variant="outline" className="border-purple-300 text-purple-700 bg-purple-50">
                            {message.type}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-gray-600">{message.channel}</TableCell>
                        <TableCell>
                          <Badge
                            variant="outline"
                            className={
                              message.status === "Entregado"
                                ? "border-green-300 text-green-700 bg-green-50"
                                : "border-yellow-300 text-yellow-700 bg-yellow-50"
                            }
                          >
                            {message.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <span className="text-sm text-gray-600">
                            {message.delivered}/{message.total}
                          </span>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
