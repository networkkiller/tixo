"use client"

import { Header } from "@/components/dashboard/header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  CreditCard,
  Plus,
  FileText,
  Calendar,
  Eye,
  Download,
  Send,
  Edit,
  Trash2,
  DollarSign,
  Clock,
  CheckCircle,
  TrendingUp,
  Receipt,
} from "lucide-react"

export default function BillingManagement() {
  return (
    <div className="flex-1 flex flex-col">
      <Header title="Gestión de Facturación" />

      <main className="flex-1 overflow-y-auto p-6 bg-gradient-to-br from-futuristic-background via-futuristic-surface to-futuristic-background">
        <Tabs defaultValue="templates" className="space-y-6">
          <div className="bg-futuristic-surface/50 backdrop-blur-sm rounded-lg p-1 w-fit">
            <TabsList className="grid grid-cols-4 w-fit">
              <TabsTrigger value="templates" className="flex items-center gap-2">
                <Receipt className="h-4 w-4" />
                <span className="hidden md:inline">Plantillas</span>
              </TabsTrigger>
              <TabsTrigger value="generation" className="flex items-center gap-2">
                <FileText className="h-4 w-4" />
                <span className="hidden md:inline">Generación</span>
              </TabsTrigger>
              <TabsTrigger value="dates" className="flex items-center gap-2">
                <Calendar className="h-4 w-4" />
                <span className="hidden md:inline">Fechas</span>
              </TabsTrigger>
              <TabsTrigger value="tracking" className="flex items-center gap-2">
                <CreditCard className="h-4 w-4" />
                <span className="hidden md:inline">Seguimiento</span>
              </TabsTrigger>
            </TabsList>
          </div>

          {/* Plantillas de Cobros */}
          <TabsContent value="templates" className="space-y-6">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-2xl font-bold text-futuristic-text-primary">Plantillas de Cobros</h2>
                <p className="text-futuristic-text-secondary">
                  Crea y gestiona plantillas reutilizables de facturación
                </p>
              </div>
              <Button className="bg-gradient-to-r from-futuristic-primary to-futuristic-primary-light hover:from-futuristic-primary-light hover:to-futuristic-primary">
                <Plus className="mr-2 h-4 w-4" /> Nueva Plantilla
              </Button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Formulario de Plantilla */}
              <Card className="bg-futuristic-surface border-futuristic-primary/10">
                <CardHeader>
                  <CardTitle className="text-futuristic-text-primary">Crear Plantilla de Cobro</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="billing-type" className="text-futuristic-text-secondary">
                      Tipo de Cobro *
                    </Label>
                    <select className="w-full bg-futuristic-background/30 border-futuristic-primary/20 text-futuristic-text-primary rounded-md px-3 py-2">
                      <option value="">Seleccionar tipo</option>
                      <option value="matricula">Matrícula</option>
                      <option value="mensualidad">Mensualidad</option>
                      <option value="cuota-especial">Cuota Especial</option>
                      <option value="evento">Evento</option>
                      <option value="material">Material Escolar</option>
                      <option value="transporte">Transporte</option>
                      <option value="alimentacion">Alimentación</option>
                    </select>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="amount" className="text-futuristic-text-secondary">
                        Monto *
                      </Label>
                      <Input
                        id="amount"
                        type="number"
                        placeholder="150.00"
                        className="bg-futuristic-background/30 border-futuristic-primary/20 text-futuristic-text-primary"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="currency" className="text-futuristic-text-secondary">
                        Moneda
                      </Label>
                      <select className="w-full bg-futuristic-background/30 border-futuristic-primary/20 text-futuristic-text-primary rounded-md px-3 py-2">
                        <option value="DOP">DOP ($)</option>
                        <option value="USD">USD ($)</option>
                      </select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="course-grade" className="text-futuristic-text-secondary">
                      Curso/Grado Aplicable
                    </Label>
                    <select className="w-full bg-futuristic-background/30 border-futuristic-primary/20 text-futuristic-text-primary rounded-md px-3 py-2">
                      <option value="all">Todos los cursos</option>
                      <option value="inicial">Inicial</option>
                      <option value="primaria">Primaria</option>
                      <option value="1A">1° A Primaria</option>
                      <option value="2B">2° B Primaria</option>
                      <option value="3A">3° A Primaria</option>
                    </select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="frequency" className="text-futuristic-text-secondary">
                      Frecuencia *
                    </Label>
                    <select className="w-full bg-futuristic-background/30 border-futuristic-primary/20 text-futuristic-text-primary rounded-md px-3 py-2">
                      <option value="">Seleccionar frecuencia</option>
                      <option value="unica">Única</option>
                      <option value="mensual">Mensual</option>
                      <option value="trimestral">Trimestral</option>
                      <option value="semestral">Semestral</option>
                      <option value="anual">Anual</option>
                    </select>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="start-date" className="text-futuristic-text-secondary">
                        Fecha de Inicio
                      </Label>
                      <Input
                        id="start-date"
                        type="date"
                        className="bg-futuristic-background/30 border-futuristic-primary/20 text-futuristic-text-primary"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="end-date" className="text-futuristic-text-secondary">
                        Fecha de Fin
                      </Label>
                      <Input
                        id="end-date"
                        type="date"
                        className="bg-futuristic-background/30 border-futuristic-primary/20 text-futuristic-text-primary"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-futuristic-text-secondary">Configuración Adicional</Label>
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <input type="checkbox" id="mandatory" className="text-futuristic-primary" />
                        <label htmlFor="mandatory" className="text-sm text-futuristic-text-secondary">
                          Cobro obligatorio
                        </label>
                      </div>
                      <div className="flex items-center gap-2">
                        <input type="checkbox" id="active" className="text-futuristic-primary" />
                        <label htmlFor="active" className="text-sm text-futuristic-text-secondary">
                          Activar plantilla inmediatamente
                        </label>
                      </div>
                    </div>
                  </div>

                  <Button className="w-full bg-gradient-to-r from-futuristic-primary to-futuristic-primary-light hover:from-futuristic-primary-light hover:to-futuristic-primary">
                    <Plus className="mr-2 h-4 w-4" />
                    Crear Plantilla
                  </Button>
                </CardContent>
              </Card>

              {/* Plantillas Existentes */}
              <Card className="bg-futuristic-surface border-futuristic-primary/10">
                <CardHeader>
                  <CardTitle className="text-futuristic-text-primary">Plantillas Activas</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {[
                      {
                        name: "Mensualidad",
                        type: "Mensualidad",
                        amount: "$150",
                        frequency: "Mensual",
                        course: "Todos los cursos",
                        status: "Activa",
                        students: 487,
                      },
                      {
                        name: "Matrícula 2025",
                        type: "Matrícula",
                        amount: "$300",
                        frequency: "Anual",
                        course: "Todos los cursos",
                        status: "Activa",
                        students: 487,
                      },
                      {
                        name: "Material Escolar",
                        type: "Material",
                        amount: "$75",
                        frequency: "Semestral",
                        course: "Primaria",
                        status: "Inactiva",
                        students: 350,
                      },
                      {
                        name: "Transporte",
                        type: "Transporte",
                        amount: "$50",
                        frequency: "Mensual",
                        course: "Todos los cursos",
                        status: "Activa",
                        students: 245,
                      },
                    ].map((template, index) => (
                      <div
                        key={index}
                        className="p-3 bg-futuristic-background/30 rounded-lg hover:bg-futuristic-background/50 transition-all"
                      >
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <p className="font-medium text-futuristic-text-primary">{template.name}</p>
                            <Badge
                              className={`text-xs ${
                                template.status === "Activa"
                                  ? "bg-futuristic-success/20 text-futuristic-success border-futuristic-success/30"
                                  : "bg-futuristic-error/20 text-futuristic-error border-futuristic-error/30"
                              }`}
                            >
                              {template.status}
                            </Badge>
                          </div>
                          <div className="flex gap-1">
                            <Button size="sm" variant="ghost" className="h-8 w-8 p-0">
                              <Edit className="h-4 w-4 text-futuristic-primary" />
                            </Button>
                            <Button size="sm" variant="ghost" className="h-8 w-8 p-0">
                              <Trash2 className="h-4 w-4 text-futuristic-error" />
                            </Button>
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-2 text-xs">
                          <div>
                            <p className="text-futuristic-text-secondary">Monto:</p>
                            <p className="font-medium text-futuristic-text-primary">{template.amount}</p>
                          </div>
                          <div>
                            <p className="text-futuristic-text-secondary">Frecuencia:</p>
                            <p className="font-medium text-futuristic-text-primary">{template.frequency}</p>
                          </div>
                          <div>
                            <p className="text-futuristic-text-secondary">Aplicable a:</p>
                            <p className="font-medium text-futuristic-text-primary">{template.course}</p>
                          </div>
                          <div>
                            <p className="text-futuristic-text-secondary">Estudiantes:</p>
                            <p className="font-medium text-futuristic-text-primary">{template.students}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Generación Automática */}
          <TabsContent value="generation" className="space-y-6">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-2xl font-bold text-futuristic-text-primary">Generación Automática de Facturas</h2>
                <p className="text-futuristic-text-secondary">Genera facturas masivas o individuales</p>
              </div>
              <div className="flex gap-2">
                <Button className="bg-gradient-to-r from-futuristic-primary to-futuristic-primary-light hover:from-futuristic-primary-light hover:to-futuristic-primary">
                  <FileText className="mr-2 h-4 w-4" /> Generar Masivo
                </Button>
                <Button
                  variant="outline"
                  className="border-futuristic-primary/30 text-futuristic-primary hover:bg-futuristic-primary/10"
                >
                  <Plus className="mr-2 h-4 w-4" /> Individual
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Configuración de Generación */}
              <Card className="bg-futuristic-surface border-futuristic-primary/10">
                <CardHeader>
                  <CardTitle className="text-futuristic-text-primary">Configurar Generación</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="template-select" className="text-futuristic-text-secondary">
                      Seleccionar Plantilla *
                    </Label>
                    <select className="w-full bg-futuristic-background/30 border-futuristic-primary/20 text-futuristic-text-primary rounded-md px-3 py-2">
                      <option value="">Seleccionar plantilla</option>
                      <option value="mensualidad">Mensualidad - $150</option>
                      <option value="matricula">Matrícula 2025 - $300</option>
                      <option value="material">Material Escolar - $75</option>
                      <option value="transporte">Transporte - $50</option>
                    </select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="target-students" className="text-futuristic-text-secondary">
                      Estudiantes Objetivo
                    </Label>
                    <select className="w-full bg-futuristic-background/30 border-futuristic-primary/20 text-futuristic-text-primary rounded-md px-3 py-2">
                      <option value="all">Todos los estudiantes (487)</option>
                      <option value="1A">1° A Primaria (24)</option>
                      <option value="1B">1° B Primaria (22)</option>
                      <option value="2A">2° A Primaria (20)</option>
                      <option value="3A">3° A Primaria (19)</option>
                      <option value="primaria">Toda Primaria (350)</option>
                    </select>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="issue-date" className="text-futuristic-text-secondary">
                        Fecha de Emisión
                      </Label>
                      <Input
                        id="issue-date"
                        type="date"
                        className="bg-futuristic-background/30 border-futuristic-primary/20 text-futuristic-text-primary"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="due-date" className="text-futuristic-text-secondary">
                        Fecha Límite de Pago
                      </Label>
                      <Input
                        id="due-date"
                        type="date"
                        className="bg-futuristic-background/30 border-futuristic-primary/20 text-futuristic-text-primary"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-futuristic-text-secondary">Notificaciones Automáticas</Label>
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <input type="checkbox" id="email-notification" className="text-futuristic-primary" />
                        <label htmlFor="email-notification" className="text-sm text-futuristic-text-secondary">
                          Enviar por correo electrónico
                        </label>
                      </div>
                      <div className="flex items-center gap-2">
                        <input type="checkbox" id="whatsapp-notification" className="text-futuristic-primary" />
                        <label htmlFor="whatsapp-notification" className="text-sm text-futuristic-text-secondary">
                          Enviar por WhatsApp
                        </label>
                      </div>
                    </div>
                  </div>

                  <div className="border-t border-futuristic-primary/20 pt-4">
                    <div className="bg-futuristic-info/10 rounded-lg p-3">
                      <h4 className="font-medium text-futuristic-text-primary mb-2">Resumen de Generación</h4>
                      <div className="space-y-1 text-sm">
                        <div className="flex justify-between">
                          <span className="text-futuristic-text-secondary">Estudiantes:</span>
                          <span className="text-futuristic-text-primary">487</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-futuristic-text-secondary">Monto por factura:</span>
                          <span className="text-futuristic-text-primary">$150</span>
                        </div>
                        <div className="flex justify-between font-medium">
                          <span className="text-futuristic-text-secondary">Total a facturar:</span>
                          <span className="text-futuristic-success">$73,050</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <Button className="w-full bg-gradient-to-r from-futuristic-primary to-futuristic-primary-light hover:from-futuristic-primary-light hover:to-futuristic-primary">
                    <FileText className="mr-2 h-4 w-4" />
                    Generar Facturas
                  </Button>
                </CardContent>
              </Card>

              {/* Facturas Generadas Recientemente */}
              <Card className="bg-futuristic-surface border-futuristic-primary/10">
                <CardHeader>
                  <CardTitle className="text-futuristic-text-primary">Facturas Generadas Recientemente</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {[
                      {
                        batch: "Mensualidad Junio 2024",
                        date: "01/06/2024",
                        students: 487,
                        amount: "$73,050",
                        status: "Completado",
                        paid: 463,
                        pending: 24,
                      },
                      {
                        batch: "Material Escolar 2024",
                        date: "15/05/2024",
                        students: 350,
                        amount: "$26,250",
                        status: "Completado",
                        paid: 340,
                        pending: 10,
                      },
                      {
                        batch: "Transporte Junio 2024",
                        date: "01/06/2024",
                        students: 245,
                        amount: "$12,250",
                        status: "En proceso",
                        paid: 230,
                        pending: 15,
                      },
                    ].map((batch, index) => (
                      <div
                        key={index}
                        className="p-3 bg-futuristic-background/30 rounded-lg hover:bg-futuristic-background/50 transition-all"
                      >
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <p className="font-medium text-futuristic-text-primary">{batch.batch}</p>
                            <Badge
                              className={`text-xs ${
                                batch.status === "Completado"
                                  ? "bg-futuristic-success/20 text-futuristic-success border-futuristic-success/30"
                                  : "bg-futuristic-warning/20 text-futuristic-warning border-futuristic-warning/30"
                              }`}
                            >
                              {batch.status}
                            </Badge>
                          </div>
                          <p className="text-xs text-futuristic-text-secondary">{batch.date}</p>
                        </div>
                        <div className="grid grid-cols-2 gap-2 text-xs mb-2">
                          <div>
                            <p className="text-futuristic-text-secondary">Estudiantes:</p>
                            <p className="font-medium text-futuristic-text-primary">{batch.students}</p>
                          </div>
                          <div>
                            <p className="text-futuristic-text-secondary">Monto Total:</p>
                            <p className="font-medium text-futuristic-text-primary">{batch.amount}</p>
                          </div>
                          <div>
                            <p className="text-futuristic-text-secondary">Pagados:</p>
                            <p className="font-medium text-futuristic-success">{batch.paid}</p>
                          </div>
                          <div>
                            <p className="text-futuristic-text-secondary">Pendientes:</p>
                            <p className="font-medium text-futuristic-warning">{batch.pending}</p>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Button size="sm" variant="ghost" className="h-8 flex-1">
                            <Eye className="h-4 w-4 mr-1" />
                            Ver Detalles
                          </Button>
                          <Button size="sm" variant="ghost" className="h-8 w-8 p-0">
                            <Download className="h-4 w-4 text-futuristic-primary" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Gestión de Fechas */}
          <TabsContent value="dates" className="space-y-6">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-2xl font-bold text-futuristic-text-primary">Gestión de Fechas de Pago</h2>
                <p className="text-futuristic-text-secondary">Administra fechas límite y recordatorios</p>
              </div>
              <Button className="bg-gradient-to-r from-futuristic-primary to-futuristic-primary-light hover:from-futuristic-primary-light hover:to-futuristic-primary">
                <Calendar className="mr-2 h-4 w-4" /> Configurar Recordatorios
              </Button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Modificación de Fechas */}
              <Card className="lg:col-span-2 bg-futuristic-surface border-futuristic-primary/10">
                <CardHeader>
                  <CardTitle className="text-futuristic-text-primary">Modificar Fechas Límite</CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b border-futuristic-primary/20">
                          <th className="text-left p-4 text-futuristic-text-secondary font-medium">Concepto</th>
                          <th className="text-left p-4 text-futuristic-text-secondary font-medium">Curso</th>
                          <th className="text-left p-4 text-futuristic-text-secondary font-medium">Fecha Actual</th>
                          <th className="text-left p-4 text-futuristic-text-secondary font-medium">Nueva Fecha</th>
                          <th className="text-right p-4 text-futuristic-text-secondary font-medium">Acciones</th>
                        </tr>
                      </thead>
                      <tbody>
                        {[
                          {
                            concept: "Mensualidad Junio",
                            course: "Todos",
                            currentDate: "15/06/2024",
                            status: "Próximo a vencer",
                          },
                          {
                            concept: "Material Escolar",
                            course: "Primaria",
                            currentDate: "30/06/2024",
                            status: "Normal",
                          },
                          {
                            concept: "Transporte Junio",
                            course: "Todos",
                            currentDate: "10/06/2024",
                            status: "Vencido",
                          },
                        ].map((item, index) => (
                          <tr
                            key={index}
                            className="border-b border-futuristic-primary/10 hover:bg-futuristic-primary/5"
                          >
                            <td className="p-4 text-futuristic-text-primary">{item.concept}</td>
                            <td className="p-4 text-futuristic-text-secondary">{item.course}</td>
                            <td className="p-4">
                              <div className="flex items-center gap-2">
                                <span className="text-futuristic-text-secondary">{item.currentDate}</span>
                                <Badge
                                  className={`text-xs ${
                                    item.status === "Vencido"
                                      ? "bg-futuristic-error/20 text-futuristic-error border-futuristic-error/30"
                                      : item.status === "Próximo a vencer"
                                        ? "bg-futuristic-warning/20 text-futuristic-warning border-futuristic-warning/30"
                                        : "bg-futuristic-success/20 text-futuristic-success border-futuristic-success/30"
                                  }`}
                                >
                                  {item.status}
                                </Badge>
                              </div>
                            </td>
                            <td className="p-4">
                              <Input
                                type="date"
                                className="bg-futuristic-background/30 border-futuristic-primary/20 text-futuristic-text-primary w-32"
                              />
                            </td>
                            <td className="p-4 text-right">
                              <div className="flex justify-end gap-2">
                                <Button size="sm" variant="ghost" className="h-8 w-8 p-0">
                                  <CheckCircle className="h-4 w-4 text-futuristic-success" />
                                </Button>
                                <Button size="sm" variant="ghost" className="h-8 w-8 p-0">
                                  <Send className="h-4 w-4 text-futuristic-primary" />
                                </Button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>

              {/* Configuración de Recordatorios */}
              <Card className="bg-futuristic-surface border-futuristic-primary/10">
                <CardHeader>
                  <CardTitle className="text-futuristic-text-primary">Recordatorios Automáticos</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="p-3 bg-futuristic-background/30 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium text-futuristic-text-primary">3 días antes</span>
                        <input type="checkbox" className="text-futuristic-primary" defaultChecked />
                      </div>
                      <p className="text-xs text-futuristic-text-secondary">Recordatorio preventivo</p>
                    </div>

                    <div className="p-3 bg-futuristic-background/30 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium text-futuristic-text-primary">1 día antes</span>
                        <input type="checkbox" className="text-futuristic-primary" defaultChecked />
                      </div>
                      <p className="text-xs text-futuristic-text-secondary">Recordatorio urgente</p>
                    </div>

                    <div className="p-3 bg-futuristic-background/30 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium text-futuristic-text-primary">Día de vencimiento</span>
                        <input type="checkbox" className="text-futuristic-primary" defaultChecked />
                      </div>
                      <p className="text-xs text-futuristic-text-secondary">Último aviso</p>
                    </div>

                    <div className="p-3 bg-futuristic-background/30 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium text-futuristic-text-primary">Después de vencer</span>
                        <input type="checkbox" className="text-futuristic-primary" />
                      </div>
                      <p className="text-xs text-futuristic-text-secondary">Notificación de mora</p>
                    </div>
                  </div>

                  <div className="border-t border-futuristic-primary/20 pt-4">
                    <h4 className="font-medium text-futuristic-text-primary mb-2">Canales de Envío</h4>
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <input type="checkbox" id="email-reminder" className="text-futuristic-primary" defaultChecked />
                        <label htmlFor="email-reminder" className="text-sm text-futuristic-text-secondary">
                          Correo electrónico
                        </label>
                      </div>
                      <div className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          id="whatsapp-reminder"
                          className="text-futuristic-primary"
                          defaultChecked
                        />
                        <label htmlFor="whatsapp-reminder" className="text-sm text-futuristic-text-secondary">
                          WhatsApp
                        </label>
                      </div>
                      <div className="flex items-center gap-2">
                        <input type="checkbox" id="sms-reminder" className="text-futuristic-primary" />
                        <label htmlFor="sms-reminder" className="text-sm text-futuristic-text-secondary">
                          SMS
                        </label>
                      </div>
                    </div>
                  </div>

                  <Button className="w-full bg-gradient-to-r from-futuristic-primary to-futuristic-primary-light hover:from-futuristic-primary-light hover:to-futuristic-primary">
                    <Calendar className="mr-2 h-4 w-4" />
                    Guardar Configuración
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Seguimiento de Facturas */}
          <TabsContent value="tracking" className="space-y-6">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-2xl font-bold text-futuristic-text-primary">Seguimiento de Facturas</h2>
                <p className="text-futuristic-text-secondary">Visualiza y gestiona el estado de todas las facturas</p>
              </div>
              <div className="flex gap-2">
                <select className="bg-futuristic-surface border-futuristic-primary/20 text-futuristic-text-primary rounded-md px-3 py-2">
                  <option value="all">Todos los estados</option>
                  <option value="paid">Pagado</option>
                  <option value="pending">Pendiente</option>
                  <option value="overdue">Vencido</option>
                </select>
                <select className="bg-futuristic-surface border-futuristic-primary/20 text-futuristic-text-primary rounded-md px-3 py-2">
                  <option value="all">Todos los cursos</option>
                  <option value="1A">1° A Primaria</option>
                  <option value="2B">2° B Primaria</option>
                  <option value="3A">3° A Primaria</option>
                </select>
                <Button
                  variant="outline"
                  className="border-futuristic-primary/30 text-futuristic-primary hover:bg-futuristic-primary/10"
                >
                  <Download className="mr-2 h-4 w-4" /> Exportar
                </Button>
              </div>
            </div>

            {/* Estadísticas Generales */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <Card className="bg-futuristic-surface border-futuristic-primary/10 hover:border-futuristic-primary/30 transition-all duration-300">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-futuristic-text-secondary text-sm font-medium">Total Facturado</CardTitle>
                  <DollarSign className="h-5 w-5 text-futuristic-success" />
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-futuristic-text-primary">$111,550</div>
                  <p className="text-xs text-futuristic-success mt-1">+8% vs mes anterior</p>
                </CardContent>
              </Card>

              <Card className="bg-futuristic-surface border-futuristic-primary/10 hover:border-futuristic-primary/30 transition-all duration-300">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-futuristic-text-secondary text-sm font-medium">Pagos Recibidos</CardTitle>
                  <CheckCircle className="h-5 w-5 text-futuristic-success" />
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-futuristic-text-primary">$98,750</div>
                  <p className="text-xs text-futuristic-success mt-1">88.5% del total</p>
                </CardContent>
              </Card>

              <Card className="bg-futuristic-surface border-futuristic-primary/10 hover:border-futuristic-primary/30 transition-all duration-300">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-futuristic-text-secondary text-sm font-medium">Pendientes</CardTitle>
                  <Clock className="h-5 w-5 text-futuristic-warning" />
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-futuristic-text-primary">$12,800</div>
                  <p className="text-xs text-futuristic-warning mt-1">49 facturas</p>
                </CardContent>
              </Card>

              <Card className="bg-futuristic-surface border-futuristic-primary/10 hover:border-futuristic-primary/30 transition-all duration-300">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-futuristic-text-secondary text-sm font-medium">Tasa de Cobro</CardTitle>
                  <TrendingUp className="h-5 w-5 text-futuristic-info" />
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-futuristic-text-primary">88.5%</div>
                  <p className="text-xs text-futuristic-success mt-1">+2.3% vs mes anterior</p>
                </CardContent>
              </Card>
            </div>

            {/* Tabla de Facturas */}
            <Card className="bg-futuristic-surface border-futuristic-primary/10">
              <CardHeader>
                <CardTitle className="text-futuristic-text-primary">Facturas Recientes</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-futuristic-primary/20">
                        <th className="text-left p-4 text-futuristic-text-secondary font-medium">Factura</th>
                        <th className="text-left p-4 text-futuristic-text-secondary font-medium">Estudiante</th>
                        <th className="text-left p-4 text-futuristic-text-secondary font-medium">Padre</th>
                        <th className="text-left p-4 text-futuristic-text-secondary font-medium">Concepto</th>
                        <th className="text-left p-4 text-futuristic-text-secondary font-medium">Monto</th>
                        <th className="text-left p-4 text-futuristic-text-secondary font-medium">Vencimiento</th>
                        <th className="text-left p-4 text-futuristic-text-secondary font-medium">Estado</th>
                        <th className="text-right p-4 text-futuristic-text-secondary font-medium">Acciones</th>
                      </tr>
                    </thead>
                    <tbody>
                      {[
                        {
                          invoice: "FAC-2024-001",
                          student: "Ana María Pérez",
                          parent: "Carlos Pérez",
                          concept: "Mensualidad Junio",
                          amount: "$150",
                          dueDate: "15/06/2024",
                          status: "Pagado",
                          payDate: "10/06/2024",
                        },
                        {
                          invoice: "FAC-2024-002",
                          student: "Luis González",
                          parent: "María González",
                          concept: "Mensualidad Junio",
                          amount: "$150",
                          dueDate: "15/06/2024",
                          status: "Pendiente",
                          payDate: null,
                        },
                        {
                          invoice: "FAC-2024-003",
                          student: "Sofia Martínez",
                          parent: "Roberto Martínez",
                          concept: "Material Escolar",
                          amount: "$75",
                          dueDate: "10/06/2024",
                          status: "Vencido",
                          payDate: null,
                        },
                        {
                          invoice: "FAC-2024-004",
                          student: "Diego López",
                          parent: "Carmen López",
                          concept: "Transporte Junio",
                          amount: "$50",
                          dueDate: "20/06/2024",
                          status: "Pagado",
                          payDate: "18/06/2024",
                        },
                      ].map((invoice, index) => (
                        <tr key={index} className="border-b border-futuristic-primary/10 hover:bg-futuristic-primary/5">
                          <td className="p-4 text-futuristic-text-primary font-medium">{invoice.invoice}</td>
                          <td className="p-4 text-futuristic-text-secondary">{invoice.student}</td>
                          <td className="p-4 text-futuristic-text-secondary">{invoice.parent}</td>
                          <td className="p-4 text-futuristic-text-secondary">{invoice.concept}</td>
                          <td className="p-4 text-futuristic-text-primary font-medium">{invoice.amount}</td>
                          <td className="p-4 text-futuristic-text-secondary">{invoice.dueDate}</td>
                          <td className="p-4">
                            <Badge
                              className={`${
                                invoice.status === "Pagado"
                                  ? "bg-futuristic-success/20 text-futuristic-success border-futuristic-success/30"
                                  : invoice.status === "Pendiente"
                                    ? "bg-futuristic-warning/20 text-futuristic-warning border-futuristic-warning/30"
                                    : "bg-futuristic-error/20 text-futuristic-error border-futuristic-error/30"
                              }`}
                            >
                              {invoice.status}
                            </Badge>
                          </td>
                          <td className="p-4 text-right">
                            <div className="flex justify-end gap-2">
                              <Button size="sm" variant="ghost" className="h-8 w-8 p-0">
                                <Eye className="h-4 w-4 text-futuristic-info" />
                              </Button>
                              <Button size="sm" variant="ghost" className="h-8 w-8 p-0">
                                <Download className="h-4 w-4 text-futuristic-primary" />
                              </Button>
                              {invoice.status !== "Pagado" && (
                                <Button size="sm" variant="ghost" className="h-8 w-8 p-0">
                                  <CheckCircle className="h-4 w-4 text-futuristic-success" />
                                </Button>
                              )}
                              <Button size="sm" variant="ghost" className="h-8 w-8 p-0">
                                <Send className="h-4 w-4 text-futuristic-secondary" />
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}
