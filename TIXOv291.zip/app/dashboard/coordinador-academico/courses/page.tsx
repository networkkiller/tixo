"use client"

import { useState, useEffect } from "react"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Search,
  Filter,
  BookOpen,
  Clock,
  AlertTriangle,
  CheckCircle,
  Eye,
  Settings,
  Mail,
  RefreshCw,
  Calendar,
} from "lucide-react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Progress } from "@/components/ui/progress"
import { CourseStatusCard } from "@/components/course/course-status-card"
import { CourseSubjectsConfigurator } from "@/components/subjects/course-subjects-configurator"
import type { Course } from "@/lib/course-interoperability"
import { CourseConfigurationForm } from "@/components/subjects/course-configuration-form"
import { CourseInteroperabilityService } from "@/services/course-interoperability.service"

export default function CoursesPage() {
  const [courses, setCourses] = useState<Course[]>([])
  const [filteredCourses, setFilteredCourses] = useState<Course[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [levelFilter, setLevelFilter] = useState("all")
  const [turnFilter, setTurnFilter] = useState("all")
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null)
  const [isConfiguratorOpen, setIsConfiguratorOpen] = useState(false)
  const [isDetailsOpen, setIsDetailsOpen] = useState(false)
  const [isCreateScheduleOpen, setIsCreateScheduleOpen] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [isFullConfiguratorOpen, setIsFullConfiguratorOpen] = useState(false)

  // Estados para creación de horario
  const [selectedCourseForSchedule, setSelectedCourseForSchedule] = useState<Course | null>(null)
  const [scheduleCreationStep, setScheduleCreationStep] = useState(1)
  const [scheduleConfig, setScheduleConfig] = useState({
    method: "automatic", // automatic | manual
    shift: "",
    activeDays: ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes"],
    startTime: "08:00",
    endTime: "13:00",
    blocksPerDay: 6,
    includeBreaks: true,
    breakDuration: 15,
    avoidConsecutiveBlocks: true,
    prioritizeComplexSubjects: true,
  })

  // Datos de ejemplo de cursos
  useEffect(() => {
    const mockCourses: Course[] = [
      {
        id: "course_urgent_1",
        name: "6to A",
        grade: "6to",
        level: "Primaria",
        modality: "Regular",
        section: "A",
        turn: "Mañana",
        capacity: 30,
        teacher: "Ana Rodríguez",
        schoolYear: "2024-2025",
        notes: "Curso creado recientemente por el Director",
        createdAt: "2024-01-15T08:00:00Z",
        createdBy: "director_001",
        status: "active",
        studentsCount: 28,
        subjectsCount: 0,
        configurationStatus: {
          hasSubjects: false,
          hasTeacher: true,
          hasSchedule: false,
          hasStudents: true,
          isComplete: false,
          completionPercentage: 25,
        },
      },
      {
        id: "course_urgent_2",
        name: "5to B",
        grade: "5to",
        level: "Primaria",
        modality: "Regular",
        section: "B",
        turn: "Tarde",
        capacity: 25,
        teacher: "",
        schoolYear: "2024-2025",
        notes: "Requiere asignación de docente",
        createdAt: "2024-01-10T14:30:00Z",
        createdBy: "director_001",
        status: "active",
        studentsCount: 0,
        subjectsCount: 0,
        configurationStatus: {
          hasSubjects: false,
          hasTeacher: false,
          hasSchedule: false,
          hasStudents: false,
          isComplete: false,
          completionPercentage: 0,
        },
      },
      {
        id: "course_partial_1",
        name: "4to A",
        grade: "4to",
        level: "Primaria",
        modality: "Regular",
        section: "A",
        turn: "Mañana",
        capacity: 28,
        teacher: "Carlos Mendoza",
        schoolYear: "2024-2025",
        notes: "Materias parcialmente configuradas",
        createdAt: "2024-01-08T09:15:00Z",
        createdBy: "director_001",
        status: "active",
        studentsCount: 26,
        subjectsCount: 4,
        configurationStatus: {
          hasSubjects: true,
          hasTeacher: true,
          hasSchedule: false,
          hasStudents: true,
          isComplete: false,
          completionPercentage: 60,
        },
      },
      {
        id: "course_ready_1",
        name: "3ro A",
        grade: "3ro",
        level: "Primaria",
        modality: "Regular",
        section: "A",
        turn: "Mañana",
        capacity: 30,
        teacher: "María González",
        schoolYear: "2024-2025",
        notes: "Configuración completa, listo para horarios",
        createdAt: "2024-01-05T10:00:00Z",
        createdBy: "director_001",
        status: "active",
        studentsCount: 29,
        subjectsCount: 8,
        configurationStatus: {
          hasSubjects: true,
          hasTeacher: true,
          hasSchedule: false,
          hasStudents: true,
          isComplete: false,
          completionPercentage: 85,
        },
      },
      {
        id: "course_complete_1",
        name: "2do A",
        grade: "2do",
        level: "Primaria",
        modality: "Regular",
        section: "A",
        turn: "Mañana",
        capacity: 25,
        teacher: "Luis Pérez",
        schoolYear: "2024-2025",
        notes: "Curso completamente configurado con horario",
        createdAt: "2024-01-03T11:30:00Z",
        createdBy: "director_001",
        status: "active",
        studentsCount: 24,
        subjectsCount: 7,
        configurationStatus: {
          hasSubjects: true,
          hasTeacher: true,
          hasSchedule: true,
          hasStudents: true,
          isComplete: true,
          completionPercentage: 100,
        },
      },
      {
        id: "course_secondary_1",
        name: "1ro Bachillerato A",
        grade: "1ro Bachillerato",
        level: "Secundaria",
        modality: "Regular",
        section: "A",
        turn: "Mañana",
        capacity: 35,
        teacher: "Elena Vásquez",
        schoolYear: "2024-2025",
        notes: "Bachillerato con materias especializadas",
        createdAt: "2024-01-12T08:45:00Z",
        createdBy: "director_001",
        status: "active",
        studentsCount: 32,
        subjectsCount: 12,
        configurationStatus: {
          hasSubjects: true,
          hasTeacher: true,
          hasSchedule: false,
          hasStudents: true,
          isComplete: false,
          completionPercentage: 75,
        },
      },
    ]

    setCourses(mockCourses)
    setFilteredCourses(mockCourses)
  }, [])

  // Filtrar cursos
  useEffect(() => {
    const filtered = courses.filter((course) => {
      const matchesSearch =
        course.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        course.grade.toLowerCase().includes(searchTerm.toLowerCase()) ||
        course.teacher.toLowerCase().includes(searchTerm.toLowerCase())

      const matchesStatus =
        statusFilter === "all" ||
        (statusFilter === "urgent" && !course.configurationStatus.hasSubjects) ||
        (statusFilter === "partial" &&
          course.configurationStatus.hasSubjects &&
          !course.configurationStatus.hasSchedule) ||
        (statusFilter === "complete" && course.configurationStatus.isComplete)

      const matchesLevel = levelFilter === "all" || course.level === levelFilter
      const matchesTurn = turnFilter === "all" || course.turn === turnFilter

      return matchesSearch && matchesStatus && matchesLevel && matchesTurn
    })

    setFilteredCourses(filtered)
  }, [courses, searchTerm, statusFilter, levelFilter, turnFilter])

  // Estadísticas calculadas
  const stats = {
    total: courses.length,
    urgent: courses.filter((c) => !c.configurationStatus.hasSubjects).length,
    partial: courses.filter((c) => c.configurationStatus.hasSubjects && !c.configurationStatus.hasSchedule).length,
    complete: courses.filter((c) => c.configurationStatus.isComplete).length,
    withoutTeacher: courses.filter((c) => !c.teacher).length,
    averageProgress: Math.round(
      courses.reduce((sum, c) => sum + c.configurationStatus.completionPercentage, 0) / courses.length,
    ),
  }

  // Agrupar cursos por prioridad
  const urgentCourses = filteredCourses.filter((c) => !c.configurationStatus.hasSubjects)
  const partialCourses = filteredCourses.filter(
    (c) => c.configurationStatus.hasSubjects && !c.configurationStatus.hasSchedule,
  )
  const readyCourses = filteredCourses.filter(
    (c) =>
      c.configurationStatus.hasSubjects &&
      !c.configurationStatus.hasSchedule &&
      c.configurationStatus.completionPercentage >= 75,
  )
  const completeCourses = filteredCourses.filter((c) => c.configurationStatus.isComplete)

  const handleConfigureSubjects = (course: Course) => {
    setSelectedCourse(course)
    setIsFullConfiguratorOpen(true)
  }

  const handleViewDetails = (course: Course) => {
    setSelectedCourse(course)
    setIsDetailsOpen(true)
  }

  const handleCreateSchedule = (course: Course) => {
    // Verificar si el curso tiene materias configuradas
    if (!course.configurationStatus.hasSubjects || course.subjectsCount === 0) {
      alert("Este curso necesita tener materias configuradas antes de crear un horario.")
      return
    }

    setSelectedCourseForSchedule(course)
    setScheduleCreationStep(1)

    // Configurar valores por defecto según el turno del curso
    const defaultConfig = {
      ...scheduleConfig,
      shift: course.turn,
      startTime: course.turn === "Mañana" ? "08:00" : course.turn === "Tarde" ? "13:30" : "08:00",
      endTime: course.turn === "Mañana" ? "13:00" : course.turn === "Tarde" ? "18:30" : "16:30",
    }

    setScheduleConfig(defaultConfig)
    setIsCreateScheduleOpen(true)
  }

  const handleSendReminder = async (course: Course) => {
    setIsLoading(true)
    // Simular envío de recordatorio
    await new Promise((resolve) => setTimeout(resolve, 1000))
    alert(`Recordatorio enviado para configurar el curso ${course.name}`)
    setIsLoading(false)
  }

  const handleRefresh = async () => {
    setIsLoading(true)
    // Simular actualización de datos
    await new Promise((resolve) => setTimeout(resolve, 1500))
    alert("Datos actualizados correctamente")
    setIsLoading(false)
  }

  const handleSubjectsConfigured = async (courseId: string, config: { subjects: any[]; teacher: any }) => {
    try {
      // Actualizar el estado del curso
      await CourseInteroperabilityService.updateCourseConfiguration(
        courseId,
        { hasSubjects: true, hasTeacher: true },
        "coordinador-academico",
      )

      // Actualizar la lista local
      setCourses((prevCourses) =>
        prevCourses.map((course) =>
          course.id === courseId
            ? {
                ...course,
                subjectsCount: config.subjects.length,
                teacher: config.teacher.name,
                configurationStatus: {
                  ...course.configurationStatus,
                  hasSubjects: true,
                  hasTeacher: true,
                  completionPercentage: CourseInteroperabilityService.calculateCompletionPercentage({
                    ...course,
                    configurationStatus: {
                      ...course.configurationStatus,
                      hasSubjects: true,
                      hasTeacher: true,
                    },
                  }),
                },
              }
            : course,
        ),
      )

      setIsFullConfiguratorOpen(false)
      setSelectedCourse(null)
    } catch (error) {
      console.error("Error actualizando configuración:", error)
    }
  }

  const handleCancelConfiguration = () => {
    setIsFullConfiguratorOpen(false)
    setSelectedCourse(null)
  }

  const proceedWithScheduleCreation = () => {
    if (!selectedCourseForSchedule) return

    if (scheduleCreationStep < 3) {
      setScheduleCreationStep(scheduleCreationStep + 1)
    } else {
      // Crear horario
      console.log("Creando horario con configuración:", {
        course: selectedCourseForSchedule,
        config: scheduleConfig,
      })

      // Simular creación exitosa
      alert(`Horario creado exitosamente para ${selectedCourseForSchedule.name}`)

      // Actualizar estado del curso
      setCourses((prevCourses) =>
        prevCourses.map((course) =>
          course.id === selectedCourseForSchedule.id
            ? {
                ...course,
                configurationStatus: {
                  ...course.configurationStatus,
                  hasSchedule: true,
                  isComplete: true,
                  completionPercentage: 100,
                },
              }
            : course,
        ),
      )

      // Cerrar diálogo
      setIsCreateScheduleOpen(false)
      setSelectedCourseForSchedule(null)
      setScheduleCreationStep(1)
    }
  }

  const getStatusBadge = (course: Course) => {
    if (course.configurationStatus.isComplete) {
      return <Badge className="bg-green-100 text-green-800">✅ Completo</Badge>
    } else if (course.configurationStatus.hasSubjects) {
      return <Badge className="bg-yellow-100 text-yellow-800">⚠️ Parcial</Badge>
    } else {
      return <Badge className="bg-red-100 text-red-800">🚨 Urgente</Badge>
    }
  }

  const getCardClassName = (course: Course) => {
    if (course.configurationStatus.isComplete) {
      return "border-green-200 bg-green-50"
    } else if (course.configurationStatus.hasSubjects) {
      return "border-yellow-200 bg-yellow-50"
    } else {
      return "border-red-200 bg-red-50"
    }
  }

  const renderScheduleCreationDialog = () => {
    if (!selectedCourseForSchedule) return null

    return (
      <Dialog open={isCreateScheduleOpen} onOpenChange={setIsCreateScheduleOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5 text-blue-600" />
              Crear Horario - {selectedCourseForSchedule.name}
            </DialogTitle>
            <DialogDescription>Paso {scheduleCreationStep} de 3: Configuración del horario académico</DialogDescription>
          </DialogHeader>

          <div className="space-y-6">
            {/* Indicador de progreso */}
            <div className="flex items-center space-x-2">
              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                  scheduleCreationStep >= 1 ? "bg-blue-600 text-white" : "bg-gray-200 text-gray-600"
                }`}
              >
                1
              </div>
              <div className={`flex-1 h-1 ${scheduleCreationStep >= 2 ? "bg-blue-600" : "bg-gray-200"}`} />
              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                  scheduleCreationStep >= 2 ? "bg-blue-600 text-white" : "bg-gray-200 text-gray-600"
                }`}
              >
                2
              </div>
              <div className={`flex-1 h-1 ${scheduleCreationStep >= 3 ? "bg-blue-600" : "bg-gray-200"}`} />
              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                  scheduleCreationStep >= 3 ? "bg-blue-600 text-white" : "bg-gray-200 text-gray-600"
                }`}
              >
                3
              </div>
            </div>

            {/* Contenido por paso */}
            {scheduleCreationStep === 1 && (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Información del Curso</h3>
                <div className="grid grid-cols-2 gap-4 p-4 bg-gray-50 rounded-lg">
                  <div>
                    <label className="text-sm font-medium text-gray-600">Curso</label>
                    <p className="text-lg font-semibold">{selectedCourseForSchedule.name}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-600">Turno</label>
                    <p className="text-lg">{selectedCourseForSchedule.turn}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-600">Docente</label>
                    <p className="text-lg">{selectedCourseForSchedule.teacher}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-600">Materias</label>
                    <p className="text-lg">{selectedCourseForSchedule.subjectsCount} configuradas</p>
                  </div>
                </div>

                <div className="space-y-3">
                  <label className="text-sm font-medium">Método de Creación</label>
                  <div className="space-y-2">
                    <label className="flex items-center space-x-2">
                      <input
                        type="radio"
                        name="method"
                        value="automatic"
                        checked={scheduleConfig.method === "automatic"}
                        onChange={(e) => setScheduleConfig({ ...scheduleConfig, method: e.target.value })}
                        className="text-blue-600"
                      />
                      <span>🤖 Generación Automática (Recomendado)</span>
                    </label>
                    <label className="flex items-center space-x-2">
                      <input
                        type="radio"
                        name="method"
                        value="manual"
                        checked={scheduleConfig.method === "manual"}
                        onChange={(e) => setScheduleConfig({ ...scheduleConfig, method: e.target.value })}
                        className="text-blue-600"
                      />
                      <span>✏️ Creación Manual</span>
                    </label>
                  </div>
                </div>
              </div>
            )}

            {scheduleCreationStep === 2 && (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Configuración de Horario</h3>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium">Hora de Inicio</label>
                    <Input
                      type="time"
                      value={scheduleConfig.startTime}
                      onChange={(e) => setScheduleConfig({ ...scheduleConfig, startTime: e.target.value })}
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Hora de Fin</label>
                    <Input
                      type="time"
                      value={scheduleConfig.endTime}
                      onChange={(e) => setScheduleConfig({ ...scheduleConfig, endTime: e.target.value })}
                    />
                  </div>
                </div>

                <div>
                  <label className="text-sm font-medium">Bloques por Día</label>
                  <Select
                    value={scheduleConfig.blocksPerDay.toString()}
                    onValueChange={(value) =>
                      setScheduleConfig({ ...scheduleConfig, blocksPerDay: Number.parseInt(value) })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="5">5 bloques</SelectItem>
                      <SelectItem value="6">6 bloques</SelectItem>
                      <SelectItem value="7">7 bloques</SelectItem>
                      <SelectItem value="8">8 bloques</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Opciones Avanzadas</label>
                  <div className="space-y-2">
                    <label className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        checked={scheduleConfig.includeBreaks}
                        onChange={(e) => setScheduleConfig({ ...scheduleConfig, includeBreaks: e.target.checked })}
                        className="text-blue-600"
                      />
                      <span>Incluir recesos automáticamente</span>
                    </label>
                    <label className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        checked={scheduleConfig.avoidConsecutiveBlocks}
                        onChange={(e) =>
                          setScheduleConfig({ ...scheduleConfig, avoidConsecutiveBlocks: e.target.checked })
                        }
                        className="text-blue-600"
                      />
                      <span>Evitar bloques consecutivos de la misma materia</span>
                    </label>
                    <label className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        checked={scheduleConfig.prioritizeComplexSubjects}
                        onChange={(e) =>
                          setScheduleConfig({ ...scheduleConfig, prioritizeComplexSubjects: e.target.checked })
                        }
                        className="text-blue-600"
                      />
                      <span>Priorizar materias complejas en horas tempranas</span>
                    </label>
                  </div>
                </div>
              </div>
            )}

            {scheduleCreationStep === 3 && (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Confirmación</h3>

                <Alert>
                  <CheckCircle className="h-4 w-4" />
                  <AlertDescription>
                    Se creará un horario {scheduleConfig.method === "automatic" ? "automático" : "manual"} para el curso{" "}
                    <strong>{selectedCourseForSchedule.name}</strong> con {selectedCourseForSchedule.subjectsCount}{" "}
                    materias.
                  </AlertDescription>
                </Alert>

                <div className="bg-gray-50 p-4 rounded-lg space-y-2">
                  <h4 className="font-medium">Resumen de Configuración:</h4>
                  <ul className="text-sm space-y-1">
                    <li>• Turno: {selectedCourseForSchedule.turn}</li>
                    <li>
                      • Horario: {scheduleConfig.startTime} - {scheduleConfig.endTime}
                    </li>
                    <li>• Bloques por día: {scheduleConfig.blocksPerDay}</li>
                    <li>• Recesos: {scheduleConfig.includeBreaks ? "Sí" : "No"}</li>
                    <li>• Método: {scheduleConfig.method === "automatic" ? "Automático" : "Manual"}</li>
                  </ul>
                </div>
              </div>
            )}

            {/* Botones de navegación */}
            <div className="flex justify-between pt-4">
              <Button
                variant="outline"
                onClick={() => {
                  if (scheduleCreationStep > 1) {
                    setScheduleCreationStep(scheduleCreationStep - 1)
                  } else {
                    setIsCreateScheduleOpen(false)
                  }
                }}
              >
                {scheduleCreationStep === 1 ? "Cancelar" : "Anterior"}
              </Button>

              <Button onClick={proceedWithScheduleCreation} className="bg-blue-600 hover:bg-blue-700">
                {scheduleCreationStep === 3 ? "Crear Horario" : "Siguiente"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    )
  }

  // Si el configurador está abierto, mostrar solo el configurador
  if (isFullConfiguratorOpen && selectedCourse) {
    return (
      <div className="flex-1 space-y-6 p-6">
        <CourseConfigurationForm
          course={selectedCourse}
          onConfigurationComplete={handleSubjectsConfigured}
          onCancel={handleCancelConfiguration}
        />
      </div>
    )
  }

  return (
    <div className="flex-1 space-y-6 p-6 bg-white">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Gestión de Cursos</h1>
          <p className="text-muted-foreground">
            Administra la configuración académica de todos los cursos creados por el Director
          </p>
        </div>
        <Button onClick={handleRefresh} disabled={isLoading} variant="outline">
          <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? "animate-spin" : ""}`} />
          Actualizar
        </Button>
      </div>

      {/* Estadísticas */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Cursos</CardTitle>
            <BookOpen className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.total}</div>
            <p className="text-xs text-muted-foreground">Progreso promedio: {stats.averageProgress}%</p>
            <Progress value={stats.averageProgress} className="mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Configuración Urgente</CardTitle>
            <AlertTriangle className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{stats.urgent}</div>
            <p className="text-xs text-muted-foreground">Sin materias configuradas</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Configuración Parcial</CardTitle>
            <Clock className="h-4 w-4 text-yellow-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">{stats.partial}</div>
            <p className="text-xs text-muted-foreground">Requieren atención</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Configuración Completa</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{stats.complete}</div>
            <p className="text-xs text-muted-foreground">Listos para uso</p>
          </CardContent>
        </Card>
      </div>

      {/* Filtros y búsqueda */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="h-5 w-5" />
            Filtros y Búsqueda
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-5">
            <div className="relative">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Buscar cursos..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-8"
              />
            </div>

            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Estado" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos los estados</SelectItem>
                <SelectItem value="urgent">🚨 Configuración urgente</SelectItem>
                <SelectItem value="partial">⚠️ Configuración parcial</SelectItem>
                <SelectItem value="complete">✅ Configuración completa</SelectItem>
              </SelectContent>
            </Select>

            <Select value={levelFilter} onValueChange={setLevelFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Nivel" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos los niveles</SelectItem>
                <SelectItem value="Inicial">Inicial</SelectItem>
                <SelectItem value="Primaria">Primaria</SelectItem>
                <SelectItem value="Secundaria">Secundaria</SelectItem>
              </SelectContent>
            </Select>

            <Select value={turnFilter} onValueChange={setTurnFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Turno" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos los turnos</SelectItem>
                <SelectItem value="Mañana">Mañana</SelectItem>
                <SelectItem value="Tarde">Tarde</SelectItem>
                <SelectItem value="Extendida">Extendida</SelectItem>
              </SelectContent>
            </Select>

            <div className="text-sm text-muted-foreground flex items-center">
              Mostrando {filteredCourses.length} de {courses.length} cursos
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Cursos Urgentes */}
      {urgentCourses.length > 0 && (
        <Card className="border-red-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-red-700">
              <AlertTriangle className="h-5 w-5" />🚨 Cursos que Requieren Configuración Urgente ({urgentCourses.length}
              )
            </CardTitle>
            <CardDescription>
              Estos cursos fueron creados por el Director pero aún no tienen materias configuradas.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {urgentCourses.map((course) => (
                <Card key={course.id} className={getCardClassName(course)}>
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">{course.name}</CardTitle>
                      {getStatusBadge(course)}
                    </div>
                    <div className="text-sm text-gray-600 space-y-1">
                      <p>📚 Nivel: {course.level}</p>
                      <p>🕐 Turno: {course.turn}</p>
                      <p>👨‍🏫 Docente: {course.teacher || "Sin asignar"}</p>
                      <p>📊 Materias: {course.subjectsCount}</p>
                      <p>
                        👥 Estudiantes: {course.studentsCount}/{course.capacity}
                      </p>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex items-center justify-between text-sm">
                      <span>Progreso:</span>
                      <span className="font-medium">{course.configurationStatus.completionPercentage}%</span>
                    </div>
                    <Progress value={course.configurationStatus.completionPercentage} />

                    <div className="flex gap-2">
                      <Button
                        onClick={() => handleConfigureSubjects(course)}
                        className="flex-1 bg-red-600 hover:bg-red-700 text-white"
                      >
                        <Settings className="mr-2 h-4 w-4" />
                        Configurar Curso
                      </Button>
                      <Button variant="outline" size="sm" onClick={() => handleViewDetails(course)}>
                        <Eye className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Cursos Listos para Horario */}
      {readyCourses.length > 0 && (
        <Card className="border-blue-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-blue-700">
              <Calendar className="h-5 w-5" />📅 Cursos Listos para Crear Horario ({readyCourses.length})
            </CardTitle>
            <CardDescription>
              Estos cursos tienen materias configuradas y están listos para la creación de horarios.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {readyCourses.map((course) => (
                <Card key={course.id} className={getCardClassName(course)}>
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">{course.name}</CardTitle>
                      {getStatusBadge(course)}
                    </div>
                    <div className="text-sm text-gray-600 space-y-1">
                      <p>📚 Nivel: {course.level}</p>
                      <p>🕐 Turno: {course.turn}</p>
                      <p>👨‍🏫 Docente: {course.teacher}</p>
                      <p>📊 Materias: {course.subjectsCount}</p>
                      <p>
                        👥 Estudiantes: {course.studentsCount}/{course.capacity}
                      </p>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex items-center justify-between text-sm">
                      <span>Progreso:</span>
                      <span className="font-medium">{course.configurationStatus.completionPercentage}%</span>
                    </div>
                    <Progress value={course.configurationStatus.completionPercentage} />

                    <div className="flex gap-2">
                      <Button
                        onClick={() => handleCreateSchedule(course)}
                        className="flex-1 bg-blue-600 hover:bg-blue-700 text-white"
                      >
                        <Calendar className="mr-2 h-4 w-4" />
                        Crear Horario
                      </Button>
                      <Button variant="outline" size="sm" onClick={() => handleViewDetails(course)}>
                        <Eye className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Cursos con Configuración Parcial */}
      {partialCourses.length > 0 && (
        <Card className="border-yellow-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-yellow-700">
              <Clock className="h-5 w-5" />
              ⚠️ Cursos con Configuración Parcial ({partialCourses.length})
            </CardTitle>
            <CardDescription>
              Estos cursos tienen materias configuradas pero requieren ajustes adicionales.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {partialCourses.map((course) => (
                <Card key={course.id} className={getCardClassName(course)}>
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">{course.name}</CardTitle>
                      {getStatusBadge(course)}
                    </div>
                    <div className="text-sm text-gray-600 space-y-1">
                      <p>📚 Nivel: {course.level}</p>
                      <p>🕐 Turno: {course.turn}</p>
                      <p>👨‍🏫 Docente: {course.teacher}</p>
                      <p>📊 Materias: {course.subjectsCount}</p>
                      <p>
                        👥 Estudiantes: {course.studentsCount}/{course.capacity}
                      </p>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex items-center justify-between text-sm">
                      <span>Progreso:</span>
                      <span className="font-medium">{course.configurationStatus.completionPercentage}%</span>
                    </div>
                    <Progress value={course.configurationStatus.completionPercentage} />

                    <div className="flex gap-2">
                      {course.configurationStatus.completionPercentage >= 75 ? (
                        <Button
                          onClick={() => handleCreateSchedule(course)}
                          className="flex-1 bg-blue-600 hover:bg-blue-700 text-white"
                        >
                          <Calendar className="mr-2 h-4 w-4" />
                          Crear Horario
                        </Button>
                      ) : (
                        <Button
                          onClick={() => handleConfigureSubjects(course)}
                          className="flex-1 bg-yellow-600 hover:bg-yellow-700 text-white"
                        >
                          <Settings className="mr-2 h-4 w-4" />
                          Completar Config.
                        </Button>
                      )}
                      <Button variant="outline" size="sm" onClick={() => handleViewDetails(course)}>
                        <Eye className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Cursos Completamente Configurados */}
      {completeCourses.length > 0 && (
        <Card className="border-green-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-green-700">
              <CheckCircle className="h-5 w-5" />✅ Cursos Completamente Configurados ({completeCourses.length})
            </CardTitle>
            <CardDescription>Estos cursos están completamente configurados y operativos.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {completeCourses.map((course) => (
                <Card key={course.id} className={getCardClassName(course)}>
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">{course.name}</CardTitle>
                      {getStatusBadge(course)}
                    </div>
                    <div className="text-sm text-gray-600 space-y-1">
                      <p>📚 Nivel: {course.level}</p>
                      <p>🕐 Turno: {course.turn}</p>
                      <p>👨‍🏫 Docente: {course.teacher}</p>
                      <p>📊 Materias: {course.subjectsCount}</p>
                      <p>
                        👥 Estudiantes: {course.studentsCount}/{course.capacity}
                      </p>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex items-center justify-between text-sm">
                      <span>Progreso:</span>
                      <span className="font-medium text-green-600">100%</span>
                    </div>
                    <Progress value={100} className="bg-green-100" />

                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        className="flex-1 bg-transparent"
                        onClick={() => handleViewDetails(course)}
                      >
                        <Eye className="mr-2 h-4 w-4" />
                        Ver Detalles
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleSendReminder(course)}
                        disabled={isLoading}
                      >
                        <Mail className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Mensaje cuando no hay cursos */}
      {filteredCourses.length === 0 && (
        <Card>
          <CardContent className="text-center py-12">
            <BookOpen className="h-12 w-12 mx-auto text-gray-400 mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">No se encontraron cursos</h3>
            <p className="text-gray-600 mb-4">
              {courses.length === 0
                ? "Aún no hay cursos creados por el Director."
                : "No hay cursos que coincidan con los filtros seleccionados."}
            </p>
            {courses.length === 0 && (
              <Button variant="outline" onClick={handleRefresh}>
                <RefreshCw className="mr-2 h-4 w-4" />
                Actualizar Lista
              </Button>
            )}
          </CardContent>
        </Card>
      )}

      {/* Diálogos */}
      {selectedCourse && (
        <CourseSubjectsConfigurator
          isOpen={isConfiguratorOpen}
          onClose={() => {
            setIsConfiguratorOpen(false)
            setSelectedCourse(null)
          }}
          course={selectedCourse}
          onSubjectsConfigured={handleSubjectsConfigured}
        />
      )}

      {/* Diálogo de detalles del curso */}
      <Dialog open={isDetailsOpen} onOpenChange={setIsDetailsOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Detalles del Curso - {selectedCourse?.name}</DialogTitle>
            <DialogDescription>Información completa del curso y su estado de configuración</DialogDescription>
          </DialogHeader>
          {selectedCourse && (
            <div className="space-y-4">
              <CourseStatusCard course={selectedCourse} />
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h4 className="font-semibold mb-2">Información General</h4>
                  <div className="space-y-1 text-sm">
                    <p>
                      <strong>Nivel:</strong> {selectedCourse.level}
                    </p>
                    <p>
                      <strong>Modalidad:</strong> {selectedCourse.modality}
                    </p>
                    <p>
                      <strong>Año Escolar:</strong> {selectedCourse.schoolYear}
                    </p>
                    <p>
                      <strong>Creado:</strong> {new Date(selectedCourse.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Estado de Configuración</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2">
                      {selectedCourse.configurationStatus.hasSubjects ? (
                        <CheckCircle className="h-4 w-4 text-green-600" />
                      ) : (
                        <AlertTriangle className="h-4 w-4 text-red-600" />
                      )}
                      <span>Materias configuradas</span>
                    </div>
                    <div className="flex items-center gap-2">
                      {selectedCourse.configurationStatus.hasTeacher ? (
                        <CheckCircle className="h-4 w-4 text-green-600" />
                      ) : (
                        <AlertTriangle className="h-4 w-4 text-red-600" />
                      )}
                      <span>Docente asignado</span>
                    </div>
                    <div className="flex items-center gap-2">
                      {selectedCourse.configurationStatus.hasSchedule ? (
                        <CheckCircle className="h-4 w-4 text-green-600" />
                      ) : (
                        <Clock className="h-4 w-4 text-yellow-600" />
                      )}
                      <span>Horario creado</span>
                    </div>
                  </div>
                </div>
              </div>
              {selectedCourse.notes && (
                <div>
                  <h4 className="font-semibold mb-2">Notas</h4>
                  <p className="text-sm text-gray-600 bg-gray-50 p-3 rounded">{selectedCourse.notes}</p>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Diálogo de creación de horario */}
      {renderScheduleCreationDialog()}
    </div>
  )
}
