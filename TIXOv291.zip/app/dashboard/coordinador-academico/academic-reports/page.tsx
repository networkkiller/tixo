"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  BarChart3,
  Download,
  FileText,
  Filter,
  LineChart,
  PieChart,
  Plus,
  Search,
  Share2,
  TrendingUp,
} from "lucide-react"

export default function AcademicReportsPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [filterType, setFilterType] = useState("all")
  const [filterDate, setFilterDate] = useState("all")

  // Datos de ejemplo para reportes
  const reports = [
    {
      id: 1,
      title: "Rendimiento Académico por Grado",
      type: "performance",
      date: "2023-07-15",
      author: "Patricia Morales",
      description: "Análisis comparativo del rendimiento académico por grado y materia",
      downloads: 24,
      chartType: "bar",
    },
    {
      id: 2,
      title: "Cobertura Curricular Trimestral",
      type: "curriculum",
      date: "2023-07-10",
      author: "Sistema",
      description: "Reporte de avance en la cobertura curricular por materia y grado",
      downloads: 18,
      chartType: "pie",
    },
    {
      id: 3,
      title: "Distribución de Carga Docente",
      type: "teachers",
      date: "2023-07-05",
      author: "Patricia Morales",
      description: "Análisis de la distribución de horas y materias por docente",
      downloads: 12,
      chartType: "bar",
    },
    {
      id: 4,
      title: "Análisis de Horarios y Espacios",
      type: "schedules",
      date: "2023-06-28",
      author: "Sistema",
      description: "Utilización de aulas y espacios según horarios establecidos",
      downloads: 9,
      chartType: "line",
    },
    {
      id: 5,
      title: "Tendencias de Rendimiento Anual",
      type: "performance",
      date: "2023-06-20",
      author: "Patricia Morales",
      description: "Comparativa de rendimiento académico en los últimos 3 años",
      downloads: 31,
      chartType: "line",
    },
    {
      id: 6,
      title: "Análisis de Materias Críticas",
      type: "curriculum",
      date: "2023-06-15",
      author: "Sistema",
      description: "Identificación de materias con mayor índice de reprobación",
      downloads: 27,
      chartType: "pie",
    },
  ]

  // Plantillas de reportes
  const reportTemplates = [
    {
      id: 1,
      title: "Rendimiento por Grado",
      description: "Análisis comparativo entre grados",
      type: "performance",
      chartType: "bar",
    },
    {
      id: 2,
      title: "Cobertura Curricular",
      description: "Avance en el currículo por materia",
      type: "curriculum",
      chartType: "pie",
    },
    {
      id: 3,
      title: "Carga Docente",
      description: "Distribución de horas por docente",
      type: "teachers",
      chartType: "bar",
    },
    {
      id: 4,
      title: "Uso de Espacios",
      description: "Utilización de aulas y laboratorios",
      type: "schedules",
      chartType: "heat",
    },
  ]

  // Datos para análisis
  const analyticsData = [
    {
      id: 1,
      title: "Promedio General",
      value: "78.5",
      trend: "+2.3%",
      isPositive: true,
    },
    {
      id: 2,
      title: "Materias Críticas",
      value: "3",
      trend: "-1",
      isPositive: true,
    },
    {
      id: 3,
      title: "Cobertura Curricular",
      value: "87%",
      trend: "+5%",
      isPositive: true,
    },
    {
      id: 4,
      title: "Asistencia Promedio",
      value: "92%",
      trend: "-1.5%",
      isPositive: false,
    },
  ]

  // Filtrar reportes basados en los criterios de búsqueda y filtros
  const filteredReports = reports.filter((report) => {
    const matchesSearch =
      report.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      report.description.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesType = filterType === "all" || report.type === filterType
    const matchesDate =
      filterDate === "all" ||
      (filterDate === "recent" && new Date(report.date) >= new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)) ||
      (filterDate === "older" && new Date(report.date) < new Date(Date.now() - 7 * 24 * 60 * 60 * 1000))

    return matchesSearch && matchesType && matchesDate
  })

  // Función para obtener el icono según el tipo de gráfico
  const getChartIcon = (chartType: string) => {
    switch (chartType) {
      case "bar":
        return <BarChart3 className="h-4 w-4" />
      case "pie":
        return <PieChart className="h-4 w-4" />
      case "line":
        return <LineChart className="h-4 w-4" />
      default:
        return <BarChart3 className="h-4 w-4" />
    }
  }

  // Función para obtener el color de la insignia según el tipo de reporte
  const getTypeBadge = (type: string) => {
    switch (type) {
      case "performance":
        return <Badge className="bg-blue-500">Rendimiento</Badge>
      case "curriculum":
        return <Badge className="bg-green-500">Curricular</Badge>
      case "teachers":
        return <Badge className="bg-purple-500">Docentes</Badge>
      case "schedules":
        return <Badge className="bg-orange-500">Horarios</Badge>
      default:
        return <Badge variant="outline">Otro</Badge>
    }
  }

  return (
    <div className="flex-1 space-y-6 p-6 bg-white">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Reportes Académicos</h1>
          <p className="text-muted-foreground">Genera y analiza reportes sobre el desempeño académico institucional</p>
        </div>
        <Button className="bg-blue-600 hover:bg-blue-700">
          <Plus className="mr-2 h-4 w-4" /> Nuevo Reporte
        </Button>
      </div>

      {/* Tabs */}
      <Tabs defaultValue="existing" className="space-y-4">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="existing">Reportes Existentes</TabsTrigger>
          <TabsTrigger value="generate">Generar Nuevo</TabsTrigger>
          <TabsTrigger value="analytics">Análisis</TabsTrigger>
        </TabsList>

        {/* Pestaña de Reportes Existentes */}
        <TabsContent value="existing" className="space-y-4">
          {/* Filtros */}
          <div className="flex flex-wrap items-center gap-2">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Buscar reportes..."
                className="pl-8"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>

            <Select value={filterType} onValueChange={setFilterType}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Tipo de Reporte" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos los Tipos</SelectItem>
                <SelectItem value="performance">Rendimiento</SelectItem>
                <SelectItem value="curriculum">Curricular</SelectItem>
                <SelectItem value="teachers">Docentes</SelectItem>
                <SelectItem value="schedules">Horarios</SelectItem>
              </SelectContent>
            </Select>

            <Select value={filterDate} onValueChange={setFilterDate}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Fecha" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas las Fechas</SelectItem>
                <SelectItem value="recent">Últimos 7 días</SelectItem>
                <SelectItem value="older">Más antiguos</SelectItem>
              </SelectContent>
            </Select>

            <Button variant="outline" size="icon">
              <Filter className="h-4 w-4" />
            </Button>
          </div>

          {/* Lista de Reportes */}
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {filteredReports.map((report) => (
              <Card key={report.id} className="overflow-hidden">
                <CardHeader className="pb-2">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center space-x-2">
                      {getChartIcon(report.chartType)}
                      <CardTitle className="text-lg">{report.title}</CardTitle>
                    </div>
                    {getTypeBadge(report.type)}
                  </div>
                  <CardDescription>
                    Creado: {report.date} por {report.author}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">{report.description}</p>
                </CardContent>
                <CardFooter className="flex justify-between border-t bg-muted/50 px-6 py-3">
                  <div className="text-xs text-muted-foreground">{report.downloads} descargas</div>
                  <div className="flex space-x-2">
                    <Button variant="ghost" size="icon" className="h-8 w-8">
                      <Share2 className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon" className="h-8 w-8">
                      <Download className="h-4 w-4" />
                    </Button>
                  </div>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Pestaña de Generar Nuevo */}
        <TabsContent value="generate" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Generar Nuevo Reporte</CardTitle>
              <CardDescription>Selecciona una plantilla o crea un reporte personalizado</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <label className="text-sm font-medium">Título del Reporte</label>
                  <Input placeholder="Ingresa un título para el reporte" />
                </div>
                <div>
                  <label className="text-sm font-medium">Tipo de Reporte</label>
                  <Select defaultValue="performance">
                    <SelectTrigger>
                      <SelectValue placeholder="Selecciona un tipo" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="performance">Rendimiento</SelectItem>
                      <SelectItem value="curriculum">Curricular</SelectItem>
                      <SelectItem value="teachers">Docentes</SelectItem>
                      <SelectItem value="schedules">Horarios</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <label className="text-sm font-medium">Descripción</label>
                <Input placeholder="Breve descripción del reporte" />
              </div>

              <div>
                <label className="text-sm font-medium">Parámetros</label>
                <div className="grid gap-4 md:grid-cols-2 mt-2">
                  <Select defaultValue="all">
                    <SelectTrigger>
                      <SelectValue placeholder="Grado" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos los Grados</SelectItem>
                      <SelectItem value="1">1ro Bachillerato</SelectItem>
                      <SelectItem value="2">2do Bachillerato</SelectItem>
                      <SelectItem value="3">3ro Bachillerato</SelectItem>
                    </SelectContent>
                  </Select>

                  <Select defaultValue="all">
                    <SelectTrigger>
                      <SelectValue placeholder="Materia" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todas las Materias</SelectItem>
                      <SelectItem value="math">Matemáticas</SelectItem>
                      <SelectItem value="science">Ciencias</SelectItem>
                      <SelectItem value="language">Lenguaje</SelectItem>
                    </SelectContent>
                  </Select>

                  <Select defaultValue="current">
                    <SelectTrigger>
                      <SelectValue placeholder="Período" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="current">Período Actual</SelectItem>
                      <SelectItem value="last">Período Anterior</SelectItem>
                      <SelectItem value="year">Año Completo</SelectItem>
                    </SelectContent>
                  </Select>

                  <Select defaultValue="bar">
                    <SelectTrigger>
                      <SelectValue placeholder="Tipo de Gráfico" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="bar">Barras</SelectItem>
                      <SelectItem value="line">Líneas</SelectItem>
                      <SelectItem value="pie">Circular</SelectItem>
                      <SelectItem value="table">Tabla</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline">Cancelar</Button>
              <Button className="bg-blue-600 hover:bg-blue-700">Generar Reporte</Button>
            </CardFooter>
          </Card>

          <h3 className="text-lg font-medium mt-6">Plantillas Disponibles</h3>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            {reportTemplates.map((template) => (
              <Card key={template.id} className="cursor-pointer hover:border-blue-300 transition-colors">
                <CardHeader className="pb-2">
                  <div className="flex items-center space-x-2">
                    {getChartIcon(template.chartType)}
                    <CardTitle className="text-base">{template.title}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">{template.description}</p>
                </CardContent>
                <CardFooter className="pt-0">
                  <Button variant="ghost" className="w-full justify-start p-2 h-auto">
                    <FileText className="mr-2 h-4 w-4" />
                    <span>Usar Plantilla</span>
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Pestaña de Análisis */}
        <TabsContent value="analytics" className="space-y-6">
          {/* Métricas Principales */}
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            {analyticsData.map((item) => (
              <Card key={item.id}>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">{item.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{item.value}</div>
                  <div className={`flex items-center text-xs ${item.isPositive ? "text-green-500" : "text-red-500"}`}>
                    <TrendingUp className="mr-1 h-3 w-3" />
                    <span>{item.trend} vs período anterior</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Gráficos de Análisis */}
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Rendimiento por Grado</CardTitle>
                <CardDescription>Promedio general por grado en el período actual</CardDescription>
              </CardHeader>
              <CardContent className="p-6">
                <div className="aspect-[4/3] bg-muted rounded-md flex items-center justify-center">
                  <BarChart3 className="h-16 w-16 text-muted-foreground/50" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Distribución de Calificaciones</CardTitle>
                <CardDescription>Distribución de notas por rango</CardDescription>
              </CardHeader>
              <CardContent className="p-6">
                <div className="aspect-[4/3] bg-muted rounded-md flex items-center justify-center">
                  <PieChart className="h-16 w-16 text-muted-foreground/50" />
                </div>
              </CardContent>
            </Card>

            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle>Tendencia de Rendimiento</CardTitle>
                <CardDescription>Evolución del rendimiento académico en los últimos 3 períodos</CardDescription>
              </CardHeader>
              <CardContent className="p-6">
                <div className="aspect-[21/9] bg-muted rounded-md flex items-center justify-center">
                  <LineChart className="h-16 w-16 text-muted-foreground/50" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Acciones de Análisis */}
          <div className="flex flex-wrap gap-2">
            <Button className="bg-blue-600 hover:bg-blue-700">
              <Download className="mr-2 h-4 w-4" /> Exportar Análisis
            </Button>
            <Button variant="outline">
              <Share2 className="mr-2 h-4 w-4" /> Compartir Dashboard
            </Button>
            <Button variant="outline">
              <FileText className="mr-2 h-4 w-4" /> Generar Informe Completo
            </Button>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
