import { Skeleton } from "@/components/ui/skeleton"

export default function AcademicReportsLoading() {
  return (
    <div className="flex-1 space-y-6 p-6 bg-white">
      {/* Header Skeleton */}
      <div className="flex items-center justify-between">
        <div>
          <Skeleton className="h-8 w-[300px]" />
          <Skeleton className="h-4 w-[250px] mt-2" />
        </div>
        <Skeleton className="h-10 w-[180px]" />
      </div>

      {/* Tabs Skeleton */}
      <div className="space-y-4">
        <Skeleton className="h-10 w-full" />

        {/* Filters Skeleton */}
        <div className="flex flex-wrap items-center gap-2">
          <Skeleton className="h-10 flex-1 min-w-[200px]" />
          <Skeleton className="h-10 w-[180px]" />
          <Skeleton className="h-10 w-[180px]" />
          <Skeleton className="h-10 w-10" />
        </div>

        {/* Cards Skeleton */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <div key={i} className="rounded-lg border bg-card text-card-foreground shadow-sm overflow-hidden">
              <div className="p-6 pb-2">
                <div className="flex items-start justify-between">
                  <div className="flex items-center space-x-2">
                    <Skeleton className="h-4 w-4" />
                    <Skeleton className="h-6 w-[150px]" />
                  </div>
                  <Skeleton className="h-6 w-[80px]" />
                </div>
                <Skeleton className="h-4 w-[180px] mt-1" />
              </div>
              <div className="p-6">
                <Skeleton className="h-4 w-full" />
              </div>
              <div className="flex justify-between border-t bg-muted/50 px-6 py-3">
                <Skeleton className="h-4 w-[80px]" />
                <div className="flex space-x-2">
                  <Skeleton className="h-8 w-8" />
                  <Skeleton className="h-8 w-8" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
