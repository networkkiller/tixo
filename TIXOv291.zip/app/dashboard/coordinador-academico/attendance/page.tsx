"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Users,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Edit,
  Download,
  Upload,
  RefreshCw,
  Eye,
  Bell,
  UserCheck,
  UserX,
  ClockIcon,
} from "lucide-react"
import { format } from "date-fns"
import { es } from "date-fns/locale"

interface Teacher {
  id: string
  name: string
  courses: string[]
  shift: "Mañana" | "Tarde" | "Tanda Extendida"
  status: "Presente" | "Ausente" | "Justificado" | "Tarde" | "Sin marcar"
  arrivalTime?: string
  observations?: string
  absenceCount: number
  lastUpdated?: string
}

interface AttendanceRecord {
  id: string
  teacherId: string
  date: string
  status: "Presente" | "Ausente" | "Justificado" | "Tarde"
  arrivalTime?: string
  observations?: string
  notifyDirector: boolean
  registeredBy: string
  registeredAt: string
}

export default function TeacherAttendancePage() {
  const [selectedDate, setSelectedDate] = useState(format(new Date(), "yyyy-MM-dd"))
  const [filterCourse, setFilterCourse] = useState("all")
  const [filterShift, setFilterShift] = useState("all")
  const [filterStatus, setFilterStatus] = useState("all")
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedTeacher, setSelectedTeacher] = useState<Teacher | null>(null)
  const [isAttendanceModalOpen, setIsAttendanceModalOpen] = useState(false)
  const [isSubstitutionModalOpen, setIsSubstitutionModalOpen] = useState(false)
  const [isBulkModalOpen, setIsBulkModalOpen] = useState(false)
  const [viewMode, setViewMode] = useState<"daily" | "weekly">("daily")

  // Datos de ejemplo
  const [teachers, setTeachers] = useState<Teacher[]>([
    {
      id: "1",
      name: "María Pérez",
      courses: ["5to A", "6to B"],
      shift: "Mañana",
      status: "Presente",
      observations: "",
      absenceCount: 0,
      lastUpdated: "08:00",
    },
    {
      id: "2",
      name: "Juan Gómez",
      courses: ["3ro B"],
      shift: "Tarde",
      status: "Ausente",
      observations: "Licencia médica",
      absenceCount: 2,
      lastUpdated: "13:00",
    },
    {
      id: "3",
      name: "Luis Lara",
      courses: ["2do A"],
      shift: "Tanda Extendida",
      status: "Tarde",
      arrivalTime: "08:40",
      observations: "Llegó a las 8:40 AM",
      absenceCount: 1,
      lastUpdated: "08:40",
    },
    {
      id: "4",
      name: "Ana García",
      courses: ["4to A", "4to B"],
      shift: "Mañana",
      status: "Sin marcar",
      observations: "",
      absenceCount: 0,
    },
    {
      id: "5",
      name: "Carlos Mendoza",
      courses: ["1ro A"],
      shift: "Tarde",
      status: "Justificado",
      observations: "Permiso personal autorizado",
      absenceCount: 1,
      lastUpdated: "12:00",
    },
  ])

  const [attendanceForm, setAttendanceForm] = useState({
    status: "",
    arrivalTime: "",
    observations: "",
    notifyDirector: false,
  })

  const courses = [
    "1ro A",
    "1ro B",
    "2do A",
    "2do B",
    "3ro A",
    "3ro B",
    "4to A",
    "4to B",
    "5to A",
    "5to B",
    "6to A",
    "6to B",
  ]
  const shifts = ["Mañana", "Tarde", "Tanda Extendida"]

  // Filtrar docentes
  const filteredTeachers = teachers.filter((teacher) => {
    const matchesSearch =
      teacher.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      teacher.courses.some((course) => course.toLowerCase().includes(searchTerm.toLowerCase()))
    const matchesCourse = filterCourse === "all" || teacher.courses.includes(filterCourse)
    const matchesShift = filterShift === "all" || teacher.shift === filterShift
    const matchesStatus = filterStatus === "all" || teacher.status === filterStatus

    return matchesSearch && matchesCourse && matchesShift && matchesStatus
  })

  // Estadísticas del día
  const stats = {
    total: teachers.length,
    present: teachers.filter((t) => t.status === "Presente").length,
    absent: teachers.filter((t) => t.status === "Ausente").length,
    justified: teachers.filter((t) => t.status === "Justificado").length,
    late: teachers.filter((t) => t.status === "Tarde").length,
    unmarked: teachers.filter((t) => t.status === "Sin marcar").length,
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "Presente":
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case "Ausente":
        return <XCircle className="h-4 w-4 text-red-500" />
      case "Justificado":
        return <UserCheck className="h-4 w-4 text-yellow-500" />
      case "Tarde":
        return <ClockIcon className="h-4 w-4 text-orange-500" />
      default:
        return <UserX className="h-4 w-4 text-gray-400" />
    }
  }

  const getStatusBadge = (status: string) => {
    const variants = {
      Presente: "default",
      Ausente: "destructive",
      Justificado: "secondary",
      Tarde: "outline",
      "Sin marcar": "outline",
    } as const

    return (
      <Badge variant={variants[status as keyof typeof variants] || "outline"}>
        {getStatusIcon(status)}
        <span className="ml-1">{status}</span>
      </Badge>
    )
  }

  const handleMarkAttendance = (teacher: Teacher) => {
    setSelectedTeacher(teacher)
    setAttendanceForm({
      status: teacher.status !== "Sin marcar" ? teacher.status : "",
      arrivalTime: teacher.arrivalTime || "",
      observations: teacher.observations || "",
      notifyDirector: false,
    })
    setIsAttendanceModalOpen(true)
  }

  const handleSaveAttendance = () => {
    if (!selectedTeacher) return

    const updatedTeachers = teachers.map((teacher) => {
      if (teacher.id === selectedTeacher.id) {
        return {
          ...teacher,
          status: attendanceForm.status as Teacher["status"],
          arrivalTime: attendanceForm.arrivalTime,
          observations: attendanceForm.observations,
          lastUpdated: format(new Date(), "HH:mm"),
        }
      }
      return teacher
    })

    setTeachers(updatedTeachers)
    setIsAttendanceModalOpen(false)
    setSelectedTeacher(null)
    setAttendanceForm({
      status: "",
      arrivalTime: "",
      observations: "",
      notifyDirector: false,
    })
  }

  const handleBulkAttendance = (shift: string, status: string) => {
    const updatedTeachers = teachers.map((teacher) => {
      if (teacher.shift === shift && teacher.status === "Sin marcar") {
        return {
          ...teacher,
          status: status as Teacher["status"],
          lastUpdated: format(new Date(), "HH:mm"),
        }
      }
      return teacher
    })

    setTeachers(updatedTeachers)
    setIsBulkModalOpen(false)
  }

  return (
    <div className="flex-1 space-y-6 p-6 bg-white">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Registro de Asistencia Docente</h1>
          <p className="text-muted-foreground">
            Control diario de asistencia del personal docente -{" "}
            {format(new Date(selectedDate), "EEEE, d 'de' MMMM 'de' yyyy", { locale: es })}
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <Button variant="outline" size="sm">
            <Upload className="h-4 w-4 mr-2" />
            Importar CSV
          </Button>
          <Button variant="outline" size="sm">
            <Download className="h-4 w-4 mr-2" />
            Exportar
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Docentes</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.total}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Presentes</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{stats.present}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Ausentes</CardTitle>
            <XCircle className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{stats.absent}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Justificados</CardTitle>
            <UserCheck className="h-4 w-4 text-yellow-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">{stats.justified}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Tardanzas</CardTitle>
            <ClockIcon className="h-4 w-4 text-orange-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">{stats.late}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Sin Marcar</CardTitle>
            <UserX className="h-4 w-4 text-gray-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gray-600">{stats.unmarked}</div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Filtros y Controles</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-6">
            <div>
              <Label htmlFor="date">Fecha</Label>
              <Input id="date" type="date" value={selectedDate} onChange={(e) => setSelectedDate(e.target.value)} />
            </div>

            <div>
              <Label htmlFor="search">Buscar Docente</Label>
              <Input
                id="search"
                placeholder="Nombre o curso..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>

            <div>
              <Label htmlFor="course">Curso</Label>
              <Select value={filterCourse} onValueChange={setFilterCourse}>
                <SelectTrigger>
                  <SelectValue placeholder="Todos los cursos" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos los cursos</SelectItem>
                  {courses.map((course) => (
                    <SelectItem key={course} value={course}>
                      {course}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="shift">Turno</Label>
              <Select value={filterShift} onValueChange={setFilterShift}>
                <SelectTrigger>
                  <SelectValue placeholder="Todos los turnos" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos los turnos</SelectItem>
                  {shifts.map((shift) => (
                    <SelectItem key={shift} value={shift}>
                      {shift}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="status">Estado</Label>
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger>
                  <SelectValue placeholder="Todos los estados" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos los estados</SelectItem>
                  <SelectItem value="Presente">Presente</SelectItem>
                  <SelectItem value="Ausente">Ausente</SelectItem>
                  <SelectItem value="Justificado">Justificado</SelectItem>
                  <SelectItem value="Tarde">Tarde</SelectItem>
                  <SelectItem value="Sin marcar">Sin marcar</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-end">
              <Dialog open={isBulkModalOpen} onOpenChange={setIsBulkModalOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" className="w-full bg-transparent">
                    <Users className="h-4 w-4 mr-2" />
                    Registro Masivo
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Registro Masivo de Asistencia</DialogTitle>
                    <DialogDescription>
                      Marcar asistencia para todos los docentes de un turno específico
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <Label>Seleccionar Turno</Label>
                      <Select>
                        <SelectTrigger>
                          <SelectValue placeholder="Seleccionar turno" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Mañana">Mañana</SelectItem>
                          <SelectItem value="Tarde">Tarde</SelectItem>
                          <SelectItem value="Tanda Extendida">Tanda Extendida</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>Estado a Asignar</Label>
                      <Select>
                        <SelectTrigger>
                          <SelectValue placeholder="Seleccionar estado" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Presente">Presente</SelectItem>
                          <SelectItem value="Ausente">Ausente</SelectItem>
                          <SelectItem value="Justificado">Justificado</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setIsBulkModalOpen(false)}>
                      Cancelar
                    </Button>
                    <Button onClick={() => handleBulkAttendance("Mañana", "Presente")}>Aplicar</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Teachers Table */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Registro de Asistencia - {filteredTeachers.length} docentes</span>
            <div className="flex items-center space-x-2">
              <Button
                variant={viewMode === "daily" ? "default" : "outline"}
                size="sm"
                onClick={() => setViewMode("daily")}
              >
                Vista Diaria
              </Button>
              <Button
                variant={viewMode === "weekly" ? "default" : "outline"}
                size="sm"
                onClick={() => setViewMode("weekly")}
              >
                Vista Semanal
              </Button>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Docente</TableHead>
                <TableHead>Curso(s) Asignado(s)</TableHead>
                <TableHead>Turno</TableHead>
                <TableHead>Estado</TableHead>
                <TableHead>Observaciones</TableHead>
                <TableHead>Última Actualización</TableHead>
                <TableHead>Acciones</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredTeachers.map((teacher) => (
                <TableRow key={teacher.id} className={teacher.absenceCount >= 3 ? "bg-red-50" : ""}>
                  <TableCell className="font-medium">
                    <div className="flex items-center space-x-2">
                      <span>{teacher.name}</span>
                      {teacher.absenceCount >= 3 && (
                        <AlertTriangle className="h-4 w-4 text-red-500" title="3+ ausencias esta semana" />
                      )}
                    </div>
                  </TableCell>
                  <TableCell>{teacher.courses.join(", ")}</TableCell>
                  <TableCell>{teacher.shift}</TableCell>
                  <TableCell>{getStatusBadge(teacher.status)}</TableCell>
                  <TableCell className="max-w-xs truncate">{teacher.observations}</TableCell>
                  <TableCell>{teacher.lastUpdated || "-"}</TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-2">
                      <Button variant="outline" size="sm" onClick={() => handleMarkAttendance(teacher)}>
                        <Edit className="h-4 w-4" />
                      </Button>

                      {(teacher.status === "Ausente" || teacher.status === "Justificado") && (
                        <Dialog open={isSubstitutionModalOpen} onOpenChange={setIsSubstitutionModalOpen}>
                          <DialogTrigger asChild>
                            <Button variant="outline" size="sm" className="text-orange-600 bg-transparent">
                              <RefreshCw className="h-4 w-4" />
                            </Button>
                          </DialogTrigger>
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle>Registrar Sustitución</DialogTitle>
                              <DialogDescription>
                                Crear sustitución para {teacher.name} - {teacher.courses.join(", ")}
                              </DialogDescription>
                            </DialogHeader>
                            <div className="space-y-4">
                              <p className="text-sm text-muted-foreground">
                                Esta acción abrirá el módulo de sustituciones con los datos precargados.
                              </p>
                            </div>
                            <DialogFooter>
                              <Button variant="outline" onClick={() => setIsSubstitutionModalOpen(false)}>
                                Cancelar
                              </Button>
                              <Button onClick={() => setIsSubstitutionModalOpen(false)}>Ir a Sustituciones</Button>
                            </DialogFooter>
                          </DialogContent>
                        </Dialog>
                      )}

                      <Button variant="outline" size="sm">
                        <Eye className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Attendance Modal */}
      <Dialog open={isAttendanceModalOpen} onOpenChange={setIsAttendanceModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Marcar Asistencia</DialogTitle>
            <DialogDescription>
              Registrar asistencia para {selectedTeacher?.name} -{" "}
              {format(new Date(selectedDate), "d 'de' MMMM 'de' yyyy", { locale: es })}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="status">Estado de Asistencia</Label>
              <Select
                value={attendanceForm.status}
                onValueChange={(value) => setAttendanceForm({ ...attendanceForm, status: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Seleccionar estado" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Presente">✅ Presente</SelectItem>
                  <SelectItem value="Ausente">❌ Ausente</SelectItem>
                  <SelectItem value="Justificado">🟡 Justificado</SelectItem>
                  <SelectItem value="Tarde">⚠️ Tarde</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {(attendanceForm.status === "Presente" || attendanceForm.status === "Tarde") && (
              <div>
                <Label htmlFor="arrivalTime">Hora de Llegada</Label>
                <Input
                  id="arrivalTime"
                  type="time"
                  value={attendanceForm.arrivalTime}
                  onChange={(e) => setAttendanceForm({ ...attendanceForm, arrivalTime: e.target.value })}
                />
              </div>
            )}

            <div>
              <Label htmlFor="observations">Observaciones</Label>
              <Textarea
                id="observations"
                placeholder="Comentarios adicionales..."
                value={attendanceForm.observations}
                onChange={(e) => setAttendanceForm({ ...attendanceForm, observations: e.target.value })}
              />
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id="notifyDirector"
                checked={attendanceForm.notifyDirector}
                onCheckedChange={(checked) =>
                  setAttendanceForm({ ...attendanceForm, notifyDirector: checked as boolean })
                }
              />
              <Label htmlFor="notifyDirector" className="flex items-center">
                <Bell className="h-4 w-4 mr-1" />
                Notificar al Director
              </Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAttendanceModalOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={handleSaveAttendance}>Guardar Asistencia</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
