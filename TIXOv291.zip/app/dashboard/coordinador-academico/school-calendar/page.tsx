"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Calendar,
  CalendarDays,
  Clock,
  Plus,
  Search,
  Edit,
  Download,
  Upload,
  AlertCircle,
  CheckCircle,
  BookOpen,
  Users,
} from "lucide-react"

export default function SchoolCalendarPage() {
  const [selectedMonth, setSelectedMonth] = useState("2024-01")
  const [selectedEventType, setSelectedEventType] = useState("all")
  const [searchTerm, setSearchTerm] = useState("")
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)

  const calendarEvents = [
    {
      id: 1,
      title: "Inicio del Período Académico 2024-1",
      description: "Comienzo oficial del primer período académico del año",
      date: "2024-01-15",
      endDate: null,
      type: "academic",
      status: "confirmed",
      participants: "Toda la comunidad educativa",
      location: "Institución",
      priority: "high",
    },
    {
      id: 2,
      title: "Evaluaciones Trimestrales",
      description: "Primera ronda de evaluaciones del período",
      date: "2024-01-22",
      endDate: "2024-01-26",
      type: "evaluation",
      status: "confirmed",
      participants: "Estudiantes y profesores",
      location: "Aulas asignadas",
      priority: "high",
    },
    {
      id: 3,
      title: "Reunión de Coordinación Académica",
      description: "Revisión de planificación curricular y asignaciones",
      date: "2024-01-18",
      endDate: null,
      type: "meeting",
      status: "confirmed",
      participants: "Coordinadores y directivos",
      location: "Sala de reuniones",
      priority: "medium",
    },
    {
      id: 4,
      title: "Día de Desarrollo Profesional",
      description: "Capacitación docente en nuevas metodologías",
      date: "2024-01-29",
      endDate: null,
      type: "training",
      status: "pending",
      participants: "Cuerpo docente",
      location: "Auditorio principal",
      priority: "medium",
    },
    {
      id: 5,
      title: "Entrega de Boletines",
      description: "Distribución de calificaciones del primer trimestre",
      date: "2024-02-02",
      endDate: null,
      type: "administrative",
      status: "pending",
      participants: "Padres y estudiantes",
      location: "Oficina de registro",
      priority: "high",
    },
  ]

  const eventTypes = [
    { value: "academic", label: "Académico", color: "bg-blue-500" },
    { value: "evaluation", label: "Evaluación", color: "bg-purple-500" },
    { value: "meeting", label: "Reunión", color: "bg-green-500" },
    { value: "training", label: "Capacitación", color: "bg-orange-500" },
    { value: "administrative", label: "Administrativo", color: "bg-gray-500" },
    { value: "holiday", label: "Feriado", color: "bg-red-500" },
  ]

  const calendarStats = {
    totalEvents: calendarEvents.length,
    confirmedEvents: calendarEvents.filter((e) => e.status === "confirmed").length,
    pendingEvents: calendarEvents.filter((e) => e.status === "pending").length,
    thisWeekEvents: 3,
  }

  const upcomingEvents = calendarEvents
    .filter((event) => new Date(event.date) >= new Date())
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
    .slice(0, 5)

  const getEventTypeColor = (type: string) => {
    const eventType = eventTypes.find((t) => t.value === type)
    return eventType ? eventType.color : "bg-gray-500"
  }

  const getEventTypeLabel = (type: string) => {
    const eventType = eventTypes.find((t) => t.value === type)
    return eventType ? eventType.label : "Desconocido"
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "confirmed":
        return "bg-green-100 text-green-800"
      case "pending":
        return "bg-yellow-100 text-yellow-800"
      case "cancelled":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case "confirmed":
        return "Confirmado"
      case "pending":
        return "Pendiente"
      case "cancelled":
        return "Cancelado"
      default:
        return "Desconocido"
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "text-red-600"
      case "medium":
        return "text-yellow-600"
      case "low":
        return "text-green-600"
      default:
        return "text-gray-600"
    }
  }

  const filteredEvents = calendarEvents.filter((event) => {
    const matchesType = selectedEventType === "all" || event.type === selectedEventType
    const matchesSearch =
      event.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      event.description.toLowerCase().includes(searchTerm.toLowerCase())
    const eventMonth = event.date.substring(0, 7)
    const matchesMonth = selectedMonth === "all" || eventMonth === selectedMonth
    return matchesType && matchesSearch && matchesMonth
  })

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("es-ES", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  return (
    <div className="flex-1 space-y-6 p-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Calendario Escolar</h1>
          <p className="text-muted-foreground">Gestión y alineación con el calendario académico oficial</p>
        </div>
        <div className="flex items-center space-x-2">
          <Button variant="outline" size="sm">
            <Upload className="h-4 w-4 mr-2" />
            Importar
          </Button>
          <Button variant="outline" size="sm">
            <Download className="h-4 w-4 mr-2" />
            Exportar
          </Button>
          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Nuevo Evento
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Crear Nuevo Evento</DialogTitle>
                <DialogDescription>Agregar un nuevo evento al calendario académico</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="title">Título del Evento</Label>
                    <Input id="title" placeholder="Nombre del evento" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="type">Tipo de Evento</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Seleccionar tipo" />
                      </SelectTrigger>
                      <SelectContent>
                        {eventTypes.map((type) => (
                          <SelectItem key={type.value} value={type.value}>
                            {type.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="date">Fecha de Inicio</Label>
                    <Input id="date" type="date" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="endDate">Fecha de Fin (Opcional)</Label>
                    <Input id="endDate" type="date" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="description">Descripción</Label>
                  <Textarea id="description" placeholder="Descripción del evento..." className="min-h-[100px]" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="participants">Participantes</Label>
                    <Input id="participants" placeholder="Quiénes participan" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="location">Ubicación</Label>
                    <Input id="location" placeholder="Dónde se realizará" />
                  </div>
                </div>
              </div>
              <div className="flex justify-end space-x-2">
                <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                  Cancelar
                </Button>
                <Button onClick={() => setIsCreateDialogOpen(false)}>Crear Evento</Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Eventos</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{calendarStats.totalEvents}</div>
            <p className="text-xs text-muted-foreground">En el calendario</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Confirmados</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{calendarStats.confirmedEvents}</div>
            <p className="text-xs text-muted-foreground">Eventos confirmados</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pendientes</CardTitle>
            <AlertCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{calendarStats.pendingEvents}</div>
            <p className="text-xs text-muted-foreground">Por confirmar</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Esta Semana</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{calendarStats.thisWeekEvents}</div>
            <p className="text-xs text-muted-foreground">Eventos próximos</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="calendar" className="space-y-4">
        <TabsList>
          <TabsTrigger value="calendar">Calendario</TabsTrigger>
          <TabsTrigger value="events">Lista de Eventos</TabsTrigger>
          <TabsTrigger value="upcoming">Próximos</TabsTrigger>
        </TabsList>

        <TabsContent value="calendar" className="space-y-4">
          <div className="grid gap-6 md:grid-cols-3">
            <div className="md:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle>Vista de Calendario</CardTitle>
                  <CardDescription>Eventos organizados por fecha</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <h3 className="text-lg font-semibold">Enero 2024</h3>
                      <div className="flex space-x-2">
                        <Button variant="outline" size="sm">
                          Anterior
                        </Button>
                        <Button variant="outline" size="sm">
                          Siguiente
                        </Button>
                      </div>
                    </div>

                    {/* Calendar Grid Placeholder */}
                    <div className="grid grid-cols-7 gap-2 text-center">
                      {["Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"].map((day) => (
                        <div key={day} className="p-2 font-medium text-sm text-muted-foreground">
                          {day}
                        </div>
                      ))}

                      {Array.from({ length: 35 }, (_, i) => {
                        const day = i - 6 + 1
                        const hasEvent = [15, 18, 22, 26, 29].includes(day)

                        return (
                          <div
                            key={i}
                            className={`p-2 text-sm border rounded ${
                              day > 0 && day <= 31
                                ? hasEvent
                                  ? "bg-blue-50 border-blue-200 font-medium"
                                  : "hover:bg-gray-50"
                                : "text-muted-foreground"
                            }`}
                          >
                            {day > 0 && day <= 31 ? day : ""}
                            {hasEvent && <div className="w-2 h-2 bg-blue-500 rounded-full mx-auto mt-1"></div>}
                          </div>
                        )
                      })}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div>
              <Card>
                <CardHeader>
                  <CardTitle>Próximos Eventos</CardTitle>
                  <CardDescription>Los siguientes en el calendario</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {upcomingEvents.map((event) => (
                      <div key={event.id} className="flex items-start space-x-3 p-3 border rounded-lg">
                        <div className={`w-3 h-3 rounded-full mt-1 ${getEventTypeColor(event.type)}`}></div>
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-sm truncate">{event.title}</p>
                          <p className="text-xs text-muted-foreground">{formatDate(event.date)}</p>
                          <Badge className={`${getStatusColor(event.status)} text-xs mt-1`}>
                            {getStatusText(event.status)}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="events" className="space-y-4">
          {/* Filters */}
          <Card>
            <CardHeader>
              <CardTitle>Filtros</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-4">
                <div className="flex items-center space-x-2">
                  <Search className="h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Buscar evento..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-64"
                  />
                </div>
                <Select value={selectedMonth} onValueChange={setSelectedMonth}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Mes" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos los meses</SelectItem>
                    <SelectItem value="2024-01">Enero 2024</SelectItem>
                    <SelectItem value="2024-02">Febrero 2024</SelectItem>
                    <SelectItem value="2024-03">Marzo 2024</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={selectedEventType} onValueChange={setSelectedEventType}>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="Tipo de evento" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos los tipos</SelectItem>
                    {eventTypes.map((type) => (
                      <SelectItem key={type.value} value={type.value}>
                        {type.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Events List */}
          <div className="grid gap-4">
            {filteredEvents.map((event) => (
              <Card key={event.id}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        <CalendarDays className="h-5 w-5" />
                        {event.title}
                      </CardTitle>
                      <CardDescription>{event.description}</CardDescription>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge variant="outline">{getEventTypeLabel(event.type)}</Badge>
                      <Badge className={getStatusColor(event.status)}>{getStatusText(event.status)}</Badge>
                      <Button variant="outline" size="sm">
                        <Edit className="h-4 w-4 mr-2" />
                        Editar
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <div className="flex items-center space-x-2 text-sm">
                        <Calendar className="h-4 w-4 text-muted-foreground" />
                        <span className="font-medium">Fecha:</span>
                        <span>{formatDate(event.date)}</span>
                      </div>
                      {event.endDate && (
                        <div className="flex items-center space-x-2 text-sm">
                          <Calendar className="h-4 w-4 text-muted-foreground" />
                          <span className="font-medium">Hasta:</span>
                          <span>{formatDate(event.endDate)}</span>
                        </div>
                      )}
                      <div className="flex items-center space-x-2 text-sm">
                        <Users className="h-4 w-4 text-muted-foreground" />
                        <span className="font-medium">Participantes:</span>
                        <span>{event.participants}</span>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center space-x-2 text-sm">
                        <BookOpen className="h-4 w-4 text-muted-foreground" />
                        <span className="font-medium">Ubicación:</span>
                        <span>{event.location}</span>
                      </div>
                      <div className="flex items-center space-x-2 text-sm">
                        <AlertCircle className={`h-4 w-4 ${getPriorityColor(event.priority)}`} />
                        <span className="font-medium">Prioridad:</span>
                        <span className={getPriorityColor(event.priority)}>
                          {event.priority === "high" ? "Alta" : event.priority === "medium" ? "Media" : "Baja"}
                        </span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="upcoming" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Eventos Próximos</CardTitle>
              <CardDescription>Los siguientes eventos en el calendario académico</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {upcomingEvents.map((event, index) => (
                  <div key={event.id} className="flex items-center space-x-4 p-4 border rounded-lg">
                    <div className="flex-shrink-0">
                      <div
                        className={`w-12 h-12 rounded-lg ${getEventTypeColor(event.type)} flex items-center justify-center`}
                      >
                        <CalendarDays className="h-6 w-6 text-white" />
                      </div>
                    </div>
                    <div className="flex-1">
                      <h4 className="font-medium">{event.title}</h4>
                      <p className="text-sm text-muted-foreground">{event.description}</p>
                      <div className="flex items-center space-x-4 mt-2 text-xs text-muted-foreground">
                        <span>{formatDate(event.date)}</span>
                        <span>•</span>
                        <span>{event.participants}</span>
                        <span>•</span>
                        <span>{event.location}</span>
                      </div>
                    </div>
                    <div className="flex-shrink-0">
                      <Badge className={getStatusColor(event.status)}>{getStatusText(event.status)}</Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
