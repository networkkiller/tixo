"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import {
  TrendingUp,
  TrendingDown,
  Users,
  AlertTriangle,
  CheckCircle,
  BookOpen,
  Search,
  Eye,
  Download,
  UserCheck,
  GraduationCap,
} from "lucide-react"
import { useRouter } from "next/navigation"

export default function StudentTrackingPage() {
  const [selectedGrade, setSelectedGrade] = useState("all")
  const [selectedPerformance, setSelectedPerformance] = useState("all")
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedPeriod, setSelectedPeriod] = useState("all")

  const trackingStats = {
    totalStudents: 1247,
    highPerformers: 342,
    averagePerformers: 756,
    lowPerformers: 149,
    atRiskStudents: 23,
    improvingStudents: 89,
  }

  const students = [
    {
      id: 1,
      name: "Ana María Rodríguez",
      grade: "3ro Bachillerato",
      section: "A",
      overallAverage: 92.5,
      trend: "up",
      performance: "high",
      subjects: [
        { name: "Matemáticas", grade: 95, trend: "up" },
        { name: "Física", grade: 88, trend: "stable" },
        { name: "Química", grade: 94, trend: "up" },
        { name: "Historia", grade: 92, trend: "stable" },
      ],
      attendance: 98,
      status: "excellent",
      alerts: [],
    },
    {
      id: 2,
      name: "Carlos Eduardo Martínez",
      grade: "2do Bachillerato",
      section: "B",
      overallAverage: 78.3,
      trend: "down",
      performance: "average",
      subjects: [
        { name: "Matemáticas", grade: 72, trend: "down" },
        { name: "Lengua Española", grade: 85, trend: "up" },
        { name: "Ciencias Naturales", grade: 76, trend: "stable" },
        { name: "Inglés", grade: 80, trend: "up" },
      ],
      attendance: 92,
      status: "needs-attention",
      alerts: ["Bajo rendimiento en Matemáticas"],
    },
    {
      id: 3,
      name: "María José Fernández",
      grade: "1ro Bachillerato",
      section: "A",
      overallAverage: 65.8,
      trend: "down",
      performance: "low",
      subjects: [
        { name: "Matemáticas", grade: 58, trend: "down" },
        { name: "Lengua Española", grade: 70, trend: "stable" },
        { name: "Ciencias Naturales", grade: 62, trend: "down" },
        { name: "Historia", grade: 73, trend: "up" },
      ],
      attendance: 85,
      status: "at-risk",
      alerts: ["Riesgo de reprobación", "Asistencia irregular"],
    },
  ]

  const performanceCategories = [
    {
      category: "Alto Rendimiento",
      count: trackingStats.highPerformers,
      percentage: (trackingStats.highPerformers / trackingStats.totalStudents) * 100,
      color: "bg-green-500",
      description: "90-100 puntos",
    },
    {
      category: "Rendimiento Promedio",
      count: trackingStats.averagePerformers,
      percentage: (trackingStats.averagePerformers / trackingStats.totalStudents) * 100,
      color: "bg-blue-500",
      description: "70-89 puntos",
    },
    {
      category: "Bajo Rendimiento",
      count: trackingStats.lowPerformers,
      percentage: (trackingStats.lowPerformers / trackingStats.totalStudents) * 100,
      color: "bg-yellow-500",
      description: "60-69 puntos",
    },
    {
      category: "En Riesgo",
      count: trackingStats.atRiskStudents,
      percentage: (trackingStats.atRiskStudents / trackingStats.totalStudents) * 100,
      color: "bg-red-500",
      description: "Menos de 60 puntos",
    },
  ]

  const getPerformanceColor = (performance: string) => {
    switch (performance) {
      case "high":
        return "bg-green-100 text-green-800"
      case "average":
        return "bg-blue-100 text-blue-800"
      case "low":
        return "bg-yellow-100 text-yellow-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getPerformanceText = (performance: string) => {
    switch (performance) {
      case "high":
        return "Alto"
      case "average":
        return "Promedio"
      case "low":
        return "Bajo"
      default:
        return "N/A"
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "excellent":
        return "bg-green-100 text-green-800"
      case "good":
        return "bg-blue-100 text-blue-800"
      case "needs-attention":
        return "bg-yellow-100 text-yellow-800"
      case "at-risk":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case "excellent":
        return "Excelente"
      case "good":
        return "Bueno"
      case "needs-attention":
        return "Requiere Atención"
      case "at-risk":
        return "En Riesgo"
      default:
        return "N/A"
    }
  }

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case "up":
        return <TrendingUp className="h-4 w-4 text-green-600" />
      case "down":
        return <TrendingDown className="h-4 w-4 text-red-600" />
      default:
        return <div className="h-4 w-4" />
    }
  }

  const filteredStudents = students.filter((student) => {
    const matchesGrade = selectedGrade === "all" || student.grade.includes(selectedGrade)
    const matchesPerformance = selectedPerformance === "all" || student.performance === selectedPerformance
    const matchesSearch = student.name.toLowerCase().includes(searchTerm.toLowerCase())
    return matchesGrade && matchesPerformance && matchesSearch
  })

  // Funciones de manejo de eventos
  const router = useRouter()

  const handleViewStudentProfile = (studentId: number) => {
    // Crear URL con parámetros para mantener contexto
    const currentFilters = new URLSearchParams({
      grade: selectedGrade,
      performance: selectedPerformance,
      search: searchTerm,
      returnTo: "student-tracking",
    }).toString()

    // Navegar al perfil detallado del estudiante con contexto
    router.push(`/dashboard/coordinador-academico/student-tracking/student/${studentId}?${currentFilters}`)
  }

  const handleExportReport = () => {
    // Generar y descargar reporte de seguimiento estudiantil
    const reportData = {
      period: selectedPeriod,
      totalStudents: trackingStats.totalStudents,
      highPerformers: trackingStats.highPerformers,
      atRiskStudents: trackingStats.atRiskStudents,
      filters: { grade: selectedGrade, performance: selectedPerformance, search: searchTerm },
      students: filteredStudents,
      generatedAt: new Date().toISOString(),
    }

    // Simular descarga de reporte
    const blob = new Blob([JSON.stringify(reportData, null, 2)], { type: "application/json" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `reporte-seguimiento-estudiantil-${new Date().toISOString().split("T")[0]}.json`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  const handleIntervention = () => {
    // Redirigir a la página de planificación de intervenciones
    window.location.href = "/dashboard/coordinador-academico/student-tracking?tab=interventions"
  }

  const handleViewRiskList = () => {
    // Filtrar estudiantes en riesgo y cambiar a la tab de estudiantes
    setSelectedPerformance("low")
    // Simular cambio de tab
    const studentsTab = document.querySelector('[data-value="students"]') as HTMLElement
    if (studentsTab) {
      studentsTab.click()
    }
  }

  const handleViewTrendList = () => {
    // Mostrar estudiantes con tendencia negativa
    window.location.href = "/dashboard/coordinador-academico/student-tracking?filter=negative-trend"
  }

  const handleViewAttendanceList = () => {
    // Mostrar estudiantes con asistencia irregular
    window.location.href = "/dashboard/coordinador-academico/student-tracking?filter=irregular-attendance"
  }

  const handleSubjectAnalysis = (subjectName: string) => {
    // Redirigir al análisis detallado de la materia
    window.location.href = `/dashboard/coordinador-academico/grade-monitoring?subject=${encodeURIComponent(subjectName)}`
  }

  const handleAssignTutor = () => {
    // Redirigir a la asignación de tutores
    window.location.href = "/dashboard/coordinador-academico/teacher-assignment?type=tutor&students=at-risk"
  }

  const handleParentMeeting = () => {
    // Programar reuniones con padres
    window.location.href =
      "/dashboard/coordinador-academico/communication?action=schedule-meeting&target=parents-at-risk"
  }

  const handleRecoveryPlan = () => {
    // Crear plan de recuperación académica
    window.location.href = "/dashboard/coordinador-academico/academic-reports?action=create-recovery-plan"
  }

  const handleAdditionalEvaluation = () => {
    // Programar evaluaciones adicionales
    window.location.href = "/dashboard/coordinador-academico/grade-monitoring?action=schedule-evaluation"
  }

  const handleAcademicReinforcement = () => {
    // Asignar refuerzo académico
    window.location.href = "/dashboard/coordinador-academico/teacher-assignment?type=reinforcement"
  }

  const handleImprovementCertificate = () => {
    // Generar certificados de mejora
    window.location.href = "/dashboard/coordinador-academico/academic-reports?action=generate-certificates"
  }

  const handlePeerMentor = () => {
    // Asignar mentores de pares
    window.location.href = "/dashboard/coordinador-academico/student-tracking?action=assign-peer-mentors"
  }

  return (
    <div className="flex-1 space-y-6 p-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Seguimiento Estudiantil</h1>
          <p className="text-muted-foreground">Monitoreo del rendimiento académico y progreso estudiantil</p>
        </div>
        <div className="flex items-center space-x-2">
          <Button variant="outline" onClick={handleExportReport}>
            <Download className="h-4 w-4 mr-2" />
            Exportar Reporte
          </Button>
          <Button onClick={handleIntervention}>
            <UserCheck className="h-4 w-4 mr-2" />
            Intervención
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Estudiantes</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{trackingStats.totalStudents.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">En seguimiento activo</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Alto Rendimiento</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{trackingStats.highPerformers}</div>
            <p className="text-xs text-muted-foreground">
              {((trackingStats.highPerformers / trackingStats.totalStudents) * 100).toFixed(1)}% del total
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">En Riesgo</CardTitle>
            <AlertTriangle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{trackingStats.atRiskStudents}</div>
            <p className="text-xs text-muted-foreground">Requieren intervención inmediata</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Mejorando</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{trackingStats.improvingStudents}</div>
            <p className="text-xs text-muted-foreground">Tendencia positiva</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList>
          <TabsTrigger value="overview">Resumen</TabsTrigger>
          <TabsTrigger value="students">Estudiantes</TabsTrigger>
          <TabsTrigger value="performance">Rendimiento</TabsTrigger>
          <TabsTrigger value="interventions">Intervenciones</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Distribución por Rendimiento</CardTitle>
                <CardDescription>Clasificación de estudiantes según su desempeño</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {performanceCategories.map((category, index) => (
                    <div key={index} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">{category.category}</span>
                        <span className="text-sm text-muted-foreground">
                          {category.count} ({category.percentage.toFixed(1)}%)
                        </span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Progress value={category.percentage} className="flex-1" />
                        <span className="text-xs text-muted-foreground w-20">{category.description}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Alertas Activas</CardTitle>
                <CardDescription>Estudiantes que requieren atención</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 border rounded-lg bg-red-50">
                    <div className="flex items-center space-x-3">
                      <AlertTriangle className="h-5 w-5 text-red-600" />
                      <div>
                        <p className="font-medium">Riesgo de Reprobación</p>
                        <p className="text-sm text-muted-foreground">23 estudiantes</p>
                      </div>
                    </div>
                    <Button variant="outline" size="sm" onClick={handleViewRiskList}>
                      Ver Lista
                    </Button>
                  </div>

                  <div className="flex items-center justify-between p-3 border rounded-lg bg-yellow-50">
                    <div className="flex items-center space-x-3">
                      <TrendingDown className="h-5 w-5 text-yellow-600" />
                      <div>
                        <p className="font-medium">Tendencia Negativa</p>
                        <p className="text-sm text-muted-foreground">67 estudiantes</p>
                      </div>
                    </div>
                    <Button variant="outline" size="sm" onClick={handleViewTrendList}>
                      Ver Lista
                    </Button>
                  </div>

                  <div className="flex items-center justify-between p-3 border rounded-lg bg-blue-50">
                    <div className="flex items-center space-x-3">
                      <Users className="h-5 w-5 text-blue-600" />
                      <div>
                        <p className="font-medium">Asistencia Irregular</p>
                        <p className="text-sm text-muted-foreground">34 estudiantes</p>
                      </div>
                    </div>
                    <Button variant="outline" size="sm" onClick={handleViewAttendanceList}>
                      Ver Lista
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="students" className="space-y-4">
          {/* Filters */}
          <Card>
            <CardHeader>
              <CardTitle>Filtros</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-4">
                <div className="flex items-center space-x-2">
                  <Search className="h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Buscar estudiante..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-64"
                  />
                </div>
                <Select value={selectedGrade} onValueChange={setSelectedGrade}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Grado" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos los grados</SelectItem>
                    <SelectItem value="1ro">1ro Bachillerato</SelectItem>
                    <SelectItem value="2do">2do Bachillerato</SelectItem>
                    <SelectItem value="3ro">3ro Bachillerato</SelectItem>
                    <SelectItem value="4to">4to Bachillerato</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={selectedPerformance} onValueChange={setSelectedPerformance}>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="Rendimiento" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos los niveles</SelectItem>
                    <SelectItem value="high">Alto Rendimiento</SelectItem>
                    <SelectItem value="average">Rendimiento Promedio</SelectItem>
                    <SelectItem value="low">Bajo Rendimiento</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Students List */}
          <div className="grid gap-4">
            {filteredStudents.map((student) => (
              <Card key={student.id}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        <GraduationCap className="h-5 w-5" />
                        {student.name}
                      </CardTitle>
                      <CardDescription>
                        {student.grade} - Sección {student.section} • Asistencia: {student.attendance}%
                      </CardDescription>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge className={getPerformanceColor(student.performance)}>
                        {getPerformanceText(student.performance)}
                      </Badge>
                      <Badge className={getStatusColor(student.status)}>{getStatusText(student.status)}</Badge>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleViewStudentProfile(student.id)}
                        className="hover:bg-primary/10 hover:text-primary hover:border-primary transition-colors"
                      >
                        <Eye className="h-4 w-4 mr-2" />
                        Ver Perfil
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <span className="text-sm font-medium">Promedio General:</span>
                        <span className="text-lg font-bold">{student.overallAverage}</span>
                        {getTrendIcon(student.trend)}
                      </div>
                      <div className="text-sm text-muted-foreground">Asistencia: {student.attendance}%</div>
                    </div>

                    <div className="grid gap-2 md:grid-cols-2">
                      {student.subjects.map((subject, index) => (
                        <div key={index} className="flex items-center justify-between p-2 border rounded">
                          <div className="flex items-center space-x-2">
                            <BookOpen className="h-4 w-4 text-muted-foreground" />
                            <span className="text-sm">{subject.name}</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <span className="text-sm font-medium">{subject.grade}</span>
                            {getTrendIcon(subject.trend)}
                          </div>
                        </div>
                      ))}
                    </div>

                    {student.alerts.length > 0 && (
                      <div className="space-y-2">
                        <span className="text-sm font-medium text-red-600">Alertas:</span>
                        {student.alerts.map((alert, index) => (
                          <div key={index} className="flex items-center space-x-2 text-sm text-red-600">
                            <AlertTriangle className="h-4 w-4" />
                            <span>{alert}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="performance" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Análisis de Rendimiento por Materia</CardTitle>
              <CardDescription>Comparativo de promedios por área académica</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  { subject: "Matemáticas", average: 78.5, trend: "up", students: 312 },
                  { subject: "Lengua Española", average: 82.3, trend: "up", students: 312 },
                  { subject: "Ciencias Naturales", average: 75.8, trend: "down", students: 312 },
                  { subject: "Historia", average: 84.2, trend: "up", students: 312 },
                  { subject: "Inglés", average: 79.6, trend: "stable", students: 312 },
                ].map((subject, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-3 border rounded-lg hover:bg-muted/50 cursor-pointer transition-colors"
                    onClick={() => handleSubjectAnalysis(subject.subject)}
                  >
                    <div className="flex items-center space-x-3">
                      <BookOpen className="h-5 w-5 text-muted-foreground" />
                      <div>
                        <p className="font-medium">{subject.subject}</p>
                        <p className="text-sm text-muted-foreground">{subject.students} estudiantes</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="text-right">
                        <p className="text-lg font-bold">{subject.average}</p>
                        <p className="text-xs text-muted-foreground">Promedio</p>
                      </div>
                      {getTrendIcon(subject.trend)}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="interventions" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Plan de Intervenciones</CardTitle>
              <CardDescription>Estrategias para mejorar el rendimiento estudiantil</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="p-4 border rounded-lg bg-red-50">
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="font-medium text-red-800">Intervención Inmediata</h4>
                    <Badge variant="destructive">23 estudiantes</Badge>
                  </div>
                  <p className="text-sm text-red-700 mb-3">
                    Estudiantes en riesgo de reprobación que requieren atención inmediata
                  </p>
                  <div className="flex space-x-2">
                    <Button size="sm" variant="outline" onClick={handleAssignTutor}>
                      Asignar Tutor
                    </Button>
                    <Button size="sm" variant="outline" onClick={handleParentMeeting}>
                      Reunión con Padres
                    </Button>
                    <Button size="sm" variant="outline" onClick={handleRecoveryPlan}>
                      Plan de Recuperación
                    </Button>
                  </div>
                </div>

                <div className="p-4 border rounded-lg bg-yellow-50">
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="font-medium text-yellow-800">Seguimiento Especial</h4>
                    <Badge className="bg-yellow-100 text-yellow-800">67 estudiantes</Badge>
                  </div>
                  <p className="text-sm text-yellow-700 mb-3">
                    Estudiantes con tendencia negativa que necesitan monitoreo cercano
                  </p>
                  <div className="flex space-x-2">
                    <Button size="sm" variant="outline" onClick={handleAdditionalEvaluation}>
                      Evaluación Adicional
                    </Button>
                    <Button size="sm" variant="outline" onClick={handleAcademicReinforcement}>
                      Refuerzo Académico
                    </Button>
                  </div>
                </div>

                <div className="p-4 border rounded-lg bg-green-50">
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="font-medium text-green-800">Reconocimiento</h4>
                    <Badge className="bg-green-100 text-green-800">89 estudiantes</Badge>
                  </div>
                  <p className="text-sm text-green-700 mb-3">
                    Estudiantes con mejoras significativas que merecen reconocimiento
                  </p>
                  <div className="flex space-x-2">
                    <Button size="sm" variant="outline" onClick={handleImprovementCertificate}>
                      Certificado de Mejora
                    </Button>
                    <Button size="sm" variant="outline" onClick={handlePeerMentor}>
                      Mentor de Pares
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
