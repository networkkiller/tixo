"use client"
import { useRouter, useSearchParams } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  ArrowLeft,
  TrendingUp,
  TrendingDown,
  Calendar,
  BookOpen,
  AlertTriangle,
  CheckCircle,
  User,
  Phone,
  Mail,
  MapPin,
  GraduationCap,
  Clock,
  Target,
  Award,
  Users,
  MessageSquare,
} from "lucide-react"

interface StudentProfileProps {
  params: {
    id: string
  }
}

export default function StudentProfilePage({ params }: StudentProfileProps) {
  const router = useRouter()
  const searchParams = useSearchParams()
  const studentId = Number.parseInt(params.id)

  // Obtener parámetros de retorno
  const returnTo = searchParams.get("returnTo") || "student-tracking"
  const grade = searchParams.get("grade") || "all"
  const performance = searchParams.get("performance") || "all"
  const search = searchParams.get("search") || ""

  // Datos del estudiante (en una aplicación real, esto vendría de una API)
  const student = {
    id: studentId,
    name: "Ana María Rodríguez",
    avatar: "/placeholder.svg?height=100&width=100&text=AR",
    grade: "3ro Bachillerato",
    section: "A",
    studentCode: "2024-0001",
    birthDate: "2006-03-15",
    age: 17,
    gender: "Femenino",
    address: "Calle Principal #123, Santo Domingo",
    phone: "(809) 555-0123",
    email: "ana.rodriguez@estudiante.edu.do",
    parentName: "María Rodríguez",
    parentPhone: "(809) 555-0124",
    parentEmail: "maria.rodriguez@email.com",
    enrollmentDate: "2022-08-15",
    overallAverage: 92.5,
    trend: "up",
    performance: "high",
    status: "excellent",
    attendance: 98,
    totalAbsences: 3,
    tardiness: 1,
    alerts: [],
    subjects: [
      {
        name: "Matemáticas",
        teacher: "Prof. Carlos Méndez",
        currentGrade: 95,
        previousGrade: 92,
        trend: "up",
        assignments: 12,
        completedAssignments: 12,
        pendingAssignments: 0,
        lastEvaluation: "2024-01-15",
        nextEvaluation: "2024-02-15",
      },
      {
        name: "Física",
        teacher: "Prof. Laura Santos",
        currentGrade: 88,
        previousGrade: 88,
        trend: "stable",
        assignments: 10,
        completedAssignments: 10,
        pendingAssignments: 0,
        lastEvaluation: "2024-01-12",
        nextEvaluation: "2024-02-12",
      },
      {
        name: "Química",
        teacher: "Prof. Roberto Díaz",
        currentGrade: 94,
        previousGrade: 90,
        trend: "up",
        assignments: 8,
        completedAssignments: 8,
        pendingAssignments: 0,
        lastEvaluation: "2024-01-18",
        nextEvaluation: "2024-02-18",
      },
      {
        name: "Historia",
        teacher: "Prof. Carmen Jiménez",
        currentGrade: 92,
        previousGrade: 92,
        trend: "stable",
        assignments: 6,
        completedAssignments: 6,
        pendingAssignments: 0,
        lastEvaluation: "2024-01-20",
        nextEvaluation: "2024-02-20",
      },
      {
        name: "Lengua Española",
        teacher: "Prof. Ana Martínez",
        currentGrade: 90,
        previousGrade: 87,
        trend: "up",
        assignments: 9,
        completedAssignments: 9,
        pendingAssignments: 0,
        lastEvaluation: "2024-01-16",
        nextEvaluation: "2024-02-16",
      },
    ],
    academicHistory: [
      {
        period: "2023-2024",
        grade: "2do Bachillerato",
        average: 89.5,
        status: "Aprobado",
        ranking: 5,
        totalStudents: 45,
      },
      {
        period: "2022-2023",
        grade: "1ro Bachillerato",
        average: 87.2,
        status: "Aprobado",
        ranking: 8,
        totalStudents: 42,
      },
    ],
    achievements: [
      {
        title: "Cuadro de Honor",
        date: "2024-01-15",
        description: "Reconocimiento por excelencia académica",
        type: "academic",
      },
      {
        title: "Mejor Estudiante de Matemáticas",
        date: "2023-12-10",
        description: "Primer lugar en competencia de matemáticas",
        type: "competition",
      },
      {
        title: "Participación en Feria de Ciencias",
        date: "2023-11-20",
        description: "Proyecto destacado en feria científica",
        type: "participation",
      },
    ],
    behaviorNotes: [
      {
        date: "2024-01-10",
        type: "positive",
        description: "Excelente participación en clase de Física",
        teacher: "Prof. Laura Santos",
      },
      {
        date: "2023-12-15",
        type: "positive",
        description: "Ayudó a compañeros con dificultades en Matemáticas",
        teacher: "Prof. Carlos Méndez",
      },
    ],
  }

  const getPerformanceColor = (performance: string) => {
    switch (performance) {
      case "high":
        return "bg-green-100 text-green-800"
      case "average":
        return "bg-blue-100 text-blue-800"
      case "low":
        return "bg-yellow-100 text-yellow-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getPerformanceText = (performance: string) => {
    switch (performance) {
      case "high":
        return "Alto Rendimiento"
      case "average":
        return "Rendimiento Promedio"
      case "low":
        return "Bajo Rendimiento"
      default:
        return "N/A"
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "excellent":
        return "bg-green-100 text-green-800"
      case "good":
        return "bg-blue-100 text-blue-800"
      case "needs-attention":
        return "bg-yellow-100 text-yellow-800"
      case "at-risk":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case "excellent":
        return "Excelente"
      case "good":
        return "Bueno"
      case "needs-attention":
        return "Requiere Atención"
      case "at-risk":
        return "En Riesgo"
      default:
        return "N/A"
    }
  }

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case "up":
        return <TrendingUp className="h-4 w-4 text-green-600" />
      case "down":
        return <TrendingDown className="h-4 w-4 text-red-600" />
      default:
        return <div className="h-4 w-4" />
    }
  }

  const getAchievementIcon = (type: string) => {
    switch (type) {
      case "academic":
        return <Award className="h-5 w-5 text-yellow-600" />
      case "competition":
        return <Target className="h-5 w-5 text-blue-600" />
      case "participation":
        return <Users className="h-5 w-5 text-green-600" />
      default:
        return <CheckCircle className="h-5 w-5 text-gray-600" />
    }
  }

  const handleGoBack = () => {
    const returnUrl = `/dashboard/coordinador-academico/${returnTo}?grade=${grade}&performance=${performance}&search=${search}`
    router.push(returnUrl)
  }

  const handleContactParent = () => {
    router.push(`/dashboard/coordinador-academico/communication?action=contact-parent&student=${studentId}`)
  }

  const handleScheduleMeeting = () => {
    router.push(`/dashboard/coordinador-academico/communication?action=schedule-meeting&student=${studentId}`)
  }

  const handleCreateIntervention = () => {
    router.push(`/dashboard/coordinador-academico/student-tracking?action=create-intervention&student=${studentId}`)
  }

  const handleViewSubjectDetail = (subjectName: string) => {
    router.push(
      `/dashboard/coordinador-academico/grade-monitoring?subject=${encodeURIComponent(subjectName)}&student=${studentId}`,
    )
  }

  return (
    <div className="flex-1 space-y-6 p-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Button variant="outline" size="sm" onClick={handleGoBack}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Volver
          </Button>
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Perfil del Estudiante</h1>
            <p className="text-muted-foreground">Información detallada y seguimiento académico</p>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <Button variant="outline" onClick={handleContactParent}>
            <MessageSquare className="h-4 w-4 mr-2" />
            Contactar Padre
          </Button>
          <Button variant="outline" onClick={handleScheduleMeeting}>
            <Calendar className="h-4 w-4 mr-2" />
            Programar Reunión
          </Button>
          <Button onClick={handleCreateIntervention}>
            <AlertTriangle className="h-4 w-4 mr-2" />
            Crear Intervención
          </Button>
        </div>
      </div>

      {/* Student Basic Info */}
      <Card>
        <CardContent className="p-6">
          <div className="flex items-start space-x-6">
            <Avatar className="h-24 w-24">
              <AvatarImage src={student.avatar || "/placeholder.svg"} alt={student.name} />
              <AvatarFallback className="text-lg">
                {student.name
                  .split(" ")
                  .map((n) => n[0])
                  .join("")}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 space-y-4">
              <div>
                <h2 className="text-2xl font-bold">{student.name}</h2>
                <p className="text-muted-foreground">Código: {student.studentCode}</p>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Grado</p>
                  <p className="text-lg font-semibold">{student.grade}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Sección</p>
                  <p className="text-lg font-semibold">{student.section}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Promedio General</p>
                  <div className="flex items-center space-x-2">
                    <p className="text-lg font-semibold">{student.overallAverage}</p>
                    {getTrendIcon(student.trend)}
                  </div>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Asistencia</p>
                  <p className="text-lg font-semibold">{student.attendance}%</p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <Badge className={getPerformanceColor(student.performance)}>
                  {getPerformanceText(student.performance)}
                </Badge>
                <Badge className={getStatusColor(student.status)}>{getStatusText(student.status)}</Badge>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="academic" className="space-y-4">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="academic">Académico</TabsTrigger>
          <TabsTrigger value="personal">Personal</TabsTrigger>
          <TabsTrigger value="attendance">Asistencia</TabsTrigger>
          <TabsTrigger value="history">Historial</TabsTrigger>
          <TabsTrigger value="achievements">Logros</TabsTrigger>
        </TabsList>

        <TabsContent value="academic" className="space-y-4">
          <div className="grid gap-4">
            <Card>
              <CardHeader>
                <CardTitle>Rendimiento por Materia</CardTitle>
                <CardDescription>Calificaciones actuales y tendencias</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {student.subjects.map((subject, index) => (
                    <div
                      key={index}
                      className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 cursor-pointer transition-colors"
                      onClick={() => handleViewSubjectDetail(subject.name)}
                    >
                      <div className="flex items-center space-x-4">
                        <BookOpen className="h-5 w-5 text-muted-foreground" />
                        <div>
                          <p className="font-medium">{subject.name}</p>
                          <p className="text-sm text-muted-foreground">{subject.teacher}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-6">
                        <div className="text-center">
                          <p className="text-sm text-muted-foreground">Tareas</p>
                          <p className="font-medium">
                            {subject.completedAssignments}/{subject.assignments}
                          </p>
                        </div>
                        <div className="text-center">
                          <p className="text-sm text-muted-foreground">Calificación</p>
                          <div className="flex items-center space-x-2">
                            <p className="text-lg font-bold">{subject.currentGrade}</p>
                            {getTrendIcon(subject.trend)}
                          </div>
                        </div>
                        <div className="text-center">
                          <p className="text-sm text-muted-foreground">Próxima Evaluación</p>
                          <p className="text-sm">{new Date(subject.nextEvaluation).toLocaleDateString()}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="personal" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Información Personal</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center space-x-3">
                  <User className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <p className="text-sm font-medium">Fecha de Nacimiento</p>
                    <p className="text-sm text-muted-foreground">
                      {new Date(student.birthDate).toLocaleDateString()} ({student.age} años)
                    </p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <User className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <p className="text-sm font-medium">Género</p>
                    <p className="text-sm text-muted-foreground">{student.gender}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <MapPin className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <p className="text-sm font-medium">Dirección</p>
                    <p className="text-sm text-muted-foreground">{student.address}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <Phone className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <p className="text-sm font-medium">Teléfono</p>
                    <p className="text-sm text-muted-foreground">{student.phone}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <Mail className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <p className="text-sm font-medium">Email</p>
                    <p className="text-sm text-muted-foreground">{student.email}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Información del Padre/Tutor</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center space-x-3">
                  <User className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <p className="text-sm font-medium">Nombre</p>
                    <p className="text-sm text-muted-foreground">{student.parentName}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <Phone className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <p className="text-sm font-medium">Teléfono</p>
                    <p className="text-sm text-muted-foreground">{student.parentPhone}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <Mail className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <p className="text-sm font-medium">Email</p>
                    <p className="text-sm text-muted-foreground">{student.parentEmail}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <p className="text-sm font-medium">Fecha de Inscripción</p>
                    <p className="text-sm text-muted-foreground">
                      {new Date(student.enrollmentDate).toLocaleDateString()}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="attendance" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-3">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Asistencia General</CardTitle>
                <CheckCircle className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-600">{student.attendance}%</div>
                <p className="text-xs text-muted-foreground">Excelente asistencia</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Ausencias</CardTitle>
                <AlertTriangle className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{student.totalAbsences}</div>
                <p className="text-xs text-muted-foreground">En el período actual</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Tardanzas</CardTitle>
                <Clock className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{student.tardiness}</div>
                <p className="text-xs text-muted-foreground">Muy puntual</p>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Progreso de Asistencia</CardTitle>
              <CardDescription>Tendencia mensual de asistencia</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  { month: "Enero 2024", attendance: 100, classes: 20, absences: 0 },
                  { month: "Diciembre 2023", attendance: 95, classes: 20, absences: 1 },
                  { month: "Noviembre 2023", attendance: 100, classes: 22, absences: 0 },
                  { month: "Octubre 2023", attendance: 90, classes: 20, absences: 2 },
                ].map((month, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">{month.month}</p>
                      <p className="text-sm text-muted-foreground">
                        {month.classes - month.absences}/{month.classes} clases
                      </p>
                    </div>
                    <div className="flex items-center space-x-4">
                      <Progress value={month.attendance} className="w-32" />
                      <span className="text-sm font-medium w-12">{month.attendance}%</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Historial Académico</CardTitle>
              <CardDescription>Rendimiento por períodos anteriores</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {student.academicHistory.map((period, index) => (
                  <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center space-x-4">
                      <GraduationCap className="h-5 w-5 text-muted-foreground" />
                      <div>
                        <p className="font-medium">{period.period}</p>
                        <p className="text-sm text-muted-foreground">{period.grade}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-6">
                      <div className="text-center">
                        <p className="text-sm text-muted-foreground">Promedio</p>
                        <p className="text-lg font-bold">{period.average}</p>
                      </div>
                      <div className="text-center">
                        <p className="text-sm text-muted-foreground">Ranking</p>
                        <p className="font-medium">
                          {period.ranking} de {period.totalStudents}
                        </p>
                      </div>
                      <Badge
                        className={
                          period.status === "Aprobado" ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
                        }
                      >
                        {period.status}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Notas de Comportamiento</CardTitle>
              <CardDescription>Observaciones de los docentes</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {student.behaviorNotes.map((note, index) => (
                  <div key={index} className="flex items-start space-x-4 p-3 border rounded-lg">
                    <div className={`p-2 rounded-full ${note.type === "positive" ? "bg-green-100" : "bg-yellow-100"}`}>
                      {note.type === "positive" ? (
                        <CheckCircle className="h-4 w-4 text-green-600" />
                      ) : (
                        <AlertTriangle className="h-4 w-4 text-yellow-600" />
                      )}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <p className="font-medium">{note.teacher}</p>
                        <p className="text-sm text-muted-foreground">{new Date(note.date).toLocaleDateString()}</p>
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">{note.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="achievements" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Logros y Reconocimientos</CardTitle>
              <CardDescription>Premios y participaciones destacadas</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {student.achievements.map((achievement, index) => (
                  <div key={index} className="flex items-start space-x-4 p-4 border rounded-lg">
                    <div className="p-2 rounded-full bg-muted">{getAchievementIcon(achievement.type)}</div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <h4 className="font-medium">{achievement.title}</h4>
                        <p className="text-sm text-muted-foreground">
                          {new Date(achievement.date).toLocaleDateString()}
                        </p>
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">{achievement.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
