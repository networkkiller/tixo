"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Calendar,
  Clock,
  BookOpen,
  Edit,
  Eye,
  Plus,
  Search,
  Filter,
  CheckCircle,
  AlertTriangle,
  Users,
} from "lucide-react"
import { ScheduleEditor } from "@/components/schedule/schedule-editor"
import { ScheduleViewer } from "@/components/schedule/schedule-viewer"
import type { Course } from "@/lib/course-interoperability"

interface ScheduleStatus {
  id: string
  courseId: string
  status: "draft" | "published" | "pending"
  lastModified: string
  createdBy: string
}

export default function SchedulesPage() {
  const [currentView, setCurrentView] = useState<"list" | "edit" | "view">("list")
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null)
  const [courses, setCourses] = useState<Course[]>([])
  const [scheduleStatuses, setScheduleStatuses] = useState<ScheduleStatus[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [filterStatus, setFilterStatus] = useState<string>("all")
  const [filterTurn, setFilterTurn] = useState<string>("all")

  useEffect(() => {
    loadCourses()
    loadScheduleStatuses()
  }, [])

  const loadCourses = () => {
    // Mock data - replace with actual API call
    const mockCourses: Course[] = [
      {
        id: "course_1",
        name: "1ro A",
        level: "Primaria",
        turn: "Mañana",
        teacher: "María González",
        students: 25,
        modality: "Presencial",
        subjects: ["Matemáticas", "Lengua", "Ciencias", "Sociales"],
        academicYear: "2024",
        status: "active",
      },
      {
        id: "course_2",
        name: "2do B",
        level: "Primaria",
        turn: "Mañana",
        teacher: "Carlos Rodríguez",
        students: 28,
        modality: "Presencial",
        subjects: ["Matemáticas", "Lengua", "Ciencias", "Sociales", "Inglés"],
        academicYear: "2024",
        status: "active",
      },
      {
        id: "course_3",
        name: "3ro A",
        level: "Primaria",
        turn: "Tarde",
        teacher: "Ana Martínez",
        students: 22,
        modality: "Presencial",
        subjects: ["Matemáticas", "Lengua", "Ciencias", "Sociales", "Inglés", "Ed. Física"],
        academicYear: "2024",
        status: "active",
      },
      {
        id: "course_4",
        name: "4to C",
        level: "Primaria",
        turn: "Mañana",
        teacher: "Luis Pérez",
        students: 26,
        modality: "Presencial",
        subjects: ["Matemáticas", "Lengua", "Ciencias", "Sociales", "Inglés", "Ed. Física"],
        academicYear: "2024",
        status: "active",
      },
      {
        id: "course_5",
        name: "5to A",
        level: "Primaria",
        turn: "Tarde",
        teacher: "Elena Vásquez",
        students: 24,
        modality: "Presencial",
        subjects: ["Matemáticas", "Lengua", "Ciencias", "Sociales", "Inglés", "Ed. Física"],
        academicYear: "2024",
        status: "active",
      },
    ]
    setCourses(mockCourses)
  }

  const loadScheduleStatuses = () => {
    // Mock data - replace with actual API call
    const mockStatuses: ScheduleStatus[] = [
      {
        id: "schedule_1",
        courseId: "course_1",
        status: "published",
        lastModified: "2024-01-15T10:30:00Z",
        createdBy: "Coordinador Académico",
      },
      {
        id: "schedule_2",
        courseId: "course_2",
        status: "draft",
        lastModified: "2024-01-14T15:45:00Z",
        createdBy: "Coordinador Académico",
      },
      {
        id: "schedule_3",
        courseId: "course_3",
        status: "published",
        lastModified: "2024-01-13T09:20:00Z",
        createdBy: "Coordinador Académico",
      },
      {
        id: "schedule_4",
        courseId: "course_4",
        status: "pending",
        lastModified: "2024-01-12T14:10:00Z",
        createdBy: "Coordinador Académico",
      },
    ]
    setScheduleStatuses(mockStatuses)
  }

  const getScheduleStatus = (courseId: string) => {
    return scheduleStatuses.find((status) => status.courseId === courseId)
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "published":
        return <Badge className="bg-green-100 text-green-800">✅ Publicado</Badge>
      case "draft":
        return <Badge className="bg-yellow-100 text-yellow-800">📝 Borrador</Badge>
      case "pending":
        return <Badge className="bg-blue-100 text-blue-800">⏳ Pendiente</Badge>
      default:
        return <Badge variant="secondary">❌ Sin horario</Badge>
    }
  }

  const filteredCourses = courses.filter((course) => {
    const matchesSearch =
      course.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      course.teacher.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = filterStatus === "all" || getScheduleStatus(course.id)?.status === filterStatus
    const matchesTurn = filterTurn === "all" || course.turn === filterTurn

    return matchesSearch && matchesStatus && matchesTurn
  })

  const handleEditSchedule = (course: Course) => {
    setSelectedCourse(course)
    setCurrentView("edit")
  }

  const handleViewSchedule = (course: Course) => {
    setSelectedCourse(course)
    setCurrentView("view")
  }

  const handleCreateSchedule = (course: Course) => {
    setSelectedCourse(course)
    setCurrentView("edit")
  }

  const handleSaveSchedule = (scheduleData: any) => {
    console.log("Saving schedule:", scheduleData)
    // Here you would save to your backend

    // Update local state
    const newStatus: ScheduleStatus = {
      id: `schedule_${Date.now()}`,
      courseId: scheduleData.course,
      status: scheduleData.published ? "published" : "draft",
      lastModified: new Date().toISOString(),
      createdBy: "Coordinador Académico",
    }

    setScheduleStatuses((prev) => {
      const existing = prev.find((s) => s.courseId === scheduleData.course)
      if (existing) {
        return prev.map((s) => (s.courseId === scheduleData.course ? { ...s, ...newStatus } : s))
      }
      return [...prev, newStatus]
    })

    setCurrentView("list")
  }

  const handleBackToList = () => {
    setCurrentView("list")
    setSelectedCourse(null)
  }

  const getStats = () => {
    const total = courses.length
    const published = scheduleStatuses.filter((s) => s.status === "published").length
    const draft = scheduleStatuses.filter((s) => s.status === "draft").length
    const pending = scheduleStatuses.filter((s) => s.status === "pending").length
    const withoutSchedule = total - scheduleStatuses.length

    return { total, published, draft, pending, withoutSchedule }
  }

  const stats = getStats()

  if (currentView === "edit" && selectedCourse) {
    return (
      <ScheduleEditor course={selectedCourse} mode="edit" onSave={handleSaveSchedule} onCancel={handleBackToList} />
    )
  }

  if (currentView === "view" && selectedCourse) {
    // Mock schedule data for viewing
    const mockSchedule = {
      slot_8: {
        Lunes: {
          type: "class" as const,
          subject: "Matemáticas",
          teacher: "Ana Rodríguez",
          color: "bg-blue-100 border-blue-300 text-blue-800",
        },
        Martes: {
          type: "class" as const,
          subject: "Lengua",
          teacher: "Carlos Mendoza",
          color: "bg-purple-100 border-purple-300 text-purple-800",
        },
        Miércoles: {
          type: "class" as const,
          subject: "Ciencias",
          teacher: "María González",
          color: "bg-green-100 border-green-300 text-green-800",
        },
        Jueves: {
          type: "class" as const,
          subject: "Sociales",
          teacher: "Luis Pérez",
          color: "bg-orange-100 border-orange-300 text-orange-800",
        },
        Viernes: {
          type: "class" as const,
          subject: "Inglés",
          teacher: "Elena Vásquez",
          color: "bg-indigo-100 border-indigo-300 text-indigo-800",
        },
      },
      slot_9: {
        Lunes: {
          type: "class" as const,
          subject: "Lengua",
          teacher: "Carlos Mendoza",
          color: "bg-purple-100 border-purple-300 text-purple-800",
        },
        Martes: {
          type: "class" as const,
          subject: "Matemáticas",
          teacher: "Ana Rodríguez",
          color: "bg-blue-100 border-blue-300 text-blue-800",
        },
        Miércoles: { type: "empty" as const },
        Jueves: {
          type: "class" as const,
          subject: "Ed. Física",
          teacher: "Pedro Sánchez",
          color: "bg-red-100 border-red-300 text-red-800",
        },
        Viernes: {
          type: "class" as const,
          subject: "Ciencias",
          teacher: "María González",
          color: "bg-green-100 border-green-300 text-green-800",
        },
      },
      slot_10: {
        Lunes: { type: "break" as const, subject: "RECESO", color: "bg-yellow-100 border-yellow-300 text-yellow-800" },
        Martes: { type: "break" as const, subject: "RECESO", color: "bg-yellow-100 border-yellow-300 text-yellow-800" },
        Miércoles: {
          type: "break" as const,
          subject: "RECESO",
          color: "bg-yellow-100 border-yellow-300 text-yellow-800",
        },
        Jueves: { type: "break" as const, subject: "RECESO", color: "bg-yellow-100 border-yellow-300 text-yellow-800" },
        Viernes: {
          type: "break" as const,
          subject: "RECESO",
          color: "bg-yellow-100 border-yellow-300 text-yellow-800",
        },
      },
      slot_11: {
        Lunes: {
          type: "class" as const,
          subject: "Ciencias",
          teacher: "María González",
          color: "bg-green-100 border-green-300 text-green-800",
        },
        Martes: {
          type: "class" as const,
          subject: "Sociales",
          teacher: "Luis Pérez",
          color: "bg-orange-100 border-orange-300 text-orange-800",
        },
        Miércoles: {
          type: "class" as const,
          subject: "Matemáticas",
          teacher: "Ana Rodríguez",
          color: "bg-blue-100 border-blue-300 text-blue-800",
        },
        Jueves: {
          type: "class" as const,
          subject: "Lengua",
          teacher: "Carlos Mendoza",
          color: "bg-purple-100 border-purple-300 text-purple-800",
        },
        Viernes: { type: "empty" as const },
      },
      slot_12: {
        Lunes: {
          type: "class" as const,
          subject: "Ed. Física",
          teacher: "Pedro Sánchez",
          color: "bg-red-100 border-red-300 text-red-800",
        },
        Martes: {
          type: "class" as const,
          subject: "Inglés",
          teacher: "Elena Vásquez",
          color: "bg-indigo-100 border-indigo-300 text-indigo-800",
        },
        Miércoles: {
          type: "class" as const,
          subject: "Sociales",
          teacher: "Luis Pérez",
          color: "bg-orange-100 border-orange-300 text-orange-800",
        },
        Jueves: { type: "empty" as const },
        Viernes: {
          type: "class" as const,
          subject: "Matemáticas",
          teacher: "Ana Rodríguez",
          color: "bg-blue-100 border-blue-300 text-blue-800",
        },
      },
    }

    return (
      <ScheduleViewer
        course={selectedCourse}
        schedule={mockSchedule}
        onEdit={() => setCurrentView("edit")}
        onBack={handleBackToList}
      />
    )
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <Calendar className="h-8 w-8" />
            🗓️ Gestión de Horarios
          </h1>
          <p className="text-gray-600 mt-1">Crear, editar y gestionar horarios de todos los cursos</p>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Users className="h-5 w-5 text-blue-600" />
              <div>
                <div className="text-2xl font-bold text-blue-600">{stats.total}</div>
                <div className="text-sm text-gray-600">Total Cursos</div>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <CheckCircle className="h-5 w-5 text-green-600" />
              <div>
                <div className="text-2xl font-bold text-green-600">{stats.published}</div>
                <div className="text-sm text-gray-600">Publicados</div>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Edit className="h-5 w-5 text-yellow-600" />
              <div>
                <div className="text-2xl font-bold text-yellow-600">{stats.draft}</div>
                <div className="text-sm text-gray-600">Borradores</div>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Clock className="h-5 w-5 text-blue-600" />
              <div>
                <div className="text-2xl font-bold text-blue-600">{stats.pending}</div>
                <div className="text-sm text-gray-600">Pendientes</div>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-red-600" />
              <div>
                <div className="text-2xl font-bold text-red-600">{stats.withoutSchedule}</div>
                <div className="text-sm text-gray-600">Sin Horario</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="h-5 w-5" />
            Filtros y Búsqueda
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="Buscar por curso o profesor..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Estado del horario" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos los estados</SelectItem>
                <SelectItem value="published">✅ Publicados</SelectItem>
                <SelectItem value="draft">📝 Borradores</SelectItem>
                <SelectItem value="pending">⏳ Pendientes</SelectItem>
              </SelectContent>
            </Select>
            <Select value={filterTurn} onValueChange={setFilterTurn}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Turno" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos los turnos</SelectItem>
                <SelectItem value="Mañana">🌅 Mañana</SelectItem>
                <SelectItem value="Tarde">🌇 Tarde</SelectItem>
                <SelectItem value="Noche">🌙 Noche</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Courses List */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BookOpen className="h-5 w-5" />
            Lista de Cursos ({filteredCourses.length})
          </CardTitle>
          <CardDescription>Gestiona los horarios de cada curso individualmente</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredCourses.map((course) => {
              const scheduleStatus = getScheduleStatus(course.id)
              return (
                <Card key={course.id} className="hover:shadow-md transition-shadow">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">{course.name}</CardTitle>
                      {getStatusBadge(scheduleStatus?.status || "none")}
                    </div>
                    <CardDescription>
                      {course.level} • {course.turn} • {course.students} estudiantes
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="text-sm">
                        <div className="font-medium">👨‍🏫 {course.teacher}</div>
                        <div className="text-gray-600">{course.modality}</div>
                      </div>

                      <div className="text-sm">
                        <div className="font-medium mb-1">📚 Materias ({course.subjects.length}):</div>
                        <div className="flex flex-wrap gap-1">
                          {course.subjects.slice(0, 3).map((subject) => (
                            <Badge key={subject} variant="outline" className="text-xs">
                              {subject}
                            </Badge>
                          ))}
                          {course.subjects.length > 3 && (
                            <Badge variant="outline" className="text-xs">
                              +{course.subjects.length - 3} más
                            </Badge>
                          )}
                        </div>
                      </div>

                      {scheduleStatus && (
                        <div className="text-xs text-gray-600">
                          Última modificación: {new Date(scheduleStatus.lastModified).toLocaleDateString()}
                        </div>
                      )}

                      <div className="flex gap-2 pt-2">
                        {scheduleStatus ? (
                          <>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleViewSchedule(course)}
                              className="flex-1"
                            >
                              <Eye className="h-4 w-4 mr-1" />📅 Ver
                            </Button>
                            <Button size="sm" onClick={() => handleEditSchedule(course)} className="flex-1">
                              <Edit className="h-4 w-4 mr-1" />
                              ✏️ Editar
                            </Button>
                          </>
                        ) : (
                          <Button size="sm" onClick={() => handleCreateSchedule(course)} className="w-full">
                            <Plus className="h-4 w-4 mr-1" />➕ Crear Horario
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>

          {filteredCourses.length === 0 && (
            <div className="text-center py-8">
              <BookOpen className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No se encontraron cursos</h3>
              <p className="text-gray-600">
                Intenta ajustar los filtros de búsqueda para encontrar los cursos que buscas.
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
