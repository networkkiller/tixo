import { Skeleton } from "@/components/ui/skeleton"

export default function SchedulesLoading() {
  return (
    <div className="flex-1 space-y-6 p-6 bg-white">
      {/* Header Skeleton */}
      <div className="flex items-center justify-between">
        <div>
          <Skeleton className="h-8 w-[300px]" />
          <Skeleton className="h-4 w-[250px] mt-2" />
        </div>
        <Skeleton className="h-10 w-[180px]" />
      </div>

      {/* Stats Skeleton */}
      <div className="grid gap-4 md:grid-cols-3">
        {[1, 2, 3].map((i) => (
          <div key={i} className="rounded-lg border bg-card text-card-foreground shadow-sm p-6">
            <Skeleton className="h-5 w-[120px] mb-2" />
            <Skeleton className="h-8 w-[60px]" />
            <Skeleton className="h-4 w-full mt-2" />
          </div>
        ))}
      </div>

      {/* Tabs Skeleton */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <Skeleton className="h-10 w-[300px]" />
          <div className="flex items-center space-x-2">
            <Skeleton className="h-10 w-[300px]" />
            <Skeleton className="h-10 w-10" />
          </div>
        </div>

        {/* Filters Skeleton */}
        <div className="flex flex-wrap gap-2">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-10 w-[180px]" />
          ))}
        </div>

        {/* Cards Skeleton */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <div key={i} className="rounded-lg border bg-card text-card-foreground shadow-sm overflow-hidden">
              <div className="p-6 pb-2 flex flex-row items-start justify-between space-y-0">
                <div>
                  <Skeleton className="h-6 w-[150px]" />
                  <Skeleton className="h-4 w-[120px] mt-1" />
                </div>
                <Skeleton className="h-6 w-[80px]" />
              </div>
              <div className="p-6 pt-2">
                <div className="space-y-4">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <Skeleton className="h-4 w-[60px]" />
                      <Skeleton className="h-4 w-[30px]" />
                    </div>
                    <Skeleton className="h-2 w-full" />
                  </div>
                  <div className="flex items-center justify-between">
                    <Skeleton className="h-4 w-[120px]" />
                    <Skeleton className="h-4 w-[40px]" />
                  </div>
                  <div className="flex items-center justify-between pt-2">
                    <Skeleton className="h-9 w-[120px]" />
                    <div className="flex space-x-1">
                      <Skeleton className="h-8 w-8" />
                      <Skeleton className="h-8 w-8" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
