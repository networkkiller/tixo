"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  BookOpen,
  Users,
  Calendar,
  TrendingUp,
  AlertTriangle,
  CheckCircle,
  Clock,
  UserCheck,
  FileText,
  BarChart3,
  GraduationCap,
  CalendarDays,
  ChevronRight,
} from "lucide-react"
import { DailySchedule } from "@/components/dashboard/daily-schedule"
import { DailyAttendanceSummary } from "@/components/dashboard/daily-attendance-summary"
import { CourseStatusCard } from "@/components/course/course-status-card"
import { CourseNotifications } from "@/components/notifications/course-notifications"
import type { Course } from "@/lib/course-interoperability"

export default function CoordinadorAcademicoDashboard() {
  const [selectedPeriod, setSelectedPeriod] = useState("2024-1")

  // Cursos de ejemplo con diferentes estados
  const [newCourses] = useState<Course[]>([
    {
      id: "course_new_1",
      name: "6to B",
      grade: "6to",
      level: "Primaria",
      modality: "Regular",
      section: "B",
      turn: "Mañana",
      capacity: 30,
      teacher: null,
      schoolYear: "2024-2025",
      notes: "",
      createdAt: new Date().toISOString(),
      createdBy: "director_001",
      status: "active",
      studentsCount: 0,
      subjectsCount: 0,
      configurationStatus: {
        hasSubjects: false,
        hasTeacher: false,
        hasSchedule: false,
        hasStudents: false,
        isComplete: false,
        completionPercentage: 0,
      },
    },
  ])

  const [pendingConfiguration] = useState<Course[]>([
    {
      id: "course_pending_1",
      name: "5to A",
      grade: "5to",
      level: "Primaria",
      modality: "Regular",
      section: "A",
      turn: "Tarde",
      capacity: 25,
      teacher: "Ana Rodríguez",
      schoolYear: "2024-2025",
      notes: "",
      createdAt: new Date().toISOString(),
      createdBy: "director_001",
      status: "active",
      studentsCount: 0,
      subjectsCount: 3,
      configurationStatus: {
        hasSubjects: true,
        hasTeacher: true,
        hasSchedule: false,
        hasStudents: false,
        isComplete: false,
        completionPercentage: 50,
      },
    },
  ])

  const stats = {
    totalSubjects: 48,
    assignedTeachers: 41,
    pendingAssignments: 7,
    completedSchedules: 85,
    activeStudents: 1247,
    teacherCoverage: 85.4,
  }

  const alerts = [
    {
      id: 1,
      type: "warning",
      title: "Materias sin Docente",
      description: "7 materias requieren asignación de docente",
      priority: "high",
    },
    {
      id: 2,
      type: "info",
      title: "Horarios Pendientes",
      description: "3 cursos necesitan completar sus horarios",
      priority: "medium",
    },
    {
      id: 3,
      type: "success",
      title: "Planificación Actualizada",
      description: "Currículo 2024 implementado exitosamente",
      priority: "low",
    },
  ]

  const recentActivities = [
    {
      id: 1,
      action: "Asignó docente",
      subject: "Matemáticas III",
      teacher: "Prof. Carlos Mendoza",
      time: "Hace 2 horas",
    },
    {
      id: 2,
      action: "Creó horario",
      subject: "4to Bachillerato A",
      teacher: "Sistema",
      time: "Hace 4 horas",
    },
    {
      id: 3,
      action: "Actualizó materia",
      subject: "Física Aplicada",
      teacher: "Sistema",
      time: "Hace 1 día",
    },
  ]

  const handleViewDetails = (courseId: string) => {
    const course = [...newCourses, ...pendingConfiguration].find((c) => c.id === courseId)
    if (course) {
      // Redirigir a la página de detalles del curso
      window.location.href = `/dashboard/coordinador-academico/courses/${courseId}`
    }
  }

  const handleConfigureCourse = (courseId: string) => {
    const course = [...newCourses, ...pendingConfiguration].find((c) => c.id === courseId)
    if (course) {
      // Redirigir a la página de configuración de materias
      window.location.href = `/dashboard/coordinador-academico/curriculum?course=${courseId}&action=configure`
    }
  }

  const quickActions = [
    {
      title: "Asignar Docente",
      description: "Asignar profesores a materias",
      icon: UserCheck,
      href: "/dashboard/coordinador-academico/teacher-assignment",
      color: "bg-blue-500",
      onClick: () => (window.location.href = "/dashboard/coordinador-academico/teacher-assignment"),
    },
    {
      title: "Gestionar Currículo",
      description: "Administrar materias y contenidos",
      icon: BookOpen,
      href: "/dashboard/coordinador-academico/curriculum",
      color: "bg-green-500",
      onClick: () => (window.location.href = "/dashboard/coordinador-academico/curriculum"),
    },
    {
      title: "Crear Horarios",
      description: "Generar horarios de clases",
      icon: Calendar,
      href: "/dashboard/coordinador-academico/schedules",
      color: "bg-purple-500",
      onClick: () => (window.location.href = "/dashboard/coordinador-academico/schedules"),
    },
    {
      title: "Ver Reportes",
      description: "Análisis académico detallado",
      icon: FileText,
      href: "/dashboard/coordinador-academico/academic-reports",
      color: "bg-orange-500",
      onClick: () => (window.location.href = "/dashboard/coordinador-academico/academic-reports"),
    },
  ]

  const handleAlertAction = (alertType: string) => {
    switch (alertType) {
      case "materias-sin-docente":
        window.location.href = "/dashboard/coordinador-academico/teacher-assignment?filter=unassigned"
        break
      case "horarios-pendientes":
        window.location.href = "/dashboard/coordinador-academico/schedules?filter=pending"
        break
      case "planificacion-actualizada":
        window.location.href = "/dashboard/coordinador-academico/curriculum"
        break
      default:
        console.log("Acción no definida para:", alertType)
    }
  }

  const handleActivityClick = (activity: any) => {
    switch (activity.action) {
      case "Asignó docente":
        window.location.href = `/dashboard/coordinador-academico/teacher-assignment?subject=${activity.subject}`
        break
      case "Creó horario":
        window.location.href = `/dashboard/coordinador-academico/schedules?course=${activity.subject}`
        break
      case "Actualizó materia":
        window.location.href = `/dashboard/coordinador-academico/curriculum?subject=${activity.subject}`
        break
      default:
        console.log("Navegación no definida para:", activity.action)
    }
  }

  return (
    <div className="flex-1 space-y-6 p-6 bg-white">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Coordinación Académica</h1>
          <p className="text-muted-foreground">Gestión curricular y planificación académica institucional</p>
        </div>
        <div className="flex items-center space-x-4">
          <CourseNotifications userRole="coordinador-academico" />
          <select
            value={selectedPeriod}
            onChange={(e) => setSelectedPeriod(e.target.value)}
            className="px-3 py-2 border rounded-md"
          >
            <option value="2024-1">Período 2024-1</option>
            <option value="2023-2">Período 2023-2</option>
            <option value="2023-1">Período 2023-1</option>
          </select>
        </div>
      </div>

      {/* Cursos Nuevos sin Configurar */}
      {newCourses.length > 0 && (
        <Card className="bg-red-50 border-red-200">
          <CardHeader>
            <CardTitle className="text-red-800 flex items-center gap-2">
              <AlertTriangle className="h-5 w-5" />🆕 Cursos Nuevos sin Configurar
            </CardTitle>
            <CardDescription className="text-red-700">
              Estos cursos fueron creados recientemente y requieren configuración académica
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {newCourses.map((course) => (
                <CourseStatusCard
                  key={course.id}
                  course={course}
                  userRole="coordinador-academico"
                  onViewDetails={handleViewDetails}
                  onEdit={handleConfigureCourse}
                />
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Daily Attendance Summary */}
      <DailyAttendanceSummary />

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Materias</CardTitle>
            <BookOpen className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalSubjects}</div>
            <p className="text-xs text-muted-foreground">+3 desde el período anterior</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Docentes Asignados</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.assignedTeachers}</div>
            <p className="text-xs text-muted-foreground">{stats.pendingAssignments} pendientes por asignar</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Cobertura Docente</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.teacherCoverage}%</div>
            <Progress value={stats.teacherCoverage} className="mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Estudiantes Activos</CardTitle>
            <GraduationCap className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.activeStudents.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">Distribuidos en 24 cursos</p>
          </CardContent>
        </Card>
      </div>

      {/* Horario Diario */}
      <DailySchedule />

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {/* Alertas */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5" />
              Alertas y Notificaciones
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {alerts.map((alert) => (
              <div
                key={alert.id}
                className={`flex items-start space-x-3 p-3 rounded-lg border ${
                  alert.type === "warning"
                    ? "bg-yellow-50 border-yellow-200"
                    : alert.type === "info"
                      ? "bg-blue-50 border-blue-200"
                      : "bg-green-50 border-green-200"
                }`}
              >
                <div className="flex-shrink-0">
                  {alert.type === "warning" ? (
                    <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  ) : alert.type === "info" ? (
                    <Clock className="h-5 w-5 text-blue-600" />
                  ) : (
                    <CheckCircle className="h-5 w-5 text-green-600" />
                  )}
                </div>
                <div className="flex-1">
                  <h4 className="font-medium">{alert.title}</h4>
                  <p className="text-sm text-muted-foreground">{alert.description}</p>
                </div>
                <div className="flex flex-col gap-1">
                  <Badge
                    variant={
                      alert.priority === "high" ? "destructive" : alert.priority === "medium" ? "default" : "secondary"
                    }
                  >
                    {alert.priority === "high" ? "Alta" : alert.priority === "medium" ? "Media" : "Baja"}
                  </Badge>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() =>
                      handleAlertAction(
                        alert.type === "warning"
                          ? "materias-sin-docente"
                          : alert.type === "info"
                            ? "horarios-pendientes"
                            : "planificacion-actualizada",
                      )
                    }
                    className="text-xs"
                  >
                    Resolver
                  </Button>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle>Acciones Rápidas</CardTitle>
            <CardDescription>Tareas frecuentes de coordinación</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {quickActions.map((action, index) => (
              <Button
                key={index}
                variant="outline"
                className="w-full justify-start h-auto p-3 bg-transparent"
                onClick={action.onClick}
              >
                <div className="flex items-center space-x-3">
                  <div className={`p-2 rounded-md ${action.color}`}>
                    <action.icon className="h-4 w-4 text-white" />
                  </div>
                  <div className="text-left">
                    <div className="font-medium">{action.title}</div>
                    <div className="text-xs text-muted-foreground">{action.description}</div>
                  </div>
                  <ChevronRight className="ml-auto h-4 w-4 text-muted-foreground" />
                </div>
              </Button>
            ))}
          </CardContent>
        </Card>
      </div>

      {/* Cursos en Configuración */}
      {pendingConfiguration.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5 text-yellow-600" />
              Cursos en Configuración
            </CardTitle>
            <CardDescription>Cursos que requieren completar su configuración académica</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {pendingConfiguration.map((course) => (
                <CourseStatusCard
                  key={course.id}
                  course={course}
                  userRole="coordinador-academico"
                  onViewDetails={handleViewDetails}
                  onEdit={handleConfigureCourse}
                />
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Recent Activities */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5" />
            Actividad Reciente
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {recentActivities.map((activity) => (
              <div
                key={activity.id}
                className="flex items-center space-x-4 p-3 rounded-lg bg-muted/50 hover:bg-muted/70 cursor-pointer transition-colors"
                onClick={() => handleActivityClick(activity)}
              >
                <div className="flex-shrink-0">
                  <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                    <CalendarDays className="h-4 w-4 text-primary" />
                  </div>
                </div>
                <div className="flex-1">
                  <p className="text-sm">
                    <span className="font-medium">{activity.action}</span> en{" "}
                    <span className="font-medium">{activity.subject}</span>
                    {activity.teacher !== "Sistema" && (
                      <>
                        {" "}
                        a <span className="font-medium">{activity.teacher}</span>
                      </>
                    )}
                  </p>
                  <p className="text-xs text-muted-foreground">{activity.time}</p>
                </div>
                <ChevronRight className="h-4 w-4 text-muted-foreground" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
