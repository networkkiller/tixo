"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Progress } from "@/components/ui/progress"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import {
  AlertTriangle,
  BarChart3,
  Download,
  Filter,
  Search,
  Eye,
  CheckCircle,
  Calendar,
  FileText,
  Send,
  MessageSquare,
  Target,
  RefreshCw,
} from "lucide-react"

// Datos de ejemplo de cursos con calificaciones
const cursosData = [
  {
    id: 1,
    name: "6to A",
    level: "Primaria",
    turn: "Tarde",
    students: 28,
    currentPeriod: "P3",
    subjects: [
      {
        id: 1,
        name: "Matemáticas",
        teacher: "Ana Rodríguez",
        progress: 75,
        periodStatus: "En progreso",
        periods: {
          P1: { status: "closed", progress: 100, validatedBy: "Coord. Académico", closedDate: "2024-03-15" },
          P2: { status: "closed", progress: 100, validatedBy: "Coord. Académico", closedDate: "2024-05-15" },
          P3: { status: "active", progress: 75, validatedBy: null, closedDate: null },
          P4: { status: "pending", progress: 0, validatedBy: null, closedDate: null },
        },
        competencias: {
          comunicativa: { configured: true, activities: 3, totalWeight: 100 },
          pensamiento: { configured: true, activities: 4, totalWeight: 100 },
          cientifica: { configured: false, activities: 2, totalWeight: 80 },
          ambiental: { configured: true, activities: 3, totalWeight: 100 },
          etica: { configured: true, activities: 2, totalWeight: 100 },
          personal: { configured: true, activities: 3, totalWeight: 100 },
        },
        alerts: ["Competencia Científica incompleta", "3 estudiantes sin calificar en P3"],
      },
      {
        id: 2,
        name: "Lenguaje",
        teacher: "Carmen Silva",
        progress: 85,
        periodStatus: "En progreso",
        periods: {
          P1: { status: "closed", progress: 100, validatedBy: "Coord. Académico", closedDate: "2024-03-15" },
          P2: { status: "closed", progress: 100, validatedBy: "Coord. Académico", closedDate: "2024-05-15" },
          P3: { status: "active", progress: 85, validatedBy: null, closedDate: null },
          P4: { status: "pending", progress: 0, validatedBy: null, closedDate: null },
        },
        competencias: {
          comunicativa: { configured: true, activities: 4, totalWeight: 100 },
          pensamiento: { configured: true, activities: 3, totalWeight: 100 },
          cientifica: { configured: true, activities: 3, totalWeight: 100 },
          ambiental: { configured: true, activities: 2, totalWeight: 100 },
          etica: { configured: true, activities: 3, totalWeight: 100 },
          personal: { configured: true, activities: 3, totalWeight: 100 },
        },
        alerts: [],
      },
      {
        id: 3,
        name: "Ciencias Naturales",
        teacher: "Roberto Martínez",
        progress: 60,
        periodStatus: "Pendiente validación",
        periods: {
          P1: { status: "closed", progress: 100, validatedBy: "Coord. Académico", closedDate: "2024-03-15" },
          P2: { status: "pending_validation", progress: 100, validatedBy: null, closedDate: null },
          P3: { status: "pending", progress: 0, validatedBy: null, closedDate: null },
          P4: { status: "pending", progress: 0, validatedBy: null, closedDate: null },
        },
        competencias: {
          comunicativa: { configured: true, activities: 3, totalWeight: 100 },
          pensamiento: { configured: true, activities: 3, totalWeight: 100 },
          cientifica: { configured: true, activities: 4, totalWeight: 100 },
          ambiental: { configured: true, activities: 4, totalWeight: 100 },
          etica: { configured: true, activities: 2, totalWeight: 100 },
          personal: { configured: true, activities: 3, totalWeight: 100 },
        },
        alerts: ["Período P2 pendiente de validación"],
      },
      {
        id: 4,
        name: "Ciencias Sociales",
        teacher: "Laura Fernández",
        progress: 90,
        periodStatus: "CERRADO",
        periods: {
          P1: { status: "closed", progress: 100, validatedBy: "Coord. Académico", closedDate: "2024-03-15" },
          P2: { status: "closed", progress: 100, validatedBy: "Coord. Académico", closedDate: "2024-05-15" },
          P3: { status: "pending", progress: 0, validatedBy: null, closedDate: null },
          P4: { status: "pending", progress: 0, validatedBy: null, closedDate: null },
        },
        competencias: {
          comunicativa: { configured: true, activities: 3, totalWeight: 100 },
          pensamiento: { configured: true, activities: 3, totalWeight: 100 },
          cientifica: { configured: true, activities: 3, totalWeight: 100 },
          ambiental: { configured: true, activities: 4, totalWeight: 100 },
          etica: { configured: true, activities: 4, totalWeight: 100 },
          personal: { configured: true, activities: 3, totalWeight: 100 },
        },
        alerts: [],
      },
    ],
  },
  {
    id: 2,
    name: "5to B",
    level: "Primaria",
    turn: "Mañana",
    students: 25,
    currentPeriod: "P2",
    subjects: [
      {
        id: 5,
        name: "Matemáticas",
        teacher: "Carlos Méndez",
        progress: 100,
        periodStatus: "CERRADO",
        periods: {
          P1: { status: "closed", progress: 100, validatedBy: "Coord. Académico", closedDate: "2024-03-15" },
          P2: { status: "closed", progress: 100, validatedBy: "Coord. Académico", closedDate: "2024-05-15" },
          P3: { status: "pending", progress: 0, validatedBy: null, closedDate: null },
          P4: { status: "pending", progress: 0, validatedBy: null, closedDate: null },
        },
        competencias: {
          comunicativa: { configured: true, activities: 4, totalWeight: 100 },
          pensamiento: { configured: true, activities: 3, totalWeight: 100 },
          cientifica: { configured: true, activities: 3, totalWeight: 100 },
          ambiental: { configured: true, activities: 2, totalWeight: 100 },
          etica: { configured: true, activities: 3, totalWeight: 100 },
          personal: { configured: true, activities: 3, totalWeight: 100 },
        },
        alerts: [],
      },
      {
        id: 6,
        name: "Lenguaje",
        teacher: "Patricia Vega",
        progress: 95,
        periodStatus: "CERRADO",
        periods: {
          P1: { status: "closed", progress: 100, validatedBy: "Coord. Académico", closedDate: "2024-03-15" },
          P2: { status: "closed", progress: 100, validatedBy: "Coord. Académico", closedDate: "2024-05-15" },
          P3: { status: "pending", progress: 0, validatedBy: null, closedDate: null },
          P4: { status: "pending", progress: 0, validatedBy: null, closedDate: null },
        },
        competencias: {
          comunicativa: { configured: true, activities: 4, totalWeight: 100 },
          pensamiento: { configured: true, activities: 3, totalWeight: 100 },
          cientifica: { configured: true, activities: 3, totalWeight: 100 },
          ambiental: { configured: true, activities: 2, totalWeight: 100 },
          etica: { configured: true, activities: 3, totalWeight: 100 },
          personal: { configured: true, activities: 3, totalWeight: 100 },
        },
        alerts: [],
      },
    ],
  },
  {
    id: 3,
    name: "4to A",
    level: "Primaria",
    turn: "Mañana",
    students: 30,
    currentPeriod: "P2",
    subjects: [
      {
        id: 7,
        name: "Ciencias Naturales",
        teacher: "María González",
        progress: 45,
        periodStatus: "Pendiente validación",
        periods: {
          P1: { status: "closed", progress: 100, validatedBy: "Coord. Académico", closedDate: "2024-03-15" },
          P2: { status: "pending_validation", progress: 100, validatedBy: null, closedDate: null },
          P3: { status: "pending", progress: 0, validatedBy: null, closedDate: null },
          P4: { status: "pending", progress: 0, validatedBy: null, closedDate: null },
        },
        competencias: {
          comunicativa: { configured: true, activities: 3, totalWeight: 100 },
          pensamiento: { configured: true, activities: 3, totalWeight: 100 },
          cientifica: { configured: true, activities: 4, totalWeight: 100 },
          ambiental: { configured: true, activities: 4, totalWeight: 100 },
          etica: { configured: true, activities: 2, totalWeight: 100 },
          personal: { configured: true, activities: 3, totalWeight: 100 },
        },
        alerts: ["Período P2 pendiente de validación"],
      },
    ],
  },
]

// Datos de ejemplo de estudiantes con calificaciones detalladas
const estudiantesDetalle = [
  {
    id: 1,
    name: "Ana María González",
    matricula: "2024001",
    grades: {
      P1: 85,
      RP1: null,
      P2: 78,
      RP2: null,
      P3: 82,
      RP3: null,
      P4: null,
      RP4: null,
      CF: null,
      CCF: null,
      CEXF: null,
      CE: null,
    },
    competencias: {
      P1: {
        comunicativa: 88,
        pensamiento: 82,
        cientifica: 85,
        ambiental: 87,
        etica: 84,
        personal: 86,
        // Recuperaciones por competencia
        recuperaciones: null,
      },
      P2: {
        comunicativa: 80,
        pensamiento: 76,
        cientifica: 78,
        ambiental: 79,
        etica: 77,
        personal: 78,
        recuperaciones: null,
      },
      P3: {
        comunicativa: 84,
        pensamiento: 80,
        cientifica: 82,
        ambiental: 85,
        etica: 81,
        personal: 83,
        recuperaciones: null,
      },
    },
    finalStatus: "En proceso",
  },
  {
    id: 2,
    name: "Carlos Eduardo Pérez",
    matricula: "2024002",
    grades: {
      P1: 68,
      RP1: 75,
      P2: 65,
      RP2: 78,
      P3: 70,
      RP3: null,
      P4: null,
      RP4: null,
      CF: null,
      CCF: null,
      CEXF: null,
      CE: null,
    },
    competencias: {
      P1: {
        comunicativa: 70,
        pensamiento: 66,
        cientifica: 68,
        ambiental: 69,
        etica: 67,
        personal: 68,
        // Recuperaciones aplicadas en competencias que estaban por debajo de 70
        recuperaciones: {
          pensamiento: 72, // Recuperación aplicada
          cientifica: 74, // Recuperación aplicada
          etica: 71, // Recuperación aplicada
        },
      },
      P2: {
        comunicativa: 74,
        pensamiento: 70,
        cientifica: 72,
        ambiental: 73,
        etica: 71,
        personal: 72,
        recuperaciones: null,
      },
      P3: {
        comunicativa: 72,
        pensamiento: 68,
        cientifica: 70,
        ambiental: 71,
        etica: 69,
        personal: 70,
        recuperaciones: {
          pensamiento: 73, // Recuperación aplicada
          etica: 72, // Recuperación aplicada
        },
      },
    },
    finalStatus: "Recuperación aplicada",
  },
  {
    id: 3,
    name: "María José Rodríguez",
    matricula: "2024003",
    grades: {
      P1: 95,
      RP1: null,
      P2: 92,
      RP2: null,
      P3: 94,
      RP3: null,
      P4: null,
      RP4: null,
      CF: null,
      CCF: null,
      CEXF: null,
      CE: null,
    },
    competencias: {
      P1: { comunicativa: 96, pensamiento: 94, cientifica: 95, ambiental: 97, etica: 93, personal: 95 },
      P2: { comunicativa: 93, pensamiento: 91, cientifica: 92, ambiental: 94, etica: 90, personal: 92 },
      P3: { comunicativa: 95, pensamiento: 93, cientifica: 94, ambiental: 96, etica: 92, personal: 94 },
    },
    finalStatus: "Excelente",
  },
  {
    id: 4,
    name: "Pedro Antonio López",
    matricula: "2024004",
    grades: {
      P1: 62,
      RP1: 73,
      P2: 58,
      RP2: 71,
      P3: 66,
      RP3: 76,
      P4: null,
      RP4: null,
      CF: null,
      CCF: null,
      CEXF: null,
      CE: null,
    },
    competencias: {
      P1: {
        comunicativa: 65,
        pensamiento: 60,
        cientifica: 62,
        ambiental: 64,
        etica: 61,
        personal: 63,
        recuperaciones: {
          comunicativa: 72,
          pensamiento: 74,
          cientifica: 73,
          ambiental: 71,
          etica: 70,
          personal: 75,
        },
      },
      P2: {
        comunicativa: 60,
        pensamiento: 56,
        cientifica: 58,
        ambiental: 59,
        etica: 57,
        personal: 58,
        recuperaciones: {
          comunicativa: 73,
          pensamiento: 72,
          cientifica: 74,
          ambiental: 71,
          etica: 70,
          personal: 76,
        },
      },
      P3: {
        comunicativa: 68,
        pensamiento: 64,
        cientifica: 66,
        ambiental: 67,
        etica: 65,
        personal: 66,
        recuperaciones: {
          pensamiento: 75,
          cientifica: 73,
          etica: 72,
        },
      },
    },
    finalStatus: "Múltiples recuperaciones",
  },
]

export default function GradeMonitoringPage() {
  // Estados para los modales
  const [validationModalOpen, setValidationModalOpen] = useState(false)
  const [returnModalOpen, setReturnModalOpen] = useState(false)
  const [dateConfigModalOpen, setDateConfigModalOpen] = useState(false)
  const [bulletinModalOpen, setBulletinModalOpen] = useState(false)
  const [detailModalOpen, setDetailModalOpen] = useState(false)

  // Estados para la búsqueda y filtros
  const [searchTerm, setSearchTerm] = useState("")
  const [filterLevel, setFilterLevel] = useState("all")
  const [filterStatus, setFilterStatus] = useState("all")
  const [filterTeacher, setFilterTeacher] = useState("all")

  // Estados para la selección de curso y período
  const [selectedCourse, setSelectedCourse] = useState(null)
  const [selectedPeriod, setSelectedPeriod] = useState("P1")

  // Estados para comentarios y detalles
  const [returnComment, setReturnComment] = useState("")
  const [selectedStudentDetail, setSelectedStudentDetail] = useState(null)

  // Función para obtener el color del estado
  const getStatusColor = (status) => {
    switch (status.toLowerCase()) {
      case "cerrado":
        return "bg-green-100 text-green-800"
      case "en progreso":
        return "bg-blue-100 text-blue-800"
      case "pendiente validación":
        return "bg-yellow-100 text-yellow-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  // Función para obtener el color del período
  const getPeriodStatusColor = (status) => {
    switch (status) {
      case "closed":
        return "bg-green-100 text-green-800"
      case "active":
        return "bg-blue-100 text-blue-800"
      case "pending_validation":
        return "bg-yellow-100 text-yellow-800"
      case "pending":
        return "bg-gray-100 text-gray-600"
      default:
        return "bg-gray-100 text-gray-600"
    }
  }

  // Función para obtener el texto del estado del período
  const getPeriodStatusText = (status) => {
    switch (status) {
      case "closed":
        return "Cerrado"
      case "active":
        return "Activo"
      case "pending_validation":
        return "Pendiente Validación"
      case "pending":
        return "Pendiente"
      default:
        return "Desconocido"
    }
  }

  // Función para validar período
  const handleValidatePeriod = (course, period) => {
    // Simular validación
    alert(`Período ${period} del curso ${course.name} validado exitosamente`)
    setValidationModalOpen(false)
  }

  // Función para devolver a docente
  const handleReturnToTeacher = () => {
    if (!returnComment.trim()) {
      alert("Por favor ingrese un comentario para el docente")
      return
    }
    alert("Calificaciones devueltas al docente con comentarios")
    setReturnModalOpen(false)
    setReturnComment("")
  }

  // Función para cerrar período definitivamente
  const handleClosePeriod = (course, period) => {
    if (confirm(`¿Está seguro de cerrar definitivamente el período ${period} del curso ${course.name}?`)) {
      alert(`Período ${period} cerrado definitivamente. Se ha notificado al Director y Coordinador de Registro.`)
    }
  }

  // Función para generar boletín
  const handleGenerateBulletin = (course) => {
    setSelectedCourse(course)
    setBulletinModalOpen(true)
  }

  // Filtrar cursos
  const filteredCourses = cursosData.filter((course) => {
    const matchesSearch =
      course.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      course.subjects.some(
        (subject) =>
          subject.teacher.toLowerCase().includes(searchTerm.toLowerCase()) ||
          subject.name.toLowerCase().includes(searchTerm.toLowerCase()),
      )
    const matchesLevel = filterLevel === "all" || course.level === filterLevel
    const matchesStatus =
      filterStatus === "all" ||
      course.subjects.some((subject) => subject.periodStatus.toLowerCase().includes(filterStatus))
    const matchesTeacher =
      filterTeacher === "all" || course.subjects.some((subject) => subject.teacher === filterTeacher)

    return matchesSearch && matchesLevel && matchesStatus && matchesTeacher
  })

  // Estadísticas calculadas
  const stats = {
    totalCourses: cursosData.length,
    activePeriods: cursosData.reduce(
      (sum, course) => sum + course.subjects.filter((s) => s.periodStatus.includes("progreso")).length,
      0,
    ),
    pendingValidation: cursosData.reduce(
      (sum, course) => sum + course.subjects.filter((s) => s.periodStatus.includes("validación")).length,
      0,
    ),
    closedPeriods: cursosData.reduce(
      (sum, course) => sum + course.subjects.filter((s) => s.periodStatus === "CERRADO").length,
      0,
    ),
    averageProgress: Math.round(
      cursosData.reduce(
        (sum, course) =>
          sum + course.subjects.reduce((subSum, subject) => subSum + subject.progress, 0) / course.subjects.length,
        0,
      ) / cursosData.length,
    ),
    totalAlerts: cursosData.reduce(
      (sum, course) => sum + course.subjects.reduce((subSum, subject) => subSum + subject.alerts.length, 0),
      0,
    ),
  }

  return (
    <div className="flex-1 space-y-6 p-6 bg-white">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Supervisión de Calificaciones</h1>
          <p className="text-muted-foreground">
            Validación y cierre de períodos evaluativos por competencias del MINERD
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <Button variant="outline" onClick={() => setDateConfigModalOpen(true)}>
            <Calendar className="h-4 w-4 mr-2" />
            Configurar Fechas
          </Button>
          <Button className="bg-blue-600 hover:bg-blue-700">
            <Download className="h-4 w-4 mr-2" />
            Reporte General
          </Button>
        </div>
      </div>

      {/* Estadísticas */}
      <div className="grid gap-4 md:grid-cols-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Cursos</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalCourses}</div>
            <p className="text-xs text-muted-foreground">Bajo supervisión</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Períodos Activos</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{stats.activePeriods}</div>
            <p className="text-xs text-muted-foreground">En progreso</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Pendientes Validación</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">{stats.pendingValidation}</div>
            <p className="text-xs text-muted-foreground">Requieren revisión</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Períodos Cerrados</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{stats.closedPeriods}</div>
            <p className="text-xs text-muted-foreground">Validados</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Progreso Promedio</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.averageProgress}%</div>
            <Progress value={stats.averageProgress} className="mt-1" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Alertas Activas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{stats.totalAlerts}</div>
            <p className="text-xs text-muted-foreground">Requieren atención</p>
          </CardContent>
        </Card>
      </div>

      {!selectedCourse ? (
        // Vista general de cursos
        <div className="space-y-6">
          {/* Filtros */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Filter className="h-5 w-5" />
                Filtros de Supervisión
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-5">
                <div className="relative">
                  <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Buscar curso, docente o materia..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-8"
                  />
                </div>

                <Select value={filterLevel} onValueChange={setFilterLevel}>
                  <SelectTrigger>
                    <SelectValue placeholder="Nivel" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos los niveles</SelectItem>
                    <SelectItem value="Inicial">Inicial</SelectItem>
                    <SelectItem value="Primaria">Primaria</SelectItem>
                    <SelectItem value="Secundaria">Secundaria</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={filterStatus} onValueChange={setFilterStatus}>
                  <SelectTrigger>
                    <SelectValue placeholder="Estado" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos los estados</SelectItem>
                    <SelectItem value="progreso">En progreso</SelectItem>
                    <SelectItem value="validación">Pendiente validación</SelectItem>
                    <SelectItem value="cerrado">Cerrado</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={filterTeacher} onValueChange={setFilterTeacher}>
                  <SelectTrigger>
                    <SelectValue placeholder="Docente" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos los docentes</SelectItem>
                    <SelectItem value="Ana Rodríguez">Ana Rodríguez</SelectItem>
                    <SelectItem value="Carlos Méndez">Carlos Méndez</SelectItem>
                    <SelectItem value="María González">María González</SelectItem>
                  </SelectContent>
                </Select>

                <Button variant="outline">
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Actualizar
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Lista de cursos */}
          <div className="grid gap-6 md:grid-cols-1 lg:grid-cols-2">
            {filteredCourses.map((course) => {
              // Calcular estadísticas del curso
              const courseAverageProgress = Math.round(
                course.subjects.reduce((sum, subject) => sum + subject.progress, 0) / course.subjects.length,
              )
              const totalCourseAlerts = course.subjects.reduce((sum, subject) => sum + subject.alerts.length, 0)
              const activePeriods = course.subjects.filter((s) => s.periodStatus.includes("progreso")).length
              const pendingValidation = course.subjects.filter((s) => s.periodStatus.includes("validación")).length
              const closedPeriods = course.subjects.filter((s) => s.periodStatus === "CERRADO").length

              return (
                <Card key={course.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-xl">{course.name}</CardTitle>
                      <div className="flex gap-2">
                        <Badge className="bg-blue-100 text-blue-800">{course.subjects.length} materias</Badge>
                        <Badge
                          className={
                            courseAverageProgress >= 80
                              ? "bg-green-100 text-green-800"
                              : courseAverageProgress >= 60
                                ? "bg-yellow-100 text-yellow-800"
                                : "bg-red-100 text-red-800"
                          }
                        >
                          {courseAverageProgress}% promedio
                        </Badge>
                      </div>
                    </div>
                    <div className="text-sm text-gray-600 space-y-1">
                      <p>📚 {course.level}</p>
                      <p>🕐 {course.turn}</p>
                      <p>👥 {course.students} estudiantes</p>
                      <p>📅 Período actual: {course.currentPeriod}</p>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Resumen de estados */}
                    <div className="grid grid-cols-3 gap-2 text-xs">
                      <div className="bg-green-50 p-2 rounded text-center">
                        <div className="font-medium text-green-800">{closedPeriods}</div>
                        <div className="text-green-600">Cerrados</div>
                      </div>
                      <div className="bg-blue-50 p-2 rounded text-center">
                        <div className="font-medium text-blue-800">{activePeriods}</div>
                        <div className="text-blue-600">Activos</div>
                      </div>
                      <div className="bg-yellow-50 p-2 rounded text-center">
                        <div className="font-medium text-yellow-800">{pendingValidation}</div>
                        <div className="text-yellow-600">Pendientes</div>
                      </div>
                    </div>

                    {/* Lista de materias */}
                    <div className="space-y-3">
                      <span className="text-sm font-medium">Materias del curso:</span>
                      {course.subjects.map((subject) => (
                        <div key={subject.id} className="border rounded-lg p-3 bg-gray-50">
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-2">
                              <span className="font-medium text-sm">{subject.name}</span>
                              <Badge className={getStatusColor(subject.periodStatus)} size="sm">
                                {subject.periodStatus}
                              </Badge>
                            </div>
                            <span className="text-xs text-gray-600">👨‍🏫 {subject.teacher}</span>
                          </div>

                          {/* Progreso de la materia */}
                          <div className="mb-2">
                            <div className="flex items-center justify-between text-xs mb-1">
                              <span>Progreso {course.currentPeriod}:</span>
                              <span className="font-medium">{subject.progress}%</span>
                            </div>
                            <Progress value={subject.progress} className="h-1" />
                          </div>

                          {/* Estado de períodos por materia */}
                          <div className="mb-2">
                            <div className="grid grid-cols-4 gap-1">
                              {["P1", "P2", "P3", "P4"].map((period) => {
                                const periodData = subject.periods[period]
                                return (
                                  <div
                                    key={period}
                                    className={`text-xs px-1 py-1 rounded text-center ${getPeriodStatusColor(
                                      periodData.status,
                                    )}`}
                                  >
                                    {period}
                                  </div>
                                )
                              })}
                            </div>
                          </div>

                          {/* Alertas por materia */}
                          {subject.alerts.length > 0 && (
                            <div className="space-y-1">
                              {subject.alerts.map((alert, index) => (
                                <div
                                  key={index}
                                  className="text-xs text-red-600 bg-red-50 p-1 rounded flex items-center"
                                >
                                  <AlertTriangle className="h-3 w-3 mr-1" />
                                  {alert}
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>

                    {/* Alertas generales del curso */}
                    {totalCourseAlerts > 0 && (
                      <div className="bg-red-50 p-3 rounded-lg">
                        <div className="flex items-center gap-2 text-red-600 text-sm font-medium mb-1">
                          <AlertTriangle className="h-4 w-4" />
                          {totalCourseAlerts} alertas activas en el curso
                        </div>
                      </div>
                    )}

                    {/* Acciones del curso */}
                    <div className="flex gap-2 pt-2 border-t">
                      <Button
                        onClick={() => setSelectedCourse(course)}
                        className="flex-1 bg-indigo-600 hover:bg-indigo-700"
                      >
                        <Eye className="h-4 w-4 mr-2" />
                        Supervisar Curso
                      </Button>
                      <Button variant="outline" size="sm" onClick={() => handleGenerateBulletin(course)}>
                        <FileText className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      ) : (
        // Vista detallada del curso seleccionado
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <Button variant="outline" onClick={() => setSelectedCourse(null)} className="mb-2">
                ← Volver a Cursos
              </Button>
              <h2 className="text-2xl font-bold text-gray-900">{selectedCourse.name} - Supervisión Detallada</h2>
              <p className="text-gray-600">
                {selectedCourse.students} estudiantes • {selectedCourse.turn} • {selectedCourse.subjects.length}{" "}
                materias
              </p>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => setReturnModalOpen(true)}>
                <MessageSquare className="h-4 w-4 mr-2" />
                Devolver a Docente
              </Button>
              <Button
                onClick={() => handleGenerateBulletin(selectedCourse)}
                className="bg-green-600 hover:bg-green-700"
              >
                <FileText className="h-4 w-4 mr-2" />
                Generar Boletín
              </Button>
            </div>
          </div>

          {/* Vista por materias del curso */}
          <div className="space-y-6">
            {selectedCourse.subjects.map((subject) => (
              <Card key={subject.id} className="border-2">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-xl flex items-center gap-2">📚 {subject.name}</CardTitle>
                      <p className="text-gray-600 mt-1">
                        👨‍🏫 {subject.teacher} • Progreso: {subject.progress}%
                      </p>
                    </div>
                    <div className="flex gap-2">
                      <Badge className={getStatusColor(subject.periodStatus)}>{subject.periodStatus}</Badge>
                      {subject.alerts.length > 0 && (
                        <Badge className="bg-red-100 text-red-800">{subject.alerts.length} alertas</Badge>
                      )}
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  {/* Tabs por período para cada materia */}
                  <Tabs value={selectedPeriod} onValueChange={setSelectedPeriod} className="w-full">
                    <TabsList className="grid w-full grid-cols-4">
                      {["P1", "P2", "P3", "P4"].map((period) => {
                        const periodData = subject.periods[period]
                        return (
                          <TabsTrigger
                            key={period}
                            value={period}
                            className={`${getPeriodStatusColor(periodData.status)} data-[state=active]:opacity-100`}
                          >
                            {period}
                            {periodData.status === "closed" && <CheckCircle className="h-3 w-3 ml-1" />}
                            {periodData.status === "pending_validation" && <AlertTriangle className="h-3 w-3 ml-1" />}
                          </TabsTrigger>
                        )
                      })}
                    </TabsList>

                    {["P1", "P2", "P3", "P4"].map((period) => {
                      const periodData = subject.periods[period]
                      return (
                        <TabsContent key={period} value={period} className="space-y-4">
                          {/* Información del período por materia */}
                          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                            <div className="bg-gray-50 p-3 rounded-lg">
                              <div className="text-sm text-gray-600">Estado</div>
                              <div className="font-medium">{getPeriodStatusText(periodData.status)}</div>
                            </div>
                            <div className="bg-gray-50 p-3 rounded-lg">
                              <div className="text-sm text-gray-600">Progreso</div>
                              <div className="font-medium">{periodData.progress}%</div>
                            </div>
                            <div className="bg-gray-50 p-3 rounded-lg">
                              <div className="text-sm text-gray-600">Validado por</div>
                              <div className="font-medium">{periodData.validatedBy || "Pendiente"}</div>
                            </div>
                            <div className="bg-gray-50 p-3 rounded-lg">
                              <div className="text-sm text-gray-600">Fecha de cierre</div>
                              <div className="font-medium">{periodData.closedDate || "No cerrado"}</div>
                            </div>
                          </div>

                          {/* Acciones por período y materia */}
                          <div className="flex gap-2 justify-end">
                            {periodData.status === "pending_validation" && (
                              <>
                                <Button
                                  variant="outline"
                                  onClick={() => setValidationModalOpen(true)}
                                  className="border-yellow-300 text-yellow-700"
                                >
                                  <CheckCircle className="h-4 w-4 mr-2" />
                                  Validar {period}
                                </Button>
                                <Button
                                  onClick={() => handleClosePeriod(selectedCourse, period)}
                                  className="bg-green-600 hover:bg-green-700"
                                >
                                  Cerrar {period}
                                </Button>
                              </>
                            )}
                          </div>

                          {/* Validación de competencias por materia */}
                          <div>
                            <h5 className="text-md font-semibold mb-3">Competencias - {subject.name}</h5>
                            <div className="grid gap-3 md:grid-cols-2">
                              {Object.entries(subject.competencias).map(([key, competencia]) => {
                                const competenciaNames = {
                                  comunicativa: "Comunicativa",
                                  pensamiento: "Pensamiento Lógico y Crítico",
                                  cientifica: "Científica y Tecnológica",
                                  ambiental: "Ambiental y de la Salud",
                                  etica: "Ética y Ciudadana",
                                  personal: "Desarrollo Personal y Espiritual",
                                }

                                return (
                                  <div
                                    key={key}
                                    className={`p-3 rounded-lg border ${
                                      competencia.configured
                                        ? "bg-green-50 border-green-200"
                                        : "bg-red-50 border-red-200"
                                    }`}
                                  >
                                    <div className="flex items-center justify-between mb-1">
                                      <h6 className="font-medium text-sm">{competenciaNames[key]}</h6>
                                      {competencia.configured ? (
                                        <CheckCircle className="h-4 w-4 text-green-600" />
                                      ) : (
                                        <AlertTriangle className="h-4 w-4 text-red-600" />
                                      )}
                                    </div>
                                    <div className="text-xs text-gray-600">
                                      <p>Actividades: {competencia.activities}</p>
                                      <p>Ponderación: {competencia.totalWeight}%</p>
                                    </div>
                                  </div>
                                )
                              })}
                            </div>
                          </div>

                          {/* Alertas específicas de la materia */}
                          {subject.alerts.length > 0 && (
                            <div className="bg-red-50 p-3 rounded-lg">
                              <h6 className="font-medium text-red-800 mb-2">Alertas de {subject.name}:</h6>
                              {subject.alerts.map((alert, index) => (
                                <div key={index} className="text-sm text-red-600 flex items-center mb-1">
                                  <AlertTriangle className="h-3 w-3 mr-2" />
                                  {alert}
                                </div>
                              ))}
                            </div>
                          )}
                        </TabsContent>
                      )
                    })}
                  </Tabs>

                  {/* Lista de estudiantes con calificaciones por materia */}
                  <div className="mt-6 pt-6 border-t">
                    <h4 className="text-lg font-semibold mb-4">Estudiantes - {subject.name}</h4>
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Estudiante</TableHead>
                            <TableHead className="text-center">P1</TableHead>
                            <TableHead className="text-center">P2</TableHead>
                            <TableHead className="text-center">P3</TableHead>
                            <TableHead className="text-center">P4</TableHead>
                            <TableHead className="text-center">Promedio</TableHead>
                            <TableHead className="text-center">Competencias</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {estudiantesDetalle.map((student) => {
                            // Simular calificaciones específicas por materia
                            const subjectGrades = {
                              P1: student.grades.P1 ? student.grades.P1 + Math.floor(Math.random() * 10) - 5 : null,
                              P2: student.grades.P2 ? student.grades.P2 + Math.floor(Math.random() * 10) - 5 : null,
                              P3: student.grades.P3 ? student.grades.P3 + Math.floor(Math.random() * 10) - 5 : null,
                              P4: student.grades.P4 ? student.grades.P4 + Math.floor(Math.random() * 10) - 5 : null,
                            }

                            // Calcular promedio
                            const validGrades = Object.values(subjectGrades).filter((grade) => grade !== null)
                            const average =
                              validGrades.length > 0
                                ? Math.round(validGrades.reduce((sum, grade) => sum + grade, 0) / validGrades.length)
                                : 0

                            return (
                              <TableRow key={student.id}>
                                <TableCell>
                                  <div>
                                    <div className="font-medium">{student.name}</div>
                                    <div className="text-sm text-gray-500">{student.matricula}</div>
                                  </div>
                                </TableCell>
                                {["P1", "P2", "P3", "P4"].map((period) => (
                                  <TableCell key={period} className="text-center">
                                    <div className="flex flex-col items-center gap-1">
                                      {subjectGrades[period] ? (
                                        <Badge
                                          className={
                                            subjectGrades[period] >= 90
                                              ? "bg-green-100 text-green-800"
                                              : subjectGrades[period] >= 80
                                                ? "bg-blue-100 text-blue-800"
                                                : subjectGrades[period] >= 70
                                                  ? "bg-yellow-100 text-yellow-800"
                                                  : "bg-red-100 text-red-800"
                                          }
                                        >
                                          {Math.max(0, Math.min(100, subjectGrades[period]))}
                                        </Badge>
                                      ) : (
                                        <span className="text-gray-400">-</span>
                                      )}
                                      {/* Mostrar recuperación si existe */}
                                      {student.grades[`R${period}`] && (
                                        <Badge className="bg-orange-100 text-orange-800 text-xs">
                                          R{period}: {student.grades[`R${period}`]}
                                        </Badge>
                                      )}
                                    </div>
                                  </TableCell>
                                ))}
                                <TableCell className="text-center">
                                  <Badge
                                    className={
                                      average >= 90
                                        ? "bg-green-100 text-green-800"
                                        : average >= 80
                                          ? "bg-blue-100 text-blue-800"
                                          : average >= 70
                                            ? "bg-yellow-100 text-yellow-800"
                                            : "bg-red-100 text-red-800"
                                    }
                                  >
                                    {average}
                                  </Badge>
                                </TableCell>
                                <TableCell className="text-center">
                                  <Dialog>
                                    <DialogTrigger asChild>
                                      <Button size="sm" variant="outline">
                                        <Eye className="h-3 w-3 mr-1" />
                                        Ver Competencias
                                      </Button>
                                    </DialogTrigger>

                                    <DialogContent className="max-w-6xl max-h-[80vh] overflow-y-auto">
                                      <DialogHeader>
                                        <DialogTitle>
                                          Competencias Consolidadas - {selectedStudentDetail?.name}
                                        </DialogTitle>
                                        <DialogDescription>
                                          Calificaciones por competencia en todas las materias y períodos (incluye
                                          recuperaciones aplicadas)
                                        </DialogDescription>
                                      </DialogHeader>
                                      <div className="space-y-6">
                                        {/* Resumen por período */}
                                        {["P1", "P2", "P3"].map((period) => {
                                          const competencias = selectedStudentDetail?.competencias[period]
                                          if (!competencias) return null

                                          return (
                                            <Card key={period}>
                                              <CardHeader>
                                                <CardTitle className="text-xl flex items-center gap-2">
                                                  📅 {period}
                                                  <Badge className="bg-blue-100 text-blue-800">
                                                    Todas las materias
                                                  </Badge>
                                                </CardTitle>
                                              </CardHeader>
                                              <CardContent>
                                                <div className="space-y-6">
                                                  {/* Resultados por materia */}
                                                  {selectedCourse?.subjects.map((subject, subjectIndex) => (
                                                    <div key={subject.id} className="border rounded-lg p-4 bg-gray-50">
                                                      <h4 className="text-lg font-semibold mb-4 flex items-center gap-2">
                                                        📚 {subject.name}
                                                        <span className="text-sm text-gray-600">
                                                          ({subject.teacher})
                                                        </span>
                                                      </h4>

                                                      <div className="space-y-4">
                                                        {/* Competencias originales por materia */}
                                                        <div>
                                                          <h5 className="text-sm font-semibold mb-3 text-gray-700">
                                                            Calificaciones Originales - {subject.name}
                                                          </h5>
                                                          <div className="grid gap-3 md:grid-cols-3">
                                                            {Object.entries(competencias)
                                                              .filter(([key]) => key !== "recuperaciones")
                                                              .map(([key, baseValue]) => {
                                                                // Simular variación por materia
                                                                const subjectVariation = subjectIndex * 3 - 5
                                                                const value = Math.max(
                                                                  60,
                                                                  Math.min(100, baseValue + subjectVariation),
                                                                )

                                                                const competenciaNames = {
                                                                  comunicativa: "Comunicativa",
                                                                  pensamiento: "Pensamiento Lógico",
                                                                  cientifica: "Científica y Tecnológica",
                                                                  ambiental: "Ambiental y de la Salud",
                                                                  etica: "Ética y Ciudadana",
                                                                  personal: "Desarrollo Personal",
                                                                }

                                                                return (
                                                                  <div
                                                                    key={key}
                                                                    className="flex items-center justify-between p-3 bg-white rounded border"
                                                                  >
                                                                    <span className="text-sm font-medium">
                                                                      {competenciaNames[key]}
                                                                    </span>
                                                                    <Badge
                                                                      className={
                                                                        value >= 90
                                                                          ? "bg-green-100 text-green-800"
                                                                          : value >= 80
                                                                            ? "bg-blue-100 text-blue-800"
                                                                            : value >= 70
                                                                              ? "bg-yellow-100 text-yellow-800"
                                                                              : "bg-red-100 text-red-800"
                                                                      }
                                                                    >
                                                                      {value}
                                                                    </Badge>
                                                                  </div>
                                                                )
                                                              })}
                                                          </div>
                                                        </div>

                                                        {/* Recuperaciones por materia si existen */}
                                                        {competencias.recuperaciones && (
                                                          <div>
                                                            <h5 className="text-sm font-semibold mb-3 text-orange-700">
                                                              Recuperaciones Aplicadas - {subject.name}
                                                            </h5>
                                                            <div className="grid gap-3 md:grid-cols-3">
                                                              {Object.entries(competencias.recuperaciones).map(
                                                                ([key, baseRecValue]) => {
                                                                  // Simular variación de recuperación por materia
                                                                  const subjectVariation = subjectIndex * 2 - 3
                                                                  const recValue = Math.max(
                                                                    70,
                                                                    Math.min(100, baseRecValue + subjectVariation),
                                                                  )

                                                                  const competenciaNames = {
                                                                    comunicativa: "Comunicativa",
                                                                    pensamiento: "Pensamiento Lógico",
                                                                    cientifica: "Científica y Tecnológica",
                                                                    ambiental: "Ambiental y de la Salud",
                                                                    etica: "Ética y Ciudadana",
                                                                    personal: "Desarrollo Personal",
                                                                  }

                                                                  return (
                                                                    <div
                                                                      key={key}
                                                                      className="flex items-center justify-between p-3 bg-orange-50 rounded border border-orange-200"
                                                                    >
                                                                      <span className="text-sm font-medium text-orange-800">
                                                                        {competenciaNames[key]}
                                                                      </span>
                                                                      <Badge className="bg-orange-100 text-orange-800">
                                                                        {recValue} (Recuperación)
                                                                      </Badge>
                                                                    </div>
                                                                  )
                                                                },
                                                              )}
                                                            </div>
                                                            <div className="mt-2 p-2 bg-green-50 rounded border border-green-200">
                                                              <p className="text-xs text-green-700 font-medium">
                                                                ✓ Recuperaciones aplicadas en {subject.name} -
                                                                Competencias elevadas por encima de 70 puntos
                                                              </p>
                                                            </div>
                                                          </div>
                                                        )}

                                                        {/* Promedio por materia */}
                                                        <div className="pt-3 border-t">
                                                          <div className="flex items-center justify-between p-3 bg-blue-50 rounded">
                                                            <span className="font-semibold text-blue-800">
                                                              Promedio {period} - {subject.name}:
                                                            </span>
                                                            <Badge className="bg-blue-100 text-blue-800 text-base px-3 py-1">
                                                              {Math.round(
                                                                Object.entries(competencias)
                                                                  .filter(([key]) => key !== "recuperaciones")
                                                                  .map(([key, originalValue]) => {
                                                                    const subjectVariation = subjectIndex * 3 - 5
                                                                    const adjustedOriginal = Math.max(
                                                                      60,
                                                                      Math.min(100, originalValue + subjectVariation),
                                                                    )

                                                                    // Si hay recuperación para esta competencia, usar la recuperación
                                                                    if (
                                                                      competencias.recuperaciones &&
                                                                      competencias.recuperaciones[key]
                                                                    ) {
                                                                      const recVariation = subjectIndex * 2 - 3
                                                                      const adjustedRec = Math.max(
                                                                        70,
                                                                        Math.min(
                                                                          100,
                                                                          competencias.recuperaciones[key] +
                                                                            recVariation,
                                                                        ),
                                                                      )
                                                                      return Math.max(adjustedOriginal, adjustedRec)
                                                                    }
                                                                    return adjustedOriginal
                                                                  })
                                                                  .reduce((sum, value) => sum + value, 0) /
                                                                  Object.keys(competencias).filter(
                                                                    (key) => key !== "recuperaciones",
                                                                  ).length,
                                                              )}
                                                            </Badge>
                                                          </div>
                                                        </div>
                                                      </div>
                                                    </div>
                                                  ))}

                                                  {/* Promedio consolidado del período */}
                                                  <div className="bg-indigo-50 p-4 rounded-lg border-2 border-indigo-200">
                                                    <div className="flex items-center justify-between">
                                                      <div>
                                                        <h4 className="text-lg font-bold text-indigo-800">
                                                          Promedio Consolidado {period}
                                                        </h4>
                                                        <p className="text-sm text-indigo-600">
                                                          Promedio de todas las materias en {period}
                                                        </p>
                                                      </div>
                                                      <Badge className="bg-indigo-100 text-indigo-800 text-xl px-4 py-2">
                                                        {Math.round(
                                                          selectedCourse?.subjects.reduce(
                                                            (sum, subject, subjectIndex) => {
                                                              const subjectAvg = Math.round(
                                                                Object.entries(competencias)
                                                                  .filter(([key]) => key !== "recuperaciones")
                                                                  .map(([key, originalValue]) => {
                                                                    const subjectVariation = subjectIndex * 3 - 5
                                                                    const adjustedOriginal = Math.max(
                                                                      60,
                                                                      Math.min(100, originalValue + subjectVariation),
                                                                    )

                                                                    if (
                                                                      competencias.recuperaciones &&
                                                                      competencias.recuperaciones[key]
                                                                    ) {
                                                                      const recVariation = subjectIndex * 2 - 3
                                                                      const adjustedRec = Math.max(
                                                                        70,
                                                                        Math.min(
                                                                          100,
                                                                          competencias.recuperaciones[key] +
                                                                            recVariation,
                                                                        ),
                                                                      )
                                                                      return Math.max(adjustedOriginal, adjustedRec)
                                                                    }
                                                                    return adjustedOriginal
                                                                  })
                                                                  .reduce((sum, value) => sum + value, 0) /
                                                                  Object.keys(competencias).filter(
                                                                    (key) => key !== "recuperaciones",
                                                                  ).length,
                                                              )
                                                              return sum + subjectAvg
                                                            },
                                                            0,
                                                          ) / selectedCourse?.subjects.length || 0,
                                                        )}
                                                      </Badge>
                                                    </div>
                                                  </div>
                                                </div>
                                              </CardContent>
                                            </Card>
                                          )
                                        })}

                                        {/* Resumen final consolidado */}
                                        <Card className="border-2 border-green-200 bg-green-50">
                                          <CardHeader>
                                            <CardTitle className="text-xl text-green-800 flex items-center gap-2">
                                              🎯 Resumen Final Consolidado
                                              <Badge className="bg-green-100 text-green-800">
                                                Todas las materias y períodos
                                              </Badge>
                                            </CardTitle>
                                          </CardHeader>
                                          <CardContent>
                                            <div className="grid gap-4 md:grid-cols-2">
                                              {/* Promedio por materia */}
                                              <div>
                                                <h4 className="font-semibold mb-3 text-green-800">
                                                  Promedio por Materia
                                                </h4>
                                                <div className="space-y-2">
                                                  {selectedCourse?.subjects.map((subject, subjectIndex) => {
                                                    // Calcular promedio de todos los períodos para esta materia
                                                    const subjectAverage = Math.round(
                                                      ["P1", "P2", "P3"].reduce((sum, period) => {
                                                        const competencias = selectedStudentDetail?.competencias[period]
                                                        if (!competencias) return sum

                                                        const periodAvg = Math.round(
                                                          Object.entries(competencias)
                                                            .filter(([key]) => key !== "recuperaciones")
                                                            .map(([key, originalValue]) => {
                                                              const subjectVariation = subjectIndex * 3 - 5
                                                              const adjustedOriginal = Math.max(
                                                                60,
                                                                Math.min(100, originalValue + subjectVariation),
                                                              )

                                                              if (
                                                                competencias.recuperaciones &&
                                                                competencias.recuperaciones[key]
                                                              ) {
                                                                const recVariation = subjectIndex * 2 - 3
                                                                const adjustedRec = Math.max(
                                                                  70,
                                                                  Math.min(
                                                                    100,
                                                                    competencias.recuperaciones[key] + recVariation,
                                                                  ),
                                                                )
                                                                return Math.max(adjustedOriginal, adjustedRec)
                                                              }
                                                              return adjustedOriginal
                                                            })
                                                            .reduce((sum, value) => sum + value, 0) /
                                                            Object.keys(competencias).filter(
                                                              (key) => key !== "recuperaciones",
                                                            ).length,
                                                        )
                                                        return sum + periodAvg
                                                      }, 0) / 3,
                                                    )

                                                    return (
                                                      <div
                                                        key={subject.id}
                                                        className="flex items-center justify-between p-2 bg-white rounded"
                                                      >
                                                        <span className="text-sm font-medium">{subject.name}</span>
                                                        <Badge
                                                          className={
                                                            subjectAverage >= 90
                                                              ? "bg-green-100 text-green-800"
                                                              : subjectAverage >= 80
                                                                ? "bg-blue-100 text-blue-800"
                                                                : subjectAverage >= 70
                                                                  ? "bg-yellow-100 text-yellow-800"
                                                                  : "bg-red-100 text-red-800"
                                                          }
                                                        >
                                                          {subjectAverage}
                                                        </Badge>
                                                      </div>
                                                    )
                                                  })}
                                                </div>
                                              </div>

                                              {/* Estado final */}
                                              <div>
                                                <h4 className="font-semibold mb-3 text-green-800">Estado Final</h4>
                                                <div className="space-y-3">
                                                  <div className="p-3 bg-white rounded border">
                                                    <div className="text-sm text-gray-600">Promedio General</div>
                                                    <div className="text-2xl font-bold text-green-800">
                                                      {Math.round(
                                                        selectedCourse?.subjects.reduce(
                                                          (sum, subject, subjectIndex) => {
                                                            const subjectAvg = Math.round(
                                                              ["P1", "P2", "P3"].reduce((periodSum, period) => {
                                                                const competencias =
                                                                  selectedStudentDetail?.competencias[period]
                                                                if (!competencias) return periodSum

                                                                const periodAvg = Math.round(
                                                                  Object.entries(competencias)
                                                                    .filter(([key]) => key !== "recuperaciones")
                                                                    .map(([key, originalValue]) => {
                                                                      const subjectVariation = subjectIndex * 3 - 5
                                                                      const adjustedOriginal = Math.max(
                                                                        60,
                                                                        Math.min(100, originalValue + subjectVariation),
                                                                      )

                                                                      if (
                                                                        competencias.recuperaciones &&
                                                                        competencias.recuperaciones[key]
                                                                      ) {
                                                                        const recVariation = subjectIndex * 2 - 3
                                                                        const adjustedRec = Math.max(
                                                                          70,
                                                                          Math.min(
                                                                            100,
                                                                            competencias.recuperaciones[key] +
                                                                              recVariation,
                                                                          ),
                                                                        )
                                                                        return Math.max(adjustedOriginal, adjustedRec)
                                                                      }
                                                                      return adjustedOriginal
                                                                    })
                                                                    .reduce((sum, value) => sum + value, 0) /
                                                                    Object.keys(competencias).filter(
                                                                      (key) => key !== "recuperaciones",
                                                                    ).length,
                                                                )
                                                                return periodSum + periodAvg
                                                              }, 0) / 3,
                                                            )
                                                            return sum + subjectAvg
                                                          },
                                                          0,
                                                        ) / selectedCourse?.subjects.length || 0,
                                                      )}
                                                    </div>
                                                  </div>

                                                  <div className="p-3 bg-white rounded border">
                                                    <div className="text-sm text-gray-600">Situación Académica</div>
                                                    <Badge
                                                      className={
                                                        selectedStudentDetail?.finalStatus === "Excelente"
                                                          ? "bg-green-100 text-green-800 text-lg px-3 py-1"
                                                          : selectedStudentDetail?.finalStatus.includes("Recuperación")
                                                            ? "bg-orange-100 text-orange-800 text-lg px-3 py-1"
                                                            : "bg-blue-100 text-blue-800 text-lg px-3 py-1"
                                                      }
                                                    >
                                                      {selectedStudentDetail?.finalStatus}
                                                    </Badge>
                                                  </div>

                                                  <div className="p-3 bg-white rounded border">
                                                    <div className="text-sm text-gray-600">
                                                      Recuperaciones Aplicadas
                                                    </div>
                                                    <div className="text-sm font-medium">
                                                      {["P1", "P2", "P3"].reduce((count, period) => {
                                                        const competencias = selectedStudentDetail?.competencias[period]
                                                        if (competencias?.recuperaciones) {
                                                          return count + Object.keys(competencias.recuperaciones).length
                                                        }
                                                        return count
                                                      }, 0)}{" "}
                                                      competencias recuperadas
                                                    </div>
                                                  </div>
                                                </div>
                                              </div>
                                            </div>
                                          </CardContent>
                                        </Card>
                                      </div>
                                    </DialogContent>
                                  </Dialog>
                                </TableCell>
                              </TableRow>
                            )
                          })}
                        </TableBody>
                      </Table>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Tabla consolidada de calificaciones por estudiante */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5" />
                Calificaciones Consolidadas - Período {selectedPeriod}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Estudiante</TableHead>
                      {selectedCourse.subjects.map((subject) => (
                        <TableHead key={subject.id} className="text-center">
                          {subject.name}
                        </TableHead>
                      ))}
                      <TableHead className="text-center">Promedio</TableHead>
                      <TableHead className="text-center">Estado</TableHead>
                      <TableHead className="text-center">Acciones</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {estudiantesDetalle.map((student) => {
                      const periodGrade = student.grades[selectedPeriod]
                      // Simular calificaciones por materia para el período seleccionado
                      const subjectGrades = selectedCourse.subjects.map((subject) => {
                        const baseGrade = periodGrade || 0
                        const variation = Math.floor(Math.random() * 20) - 10 // Variación de -10 a +10
                        return Math.max(0, Math.min(100, baseGrade + variation))
                      })
                      const averageGrade = Math.round(
                        subjectGrades.reduce((sum, grade) => sum + grade, 0) / subjectGrades.length,
                      )

                      return (
                        <TableRow key={student.id}>
                          <TableCell>
                            <div>
                              <div className="font-medium">{student.name}</div>
                              <div className="text-sm text-gray-500">{student.matricula}</div>
                            </div>
                          </TableCell>
                          {selectedCourse.subjects.map((subject, index) => (
                            <TableCell key={subject.id} className="text-center">
                              <div className="flex flex-col items-center gap-1">
                                {subjectGrades[index] ? (
                                  <Badge
                                    className={
                                      subjectGrades[index] >= 90
                                        ? "bg-green-100 text-green-800"
                                        : subjectGrades[index] >= 80
                                          ? "bg-blue-100 text-blue-800"
                                          : subjectGrades[index] >= 70
                                            ? "bg-yellow-100 text-yellow-800"
                                            : "bg-red-100 text-red-800"
                                    }
                                  >
                                    {subjectGrades[index]}
                                  </Badge>
                                ) : (
                                  <span className="text-gray-400">-</span>
                                )}
                                {/* Mostrar recuperación si existe */}
                                {student.grades[`R${selectedPeriod}`] && (
                                  <Badge className="bg-orange-100 text-orange-800 text-xs">
                                    R{selectedPeriod}: {student.grades[`R${selectedPeriod}`]}
                                  </Badge>
                                )}
                              </div>
                            </TableCell>
                          ))}
                          <TableCell className="text-center">
                            <Badge
                              className={
                                averageGrade >= 90
                                  ? "bg-green-100 text-green-800"
                                  : averageGrade >= 80
                                    ? "bg-blue-100 text-blue-800"
                                    : averageGrade >= 70
                                      ? "bg-yellow-100 text-yellow-800"
                                      : "bg-red-100 text-red-800"
                              }
                            >
                              {averageGrade}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-center">
                            <Badge className="bg-blue-100 text-blue-800">{student.finalStatus}</Badge>
                          </TableCell>
                          <TableCell className="text-center">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => {
                                setSelectedStudentDetail(student)
                                setDetailModalOpen(true)
                              }}
                            >
                              <Eye className="h-3 w-3 mr-1" />
                              Ver Detalle
                            </Button>
                          </TableCell>
                        </TableRow>
                      )
                    })}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>

          {/* Resumen de calificaciones finales por todas las materias */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5" />
                Resumen Final por Materias - {selectedCourse.name}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Estudiante</TableHead>
                      {selectedCourse.subjects.map((subject) => (
                        <TableHead key={subject.id} className="text-center">
                          {subject.name}
                        </TableHead>
                      ))}
                      <TableHead className="text-center">Promedio General</TableHead>
                      <TableHead className="text-center">Estado Final</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {estudiantesDetalle.map((student) => {
                      // Simular calificaciones finales por materia
                      const finalGrades = selectedCourse.subjects.map((subject) => {
                        const p1 = student.grades.P1 || 0
                        const p2 = student.grades.P2 || 0
                        const p3 = student.grades.P3 || 0
                        const p4 = student.grades.P4 || 0
                        return Math.round((p1 + p2 + p3 + p4) / 4)
                      })
                      const generalAverage = Math.round(
                        finalGrades.reduce((sum, grade) => sum + grade, 0) / finalGrades.length,
                      )

                      return (
                        <TableRow key={student.id}>
                          <TableCell>
                            <div className="font-medium">{student.name}</div>
                          </TableCell>
                          {finalGrades.map((grade, index) => (
                            <TableCell key={index} className="text-center">
                              <Badge
                                className={
                                  grade >= 90
                                    ? "bg-green-100 text-green-800"
                                    : grade >= 80
                                      ? "bg-blue-100 text-blue-800"
                                      : grade >= 70
                                        ? "bg-yellow-100 text-yellow-800"
                                        : "bg-red-100 text-red-800"
                                }
                              >
                                {grade}
                              </Badge>
                            </TableCell>
                          ))}
                          <TableCell className="text-center">
                            <Badge
                              className={
                                generalAverage >= 90
                                  ? "bg-green-100 text-green-800"
                                  : generalAverage >= 80
                                    ? "bg-blue-100 text-blue-800"
                                    : generalAverage >= 70
                                      ? "bg-yellow-100 text-yellow-800"
                                      : "bg-red-100 text-red-800"
                              }
                            >
                              {generalAverage}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-center">
                            <Badge
                              className={
                                generalAverage >= 70 ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
                              }
                            >
                              {generalAverage >= 70 ? "Aprobado" : "Reprobado"}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      )
                    })}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Modal de detalle por competencias */}
      <Dialog open={detailModalOpen} onOpenChange={setDetailModalOpen}>
        <DialogContent className="max-w-6xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Competencias Consolidadas - {selectedStudentDetail?.name}</DialogTitle>
            <DialogDescription>
              Calificaciones por competencia en todas las materias y períodos (incluye recuperaciones aplicadas)
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-6">
            {/* Resumen por período */}
            {["P1", "P2", "P3"].map((period) => {
              const competencias = selectedStudentDetail?.competencias[period]
              if (!competencias) return null

              return (
                <Card key={period}>
                  <CardHeader>
                    <CardTitle className="text-xl flex items-center gap-2">
                      📅 {period}
                      <Badge className="bg-blue-100 text-blue-800">Todas las materias</Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      {/* Resultados por materia */}
                      {selectedCourse?.subjects.map((subject, subjectIndex) => (
                        <div key={subject.id} className="border rounded-lg p-4 bg-gray-50">
                          <h4 className="text-lg font-semibold mb-4 flex items-center gap-2">
                            📚 {subject.name}
                            <span className="text-sm text-gray-600">({subject.teacher})</span>
                          </h4>

                          <div className="space-y-4">
                            {/* Competencias originales por materia */}
                            <div>
                              <h5 className="text-sm font-semibold mb-3 text-gray-700">
                                Calificaciones Originales - {subject.name}
                              </h5>
                              <div className="grid gap-3 md:grid-cols-3">
                                {Object.entries(competencias)
                                  .filter(([key]) => key !== "recuperaciones")
                                  .map(([key, baseValue]) => {
                                    // Simular variación por materia
                                    const subjectVariation = subjectIndex * 3 - 5
                                    const value = Math.max(60, Math.min(100, baseValue + subjectVariation))

                                    const competenciaNames = {
                                      comunicativa: "Comunicativa",
                                      pensamiento: "Pensamiento Lógico",
                                      cientifica: "Científica y Tecnológica",
                                      ambiental: "Ambiental y de la Salud",
                                      etica: "Ética y Ciudadana",
                                      personal: "Desarrollo Personal",
                                    }

                                    return (
                                      <div
                                        key={key}
                                        className="flex items-center justify-between p-3 bg-white rounded border"
                                      >
                                        <span className="text-sm font-medium">{competenciaNames[key]}</span>
                                        <Badge
                                          className={
                                            value >= 90
                                              ? "bg-green-100 text-green-800"
                                              : value >= 80
                                                ? "bg-blue-100 text-blue-800"
                                                : value >= 70
                                                  ? "bg-yellow-100 text-yellow-800"
                                                  : "bg-red-100 text-red-800"
                                          }
                                        >
                                          {value}
                                        </Badge>
                                      </div>
                                    )
                                  })}
                              </div>
                            </div>

                            {/* Recuperaciones por materia si existen */}
                            {competencias.recuperaciones && (
                              <div>
                                <h5 className="text-sm font-semibold mb-3 text-orange-700">
                                  Recuperaciones Aplicadas - {subject.name}
                                </h5>
                                <div className="grid gap-3 md:grid-cols-3">
                                  {Object.entries(competencias.recuperaciones).map(([key, baseRecValue]) => {
                                    // Simular variación de recuperación por materia
                                    const subjectVariation = subjectIndex * 2 - 3
                                    const recValue = Math.max(70, Math.min(100, baseRecValue + subjectVariation))

                                    const competenciaNames = {
                                      comunicativa: "Comunicativa",
                                      pensamiento: "Pensamiento Lógico",
                                      cientifica: "Científica y Tecnológica",
                                      ambiental: "Ambiental y de la Salud",
                                      etica: "Ética y Ciudadana",
                                      personal: "Desarrollo Personal",
                                    }

                                    return (
                                      <div
                                        key={key}
                                        className="flex items-center justify-between p-3 bg-orange-50 rounded border border-orange-200"
                                      >
                                        <span className="text-sm font-medium text-orange-800">
                                          {competenciaNames[key]}
                                        </span>
                                        <Badge className="bg-orange-100 text-orange-800">
                                          {recValue} (Recuperación)
                                        </Badge>
                                      </div>
                                    )
                                  })}
                                </div>
                                <div className="mt-2 p-2 bg-green-50 rounded border border-green-200">
                                  <p className="text-xs text-green-700 font-medium">
                                    ✓ Recuperaciones aplicadas en {subject.name} - Competencias elevadas por encima de
                                    70 puntos
                                  </p>
                                </div>
                              </div>
                            )}

                            {/* Promedio por materia */}
                            <div className="pt-3 border-t">
                              <div className="flex items-center justify-between p-3 bg-blue-50 rounded">
                                <span className="font-semibold text-blue-800">
                                  Promedio {period} - {subject.name}:
                                </span>
                                <Badge className="bg-blue-100 text-blue-800 text-base px-3 py-1">
                                  {Math.round(
                                    Object.entries(competencias)
                                      .filter(([key]) => key !== "recuperaciones")
                                      .map(([key, originalValue]) => {
                                        const subjectVariation = subjectIndex * 3 - 5
                                        const adjustedOriginal = Math.max(
                                          60,
                                          Math.min(100, originalValue + subjectVariation),
                                        )

                                        // Si hay recuperación para esta competencia, usar la recuperación
                                        if (competencias.recuperaciones && competencias.recuperaciones[key]) {
                                          const recVariation = subjectIndex * 2 - 3
                                          const adjustedRec = Math.max(
                                            70,
                                            Math.min(100, competencias.recuperaciones[key] + recVariation),
                                          )
                                          return Math.max(adjustedOriginal, adjustedRec)
                                        }
                                        return adjustedOriginal
                                      })
                                      .reduce((sum, value) => sum + value, 0) /
                                      Object.keys(competencias).filter((key) => key !== "recuperaciones").length,
                                  )}
                                </Badge>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}

                      {/* Promedio consolidado del período */}
                      <div className="bg-indigo-50 p-4 rounded-lg border-2 border-indigo-200">
                        <div className="flex items-center justify-between">
                          <div>
                            <h4 className="text-lg font-bold text-indigo-800">Promedio Consolidado {period}</h4>
                            <p className="text-sm text-indigo-600">Promedio de todas las materias en {period}</p>
                          </div>
                          <Badge className="bg-indigo-100 text-indigo-800 text-xl px-4 py-2">
                            {Math.round(
                              selectedCourse?.subjects.reduce((sum, subject, subjectIndex) => {
                                const subjectAvg = Math.round(
                                  Object.entries(competencias)
                                    .filter(([key]) => key !== "recuperaciones")
                                    .map(([key, originalValue]) => {
                                      const subjectVariation = subjectIndex * 3 - 5
                                      const adjustedOriginal = Math.max(
                                        60,
                                        Math.min(100, originalValue + subjectVariation),
                                      )

                                      if (competencias.recuperaciones && competencias.recuperaciones[key]) {
                                        const recVariation = subjectIndex * 2 - 3
                                        const adjustedRec = Math.max(
                                          70,
                                          Math.min(100, competencias.recuperaciones[key] + recVariation),
                                        )
                                        return Math.max(adjustedOriginal, adjustedRec)
                                      }
                                      return adjustedOriginal
                                    })
                                    .reduce((sum, value) => sum + value, 0) /
                                    Object.keys(competencias).filter((key) => key !== "recuperaciones").length,
                                )
                                return sum + subjectAvg
                              }, 0) / selectedCourse?.subjects.length || 0,
                            )}
                          </Badge>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )
            })}

            {/* Resumen final consolidado */}
            <Card className="border-2 border-green-200 bg-green-50">
              <CardHeader>
                <CardTitle className="text-xl text-green-800 flex items-center gap-2">
                  🎯 Resumen Final Consolidado
                  <Badge className="bg-green-100 text-green-800">Todas las materias y períodos</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 md:grid-cols-2">
                  {/* Promedio por materia */}
                  <div>
                    <h4 className="font-semibold mb-3 text-green-800">Promedio por Materia</h4>
                    <div className="space-y-2">
                      {selectedCourse?.subjects.map((subject, subjectIndex) => {
                        // Calcular promedio de todos los períodos para esta materia
                        const subjectAverage = Math.round(
                          ["P1", "P2", "P3"].reduce((sum, period) => {
                            const competencias = selectedStudentDetail?.competencias[period]
                            if (!competencias) return sum

                            const periodAvg = Math.round(
                              Object.entries(competencias)
                                .filter(([key]) => key !== "recuperaciones")
                                .map(([key, originalValue]) => {
                                  const subjectVariation = subjectIndex * 3 - 5
                                  const adjustedOriginal = Math.max(60, Math.min(100, originalValue + subjectVariation))

                                  if (competencias.recuperaciones && competencias.recuperaciones[key]) {
                                    const recVariation = subjectIndex * 2 - 3
                                    const adjustedRec = Math.max(
                                      70,
                                      Math.min(100, competencias.recuperaciones[key] + recVariation),
                                    )
                                    return Math.max(adjustedOriginal, adjustedRec)
                                  }
                                  return adjustedOriginal
                                })
                                .reduce((sum, value) => sum + value, 0) /
                                Object.keys(competencias).filter((key) => key !== "recuperaciones").length,
                            )
                            return sum + periodAvg
                          }, 0) / 3,
                        )

                        return (
                          <div key={subject.id} className="flex items-center justify-between p-2 bg-white rounded">
                            <span className="text-sm font-medium">{subject.name}</span>
                            <Badge
                              className={
                                subjectAverage >= 90
                                  ? "bg-green-100 text-green-800"
                                  : subjectAverage >= 80
                                    ? "bg-blue-100 text-blue-800"
                                    : subjectAverage >= 70
                                      ? "bg-yellow-100 text-yellow-800"
                                      : "bg-red-100 text-red-800"
                              }
                            >
                              {subjectAverage}
                            </Badge>
                          </div>
                        )
                      })}
                    </div>
                  </div>

                  {/* Estado final */}
                  <div>
                    <h4 className="font-semibold mb-3 text-green-800">Estado Final</h4>
                    <div className="space-y-3">
                      <div className="p-3 bg-white rounded border">
                        <div className="text-sm text-gray-600">Promedio General</div>
                        <div className="text-2xl font-bold text-green-800">
                          {Math.round(
                            selectedCourse?.subjects.reduce((sum, subject, subjectIndex) => {
                              const subjectAvg = Math.round(
                                ["P1", "P2", "P3"].reduce((periodSum, period) => {
                                  const competencias = selectedStudentDetail?.competencias[period]
                                  if (!competencias) return periodSum

                                  const periodAvg = Math.round(
                                    Object.entries(competencias)
                                      .filter(([key]) => key !== "recuperaciones")
                                      .map(([key, originalValue]) => {
                                        const subjectVariation = subjectIndex * 3 - 5
                                        const adjustedOriginal = Math.max(
                                          60,
                                          Math.min(100, originalValue + subjectVariation),
                                        )

                                        if (competencias.recuperaciones && competencias.recuperaciones[key]) {
                                          const recVariation = subjectIndex * 2 - 3
                                          const adjustedRec = Math.max(
                                            70,
                                            Math.min(100, competencias.recuperaciones[key] + recVariation),
                                          )
                                          return Math.max(adjustedOriginal, adjustedRec)
                                        }
                                        return adjustedOriginal
                                      })
                                      .reduce((sum, value) => sum + value, 0) /
                                      Object.keys(competencias).filter((key) => key !== "recuperaciones").length,
                                  )
                                  return periodSum + periodAvg
                                }, 0) / 3,
                              )
                              return sum + subjectAvg
                            }, 0) / selectedCourse?.subjects.length || 0,
                          )}
                        </div>
                      </div>

                      <div className="p-3 bg-white rounded border">
                        <div className="text-sm text-gray-600">Situación Académica</div>
                        <Badge
                          className={
                            selectedStudentDetail?.finalStatus === "Excelente"
                              ? "bg-green-100 text-green-800 text-lg px-3 py-1"
                              : selectedStudentDetail?.finalStatus.includes("Recuperación")
                                ? "bg-orange-100 text-orange-800 text-lg px-3 py-1"
                                : "bg-blue-100 text-blue-800 text-lg px-3 py-1"
                          }
                        >
                          {selectedStudentDetail?.finalStatus}
                        </Badge>
                      </div>

                      <div className="p-3 bg-white rounded border">
                        <div className="text-sm text-gray-600">Recuperaciones Aplicadas</div>
                        <div className="text-sm font-medium">
                          {["P1", "P2", "P3"].reduce((count, period) => {
                            const competencias = selectedStudentDetail?.competencias[period]
                            if (competencias?.recuperaciones) {
                              return count + Object.keys(competencias.recuperaciones).length
                            }
                            return count
                          }, 0)}{" "}
                          competencias recuperadas
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </DialogContent>
      </Dialog>

      {/* Modal de validación */}
      <Dialog open={validationModalOpen} onOpenChange={setValidationModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Validar Período</DialogTitle>
            <DialogDescription>
              Confirme que todas las competencias están configuradas correctamente y todos los estudiantes tienen
              calificaciones registradas.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="bg-yellow-50 p-4 rounded-lg">
              <h4 className="font-medium mb-2">Verificaciones:</h4>
              <ul className="space-y-1 text-sm">
                <li className="flex items-center">
                  <CheckCircle className="h-4 w-4 text-green-600 mr-2" />
                  Todas las competencias configuradas
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-4 w-4 text-green-600 mr-2" />
                  Actividades suman 100% por competencia
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-4 w-4 text-green-600 mr-2" />
                  Todos los estudiantes calificados
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-4 w-4 text-green-600 mr-2" />
                  Recuperaciones aplicadas donde corresponde
                </li>
              </ul>
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setValidationModalOpen(false)}>
                Cancelar
              </Button>
              <Button
                onClick={() => handleValidatePeriod(selectedCourse, selectedPeriod)}
                className="bg-green-600 hover:bg-green-700"
              >
                <CheckCircle className="h-4 w-4 mr-2" />
                Validar Período
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Modal de devolución a docente */}
      <Dialog open={returnModalOpen} onOpenChange={setReturnModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Devolver a Docente</DialogTitle>
            <DialogDescription>
              Envíe comentarios al docente sobre las correcciones necesarias en las calificaciones.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="comment">Comentarios para el docente</Label>
              <Textarea
                id="comment"
                placeholder="Describa las correcciones necesarias..."
                value={returnComment}
                onChange={(e) => setReturnComment(e.target.value)}
                className="min-h-[100px]"
              />
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setReturnModalOpen(false)}>
                Cancelar
              </Button>
              <Button onClick={handleReturnToTeacher} className="bg-orange-600 hover:bg-orange-700">
                <Send className="h-4 w-4 mr-2" />
                Enviar Comentarios
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Modal de configuración de fechas */}
      <Dialog open={dateConfigModalOpen} onOpenChange={setDateConfigModalOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Configurar Fechas Evaluativas</DialogTitle>
            <DialogDescription>
              Configure las fechas de apertura y cierre para cada período evaluativo
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-6">
            {["P1", "P2", "P3", "P4"].map((period) => (
              <Card key={period}>
                <CardHeader>
                  <CardTitle className="text-lg">{period}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>Fecha de Inicio</Label>
                      <Input type="date" />
                    </div>
                    <div>
                      <Label>Fecha de Cierre</Label>
                      <Input type="date" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setDateConfigModalOpen(false)}>
                Cancelar
              </Button>
              <Button className="bg-blue-600 hover:bg-blue-700">
                <Calendar className="h-4 w-4 mr-2" />
                Guardar Fechas
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Modal de boletín */}
      <Dialog open={bulletinModalOpen} onOpenChange={setBulletinModalOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Generar Boletín Automatizado</DialogTitle>
            <DialogDescription>
              Configure las opciones para la generación del boletín oficial del MINERD
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="bg-blue-50 p-4 rounded-lg">
              <h4 className="font-medium mb-2">Boletín incluirá:</h4>
              <ul className="space-y-1 text-sm">
                <li>• Información del estudiante</li>
                <li>• Materias evaluadas</li>
                <li>• Competencias por período (P1-P4)</li>
                <li>• Recuperaciones aplicadas (RP1-RP4)</li>
                <li>• Calificaciones finales (C.F., C.C.F., C.EX.F.)</li>
                <li>• Situación final (Aprobado/Reprobado)</li>
              </ul>
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setBulletinModalOpen(false)}>
                Cancelar
              </Button>
              <Button className="bg-green-600 hover:bg-green-700">
                <Download className="h-4 w-4 mr-2" />
                Generar Boletín PDF
              </Button>
              <Button className="bg-blue-600 hover:bg-blue-700">
                <Send className="h-4 w-4 mr-2" />
                Enviar a Registro
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
