"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  BookOpen,
  Plus,
  Search,
  Download,
  Upload,
  Edit,
  Eye,
  Trash2,
  CheckCircle,
  Clock,
  AlertTriangle,
  Settings,
  GraduationCap,
  Users,
  Calendar,
} from "lucide-react"
import { CourseSubjectsConfigurator } from "@/components/subjects/course-subjects-configurator"
import type { Course } from "@/lib/course-interoperability"

interface Subject {
  id: string
  name: string
  code: string
  area: string
  grade: string
  hours: number
  teacher?: string
  status: "active" | "inactive" | "pending"
  hasGrades: boolean
  description: string
}

export default function CurriculumManagement() {
  const [activeTab, setActiveTab] = useState("courses-config")
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null)
  const [isConfiguratorOpen, setIsConfiguratorOpen] = useState(false)
  const [availableTeachers] = useState([
    { id: "teacher_1", name: "Ana Rodríguez", subjects: ["Matemáticas", "Física"], assignedCourse: null },
    { id: "teacher_2", name: "Carlos Mendoza", subjects: ["Lengua Española", "Literatura"], assignedCourse: "4to A" },
    { id: "teacher_3", name: "María González", subjects: ["Ciencias Naturales", "Química"], assignedCourse: null },
    { id: "teacher_4", name: "Luis Pérez", subjects: ["Historia", "Geografía"], assignedCourse: "2do A" },
    { id: "teacher_5", name: "Elena Vásquez", subjects: ["Matemáticas", "Física"], assignedCourse: null },
    { id: "teacher_6", name: "Roberto Silva", subjects: ["Educación Física"], assignedCourse: null },
    { id: "teacher_7", name: "Carmen Torres", subjects: ["Arte", "Música"], assignedCourse: null },
  ])

  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [selectedCourseForView, setSelectedCourseForView] = useState<Course | null>(null)
  const [selectedCourseForEdit, setSelectedCourseForEdit] = useState<Course | null>(null)

  // Cursos sin configuración de materias
  const [coursesWithoutSubjects] = useState<Course[]>([
    {
      id: "course_new_1",
      name: "6to B",
      grade: "6to",
      level: "Primaria",
      modality: "Regular",
      section: "B",
      turn: "Mañana",
      capacity: 30,
      teacher: null,
      schoolYear: "2024-2025",
      notes: "",
      createdAt: new Date().toISOString(),
      createdBy: "director_001",
      status: "active",
      studentsCount: 0,
      subjectsCount: 0,
      configurationStatus: {
        hasSubjects: false,
        hasTeacher: false,
        hasSchedule: false,
        hasStudents: false,
        isComplete: false,
        completionPercentage: 0,
      },
    },
    {
      id: "course_new_2",
      name: "5to C",
      grade: "5to",
      level: "Primaria",
      modality: "Regular",
      section: "C",
      turn: "Tarde",
      capacity: 25,
      teacher: "Ana Rodríguez",
      schoolYear: "2024-2025",
      notes: "",
      createdAt: new Date().toISOString(),
      createdBy: "director_001",
      status: "active",
      studentsCount: 0,
      subjectsCount: 0,
      configurationStatus: {
        hasSubjects: false,
        hasTeacher: true,
        hasSchedule: false,
        hasStudents: false,
        isComplete: false,
        completionPercentage: 25,
      },
    },
  ])

  // Cursos con configuración parcial
  const [coursesWithPartialConfig] = useState<Course[]>([
    {
      id: "course_partial_1",
      name: "4to A",
      grade: "4to",
      level: "Primaria",
      modality: "Regular",
      section: "A",
      turn: "Mañana",
      capacity: 28,
      teacher: "Carlos Mendoza",
      schoolYear: "2024-2025",
      notes: "",
      createdAt: new Date().toISOString(),
      createdBy: "director_001",
      status: "active",
      studentsCount: 0,
      subjectsCount: 4,
      configurationStatus: {
        hasSubjects: true,
        hasTeacher: true,
        hasSchedule: false,
        hasStudents: false,
        isComplete: false,
        completionPercentage: 50,
      },
    },
  ])

  // Cursos con configuración completa
  const [coursesWithCompleteConfig] = useState<Course[]>([
    {
      id: "course_complete_1",
      name: "3ro A",
      grade: "3ro",
      level: "Primaria",
      modality: "Regular",
      section: "A",
      turn: "Mañana",
      capacity: 30,
      teacher: "María González",
      schoolYear: "2024-2025",
      notes: "",
      createdAt: new Date().toISOString(),
      createdBy: "director_001",
      status: "active",
      studentsCount: 28,
      subjectsCount: 8,
      configurationStatus: {
        hasSubjects: true,
        hasTeacher: true,
        hasSchedule: true,
        hasStudents: true,
        isComplete: true,
        completionPercentage: 100,
      },
    },
    {
      id: "course_complete_2",
      name: "2do A",
      grade: "2do",
      level: "Primaria",
      modality: "Regular",
      section: "A",
      turn: "Mañana",
      capacity: 25,
      teacher: "Luis Pérez",
      schoolYear: "2024-2025",
      notes: "",
      createdAt: new Date().toISOString(),
      createdBy: "director_001",
      status: "active",
      studentsCount: 23,
      subjectsCount: 7,
      configurationStatus: {
        hasSubjects: true,
        hasTeacher: true,
        hasSchedule: true,
        hasStudents: true,
        isComplete: true,
        completionPercentage: 100,
      },
    },
    {
      id: "course_complete_3",
      name: "1ro B",
      grade: "1ro",
      level: "Primaria",
      modality: "Regular",
      section: "B",
      turn: "Tarde",
      capacity: 28,
      teacher: "Elena Vásquez",
      schoolYear: "2024-2025",
      notes: "",
      createdAt: new Date().toISOString(),
      createdBy: "director_001",
      status: "active",
      studentsCount: 26,
      subjectsCount: 6,
      configurationStatus: {
        hasSubjects: true,
        hasTeacher: true,
        hasSchedule: true,
        hasStudents: true,
        isComplete: true,
        completionPercentage: 100,
      },
    },
  ])

  const getCourseDetails = (courseId: string) => {
    return {
      schedule: [
        {
          day: "Lunes",
          subjects: [
            { time: "8:00-8:45", subject: "Matemáticas", teacher: "Ana Rodríguez" },
            { time: "8:45-9:30", subject: "Lengua Española", teacher: "Carlos Mendoza" },
            { time: "9:30-10:15", subject: "Ciencias Naturales", teacher: "María González" },
            { time: "10:30-11:15", subject: "Educación Física", teacher: "Roberto Silva" },
            { time: "11:15-12:00", subject: "Arte", teacher: "Carmen Torres" },
          ],
        },
        {
          day: "Martes",
          subjects: [
            { time: "8:00-8:45", subject: "Historia", teacher: "Luis Pérez" },
            { time: "8:45-9:30", subject: "Matemáticas", teacher: "Ana Rodríguez" },
            { time: "9:30-10:15", subject: "Lengua Española", teacher: "Carlos Mendoza" },
            { time: "10:30-11:15", subject: "Ciencias Naturales", teacher: "María González" },
            { time: "11:15-12:00", subject: "Música", teacher: "Carmen Torres" },
          ],
        },
      ],
      students: [
        { id: "1", name: "Juan Pérez", attendance: 95, average: 85 },
        { id: "2", name: "María García", attendance: 98, average: 92 },
        { id: "3", name: "Carlos López", attendance: 88, average: 78 },
        { id: "4", name: "Ana Martínez", attendance: 92, average: 88 },
      ],
      subjects: [
        { id: "1", name: "Matemáticas", teacher: "Ana Rodríguez", hours: 5 },
        { id: "2", name: "Lengua Española", teacher: "Carlos Mendoza", hours: 4 },
        { id: "3", name: "Ciencias Naturales", teacher: "María González", hours: 3 },
        { id: "4", name: "Historia", teacher: "Luis Pérez", hours: 3 },
        { id: "5", name: "Educación Física", teacher: "Roberto Silva", hours: 2 },
        { id: "6", name: "Arte", teacher: "Carmen Torres", hours: 2 },
        { id: "7", name: "Música", teacher: "Carmen Torres", hours: 1 },
      ],
    }
  }

  const [subjects, setSubjects] = useState<Subject[]>([
    {
      id: "1",
      name: "Matemáticas I",
      code: "MAT-101",
      area: "Matemáticas",
      grade: "1ro Bachillerato",
      hours: 5,
      teacher: "Prof. Carlos Mendoza",
      status: "active",
      hasGrades: true,
      description: "Fundamentos de álgebra y geometría básica",
    },
    {
      id: "2",
      name: "Lengua Española",
      code: "LEN-101",
      area: "Lenguas",
      grade: "1ro Bachillerato",
      hours: 4,
      teacher: "Prof. María García",
      status: "active",
      hasGrades: false,
      description: "Comprensión lectora y expresión escrita",
    },
    {
      id: "3",
      name: "Física Aplicada",
      code: "FIS-201",
      area: "Ciencias",
      grade: "2do Bachillerato",
      hours: 4,
      status: "pending",
      hasGrades: false,
      description: "Principios fundamentales de la física",
    },
    {
      id: "4",
      name: "Historia Dominicana",
      code: "HIS-101",
      area: "Sociales",
      grade: "1ro Bachillerato",
      hours: 3,
      teacher: "Prof. Ana Rodríguez",
      status: "active",
      hasGrades: true,
      description: "Historia de la República Dominicana",
    },
  ])

  const [searchTerm, setSearchTerm] = useState("")
  const [selectedArea, setSelectedArea] = useState("all")
  const [selectedGrade, setSelectedGrade] = useState("all")
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)

  const areas = ["Matemáticas", "Lenguas", "Ciencias", "Sociales", "Artística", "Educación Física"]
  const grades = ["1ro Bachillerato", "2do Bachillerato", "3ro Bachillerato", "4to Bachillerato"]

  const handleConfigureSubjects = (course: Course) => {
    setSelectedCourse(course)
    setIsConfiguratorOpen(true)
  }

  const handleSubjectsConfigured = (courseId: string, subjects: any[]) => {
    // Actualizar el estado del curso
    console.log("Materias configuradas para curso:", courseId, subjects)
    setIsConfiguratorOpen(false)
    setSelectedCourse(null)

    // Aquí podrías actualizar la lista de cursos o recargar datos
  }

  const handleCancelConfiguration = () => {
    setIsConfiguratorOpen(false)
    setSelectedCourse(null)
  }

  const handleAssignTeacher = (courseId: string, teacherId: string) => {
    const teacher = availableTeachers.find((t) => t.id === teacherId)
    if (!teacher) return

    // Check if teacher is already assigned to another course
    if (teacher.assignedCourse && teacher.assignedCourse !== courseId) {
      alert(`${teacher.name} ya está asignado como encargado del curso ${teacher.assignedCourse}`)
      return
    }

    // Update course with assigned teacher
    console.log(`Asignando ${teacher.name} como encargado del curso ${courseId}`)

    // Here you would update the course data
    // For now, just show confirmation
    alert(`${teacher.name} ha sido asignado como docente encargado`)
  }

  const filteredSubjects = subjects.filter((subject) => {
    const matchesSearch =
      subject.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      subject.code.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesArea = selectedArea === "all" || subject.area === selectedArea
    const matchesGrade = selectedGrade === "all" || subject.grade === selectedGrade
    return matchesSearch && matchesArea && matchesGrade
  })

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "active":
        return <Badge className="bg-green-100 text-green-800">Activa</Badge>
      case "inactive":
        return <Badge variant="secondary">Inactiva</Badge>
      case "pending":
        return <Badge className="bg-yellow-100 text-yellow-800">Pendiente</Badge>
      default:
        return <Badge variant="outline">Desconocido</Badge>
    }
  }

  const stats = {
    total: subjects.length,
    active: subjects.filter((s) => s.status === "active").length,
    pending: subjects.filter((s) => s.status === "pending").length,
    withTeacher: subjects.filter((s) => s.teacher).length,
    coursesWithoutSubjects: coursesWithoutSubjects.length,
    coursesWithPartialConfig: coursesWithPartialConfig.length,
    coursesWithCompleteConfig: coursesWithCompleteConfig.length,
  }

  // Si el configurador está abierto, mostrar solo el configurador
  if (isConfiguratorOpen && selectedCourse) {
    return (
      <div className="flex-1 space-y-6 p-6">
        <CourseSubjectsConfigurator
          course={selectedCourse}
          onSubjectsConfigured={handleSubjectsConfigured}
          onCancel={handleCancelConfiguration}
        />
      </div>
    )
  }

  return (
    <div className="flex-1 space-y-6 p-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Gestión Curricular</h1>
          <p className="text-muted-foreground">Administrar materias y estructura curricular institucional</p>
        </div>
        <div className="flex items-center space-x-2">
          <Button variant="outline" size="sm">
            <Upload className="h-4 w-4 mr-2" />
            Importar
          </Button>
          <Button variant="outline" size="sm">
            <Download className="h-4 w-4 mr-2" />
            Exportar
          </Button>
          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Nueva Materia
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px]">
              <DialogHeader>
                <DialogTitle>Crear Nueva Materia</DialogTitle>
                <DialogDescription>Ingresa los detalles de la nueva materia curricular</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="name" className="text-right">
                    Nombre
                  </Label>
                  <Input id="name" placeholder="Ej: Matemáticas I" className="col-span-3" required />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="code" className="text-right">
                    Código
                  </Label>
                  <Input id="code" placeholder="Ej: MAT-101" className="col-span-3" required />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="area" className="text-right">
                    Área
                  </Label>
                  <Select required>
                    <SelectTrigger className="col-span-3">
                      <SelectValue placeholder="Seleccionar área" />
                    </SelectTrigger>
                    <SelectContent>
                      {areas.map((area) => (
                        <SelectItem key={area} value={area}>
                          {area}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="grade" className="text-right">
                    Grado
                  </Label>
                  <Select required>
                    <SelectTrigger className="col-span-3">
                      <SelectValue placeholder="Seleccionar grado" />
                    </SelectTrigger>
                    <SelectContent>
                      {grades.map((grade) => (
                        <SelectItem key={grade} value={grade}>
                          {grade}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="hours" className="text-right">
                    Horas
                  </Label>
                  <Input id="hours" type="number" min="1" max="10" placeholder="5" className="col-span-3" required />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="description" className="text-right">
                    Descripción
                  </Label>
                  <Textarea
                    id="description"
                    placeholder="Descripción de la materia..."
                    className="col-span-3"
                    rows={3}
                  />
                </div>
              </div>
              <DialogFooter>
                <Button type="submit">Crear Materia</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-7">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Materias</CardTitle>
            <BookOpen className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.total}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Activas</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{stats.active}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pendientes</CardTitle>
            <Clock className="h-4 w-4 text-yellow-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">{stats.pending}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Con Docente</CardTitle>
            <Users className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{stats.withTeacher}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Sin Materias</CardTitle>
            <AlertTriangle className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{stats.coursesWithoutSubjects}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Config. Parcial</CardTitle>
            <Clock className="h-4 w-4 text-orange-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">{stats.coursesWithPartialConfig}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Completados</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{stats.coursesWithCompleteConfig}</div>
          </CardContent>
        </Card>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="courses-config" className="flex items-center gap-2">
            <GraduationCap className="h-4 w-4" />
            Configurar Cursos
          </TabsTrigger>
          <TabsTrigger value="subjects-catalog" className="flex items-center gap-2">
            <BookOpen className="h-4 w-4" />
            Catálogo de Materias
          </TabsTrigger>
          <TabsTrigger value="curriculum-reports" className="flex items-center gap-2">
            <Calendar className="h-4 w-4" />
            Reportes Curriculares
          </TabsTrigger>
        </TabsList>

        {/* Configuración de Cursos */}
        <TabsContent value="courses-config" className="space-y-6">
          {/* Cursos sin configuración de materias */}
          {coursesWithoutSubjects.length > 0 && (
            <Card className="bg-red-50 border-red-200">
              <CardHeader>
                <CardTitle className="text-red-800 flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5" />🆕 Cursos sin Configuración de Materias
                </CardTitle>
                <CardDescription className="text-red-700">
                  Estos cursos fueron creados por el Director y requieren configuración de materias
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {coursesWithoutSubjects.map((course) => (
                    <Card key={course.id} className="bg-white border-red-200">
                      <CardHeader className="pb-3">
                        <div className="flex items-center justify-between">
                          <CardTitle className="text-gray-900">{course.name}</CardTitle>
                          <Badge className="bg-red-100 text-red-800">❌ No configuradas</Badge>
                        </div>
                        <div className="text-sm text-gray-600">
                          <p>Turno: {course.turn}</p>
                          <p>Capacidad: {course.capacity} estudiantes</p>
                          <p>Nivel: {course.level}</p>
                        </div>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        <div className="text-xs text-gray-500">
                          <p>Creado: {new Date(course.createdAt).toLocaleDateString()}</p>
                          {course.teacher && <p>Encargado: {course.teacher}</p>}
                        </div>

                        {/* Teacher Assignment Section */}
                        <div className="space-y-2">
                          <Label className="text-sm font-medium">Docente Encargado</Label>
                          {course.teacher ? (
                            <div className="flex items-center justify-between p-2 bg-green-50 border border-green-200 rounded">
                              <span className="text-sm text-green-800">👨‍🏫 {course.teacher}</span>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => {
                                  // Logic to unassign teacher
                                  console.log(`Desasignando docente del curso ${course.id}`)
                                }}
                                className="text-red-600 hover:text-red-700"
                              >
                                Cambiar
                              </Button>
                            </div>
                          ) : (
                            <Select onValueChange={(teacherId) => handleAssignTeacher(course.id, teacherId)}>
                              <SelectTrigger className="w-full">
                                <SelectValue placeholder="Seleccionar docente encargado" />
                              </SelectTrigger>
                              <SelectContent>
                                {availableTeachers
                                  .filter((teacher) => !teacher.assignedCourse || teacher.assignedCourse === course.id)
                                  .map((teacher) => (
                                    <SelectItem key={teacher.id} value={teacher.id}>
                                      <div className="flex flex-col">
                                        <span>{teacher.name}</span>
                                        <span className="text-xs text-gray-500">{teacher.subjects.join(", ")}</span>
                                      </div>
                                    </SelectItem>
                                  ))}
                                {availableTeachers.filter((teacher) => !teacher.assignedCourse).length === 0 && (
                                  <SelectItem value="none" disabled>
                                    No hay docentes disponibles
                                  </SelectItem>
                                )}
                              </SelectContent>
                            </Select>
                          )}
                        </div>

                        <Button
                          onClick={() => handleConfigureSubjects(course)}
                          className="w-full bg-purple-600 hover:bg-purple-700 text-white"
                        >
                          <Settings className="mr-2 h-4 w-4" />
                          ⚙️ Configurar Materias
                        </Button>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Cursos con configuración parcial */}
          {coursesWithPartialConfig.length > 0 && (
            <Card className="bg-yellow-50 border-yellow-200">
              <CardHeader>
                <CardTitle className="text-yellow-800 flex items-center gap-2">
                  <Clock className="h-5 w-5" />🟡 Cursos con Configuración Parcial
                </CardTitle>
                <CardDescription className="text-yellow-700">
                  Estos cursos tienen materias asignadas pero pueden necesitar ajustes
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {coursesWithPartialConfig.map((course) => (
                    <Card key={course.id} className="bg-white border-yellow-200">
                      <CardHeader className="pb-3">
                        <div className="flex items-center justify-between">
                          <CardTitle className="text-gray-900">{course.name}</CardTitle>
                          <Badge className="bg-yellow-100 text-yellow-800">🟡 Parcial</Badge>
                        </div>
                        <div className="text-sm text-gray-600">
                          <p>Turno: {course.turn}</p>
                          <p>Materias: {course.subjectsCount}</p>
                          <p>Completitud: {course.configurationStatus.completionPercentage}%</p>
                        </div>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        <div className="text-xs text-gray-500">
                          <p>Encargado: {course.teacher || "Sin asignar"}</p>
                        </div>
                        <div className="flex gap-2">
                          <Button onClick={() => handleConfigureSubjects(course)} variant="outline" className="flex-1">
                            <Edit className="mr-2 h-4 w-4" />
                            Editar
                          </Button>
                          <Button variant="outline" size="sm">
                            <Eye className="h-4 w-4" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Cursos con configuración completa */}
          {coursesWithCompleteConfig.length > 0 &&
            coursesWithCompleteConfig.map((course) => (
              <Card key={course.id} className="bg-green-50 border-green-200">
                <CardHeader>
                  <CardTitle className="text-green-800 flex items-center gap-2">
                    <CheckCircle className="h-5 w-5" />✅ Cursos con Configuración Completa
                  </CardTitle>
                  <CardDescription className="text-green-700">
                    Estos cursos tienen toda su configuración completa y están listos para el año escolar
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="text-xs text-gray-500">
                    <p>Encargado: {course.teacher}</p>
                    <p>Completitud: {course.configurationStatus.completionPercentage}%</p>
                  </div>

                  {/* Configuration Status Indicators */}
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div className="flex items-center gap-1">
                      <CheckCircle className="h-3 w-3 text-green-600" />
                      <span className="text-green-700">Materias</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <CheckCircle className="h-3 w-3 text-green-600" />
                      <span className="text-green-700">Docente</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <CheckCircle className="h-3 w-3 text-green-600" />
                      <span className="text-green-700">Horario</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <CheckCircle className="h-3 w-3 text-green-600" />
                      <span className="text-green-700">Estudiantes</span>
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex gap-2">
                    <Button
                      onClick={() => {
                        setSelectedCourseForEdit(course)
                        setIsEditDialogOpen(true)
                      }}
                      variant="outline"
                      className="flex-1 border-green-300 text-green-700 hover:bg-green-50"
                    >
                      <Edit className="mr-2 h-4 w-4" />
                      Editar
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="border-green-300 text-green-700 hover:bg-green-50 bg-transparent"
                      onClick={() => {
                        setSelectedCourseForView(course)
                        setIsViewDialogOpen(true)
                      }}
                    >
                      <Eye className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="border-green-300 text-green-700 hover:bg-green-50 bg-transparent"
                      onClick={() => {
                        console.log(`Duplicar configuración del curso ${course.id}`)
                        alert(`Duplicar configuración del curso ${course.name}`)
                      }}
                    >
                      <Settings className="h-4 w-4" />
                    </Button>
                  </div>

                  {/* Quick Stats */}
                  <div className="bg-green-50 p-2 rounded text-xs">
                    <div className="flex justify-between">
                      <span>Ocupación:</span>
                      <span className="font-medium">{Math.round((course.studentsCount / course.capacity) * 100)}%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}

          {/* Mensaje si no hay cursos pendientes */}
          {coursesWithoutSubjects.length === 0 &&
            coursesWithPartialConfig.length === 0 &&
            coursesWithCompleteConfig.length === 0 && (
              <Card>
                <CardContent className="text-center py-8">
                  <CheckCircle className="h-12 w-12 mx-auto mb-4 text-green-600" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">📚 No hay cursos registrados</h3>
                  <p className="text-gray-600">No hay cursos disponibles para configurar en este momento</p>
                </CardContent>
              </Card>
            )}
        </TabsContent>

        {/* Catálogo de Materias */}
        <TabsContent value="subjects-catalog" className="space-y-6">
          {/* Filtros */}
          <Card>
            <CardHeader>
              <CardTitle>Filtros y Búsqueda</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Buscar por nombre o código..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-8"
                    />
                  </div>
                </div>
                <Select value={selectedArea} onValueChange={setSelectedArea}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Área" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todas las áreas</SelectItem>
                    {areas.map((area) => (
                      <SelectItem key={area} value={area}>
                        {area}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select value={selectedGrade} onValueChange={setSelectedGrade}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Grado" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos los grados</SelectItem>
                    {grades.map((grade) => (
                      <SelectItem key={grade} value={grade}>
                        {grade}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Subjects Table */}
          <Card>
            <CardHeader>
              <CardTitle>Materias Curriculares</CardTitle>
              <CardDescription>Lista completa de materias del currículo institucional</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Código</TableHead>
                    <TableHead>Materia</TableHead>
                    <TableHead>Área</TableHead>
                    <TableHead>Grado</TableHead>
                    <TableHead>Horas</TableHead>
                    <TableHead>Docente</TableHead>
                    <TableHead>Estado</TableHead>
                    <TableHead>Acciones</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredSubjects.map((subject) => (
                    <TableRow key={subject.id}>
                      <TableCell className="font-mono text-sm">{subject.code}</TableCell>
                      <TableCell>
                        <div>
                          <div className="font-medium">{subject.name}</div>
                          <div className="text-sm text-muted-foreground">{subject.description}</div>
                        </div>
                      </TableCell>
                      <TableCell>{subject.area}</TableCell>
                      <TableCell>{subject.grade}</TableCell>
                      <TableCell>{subject.hours}h</TableCell>
                      <TableCell>
                        {subject.teacher ? (
                          <span className="text-sm">{subject.teacher}</span>
                        ) : (
                          <Badge variant="outline">Sin asignar</Badge>
                        )}
                      </TableCell>
                      <TableCell>{getStatusBadge(subject.status)}</TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-2">
                          <Button variant="ghost" size="sm">
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm" disabled={subject.hasGrades || !!subject.teacher}>
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Reportes Curriculares */}
        <TabsContent value="curriculum-reports" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Cumplimiento Curricular por Nivel</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span>Inicial</span>
                    <div className="flex items-center gap-2">
                      <div className="w-32 bg-gray-200 rounded-full h-2">
                        <div className="bg-green-600 h-2 rounded-full" style={{ width: "95%" }}></div>
                      </div>
                      <span className="text-sm font-medium">95%</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Primaria</span>
                    <div className="flex items-center gap-2">
                      <div className="w-32 bg-gray-200 rounded-full h-2">
                        <div className="bg-yellow-600 h-2 rounded-full" style={{ width: "78%" }}></div>
                      </div>
                      <span className="text-sm font-medium">78%</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Secundaria</span>
                    <div className="flex items-center gap-2">
                      <div className="w-32 bg-gray-200 rounded-full h-2">
                        <div className="bg-red-600 h-2 rounded-full" style={{ width: "65%" }}></div>
                      </div>
                      <span className="text-sm font-medium">65%</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Materias por Área</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {areas.map((area) => {
                    const count = subjects.filter((s) => s.area === area).length
                    return (
                      <div key={area} className="flex items-center justify-between">
                        <span>{area}</span>
                        <Badge variant="outline">{count} materias</Badge>
                      </div>
                    )
                  })}
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Resumen de Configuración</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="text-center p-4 bg-green-50 rounded-lg">
                  <div className="text-2xl font-bold text-green-600">12</div>
                  <div className="text-sm text-green-700">Cursos Completos</div>
                </div>
                <div className="text-center p-4 bg-yellow-50 rounded-lg">
                  <div className="text-2xl font-bold text-yellow-600">{stats.coursesWithPartialConfig}</div>
                  <div className="text-sm text-yellow-700">Config. Parcial</div>
                </div>
                <div className="text-center p-4 bg-red-50 rounded-lg">
                  <div className="text-2xl font-bold text-red-600">{stats.coursesWithoutSubjects}</div>
                  <div className="text-sm text-red-700">Sin Configurar</div>
                </div>
                <div className="text-center p-4 bg-blue-50 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600">{stats.total}</div>
                  <div className="text-sm text-blue-700">Total Materias</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* View Course Dialog */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Eye className="h-5 w-5" />
              Detalles del Curso: {selectedCourseForView?.name}
            </DialogTitle>
            <DialogDescription>Información completa del curso y su configuración</DialogDescription>
          </DialogHeader>

          {selectedCourseForView && (
            <div className="space-y-6">
              {/* Course Info */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm">Información General</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Nivel:</span>
                      <span className="font-medium">{selectedCourseForView.level}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Turno:</span>
                      <span className="font-medium">{selectedCourseForView.turn}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Capacidad:</span>
                      <span className="font-medium">{selectedCourseForView.capacity}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Encargado:</span>
                      <span className="font-medium">{selectedCourseForView.teacher}</span>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm">Estadísticas</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Estudiantes:</span>
                      <span className="font-medium">{selectedCourseForView.studentsCount}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Materias:</span>
                      <span className="font-medium">{selectedCourseForView.subjectsCount}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Ocupación:</span>
                      <span className="font-medium">
                        {Math.round((selectedCourseForView.studentsCount / selectedCourseForView.capacity) * 100)}%
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Estado:</span>
                      <Badge className="bg-green-100 text-green-800">Activo</Badge>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm">Configuración</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2 text-sm">
                    <div className="flex items-center justify-between">
                      <span className="text-gray-600">Materias:</span>
                      <CheckCircle className="h-4 w-4 text-green-600" />
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-600">Docente:</span>
                      <CheckCircle className="h-4 w-4 text-green-600" />
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-600">Horario:</span>
                      <CheckCircle className="h-4 w-4 text-green-600" />
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-600">Estudiantes:</span>
                      <CheckCircle className="h-4 w-4 text-green-600" />
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Schedule */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Horario de Clases</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {getCourseDetails(selectedCourseForView.id).schedule.map((day) => (
                      <div key={day.day}>
                        <h4 className="font-medium text-sm mb-2 text-blue-700">{day.day}</h4>
                        <div className="grid grid-cols-1 md:grid-cols-5 gap-2">
                          {day.subjects.map((subject, index) => (
                            <div key={index} className="bg-blue-50 p-2 rounded text-xs">
                              <div className="font-medium text-blue-800">{subject.time}</div>
                              <div className="text-blue-700">{subject.subject}</div>
                              <div className="text-blue-600">{subject.teacher}</div>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Subjects */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Materias Asignadas</CardTitle>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Materia</TableHead>
                        <TableHead>Docente</TableHead>
                        <TableHead>Horas Semanales</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {getCourseDetails(selectedCourseForView.id).subjects.map((subject) => (
                        <TableRow key={subject.id}>
                          <TableCell className="font-medium">{subject.name}</TableCell>
                          <TableCell>{subject.teacher}</TableCell>
                          <TableCell>{subject.hours}h</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>

              {/* Students */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Lista de Estudiantes</CardTitle>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Estudiante</TableHead>
                        <TableHead>Asistencia</TableHead>
                        <TableHead>Promedio</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {getCourseDetails(selectedCourseForView.id).students.map((student) => (
                        <TableRow key={student.id}>
                          <TableCell className="font-medium">{student.name}</TableCell>
                          <TableCell>
                            <Badge variant={student.attendance >= 90 ? "default" : "secondary"}>
                              {student.attendance}%
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Badge variant={student.average >= 80 ? "default" : "secondary"}>{student.average}</Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Edit Course Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Edit className="h-5 w-5" />
              Editar Curso: {selectedCourseForEdit?.name}
            </DialogTitle>
            <DialogDescription>Modificar materias y docente encargado del curso</DialogDescription>
          </DialogHeader>

          {selectedCourseForEdit && (
            <div className="space-y-6">
              {/* Teacher Assignment */}
              <div className="space-y-3">
                <Label className="text-sm font-medium">Docente Encargado</Label>
                <Select defaultValue={selectedCourseForEdit.teacher || ""}>
                  <SelectTrigger>
                    <SelectValue placeholder="Seleccionar docente encargado" />
                  </SelectTrigger>
                  <SelectContent>
                    {availableTeachers.map((teacher) => (
                      <SelectItem key={teacher.id} value={teacher.name}>
                        <div className="flex flex-col">
                          <span>{teacher.name}</span>
                          <span className="text-xs text-gray-500">{teacher.subjects.join(", ")}</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Subjects Configuration */}
              <div className="space-y-3">
                <Label className="text-sm font-medium">Materias del Curso</Label>
                <Card>
                  <CardContent className="p-4">
                    <div className="space-y-3">
                      {getCourseDetails(selectedCourseForEdit.id).subjects.map((subject) => (
                        <div key={subject.id} className="flex items-center justify-between p-3 bg-gray-50 rounded">
                          <div>
                            <div className="font-medium text-sm">{subject.name}</div>
                            <div className="text-xs text-gray-600">{subject.hours}h semanales</div>
                          </div>
                          <div className="flex items-center gap-2">
                            <Select defaultValue={subject.teacher}>
                              <SelectTrigger className="w-40">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                {availableTeachers
                                  .filter((teacher) => teacher.subjects.includes(subject.name.split(" ")[0]))
                                  .map((teacher) => (
                                    <SelectItem key={teacher.id} value={teacher.name}>
                                      {teacher.name}
                                    </SelectItem>
                                  ))}
                              </SelectContent>
                            </Select>
                            <Button variant="ghost" size="sm">
                              <Trash2 className="h-4 w-4 text-red-600" />
                            </Button>
                          </div>
                        </div>
                      ))}

                      <Button variant="outline" className="w-full bg-transparent">
                        <Plus className="h-4 w-4 mr-2" />
                        Agregar Materia
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              Cancelar
            </Button>
            <Button
              onClick={() => {
                console.log("Guardando cambios del curso:", selectedCourseForEdit?.id)
                setIsEditDialogOpen(false)
                alert("Cambios guardados exitosamente")
              }}
            >
              Guardar Cambios
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
