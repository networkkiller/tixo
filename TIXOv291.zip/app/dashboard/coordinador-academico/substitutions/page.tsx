"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import {
  AlertTriangle,
  Calendar,
  Download,
  Edit,
  Eye,
  Filter,
  Plus,
  Search,
  Trash2,
  Upload,
  UserCheck,
  UserPlus,
  X,
  CheckCircle,
  AlertCircle,
} from "lucide-react"
import { format } from "date-fns"
import { es } from "date-fns/locale"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Calendar as CalendarComponent } from "@/components/ui/calendar"

export default function SubstitutionsPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [filterStatus, setFilterStatus] = useState("all")
  const [filterCourse, setFilterCourse] = useState("all")
  const [filterSubject, setFilterSubject] = useState("all")
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false)
  const [selectedSubstitutionId, setSelectedSubstitutionId] = useState<number | null>(null)
  const [substitutionType, setSubstitutionType] = useState<"internal" | "external">("internal")
  const [startDate, setStartDate] = useState<Date>()
  const [endDate, setEndDate] = useState<Date>()
  const [selectedCourse, setSelectedCourse] = useState("")
  const [selectedSubject, setSelectedSubject] = useState("")
  const [selectedTeacher, setSelectedTeacher] = useState("")
  const [selectedSubstitute, setSelectedSubstitute] = useState("")
  const [substitutionReason, setSubstitutionReason] = useState("")
  const [observations, setObservations] = useState("")
  const [formStep, setFormStep] = useState(1)
  const [externalSubstituteData, setExternalSubstituteData] = useState({
    fullName: "",
    idNumber: "",
    phone: "",
    email: "",
    specialty: "",
    availability: "morning",
    document: null,
  })
  const [showValidationWarning, setShowValidationWarning] = useState(false)
  const [validationMessages, setValidationMessages] = useState<string[]>([])
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [editingSubstitution, setEditingSubstitution] = useState<any>(null)
  const [editFormData, setEditFormData] = useState({
    startDate: undefined as Date | undefined,
    endDate: undefined as Date | undefined,
    substitutionType: "internal" as "internal" | "external",
    selectedSubstitute: "",
    substitutionReason: "",
    observations: "",
    externalSubstituteData: {
      fullName: "",
      idNumber: "",
      phone: "",
      email: "",
      specialty: "",
      availability: "morning",
      document: null,
    },
  })
  const [showEditWarning, setShowEditWarning] = useState(false)
  const [editWarningMessage, setEditWarningMessage] = useState("")

  // Datos de ejemplo para sustituciones
  const substitutions = [
    {
      id: 1,
      course: "3ro Bachillerato A",
      subject: "Matemáticas III",
      originalTeacher: "Prof. Carlos Mendoza",
      substituteTeacher: "Prof. Carmen Vega",
      startDate: "2024-07-15",
      endDate: "2024-07-25",
      reason: "Licencia médica",
      status: "active",
      isExternal: false,
      createdBy: "Patricia Morales",
      createdAt: "2024-07-12",
      observations: "El docente presentó certificado médico por 10 días",
    },
    {
      id: 2,
      course: "4to Bachillerato B",
      subject: "Física",
      originalTeacher: "Prof. Ana Gutiérrez",
      substituteTeacher: "Prof. Roberto Silva",
      startDate: "2024-07-18",
      endDate: "2024-07-22",
      reason: "Capacitación profesional",
      status: "pending",
      isExternal: false,
      createdBy: "Patricia Morales",
      createdAt: "2024-07-14",
      observations: "Asistirá a taller de actualización docente",
    },
    {
      id: 3,
      course: "2do Bachillerato A",
      subject: "Lengua Española",
      originalTeacher: "Prof. María López",
      substituteTeacher: "Lic. Fernando Ramírez",
      startDate: "2024-07-10",
      endDate: "2024-07-31",
      reason: "Permiso personal",
      status: "active",
      isExternal: true,
      createdBy: "Patricia Morales",
      createdAt: "2024-07-08",
      observations: "Sustituto externo con experiencia previa en la institución",
    },
    {
      id: 4,
      course: "5to Bachillerato C",
      subject: "Historia",
      originalTeacher: "Prof. Javier Ramírez",
      substituteTeacher: "Prof. Miguel Torres",
      startDate: "2024-07-05",
      endDate: "2024-07-12",
      reason: "Licencia médica",
      status: "completed",
      isExternal: false,
      createdBy: "Patricia Morales",
      createdAt: "2024-07-03",
      observations: "",
    },
    {
      id: 5,
      course: "1ro Bachillerato B",
      subject: "Ciencias Naturales",
      originalTeacher: "Prof. Lucía Fernández",
      substituteTeacher: "Lic. Carolina Méndez",
      startDate: "2024-07-22",
      endDate: "2024-08-05",
      reason: "Vacaciones",
      status: "pending",
      isExternal: true,
      createdBy: "Patricia Morales",
      createdAt: "2024-07-15",
      observations: "Sustituta externa recomendada por el departamento académico",
    },
  ]

  // Datos de ejemplo para cursos
  const courses = [
    { id: "1", name: "1ro Bachillerato A" },
    { id: "2", name: "1ro Bachillerato B" },
    { id: "3", name: "2do Bachillerato A" },
    { id: "4", name: "3ro Bachillerato A" },
    { id: "5", name: "4to Bachillerato B" },
    { id: "6", name: "5to Bachillerato C" },
    { id: "7", name: "6to Bachillerato A" },
  ]

  // Datos de ejemplo para materias
  const subjects = [
    { id: "1", name: "Matemáticas", teacher: "Prof. Carlos Mendoza" },
    { id: "2", name: "Lengua Española", teacher: "Prof. María López" },
    { id: "3", name: "Ciencias Naturales", teacher: "Prof. Lucía Fernández" },
    { id: "4", name: "Historia", teacher: "Prof. Javier Ramírez" },
    { id: "5", name: "Física", teacher: "Prof. Ana Gutiérrez" },
    { id: "6", name: "Química", teacher: "Prof. Roberto Silva" },
    { id: "7", name: "Inglés", teacher: "Prof. Laura Martín" },
  ]

  // Datos de ejemplo para docentes internos disponibles
  const internalTeachers = [
    { id: "1", name: "Prof. Carmen Vega", specialty: "Matemáticas" },
    { id: "2", name: "Prof. Roberto Silva", specialty: "Física, Química" },
    { id: "3", name: "Prof. Miguel Torres", specialty: "Historia, Geografía" },
    { id: "4", name: "Prof. Elena Rodríguez", specialty: "Física, Matemáticas" },
    { id: "5", name: "Prof. Pedro Sánchez", specialty: "Educación Física" },
  ]

  // Filtrar sustituciones basadas en los criterios de búsqueda y filtros
  const filteredSubstitutions = substitutions.filter((substitution) => {
    const matchesSearch =
      substitution.course.toLowerCase().includes(searchTerm.toLowerCase()) ||
      substitution.subject.toLowerCase().includes(searchTerm.toLowerCase()) ||
      substitution.originalTeacher.toLowerCase().includes(searchTerm.toLowerCase()) ||
      substitution.substituteTeacher.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = filterStatus === "all" || substitution.status === filterStatus
    const matchesCourse = filterCourse === "all" || substitution.course === filterCourse
    const matchesSubject = filterSubject === "all" || substitution.subject === filterSubject

    return matchesSearch && matchesStatus && matchesCourse && matchesSubject
  })

  // Función para obtener el color de la insignia según el estado
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "active":
        return <Badge className="bg-green-500">Activa</Badge>
      case "pending":
        return <Badge className="bg-yellow-500">Pendiente</Badge>
      case "completed":
        return <Badge className="bg-blue-500">Completada</Badge>
      case "cancelled":
        return <Badge className="bg-red-500">Cancelada</Badge>
      default:
        return <Badge variant="outline">Desconocido</Badge>
    }
  }

  // Función para obtener la sustitución seleccionada
  const getSelectedSubstitution = () => {
    return substitutions.find((substitution) => substitution.id === selectedSubstitutionId) || null
  }

  // Función para manejar el clic en Ver Sustitución
  const handleViewSubstitution = (id: number) => {
    setSelectedSubstitutionId(id)
    setIsViewDialogOpen(true)
  }

  // Función para manejar el cambio de paso en el formulario
  const handleStepChange = (direction: "next" | "prev") => {
    if (direction === "next") {
      // Validaciones para el paso 1
      if (formStep === 1) {
        const messages = []
        if (!selectedCourse) messages.push("Debe seleccionar un curso")
        if (!selectedSubject) messages.push("Debe seleccionar una materia")
        if (!startDate) messages.push("Debe seleccionar una fecha de inicio")

        if (messages.length > 0) {
          setValidationMessages(messages)
          setShowValidationWarning(true)
          return
        }
      }

      // Validaciones para el paso 2
      if (formStep === 2) {
        const messages = []
        if (substitutionType === "internal" && !selectedSubstitute) {
          messages.push("Debe seleccionar un docente sustituto")
        }
        if (substitutionType === "external") {
          if (!externalSubstituteData.fullName) messages.push("Debe ingresar el nombre completo del sustituto")
          if (!externalSubstituteData.idNumber) messages.push("Debe ingresar la cédula o ID del sustituto")
          if (!externalSubstituteData.email) messages.push("Debe ingresar el correo electrónico del sustituto")
          if (!externalSubstituteData.specialty) messages.push("Debe ingresar la especialidad del sustituto")
        }
        if (!substitutionReason) messages.push("Debe seleccionar un motivo para la sustitución")

        if (messages.length > 0) {
          setValidationMessages(messages)
          setShowValidationWarning(true)
          return
        }
      }

      setFormStep(formStep + 1)
      setShowValidationWarning(false)
    } else if (direction === "prev" && formStep > 1) {
      setFormStep(formStep - 1)
      setShowValidationWarning(false)
    }
  }

  // Función para reiniciar el formulario
  const resetForm = () => {
    setFormStep(1)
    setSelectedCourse("")
    setSelectedSubject("")
    setSelectedTeacher("")
    setSelectedSubstitute("")
    setStartDate(undefined)
    setEndDate(undefined)
    setSubstitutionReason("")
    setObservations("")
    setSubstitutionType("internal")
    setExternalSubstituteData({
      fullName: "",
      idNumber: "",
      phone: "",
      email: "",
      specialty: "",
      availability: "morning",
      document: null,
    })
    setShowValidationWarning(false)
    setValidationMessages([])
  }

  // Función para cerrar el diálogo de creación
  const handleCloseCreationDialog = () => {
    resetForm()
    setIsCreateDialogOpen(false)
  }

  // Función para manejar la creación de una nueva sustitución
  const handleCreateSubstitution = () => {
    // Aquí iría la lógica para crear la sustitución en la base de datos
    console.log("Creando sustitución con los siguientes datos:", {
      course: selectedCourse,
      subject: selectedSubject,
      originalTeacher: selectedTeacher,
      substituteTeacher: substitutionType === "internal" ? selectedSubstitute : externalSubstituteData.fullName,
      startDate,
      endDate,
      reason: substitutionReason,
      observations,
      isExternal: substitutionType === "external",
      externalSubstituteData: substitutionType === "external" ? externalSubstituteData : null,
    })

    // Cerrar el diálogo y reiniciar el formulario
    handleCloseCreationDialog()
  }

  // Función para formatear fechas
  const formatDate = (dateString: string) => {
    return format(new Date(dateString), "dd 'de' MMMM 'de' yyyy", { locale: es })
  }

  // Función para manejar el clic en Editar Sustitución
  const handleEditSubstitution = (substitution: any) => {
    setEditingSubstitution(substitution)
    setEditFormData({
      startDate: new Date(substitution.startDate),
      endDate: new Date(substitution.endDate),
      substitutionType: substitution.isExternal ? "external" : "internal",
      selectedSubstitute: substitution.isExternal ? "" : substitution.substituteTeacher,
      substitutionReason:
        substitution.reason === "Licencia médica"
          ? "medical"
          : substitution.reason === "Vacaciones"
            ? "vacation"
            : substitution.reason === "Capacitación profesional"
              ? "training"
              : substitution.reason === "Permiso personal"
                ? "personal"
                : "other",
      observations: substitution.observations || "",
      externalSubstituteData: substitution.isExternal
        ? {
            fullName: substitution.substituteTeacher,
            idNumber: "",
            phone: "",
            email: "",
            specialty: "",
            availability: "morning",
            document: null,
          }
        : {
            fullName: "",
            idNumber: "",
            phone: "",
            email: "",
            specialty: "",
            availability: "morning",
            document: null,
          },
    })
    setIsEditDialogOpen(true)
  }

  // Función para verificar si una sustitución puede ser editada
  const canEditSubstitution = (status: string) => {
    return status === "active" || status === "pending"
  }

  // Función para manejar el guardado de cambios en la edición
  const handleSaveEditChanges = () => {
    // Validaciones
    const messages = []

    if (!editFormData.startDate) messages.push("Debe seleccionar una fecha de inicio")
    if (!editFormData.endDate) messages.push("Debe seleccionar una fecha de fin")

    if (editFormData.substitutionType === "internal" && !editFormData.selectedSubstitute) {
      messages.push("Debe seleccionar un docente sustituto")
    }

    if (editFormData.substitutionType === "external") {
      if (!editFormData.externalSubstituteData.fullName) messages.push("Debe ingresar el nombre completo del sustituto")
      if (!editFormData.externalSubstituteData.idNumber) messages.push("Debe ingresar la cédula o ID del sustituto")
      if (!editFormData.externalSubstituteData.email) messages.push("Debe ingresar el correo electrónico del sustituto")
      if (!editFormData.externalSubstituteData.specialty) messages.push("Debe ingresar la especialidad del sustituto")
    }

    if (!editFormData.substitutionReason) messages.push("Debe seleccionar un motivo para la sustitución")

    // Validación de fechas
    if (editFormData.endDate && editFormData.endDate < new Date()) {
      messages.push("No se puede establecer una fecha de finalización anterior al día actual")
    }

    if (messages.length > 0) {
      setValidationMessages(messages)
      setShowValidationWarning(true)
      return
    }

    // Verificar si la sustitución está en curso y se está cambiando el sustituto
    if (
      editingSubstitution?.status === "active" &&
      ((editFormData.substitutionType === "internal" &&
        editFormData.selectedSubstitute !== editingSubstitution.substituteTeacher) ||
        (editFormData.substitutionType === "external" &&
          editFormData.externalSubstituteData.fullName !== editingSubstitution.substituteTeacher))
    ) {
      setEditWarningMessage("Esta acción reemplazará al docente actualmente en funciones. ¿Desea continuar?")
      setShowEditWarning(true)
      return
    }

    // Aquí iría la lógica para guardar los cambios en la base de datos
    console.log("Guardando cambios en la sustitución:", {
      id: editingSubstitution?.id,
      ...editFormData,
    })

    // Cerrar el diálogo y limpiar el estado
    setIsEditDialogOpen(false)
    setEditingSubstitution(null)
    setShowEditWarning(false)
    setShowValidationWarning(false)
  }

  // Función para confirmar el cambio de sustituto en curso
  const confirmSubstituteChange = () => {
    setShowEditWarning(false)

    // Aquí iría la lógica para guardar los cambios en la base de datos
    console.log("Confirmando cambio de sustituto en curso:", {
      id: editingSubstitution?.id,
      ...editFormData,
    })

    // Cerrar el diálogo y limpiar el estado
    setIsEditDialogOpen(false)
    setEditingSubstitution(null)
    setShowValidationWarning(false)
  }

  // Función para cerrar el diálogo de edición
  const handleCloseEditDialog = () => {
    setIsEditDialogOpen(false)
    setEditingSubstitution(null)
    setShowEditWarning(false)
    setShowValidationWarning(false)
    setValidationMessages([])
  }

  return (
    <div className="flex-1 space-y-6 p-6 bg-white">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Sustituciones Académicas</h1>
          <p className="text-muted-foreground">Gestión de sustituciones temporales de docentes</p>
        </div>
        <Button className="bg-blue-600 hover:bg-blue-700" onClick={() => setIsCreateDialogOpen(true)}>
          <Plus className="mr-2 h-4 w-4" /> Nueva Sustitución
        </Button>
      </div>

      {/* Estadísticas */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Sustituciones</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{substitutions.length}</div>
            <p className="text-xs text-muted-foreground">En el período actual</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Sustituciones Activas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {substitutions.filter((s) => s.status === "active").length}
            </div>
            <p className="text-xs text-muted-foreground">En curso actualmente</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Sustituciones Pendientes</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">
              {substitutions.filter((s) => s.status === "pending").length}
            </div>
            <p className="text-xs text-muted-foreground">Por iniciar</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Sustitutos Externos</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{substitutions.filter((s) => s.isExternal).length}</div>
            <p className="text-xs text-muted-foreground">Docentes temporales</p>
          </CardContent>
        </Card>
      </div>

      {/* Tabs y Filtros */}
      <Tabs defaultValue="all" className="space-y-4">
        <div className="flex items-center justify-between">
          <TabsList>
            <TabsTrigger value="all">Todas</TabsTrigger>
            <TabsTrigger value="active">Activas</TabsTrigger>
            <TabsTrigger value="pending">Pendientes</TabsTrigger>
            <TabsTrigger value="completed">Completadas</TabsTrigger>
          </TabsList>
          <div className="flex items-center space-x-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Buscar sustituciones..."
                className="pl-8 w-[200px] md:w-[300px]"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Button variant="outline" size="icon">
              <Filter className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Filtros adicionales */}
        <div className="flex flex-wrap gap-2">
          <Select value={filterCourse} onValueChange={setFilterCourse}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Filtrar por Curso" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos los Cursos</SelectItem>
              {courses.map((course) => (
                <SelectItem key={course.id} value={course.name}>
                  {course.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={filterSubject} onValueChange={setFilterSubject}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Filtrar por Materia" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todas las Materias</SelectItem>
              {subjects.map((subject) => (
                <SelectItem key={subject.id} value={subject.name}>
                  {subject.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Filtrar por Estado" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos los Estados</SelectItem>
              <SelectItem value="active">Activas</SelectItem>
              <SelectItem value="pending">Pendientes</SelectItem>
              <SelectItem value="completed">Completadas</SelectItem>
              <SelectItem value="cancelled">Canceladas</SelectItem>
            </SelectContent>
          </Select>

          <Button variant="outline" className="ml-auto bg-transparent">
            <Download className="mr-2 h-4 w-4" /> Exportar
          </Button>
        </div>

        {/* Lista de Sustituciones */}
        <TabsContent value="all" className="space-y-4">
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Curso</TableHead>
                  <TableHead>Materia</TableHead>
                  <TableHead>Docente Original</TableHead>
                  <TableHead>Sustituto</TableHead>
                  <TableHead>Período</TableHead>
                  <TableHead>Estado</TableHead>
                  <TableHead>Acciones</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredSubstitutions.map((substitution) => (
                  <TableRow key={substitution.id}>
                    <TableCell className="font-medium">{substitution.course}</TableCell>
                    <TableCell>{substitution.subject}</TableCell>
                    <TableCell>{substitution.originalTeacher}</TableCell>
                    <TableCell>
                      <div className="flex items-center">
                        {substitution.substituteTeacher}
                        {substitution.isExternal && (
                          <Badge variant="outline" className="ml-2 text-xs">
                            Externo
                          </Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="text-sm">
                        <div>{format(new Date(substitution.startDate), "dd/MM/yyyy")}</div>
                        <div>{format(new Date(substitution.endDate), "dd/MM/yyyy")}</div>
                      </div>
                    </TableCell>
                    <TableCell>{getStatusBadge(substitution.status)}</TableCell>
                    <TableCell>
                      <div className="flex space-x-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8"
                          onClick={() => handleViewSubstitution(substitution.id)}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                        {canEditSubstitution(substitution.status) && (
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8"
                            onClick={() => handleEditSubstitution(substitution)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                        )}
                        {substitution.status === "pending" && (
                          <>
                            <Button variant="ghost" size="icon" className="h-8 w-8 text-red-500">
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </TabsContent>

        <TabsContent value="active">
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Curso</TableHead>
                  <TableHead>Materia</TableHead>
                  <TableHead>Docente Original</TableHead>
                  <TableHead>Sustituto</TableHead>
                  <TableHead>Período</TableHead>
                  <TableHead>Estado</TableHead>
                  <TableHead>Acciones</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredSubstitutions
                  .filter((s) => s.status === "active")
                  .map((substitution) => (
                    <TableRow key={substitution.id}>
                      <TableCell className="font-medium">{substitution.course}</TableCell>
                      <TableCell>{substitution.subject}</TableCell>
                      <TableCell>{substitution.originalTeacher}</TableCell>
                      <TableCell>
                        <div className="flex items-center">
                          {substitution.substituteTeacher}
                          {substitution.isExternal && (
                            <Badge variant="outline" className="ml-2 text-xs">
                              Externo
                            </Badge>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="text-sm">
                          <div>{format(new Date(substitution.startDate), "dd/MM/yyyy")}</div>
                          <div>{format(new Date(substitution.endDate), "dd/MM/yyyy")}</div>
                        </div>
                      </TableCell>
                      <TableCell>{getStatusBadge(substitution.status)}</TableCell>
                      <TableCell>
                        <div className="flex space-x-1">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8"
                            onClick={() => handleViewSubstitution(substitution.id)}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                          {canEditSubstitution(substitution.status) && (
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8"
                              onClick={() => handleEditSubstitution(substitution)}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
              </TableBody>
            </Table>
          </div>
        </TabsContent>

        <TabsContent value="pending">
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Curso</TableHead>
                  <TableHead>Materia</TableHead>
                  <TableHead>Docente Original</TableHead>
                  <TableHead>Sustituto</TableHead>
                  <TableHead>Período</TableHead>
                  <TableHead>Estado</TableHead>
                  <TableHead>Acciones</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredSubstitutions
                  .filter((s) => s.status === "pending")
                  .map((substitution) => (
                    <TableRow key={substitution.id}>
                      <TableCell className="font-medium">{substitution.course}</TableCell>
                      <TableCell>{substitution.subject}</TableCell>
                      <TableCell>{substitution.originalTeacher}</TableCell>
                      <TableCell>
                        <div className="flex items-center">
                          {substitution.substituteTeacher}
                          {substitution.isExternal && (
                            <Badge variant="outline" className="ml-2 text-xs">
                              Externo
                            </Badge>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="text-sm">
                          <div>{format(new Date(substitution.startDate), "dd/MM/yyyy")}</div>
                          <div>{format(new Date(substitution.endDate), "dd/MM/yyyy")}</div>
                        </div>
                      </TableCell>
                      <TableCell>{getStatusBadge(substitution.status)}</TableCell>
                      <TableCell>
                        <div className="flex space-x-1">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8"
                            onClick={() => handleViewSubstitution(substitution.id)}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                          {canEditSubstitution(substitution.status) && (
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8"
                              onClick={() => handleEditSubstitution(substitution)}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                          )}
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-red-500">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
              </TableBody>
            </Table>
          </div>
        </TabsContent>

        <TabsContent value="completed">
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Curso</TableHead>
                  <TableHead>Materia</TableHead>
                  <TableHead>Docente Original</TableHead>
                  <TableHead>Sustituto</TableHead>
                  <TableHead>Período</TableHead>
                  <TableHead>Estado</TableHead>
                  <TableHead>Acciones</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredSubstitutions
                  .filter((s) => s.status === "completed")
                  .map((substitution) => (
                    <TableRow key={substitution.id}>
                      <TableCell className="font-medium">{substitution.course}</TableCell>
                      <TableCell>{substitution.subject}</TableCell>
                      <TableCell>{substitution.originalTeacher}</TableCell>
                      <TableCell>
                        <div className="flex items-center">
                          {substitution.substituteTeacher}
                          {substitution.isExternal && (
                            <Badge variant="outline" className="ml-2 text-xs">
                              Externo
                            </Badge>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="text-sm">
                          <div>{format(new Date(substitution.startDate), "dd/MM/yyyy")}</div>
                          <div>{format(new Date(substitution.endDate), "dd/MM/yyyy")}</div>
                        </div>
                      </TableCell>
                      <TableCell>{getStatusBadge(substitution.status)}</TableCell>
                      <TableCell>
                        <div className="flex space-x-1">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8"
                            onClick={() => handleViewSubstitution(substitution.id)}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                          {canEditSubstitution(substitution.status) && (
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8"
                              onClick={() => handleEditSubstitution(substitution)}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
              </TableBody>
            </Table>
          </div>
        </TabsContent>
      </Tabs>

      {/* Diálogo para ver detalles de la sustitución */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="max-w-3xl">
          {getSelectedSubstitution() && (
            <>
              <DialogHeader>
                <DialogTitle>Detalles de la Sustitución</DialogTitle>
                <DialogDescription>Información completa sobre la sustitución académica temporal</DialogDescription>
              </DialogHeader>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Curso</h3>
                    <p className="text-base font-medium">{getSelectedSubstitution()?.course}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Materia</h3>
                    <p className="text-base font-medium">{getSelectedSubstitution()?.subject}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Docente Original</h3>
                    <p className="text-base font-medium">{getSelectedSubstitution()?.originalTeacher}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Docente Sustituto</h3>
                    <div className="flex items-center">
                      <p className="text-base font-medium">{getSelectedSubstitution()?.substituteTeacher}</p>
                      {getSelectedSubstitution()?.isExternal && (
                        <Badge variant="outline" className="ml-2">
                          Externo
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Período de Sustitución</h3>
                    <p className="text-base">
                      {formatDate(getSelectedSubstitution()?.startDate || "")} -{" "}
                      {formatDate(getSelectedSubstitution()?.endDate || "")}
                    </p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Motivo</h3>
                    <p className="text-base">{getSelectedSubstitution()?.reason}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Estado</h3>
                    <div>{getStatusBadge(getSelectedSubstitution()?.status || "")}</div>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Creado por</h3>
                    <p className="text-base">
                      {getSelectedSubstitution()?.createdBy} el {formatDate(getSelectedSubstitution()?.createdAt || "")}
                    </p>
                  </div>
                </div>
              </div>

              {getSelectedSubstitution()?.observations && (
                <div className="mt-4">
                  <h3 className="text-sm font-medium text-gray-500">Observaciones</h3>
                  <p className="text-base mt-1">{getSelectedSubstitution()?.observations}</p>
                </div>
              )}

              <div className="mt-6 bg-gray-50 p-4 rounded-lg">
                <h3 className="text-sm font-medium text-gray-700 mb-2">Impacto en Módulos</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    <span className="text-sm">Horario del curso actualizado</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    <span className="text-sm">Panel del docente sustituto actualizado</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    <span className="text-sm">Módulo de calificaciones actualizado</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    <span className="text-sm">Panel del estudiante/tutor actualizado</span>
                  </div>
                </div>
              </div>

              <DialogFooter>
                <Button variant="outline" onClick={() => setIsViewDialogOpen(false)}>
                  Cerrar
                </Button>
                <Button variant="outline">
                  <Download className="mr-2 h-4 w-4" /> Exportar Detalles
                </Button>
                {getSelectedSubstitution()?.status === "pending" && (
                  <Button variant="destructive">
                    <X className="mr-2 h-4 w-4" /> Cancelar Sustitución
                  </Button>
                )}
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* Diálogo para crear nueva sustitución */}
      <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>Nueva Sustitución Académica</DialogTitle>
            <DialogDescription>
              {formStep === 1 && "Selecciona el curso y la materia para la sustitución"}
              {formStep === 2 && "Selecciona el docente sustituto y el período de sustitución"}
              {formStep === 3 && "Revisa y confirma la información de la sustitución"}
            </DialogDescription>
          </DialogHeader>

          {/* Indicador de pasos */}
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center">
              <div
                className={`rounded-full h-8 w-8 flex items-center justify-center ${formStep >= 1 ? "bg-blue-600 text-white" : "bg-gray-200"}`}
              >
                1
              </div>
              <div className={`h-1 w-12 ${formStep > 1 ? "bg-blue-600" : "bg-gray-200"}`}></div>
              <div
                className={`rounded-full h-8 w-8 flex items-center justify-center ${formStep >= 2 ? "bg-blue-600 text-white" : "bg-gray-200"}`}
              >
                2
              </div>
              <div className={`h-1 w-12 ${formStep > 2 ? "bg-blue-600" : "bg-gray-200"}`}></div>
              <div
                className={`rounded-full h-8 w-8 flex items-center justify-center ${formStep >= 3 ? "bg-blue-600 text-white" : "bg-gray-200"}`}
              >
                3
              </div>
            </div>
            <Button variant="ghost" size="sm" onClick={handleCloseCreationDialog}>
              <X className="h-4 w-4" />
            </Button>
          </div>

          {/* Alertas de validación */}
          {showValidationWarning && (
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-4">
              <div className="flex items-start">
                <AlertTriangle className="h-5 w-5 text-yellow-600 mr-3 mt-0.5" />
                <div>
                  <h4 className="font-medium text-yellow-800">Por favor, complete todos los campos requeridos</h4>
                  <ul className="mt-1 text-sm text-yellow-700 list-disc list-inside">
                    {validationMessages.map((message, index) => (
                      <li key={index}>{message}</li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          )}

          {/* Paso 1: Seleccionar Curso y Materia */}
          {formStep === 1 && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="course">Curso</Label>
                  <Select value={selectedCourse} onValueChange={setSelectedCourse}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecciona un curso" />
                    </SelectTrigger>
                    <SelectContent>
                      {courses.map((course) => (
                        <SelectItem key={course.id} value={course.id}>
                          {course.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="subject">Materia</Label>
                  <Select
                    value={selectedSubject}
                    onValueChange={(value) => {
                      setSelectedSubject(value)
                      const subject = subjects.find((s) => s.id === value)
                      if (subject) {
                        setSelectedTeacher(subject.teacher)
                      }
                    }}
                    disabled={!selectedCourse}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecciona una materia" />
                    </SelectTrigger>
                    <SelectContent>
                      {subjects.map((subject) => (
                        <SelectItem key={subject.id} value={subject.id}>
                          {subject.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {selectedSubject && (
                <div className="space-y-2">
                  <Label>Docente Titular</Label>
                  <div className="p-3 bg-gray-50 rounded-lg border border-gray-200">
                    <div className="font-medium">{selectedTeacher}</div>
                    <div className="text-sm text-gray-500">{subjects.find((s) => s.id === selectedSubject)?.name}</div>
                  </div>
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="startDate">Fecha de Inicio</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className="w-full justify-start text-left font-normal bg-transparent"
                        disabled={!selectedSubject}
                      >
                        <Calendar className="mr-2 h-4 w-4" />
                        {startDate ? format(startDate, "PPP", { locale: es }) : "Seleccionar fecha"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <CalendarComponent
                        mode="single"
                        selected={startDate}
                        onSelect={setStartDate}
                        initialFocus
                        locale={es}
                      />
                    </PopoverContent>
                  </Popover>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="endDate">Fecha de Fin (Opcional)</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className="w-full justify-start text-left font-normal bg-transparent"
                        disabled={!startDate}
                      >
                        <Calendar className="mr-2 h-4 w-4" />
                        {endDate ? format(endDate, "PPP", { locale: es }) : "Seleccionar fecha"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <CalendarComponent
                        mode="single"
                        selected={endDate}
                        onSelect={setEndDate}
                        disabled={(date) => date < (startDate || new Date())}
                        initialFocus
                        locale={es}
                      />
                    </PopoverContent>
                  </Popover>
                </div>
              </div>
            </div>
          )}

          {/* Paso 2: Seleccionar Docente Sustituto */}
          {formStep === 2 && (
            <div className="space-y-6">
              <div className="space-y-4">
                <Label>Tipo de Sustitución</Label>
                <RadioGroup
                  value={substitutionType}
                  onValueChange={(value) => setSubstitutionType(value as "internal" | "external")}
                  className="flex flex-col space-y-3"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="internal" id="internal" />
                    <Label htmlFor="internal" className="flex items-center">
                      <UserCheck className="mr-2 h-4 w-4" />
                      Docente Interno
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="external" id="external" />
                    <Label htmlFor="external" className="flex items-center">
                      <UserPlus className="mr-2 h-4 w-4" />
                      Docente Externo (Temporal)
                    </Label>
                  </div>
                </RadioGroup>
              </div>

              {substitutionType === "internal" ? (
                <div className="space-y-2">
                  <Label htmlFor="substitute">Docente Sustituto</Label>
                  <Select value={selectedSubstitute} onValueChange={setSelectedSubstitute}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecciona un docente" />
                    </SelectTrigger>
                    <SelectContent>
                      {internalTeachers.map((teacher) => (
                        <SelectItem key={teacher.id} value={teacher.id}>
                          {teacher.name} - {teacher.specialty}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              ) : (
                <div className="space-y-4 border border-gray-200 rounded-lg p-4">
                  <h3 className="font-medium">Datos del Docente Externo</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="fullName">Nombre Completo</Label>
                      <Input
                        id="fullName"
                        value={externalSubstituteData.fullName}
                        onChange={(e) =>
                          setExternalSubstituteData({ ...externalSubstituteData, fullName: e.target.value })
                        }
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="idNumber">Cédula o ID</Label>
                      <Input
                        id="idNumber"
                        value={externalSubstituteData.idNumber}
                        onChange={(e) =>
                          setExternalSubstituteData({ ...externalSubstituteData, idNumber: e.target.value })
                        }
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="phone">Teléfono</Label>
                      <Input
                        id="phone"
                        value={externalSubstituteData.phone}
                        onChange={(e) =>
                          setExternalSubstituteData({ ...externalSubstituteData, phone: e.target.value })
                        }
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email">Correo Electrónico</Label>
                      <Input
                        id="email"
                        type="email"
                        value={externalSubstituteData.email}
                        onChange={(e) =>
                          setExternalSubstituteData({ ...externalSubstituteData, email: e.target.value })
                        }
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="specialty">Especialidad / Materia</Label>
                      <Input
                        id="specialty"
                        value={externalSubstituteData.specialty}
                        onChange={(e) =>
                          setExternalSubstituteData({ ...externalSubstituteData, specialty: e.target.value })
                        }
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="availability">Disponibilidad</Label>
                      <Select
                        value={externalSubstituteData.availability}
                        onValueChange={(value) =>
                          setExternalSubstituteData({ ...externalSubstituteData, availability: value })
                        }
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="morning">Mañana</SelectItem>
                          <SelectItem value="afternoon">Tarde</SelectItem>
                          <SelectItem value="evening">Noche</SelectItem>
                          <SelectItem value="extended">Tanda Extendida</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="document">Documento de Respaldo (Opcional)</Label>
                    <div className="flex items-center space-x-2">
                      <Input id="document" type="file" className="flex-1" />
                      <Button variant="outline" size="sm">
                        <Upload className="h-4 w-4 mr-2" /> Subir
                      </Button>
                    </div>
                    <p className="text-xs text-gray-500">
                      Carta de designación, constancia del MINERD, u otro documento relevante
                    </p>
                  </div>
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="reason">Motivo de la Sustitución</Label>
                <Select value={substitutionReason} onValueChange={setSubstitutionReason}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecciona un motivo" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="medical">Licencia médica</SelectItem>
                    <SelectItem value="vacation">Vacaciones</SelectItem>
                    <SelectItem value="training">Formación</SelectItem>
                    <SelectItem value="personal">Permiso personal</SelectItem>
                    <SelectItem value="other">Otro</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="observations">Observaciones Adicionales (Opcional)</Label>
                <Textarea
                  id="observations"
                  placeholder="Añade cualquier información relevante sobre esta sustitución..."
                  value={observations}
                  onChange={(e) => setObservations(e.target.value)}
                />
              </div>
            </div>
          )}

          {/* Paso 3: Confirmación */}
          {formStep === 3 && (
            <div className="space-y-6">
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="font-medium mb-4">Resumen de la Sustitución</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-3">
                    <div>
                      <span className="text-sm text-gray-500">Curso:</span>
                      <p className="font-medium">
                        {courses.find((c) => c.id === selectedCourse)?.name || "No seleccionado"}
                      </p>
                    </div>
                    <div>
                      <span className="text-sm text-gray-500">Materia:</span>
                      <p className="font-medium">
                        {subjects.find((s) => s.id === selectedSubject)?.name || "No seleccionada"}
                      </p>
                    </div>
                    <div>
                      <span className="text-sm text-gray-500">Docente Titular:</span>
                      <p className="font-medium">{selectedTeacher}</p>
                    </div>
                    <div>
                      <span className="text-sm text-gray-500">Período de Sustitución:</span>
                      <p className="font-medium">
                        {startDate ? format(startDate, "PPP", { locale: es }) : "No seleccionado"}{" "}
                        {endDate ? `- ${format(endDate, "PPP", { locale: es })}` : "(Sin fecha de fin)"}
                      </p>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <div>
                      <span className="text-sm text-gray-500">Tipo de Sustitución:</span>
                      <p className="font-medium">
                        {substitutionType === "internal" ? "Docente Interno" : "Docente Externo (Temporal)"}
                      </p>
                    </div>
                    <div>
                      <span className="text-sm text-gray-500">Docente Sustituto:</span>
                      <p className="font-medium">
                        {substitutionType === "internal"
                          ? internalTeachers.find((t) => t.id === selectedSubstitute)?.name || "No seleccionado"
                          : externalSubstituteData.fullName || "No especificado"}
                      </p>
                    </div>
                    <div>
                      <span className="text-sm text-gray-500">Motivo:</span>
                      <p className="font-medium">
                        {substitutionReason === "medical"
                          ? "Licencia médica"
                          : substitutionReason === "vacation"
                            ? "Vacaciones"
                            : substitutionReason === "training"
                              ? "Formación"
                              : substitutionReason === "personal"
                                ? "Permiso personal"
                                : substitutionReason === "other"
                                  ? "Otro"
                                  : "No especificado"}
                      </p>
                    </div>
                  </div>
                </div>
                {observations && (
                  <div className="mt-4">
                    <span className="text-sm text-gray-500">Observaciones:</span>
                    <p className="text-sm mt-1">{observations}</p>
                  </div>
                )}
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <div className="flex items-start">
                  <AlertCircle className="h-5 w-5 text-blue-600 mr-3 mt-0.5" />
                  <div>
                    <h4 className="font-medium text-blue-800">Información Importante</h4>
                    <ul className="mt-1 text-sm text-blue-700 list-disc list-inside space-y-1">
                      <li>
                        Esta sustitución afectará automáticamente al horario del curso, panel del docente y módulo de
                        calificaciones.
                      </li>
                      <li>
                        El docente titular no podrá registrar calificaciones ni asistencia durante el período de
                        sustitución.
                      </li>
                      {substitutionType === "external" && (
                        <li>
                          Se creará un usuario temporal para el docente externo con acceso limitado a esta materia y
                          curso.
                        </li>
                      )}
                      <li>
                        Los estudiantes y padres verán reflejado el cambio de docente en su panel durante el período
                        establecido.
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          )}

          <DialogFooter className="flex items-center justify-between">
            <div>
              {formStep > 1 && (
                <Button variant="outline" onClick={() => handleStepChange("prev")}>
                  Anterior
                </Button>
              )}
            </div>
            <div className="flex space-x-2">
              <Button variant="outline" onClick={handleCloseCreationDialog}>
                Cancelar
              </Button>
              {formStep < 3 ? (
                <Button onClick={() => handleStepChange("next")}>Siguiente</Button>
              ) : (
                <Button onClick={handleCreateSubstitution}>Crear Sustitución</Button>
              )}
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Diálogo para editar sustitución */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>Editar Sustitución Académica</DialogTitle>
            <DialogDescription>
              Modifica los datos de la sustitución para {editingSubstitution?.course} - {editingSubstitution?.subject}
            </DialogDescription>
          </DialogHeader>

          {/* Alertas de validación */}
          {showValidationWarning && (
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-4">
              <div className="flex items-start">
                <AlertTriangle className="h-5 w-5 text-yellow-600 mr-3 mt-0.5" />
                <div>
                  <h4 className="font-medium text-yellow-800">Por favor, complete todos los campos requeridos</h4>
                  <ul className="mt-1 text-sm text-yellow-700 list-disc list-inside">
                    {validationMessages.map((message, index) => (
                      <li key={index}>{message}</li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          )}

          {/* Alerta de cambio de sustituto en curso */}
          {showEditWarning && (
            <div className="bg-orange-50 border border-orange-200 rounded-lg p-4 mb-4">
              <div className="flex items-start">
                <AlertTriangle className="h-5 w-5 text-orange-600 mr-3 mt-0.5" />
                <div>
                  <h4 className="font-medium text-orange-800">Confirmación requerida</h4>
                  <p className="mt-1 text-sm text-orange-700">{editWarningMessage}</p>
                  <div className="mt-3 flex space-x-2">
                    <Button size="sm" onClick={confirmSubstituteChange}>
                      Sí, continuar
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => setShowEditWarning(false)}>
                      Cancelar
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          )}

          <div className="space-y-6">
            {/* Información no editable */}
            <div className="bg-gray-50 p-4 rounded-lg">
              <h3 className="font-medium mb-2">Información de la Sustitución</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                <div>
                  <span className="text-gray-500">Curso:</span>
                  <p className="font-medium">{editingSubstitution?.course}</p>
                </div>
                <div>
                  <span className="text-gray-500">Materia:</span>
                  <p className="font-medium">{editingSubstitution?.subject}</p>
                </div>
                <div>
                  <span className="text-gray-500">Docente Original:</span>
                  <p className="font-medium">{editingSubstitution?.originalTeacher}</p>
                </div>
              </div>
            </div>

            {/* Campos editables */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="editStartDate">Fecha de Inicio</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className="w-full justify-start text-left font-normal bg-transparent"
                      disabled={editingSubstitution?.status === "active"}
                    >
                      <Calendar className="mr-2 h-4 w-4" />
                      {editFormData.startDate
                        ? format(editFormData.startDate, "PPP", { locale: es })
                        : "Seleccionar fecha"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <CalendarComponent
                      mode="single"
                      selected={editFormData.startDate}
                      onSelect={(date) => setEditFormData({ ...editFormData, startDate: date })}
                      initialFocus
                      locale={es}
                    />
                  </PopoverContent>
                </Popover>
                {editingSubstitution?.status === "active" && (
                  <p className="text-xs text-gray-500">
                    No se puede modificar la fecha de inicio de una sustitución en curso
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="editEndDate">Fecha de Fin</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="w-full justify-start text-left font-normal bg-transparent">
                      <Calendar className="mr-2 h-4 w-4" />
                      {editFormData.endDate ? format(editFormData.endDate, "PPP", { locale: es }) : "Seleccionar fecha"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <CalendarComponent
                      mode="single"
                      selected={editFormData.endDate}
                      onSelect={(date) => setEditFormData({ ...editFormData, endDate: date })}
                      disabled={(date) => date < new Date()}
                      initialFocus
                      locale={es}
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </div>

            {/* Tipo de sustitución */}
            <div className="space-y-4">
              <Label>Tipo de Sustitución</Label>
              <RadioGroup
                value={editFormData.substitutionType}
                onValueChange={(value) =>
                  setEditFormData({ ...editFormData, substitutionType: value as "internal" | "external" })
                }
                className="flex flex-col space-y-3"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="internal" id="editInternal" />
                  <Label htmlFor="editInternal" className="flex items-center">
                    <UserCheck className="mr-2 h-4 w-4" />
                    Docente Interno
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="external" id="editExternal" />
                  <Label htmlFor="editExternal" className="flex items-center">
                    <UserPlus className="mr-2 h-4 w-4" />
                    Docente Externo (Temporal)
                  </Label>
                </div>
              </RadioGroup>
            </div>

            {/* Selección de sustituto */}
            {editFormData.substitutionType === "internal" ? (
              <div className="space-y-2">
                <Label htmlFor="editSubstitute">Docente Sustituto</Label>
                <Select
                  value={editFormData.selectedSubstitute}
                  onValueChange={(value) => setEditFormData({ ...editFormData, selectedSubstitute: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecciona un docente" />
                  </SelectTrigger>
                  <SelectContent>
                    {internalTeachers.map((teacher) => (
                      <SelectItem key={teacher.id} value={teacher.name}>
                        {teacher.name} - {teacher.specialty}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            ) : (
              <div className="space-y-4 border border-gray-200 rounded-lg p-4">
                <h3 className="font-medium">Datos del Docente Externo</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="editFullName">Nombre Completo</Label>
                    <Input
                      id="editFullName"
                      value={editFormData.externalSubstituteData.fullName}
                      onChange={(e) =>
                        setEditFormData({
                          ...editFormData,
                          externalSubstituteData: { ...editFormData.externalSubstituteData, fullName: e.target.value },
                        })
                      }
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="editIdNumber">Cédula o ID</Label>
                    <Input
                      id="editIdNumber"
                      value={editFormData.externalSubstituteData.idNumber}
                      onChange={(e) =>
                        setEditFormData({
                          ...editFormData,
                          externalSubstituteData: { ...editFormData.externalSubstituteData, idNumber: e.target.value },
                        })
                      }
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="editPhone">Teléfono</Label>
                    <Input
                      id="editPhone"
                      value={editFormData.externalSubstituteData.phone}
                      onChange={(e) =>
                        setEditFormData({
                          ...editFormData,
                          externalSubstituteData: { ...editFormData.externalSubstituteData, phone: e.target.value },
                        })
                      }
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="editEmail">Correo Electrónico</Label>
                    <Input
                      id="editEmail"
                      type="email"
                      value={editFormData.externalSubstituteData.email}
                      onChange={(e) =>
                        setEditFormData({
                          ...editFormData,
                          externalSubstituteData: { ...editFormData.externalSubstituteData, email: e.target.value },
                        })
                      }
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="editSpecialty">Especialidad / Materia</Label>
                    <Input
                      id="editSpecialty"
                      value={editFormData.externalSubstituteData.specialty}
                      onChange={(e) =>
                        setEditFormData({
                          ...editFormData,
                          externalSubstituteData: { ...editFormData.externalSubstituteData, specialty: e.target.value },
                        })
                      }
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="editAvailability">Disponibilidad</Label>
                    <Select
                      value={editFormData.externalSubstituteData.availability}
                      onValueChange={(value) =>
                        setEditFormData({
                          ...editFormData,
                          externalSubstituteData: { ...editFormData.externalSubstituteData, availability: value },
                        })
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="morning">Mañana</SelectItem>
                        <SelectItem value="afternoon">Tarde</SelectItem>
                        <SelectItem value="evening">Noche</SelectItem>
                        <SelectItem value="extended">Tanda Extendida</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
            )}

            {/* Motivo y observaciones */}
            <div className="space-y-2">
              <Label htmlFor="editReason">Motivo de la Sustitución</Label>
              <Select
                value={editFormData.substitutionReason}
                onValueChange={(value) => setEditFormData({ ...editFormData, substitutionReason: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecciona un motivo" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="medical">Licencia médica</SelectItem>
                  <SelectItem value="vacation">Vacaciones</SelectItem>
                  <SelectItem value="training">Capacitación profesional</SelectItem>
                  <SelectItem value="personal">Permiso personal</SelectItem>
                  <SelectItem value="other">Otro</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="editObservations">Observaciones Adicionales</Label>
              <Textarea
                id="editObservations"
                placeholder="Añade cualquier información relevante sobre esta sustitución..."
                value={editFormData.observations}
                onChange={(e) => setEditFormData({ ...editFormData, observations: e.target.value })}
              />
            </div>

            {/* Información de interoperabilidad */}
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <div className="flex items-start">
                <AlertCircle className="h-5 w-5 text-blue-600 mr-3 mt-0.5" />
                <div>
                  <h4 className="font-medium text-blue-800">Cambios que se aplicarán automáticamente</h4>
                  <ul className="mt-1 text-sm text-blue-700 list-disc list-inside space-y-1">
                    <li>El horario del curso se actualizará con el nuevo sustituto</li>
                    <li>El panel del nuevo sustituto mostrará la materia asignada</li>
                    <li>Se actualizará quién puede registrar calificaciones y asistencia</li>
                    <li>Los estudiantes y padres verán reflejado el cambio</li>
                    <li>Se registrará el cambio en el historial del curso</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>

          <DialogFooter className="flex items-center justify-between">
            <Button variant="outline" onClick={handleCloseEditDialog}>
              Cancelar
            </Button>
            <Button onClick={handleSaveEditChanges}>💾 Guardar Cambios</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
