"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Progress } from "@/components/ui/progress"
import { Users, AlertTriangle, CheckCircle, TrendingUp } from "lucide-react"

interface Teacher {
  id: string
  name: string
  email: string
  specialties: string[]
  maxHours: number
  currentHours: number
  subjects: string[]
  status: "available" | "full" | "overloaded"
}

interface Subject {
  id: string
  name: string
  code: string
  area: string
  grade: string
  hours: number
  teacher?: string
  status: "assigned" | "unassigned" | "conflict"
}

interface Course {
  id: string
  name: string
  grade: string
  section: string
  subjects: Subject[]
  totalHours: number
  assignedHours: number
}

export default function TeacherAssignment() {
  const [teachers] = useState<Teacher[]>([
    {
      id: "1",
      name: "Prof. Carlos Mendoza",
      email: "carlos.mendoza@colegio.edu",
      specialties: ["Matemáticas", "Física"],
      maxHours: 25,
      currentHours: 20,
      subjects: ["MAT-101", "MAT-201"],
      status: "available",
    },
    {
      id: "2",
      name: "Prof. María García",
      email: "maria.garcia@colegio.edu",
      specialties: ["Lenguas", "Literatura"],
      maxHours: 22,
      currentHours: 22,
      subjects: ["LEN-101", "LIT-201"],
      status: "full",
    },
    {
      id: "3",
      name: "Prof. Ana Rodríguez",
      email: "ana.rodriguez@colegio.edu",
      specialties: ["Historia", "Sociales"],
      maxHours: 20,
      currentHours: 24,
      subjects: ["HIS-101", "SOC-201", "GEO-101"],
      status: "overloaded",
    },
    {
      id: "4",
      name: "Prof. Luis Fernández",
      email: "luis.fernandez@colegio.edu",
      specialties: ["Ciencias", "Biología"],
      maxHours: 25,
      currentHours: 15,
      subjects: ["BIO-101"],
      status: "available",
    },
  ])

  const [courses] = useState<Course[]>([
    {
      id: "1",
      name: "1ro Bachillerato A",
      grade: "1ro",
      section: "A",
      totalHours: 35,
      assignedHours: 28,
      subjects: [
        {
          id: "1",
          name: "Matemáticas I",
          code: "MAT-101",
          area: "Matemáticas",
          grade: "1ro",
          hours: 5,
          teacher: "Prof. Carlos Mendoza",
          status: "assigned",
        },
        {
          id: "2",
          name: "Lengua Española",
          code: "LEN-101",
          area: "Lenguas",
          grade: "1ro",
          hours: 4,
          teacher: "Prof. María García",
          status: "assigned",
        },
        {
          id: "3",
          name: "Historia Dominicana",
          code: "HIS-101",
          area: "Sociales",
          grade: "1ro",
          hours: 3,
          teacher: "Prof. Ana Rodríguez",
          status: "assigned",
        },
        {
          id: "4",
          name: "Biología General",
          code: "BIO-101",
          area: "Ciencias",
          grade: "1ro",
          hours: 4,
          status: "unassigned",
        },
        {
          id: "5",
          name: "Educación Física",
          code: "EDF-101",
          area: "Educación Física",
          grade: "1ro",
          hours: 2,
          status: "unassigned",
        },
      ],
    },
    {
      id: "2",
      name: "2do Bachillerato A",
      grade: "2do",
      section: "A",
      totalHours: 38,
      assignedHours: 25,
      subjects: [
        {
          id: "6",
          name: "Matemáticas II",
          code: "MAT-201",
          area: "Matemáticas",
          grade: "2do",
          hours: 5,
          teacher: "Prof. Carlos Mendoza",
          status: "assigned",
        },
        {
          id: "7",
          name: "Literatura Universal",
          code: "LIT-201",
          area: "Lenguas",
          grade: "2do",
          hours: 4,
          teacher: "Prof. María García",
          status: "assigned",
        },
        {
          id: "8",
          name: "Física Aplicada",
          code: "FIS-201",
          area: "Ciencias",
          grade: "2do",
          hours: 4,
          status: "unassigned",
        },
        {
          id: "9",
          name: "Química General",
          code: "QUI-201",
          area: "Ciencias",
          grade: "2do",
          hours: 4,
          status: "unassigned",
        },
      ],
    },
  ])

  const [selectedCourse, setSelectedCourse] = useState<string>("1")
  const [assignmentDialog, setAssignmentDialog] = useState<{
    open: boolean
    subject?: Subject
  }>({ open: false })

  const getTeacherStatusBadge = (status: string) => {
    switch (status) {
      case "available":
        return <Badge className="bg-green-100 text-green-800">Disponible</Badge>
      case "full":
        return <Badge className="bg-blue-100 text-blue-800">Completo</Badge>
      case "overloaded":
        return <Badge className="bg-red-100 text-red-800">Sobrecargado</Badge>
      default:
        return <Badge variant="outline">Desconocido</Badge>
    }
  }

  const getSubjectStatusBadge = (status: string) => {
    switch (status) {
      case "assigned":
        return <Badge className="bg-green-100 text-green-800">Asignada</Badge>
      case "unassigned":
        return <Badge className="bg-yellow-100 text-yellow-800">Sin Asignar</Badge>
      case "conflict":
        return <Badge className="bg-red-100 text-red-800">Conflicto</Badge>
      default:
        return <Badge variant="outline">Desconocido</Badge>
    }
  }

  const getWorkloadPercentage = (current: number, max: number) => {
    return Math.min((current / max) * 100, 100)
  }

  const getWorkloadColor = (percentage: number) => {
    if (percentage <= 80) return "bg-green-500"
    if (percentage <= 100) return "bg-yellow-500"
    return "bg-red-500"
  }

  const currentCourse = courses.find((c) => c.id === selectedCourse)
  const unassignedSubjects = currentCourse?.subjects.filter((s) => s.status === "unassigned") || []
  const assignedSubjects = currentCourse?.subjects.filter((s) => s.status === "assigned") || []

  const stats = {
    totalTeachers: teachers.length,
    availableTeachers: teachers.filter((t) => t.status === "available").length,
    overloadedTeachers: teachers.filter((t) => t.status === "overloaded").length,
    totalSubjects: courses.reduce((acc, course) => acc + course.subjects.length, 0),
    assignedSubjects: courses.reduce(
      (acc, course) => acc + course.subjects.filter((s) => s.status === "assigned").length,
      0,
    ),
    unassignedSubjects: courses.reduce(
      (acc, course) => acc + course.subjects.filter((s) => s.status === "unassigned").length,
      0,
    ),
  }

  return (
    <div className="flex-1 space-y-6 p-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Asignación Docente</h1>
          <p className="text-muted-foreground">Gestionar asignación de profesores a materias y cursos</p>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Docentes</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalTeachers}</div>
            <p className="text-xs text-muted-foreground">{stats.availableTeachers} disponibles</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Materias Asignadas</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{stats.assignedSubjects}</div>
            <p className="text-xs text-muted-foreground">de {stats.totalSubjects} total</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Sin Asignar</CardTitle>
            <AlertTriangle className="h-4 w-4 text-yellow-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">{stats.unassignedSubjects}</div>
            <p className="text-xs text-muted-foreground">Requieren asignación</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Sobrecargados</CardTitle>
            <TrendingUp className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{stats.overloadedTeachers}</div>
            <p className="text-xs text-muted-foreground">Docentes con exceso de horas</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="courses" className="space-y-4">
        <TabsList>
          <TabsTrigger value="courses">Por Cursos</TabsTrigger>
          <TabsTrigger value="teachers">Por Docentes</TabsTrigger>
          <TabsTrigger value="workload">Carga Horaria</TabsTrigger>
        </TabsList>

        <TabsContent value="courses" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Asignación por Cursos</CardTitle>
                  <CardDescription>Gestionar asignación de docentes por curso y materia</CardDescription>
                </div>
                <Select value={selectedCourse} onValueChange={setSelectedCourse}>
                  <SelectTrigger className="w-[200px]">
                    <SelectValue placeholder="Seleccionar curso" />
                  </SelectTrigger>
                  <SelectContent>
                    {courses.map((course) => (
                      <SelectItem key={course.id} value={course.id}>
                        {course.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent>
              {currentCourse && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
                    <div>
                      <h3 className="font-semibold">{currentCourse.name}</h3>
                      <p className="text-sm text-muted-foreground">
                        {currentCourse.assignedHours} de {currentCourse.totalHours} horas asignadas
                      </p>
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-bold">
                        {Math.round((currentCourse.assignedHours / currentCourse.totalHours) * 100)}%
                      </div>
                      <Progress
                        value={(currentCourse.assignedHours / currentCourse.totalHours) * 100}
                        className="w-24 mt-1"
                      />
                    </div>
                  </div>

                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Código</TableHead>
                        <TableHead>Materia</TableHead>
                        <TableHead>Área</TableHead>
                        <TableHead>Horas</TableHead>
                        <TableHead>Docente Asignado</TableHead>
                        <TableHead>Estado</TableHead>
                        <TableHead>Acciones</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {currentCourse.subjects.map((subject) => (
                        <TableRow key={subject.id}>
                          <TableCell className="font-mono text-sm">{subject.code}</TableCell>
                          <TableCell className="font-medium">{subject.name}</TableCell>
                          <TableCell>{subject.area}</TableCell>
                          <TableCell>{subject.hours}h</TableCell>
                          <TableCell>
                            {subject.teacher ? (
                              <span className="text-sm">{subject.teacher}</span>
                            ) : (
                              <Badge variant="outline">Sin asignar</Badge>
                            )}
                          </TableCell>
                          <TableCell>{getSubjectStatusBadge(subject.status)}</TableCell>
                          <TableCell>
                            <Dialog
                              open={assignmentDialog.open && assignmentDialog.subject?.id === subject.id}
                              onOpenChange={(open) =>
                                setAssignmentDialog({
                                  open,
                                  subject: open ? subject : undefined,
                                })
                              }
                            >
                              <DialogTrigger asChild>
                                <Button variant="outline" size="sm">
                                  {subject.teacher ? "Cambiar" : "Asignar"}
                                </Button>
                              </DialogTrigger>
                              <DialogContent>
                                <DialogHeader>
                                  <DialogTitle>Asignar Docente</DialogTitle>
                                  <DialogDescription>
                                    Seleccionar docente para {subject.name} ({subject.code})
                                  </DialogDescription>
                                </DialogHeader>
                                <div className="space-y-4">
                                  <div className="grid gap-4">
                                    {teachers
                                      .filter((teacher) =>
                                        teacher.specialties.some((specialty) => subject.area.includes(specialty)),
                                      )
                                      .map((teacher) => (
                                        <div
                                          key={teacher.id}
                                          className="flex items-center justify-between p-3 border rounded-lg hover:bg-muted/50"
                                        >
                                          <div className="flex-1">
                                            <div className="font-medium">{teacher.name}</div>
                                            <div className="text-sm text-muted-foreground">
                                              {teacher.specialties.join(", ")}
                                            </div>
                                            <div className="text-xs text-muted-foreground">
                                              {teacher.currentHours}/{teacher.maxHours} horas
                                            </div>
                                          </div>
                                          <div className="flex items-center space-x-2">
                                            {getTeacherStatusBadge(teacher.status)}
                                            <Button size="sm">Asignar</Button>
                                          </div>
                                        </div>
                                      ))}
                                  </div>
                                </div>
                              </DialogContent>
                            </Dialog>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="teachers" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Gestión de Docentes</CardTitle>
              <CardDescription>Vista general de todos los docentes y sus asignaciones</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Docente</TableHead>
                    <TableHead>Especialidades</TableHead>
                    <TableHead>Materias Asignadas</TableHead>
                    <TableHead>Carga Horaria</TableHead>
                    <TableHead>Estado</TableHead>
                    <TableHead>Acciones</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {teachers.map((teacher) => (
                    <TableRow key={teacher.id}>
                      <TableCell>
                        <div>
                          <div className="font-medium">{teacher.name}</div>
                          <div className="text-sm text-muted-foreground">{teacher.email}</div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-wrap gap-1">
                          {teacher.specialties.map((specialty) => (
                            <Badge key={specialty} variant="secondary" className="text-xs">
                              {specialty}
                            </Badge>
                          ))}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="text-sm">{teacher.subjects.length} materias</div>
                      </TableCell>
                      <TableCell>
                        <div className="space-y-1">
                          <div className="text-sm">
                            {teacher.currentHours}/{teacher.maxHours} horas
                          </div>
                          <Progress
                            value={getWorkloadPercentage(teacher.currentHours, teacher.maxHours)}
                            className="h-2"
                          />
                        </div>
                      </TableCell>
                      <TableCell>{getTeacherStatusBadge(teacher.status)}</TableCell>
                      <TableCell>
                        <Button variant="outline" size="sm">
                          Ver Detalles
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="workload" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Análisis de Carga Horaria</CardTitle>
              <CardDescription>Monitoreo de distribución de horas por docente</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {teachers.map((teacher) => {
                  const workloadPercentage = getWorkloadPercentage(teacher.currentHours, teacher.maxHours)
                  const colorClass = getWorkloadColor(workloadPercentage)

                  return (
                    <div key={teacher.id} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="font-medium">{teacher.name}</div>
                          <div className="text-sm text-muted-foreground">{teacher.specialties.join(", ")}</div>
                        </div>
                        <div className="text-right">
                          <div className="text-sm font-medium">
                            {teacher.currentHours}/{teacher.maxHours} horas
                          </div>
                          <div className="text-xs text-muted-foreground">
                            {Math.round(workloadPercentage)}% de capacidad
                          </div>
                        </div>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-3">
                        <div
                          className={`h-3 rounded-full transition-all duration-300 ${colorClass}`}
                          style={{ width: `${Math.min(workloadPercentage, 100)}%` }}
                        />
                      </div>
                      {workloadPercentage > 100 && (
                        <div className="flex items-center text-sm text-red-600">
                          <AlertTriangle className="h-4 w-4 mr-1" />
                          Sobrecarga de {teacher.currentHours - teacher.maxHours} horas
                        </div>
                      )}
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
