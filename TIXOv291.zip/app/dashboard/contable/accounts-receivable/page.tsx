"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import {
  AlertTriangle,
  DollarSign,
  Calendar,
  User,
  FileText,
  Search,
  Filter,
  Download,
  Plus,
  Clock,
  CheckCircle,
} from "lucide-react"

export default function AccountsReceivablePage() {
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState("")
  const [paymentAmount, setPaymentAmount] = useState("")

  // Datos de ejemplo
  const pendingInvoices = [
    {
      id: "F-2024-005",
      student: "Ana García Pérez",
      course: "5to A",
      parent: "Carlos García",
      amount: 350.0,
      dueDate: "2024-01-15",
      daysOverdue: 5,
      concept: "Mensualidad",
      phone: "+1234567890",
      email: "carlos.garcia@email.com",
    },
    {
      id: "F-2024-006",
      student: "Luis Martínez López",
      course: "3ro B",
      parent: "María Martínez",
      amount: 350.0,
      dueDate: "2024-01-20",
      daysOverdue: 0,
      concept: "Mensualidad",
      phone: "+1234567891",
      email: "maria.martinez@email.com",
    },
    {
      id: "F-2024-007",
      student: "Sofia Rodríguez",
      course: "2do A",
      parent: "Juan Rodríguez",
      amount: 120.0,
      dueDate: "2024-01-10",
      daysOverdue: 10,
      concept: "Materiales",
      phone: "+1234567892",
      email: "juan.rodriguez@email.com",
    },
    {
      id: "F-2024-008",
      student: "Diego Torres",
      course: "4to C",
      parent: "Carmen Torres",
      amount: 350.0,
      dueDate: "2024-01-25",
      daysOverdue: 0,
      concept: "Mensualidad",
      phone: "+1234567893",
      email: "carmen.torres@email.com",
    },
  ]

  const paymentPlans = [
    {
      id: "PP-001",
      student: "Pedro Sánchez",
      totalDebt: 1050.0,
      monthlyPayment: 175.0,
      installments: 6,
      paidInstallments: 2,
      nextPayment: "2024-02-01",
      status: "Activo",
    },
    {
      id: "PP-002",
      student: "Laura Jiménez",
      totalDebt: 700.0,
      monthlyPayment: 140.0,
      installments: 5,
      paidInstallments: 3,
      nextPayment: "2024-02-05",
      status: "Activo",
    },
  ]

  const getOverdueBadge = (daysOverdue: number) => {
    if (daysOverdue === 0) {
      return <Badge className="bg-[#d1fae5] text-[#10b981] border-[#10b981]/20">Al día</Badge>
    } else if (daysOverdue <= 7) {
      return <Badge className="bg-[#fef3c7] text-[#f59e0b] border-[#f59e0b]/20">{daysOverdue} días</Badge>
    } else {
      return <Badge className="bg-[#fee2e2] text-[#ef4444] border-[#ef4444]/20">{daysOverdue} días</Badge>
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "Activo":
        return <Badge className="bg-[#d1fae5] text-[#10b981] border-[#10b981]/20">Activo</Badge>
      case "Completado":
        return <Badge className="bg-[#dbeafe] text-[#3b82f6] border-[#3b82f6]/20">Completado</Badge>
      case "Suspendido":
        return <Badge className="bg-[#fee2e2] text-[#ef4444] border-[#ef4444]/20">Suspendido</Badge>
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  return (
    <div className="flex-1 space-y-6 p-8 bg-[#f0f4f8]">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight text-[#1f2937]">Cuentas por Cobrar</h2>
          <p className="text-[#6b7280]">Supervisar facturas pendientes y gestionar pagos</p>
        </div>
        <div className="flex items-center space-x-3">
          <Button variant="outline" size="sm" className="border-[#6b7280] text-[#6b7280]">
            <Download className="mr-2 h-4 w-4" />
            Exportar
          </Button>
          <Dialog>
            <DialogTrigger asChild>
              <Button size="sm" className="bg-[#4338ca] hover:bg-[#3730a3] text-white">
                <Plus className="mr-2 h-4 w-4" />
                Registrar Pago
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md bg-white">
              <DialogHeader>
                <DialogTitle className="text-[#1f2937]">Registrar Pago</DialogTitle>
                <DialogDescription className="text-[#6b7280]">Registre un pago recibido manualmente</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="invoice" className="text-[#1f2937]">
                    Factura
                  </Label>
                  <Select>
                    <SelectTrigger className="bg-white border-[#e5e7eb]">
                      <SelectValue placeholder="Seleccionar factura" />
                    </SelectTrigger>
                    <SelectContent className="bg-white">
                      {pendingInvoices.map((invoice) => (
                        <SelectItem key={invoice.id} value={invoice.id}>
                          {invoice.id} - {invoice.student} - ${invoice.amount}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="amount" className="text-[#1f2937]">
                    Monto Pagado
                  </Label>
                  <Input
                    id="amount"
                    type="number"
                    placeholder="0.00"
                    value={paymentAmount}
                    onChange={(e) => setPaymentAmount(e.target.value)}
                    className="bg-white border-[#e5e7eb]"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="method" className="text-[#1f2937]">
                    Método de Pago
                  </Label>
                  <Select value={selectedPaymentMethod} onValueChange={setSelectedPaymentMethod}>
                    <SelectTrigger className="bg-white border-[#e5e7eb]">
                      <SelectValue placeholder="Seleccionar método" />
                    </SelectTrigger>
                    <SelectContent className="bg-white">
                      <SelectItem value="cash">Efectivo</SelectItem>
                      <SelectItem value="transfer">Transferencia</SelectItem>
                      <SelectItem value="electronic">Pago electrónico</SelectItem>
                      <SelectItem value="check">Cheque</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="date" className="text-[#1f2937]">
                    Fecha de Pago
                  </Label>
                  <Input id="date" type="date" className="bg-white border-[#e5e7eb]" />
                </div>
              </div>
              <div className="flex justify-end space-x-2">
                <Button variant="outline">Cancelar</Button>
                <Button className="bg-[#4338ca] hover:bg-[#3730a3] text-white">
                  <CheckCircle className="mr-2 h-4 w-4" />
                  Registrar Pago
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card className="bg-white border-0 shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-[#6b7280]">Total por Cobrar</CardTitle>
            <DollarSign className="h-4 w-4 text-[#4338ca]" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-[#1f2937]">$12,386.39</div>
            <p className="text-xs text-[#6b7280]">45 facturas pendientes</p>
          </CardContent>
        </Card>

        <Card className="bg-white border-0 shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-[#6b7280]">Facturas Vencidas</CardTitle>
            <AlertTriangle className="h-4 w-4 text-[#ef4444]" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-[#1f2937]">$4,141.27</div>
            <p className="text-xs text-[#ef4444]">12 facturas vencidas</p>
          </CardContent>
        </Card>

        <Card className="bg-white border-0 shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-[#6b7280]">Por Vencer (7 días)</CardTitle>
            <Clock className="h-4 w-4 text-[#f59e0b]" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-[#1f2937]">$2,450.00</div>
            <p className="text-xs text-[#f59e0b]">8 facturas próximas</p>
          </CardContent>
        </Card>

        <Card className="bg-white border-0 shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-[#6b7280]">Planes de Pago</CardTitle>
            <Calendar className="h-4 w-4 text-[#3b82f6]" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-[#1f2937]">8</div>
            <p className="text-xs text-[#3b82f6]">Planes activos</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="pending" className="space-y-4">
        <TabsList className="bg-white border border-[#e5e7eb]">
          <TabsTrigger value="pending" className="data-[state=active]:bg-[#4338ca] data-[state=active]:text-white">
            Facturas Pendientes
          </TabsTrigger>
          <TabsTrigger
            value="payment-plans"
            className="data-[state=active]:bg-[#4338ca] data-[state=active]:text-white"
          >
            Planes de Pago
          </TabsTrigger>
          <TabsTrigger value="alerts" className="data-[state=active]:bg-[#4338ca] data-[state=active]:text-white">
            Alertas
          </TabsTrigger>
        </TabsList>

        <TabsContent value="pending" className="space-y-4">
          <Card className="bg-white border-0 shadow-sm">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-[#1f2937]">Facturas Pendientes</CardTitle>
                  <CardDescription className="text-[#6b7280]">Lista completa de facturas por cobrar</CardDescription>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="relative">
                    <Search className="absolute left-2 top-2.5 h-4 w-4 text-[#9ca3af]" />
                    <Input placeholder="Buscar estudiante..." className="pl-8 bg-white border-[#e5e7eb]" />
                  </div>
                  <Button variant="outline" size="sm" className="border-[#6b7280] text-[#6b7280]">
                    <Filter className="mr-2 h-4 w-4" />
                    Filtros
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow className="border-[#e5e7eb]">
                    <TableHead className="text-[#6b7280]">Factura</TableHead>
                    <TableHead className="text-[#6b7280]">Estudiante</TableHead>
                    <TableHead className="text-[#6b7280]">Curso</TableHead>
                    <TableHead className="text-[#6b7280]">Padre/Tutor</TableHead>
                    <TableHead className="text-[#6b7280]">Monto</TableHead>
                    <TableHead className="text-[#6b7280]">Vencimiento</TableHead>
                    <TableHead className="text-[#6b7280]">Estado</TableHead>
                    <TableHead className="text-[#6b7280]">Acciones</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {pendingInvoices.map((invoice) => (
                    <TableRow key={invoice.id} className="border-[#e5e7eb]">
                      <TableCell className="text-[#1f2937] font-medium">{invoice.id}</TableCell>
                      <TableCell className="text-[#1f2937]">{invoice.student}</TableCell>
                      <TableCell className="text-[#6b7280]">{invoice.course}</TableCell>
                      <TableCell className="text-[#6b7280]">{invoice.parent}</TableCell>
                      <TableCell className="text-[#1f2937]">${invoice.amount.toFixed(2)}</TableCell>
                      <TableCell className="text-[#6b7280]">{invoice.dueDate}</TableCell>
                      <TableCell>{getOverdueBadge(invoice.daysOverdue)}</TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-2">
                          <Button variant="ghost" size="sm" className="text-[#6b7280] hover:text-[#4338ca]">
                            <User className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm" className="text-[#6b7280] hover:text-[#4338ca]">
                            <DollarSign className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm" className="text-[#6b7280] hover:text-[#4338ca]">
                            <FileText className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="payment-plans" className="space-y-4">
          <Card className="bg-white border-0 shadow-sm">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-[#1f2937]">Planes de Pago</CardTitle>
                  <CardDescription className="text-[#6b7280]">
                    Gestión de planes de pago para familias con deudas
                  </CardDescription>
                </div>
                <Button size="sm" className="bg-[#4338ca] hover:bg-[#3730a3] text-white">
                  <Plus className="mr-2 h-4 w-4" />
                  Nuevo Plan
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {paymentPlans.map((plan) => (
                  <Card key={plan.id} className="bg-[#f0f4f8] border border-[#e5e7eb]">
                    <CardContent className="pt-6">
                      <div className="flex items-center justify-between mb-4">
                        <div>
                          <h4 className="text-[#1f2937] font-medium">{plan.student}</h4>
                          <p className="text-sm text-[#6b7280]">Plan ID: {plan.id}</p>
                        </div>
                        {getStatusBadge(plan.status)}
                      </div>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                        <div>
                          <p className="text-[#6b7280]">Deuda Total</p>
                          <p className="text-[#1f2937] font-medium">${plan.totalDebt.toFixed(2)}</p>
                        </div>
                        <div>
                          <p className="text-[#6b7280]">Cuota Mensual</p>
                          <p className="text-[#1f2937] font-medium">${plan.monthlyPayment.toFixed(2)}</p>
                        </div>
                        <div>
                          <p className="text-[#6b7280]">Progreso</p>
                          <p className="text-[#1f2937] font-medium">
                            {plan.paidInstallments}/{plan.installments} cuotas
                          </p>
                        </div>
                        <div>
                          <p className="text-[#6b7280]">Próximo Pago</p>
                          <p className="text-[#1f2937] font-medium">{plan.nextPayment}</p>
                        </div>
                      </div>
                      <div className="mt-4">
                        <div className="w-full bg-[#e5e7eb] rounded-full h-2">
                          <div
                            className="bg-[#4338ca] h-2 rounded-full"
                            style={{ width: `${(plan.paidInstallments / plan.installments) * 100}%` }}
                          ></div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="alerts" className="space-y-4">
          <div className="grid gap-4">
            <Alert className="bg-[#fee2e2] border-[#ef4444]/20">
              <AlertTriangle className="h-4 w-4 text-[#ef4444]" />
              <AlertTitle className="text-[#ef4444]">Facturas Críticas</AlertTitle>
              <AlertDescription className="text-[#1f2937]">
                5 facturas vencidas hace más de 30 días. Total adeudado: $1,750.00
                <Button variant="link" className="p-0 h-auto text-[#ef4444] ml-2">
                  Ver detalles
                </Button>
              </AlertDescription>
            </Alert>

            <Alert className="bg-[#fef3c7] border-[#f59e0b]/20">
              <Clock className="h-4 w-4 text-[#f59e0b]" />
              <AlertTitle className="text-[#f59e0b]">Próximos Vencimientos</AlertTitle>
              <AlertDescription className="text-[#1f2937]">
                8 facturas vencen en los próximos 3 días. Total: $2,800.00
                <Button variant="link" className="p-0 h-auto text-[#f59e0b] ml-2">
                  Enviar recordatorios
                </Button>
              </AlertDescription>
            </Alert>

            <Alert className="bg-[#dbeafe] border-[#3b82f6]/20">
              <User className="h-4 w-4 text-[#3b82f6]" />
              <AlertTitle className="text-[#3b82f6]">Padres Sin Contacto</AlertTitle>
              <AlertDescription className="text-[#1f2937]">
                3 familias no tienen información de contacto actualizada
                <Button variant="link" className="p-0 h-auto text-[#3b82f6] ml-2">
                  Actualizar contactos
                </Button>
              </AlertDescription>
            </Alert>

            <Alert className="bg-[#d1fae5] border-[#10b981]/20">
              <CheckCircle className="h-4 w-4 text-[#10b981]" />
              <AlertTitle className="text-[#10b981]">Pagos Recientes</AlertTitle>
              <AlertDescription className="text-[#1f2937]">
                12 pagos recibidos hoy por un total de $4,200.00
                <Button variant="link" className="p-0 h-auto text-[#10b981] ml-2">
                  Ver detalles
                </Button>
              </AlertDescription>
            </Alert>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
