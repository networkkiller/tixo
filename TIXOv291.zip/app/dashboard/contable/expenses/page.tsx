"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Textarea } from "@/components/ui/textarea"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import {
  Plus,
  FileText,
  Download,
  Filter,
  Search,
  Eye,
  Edit,
  Upload,
  AlertTriangle,
  TrendingUp,
  PieChart,
  BarChart3,
  DollarSign,
  Users,
  Calendar,
  CheckCircle,
} from "lucide-react"

export default function ExpensesPage() {
  const [category, setCategory] = useState("")
  const [amount, setAmount] = useState("")
  const [provider, setProvider] = useState("")
  const [description, setDescription] = useState("")
  const [expenseDate, setExpenseDate] = useState("")
  const [file, setFile] = useState<File | null>(null)

  // Datos de ejemplo
  const expenses = [
    {
      id: "EG-2024-001",
      date: "2024-01-15",
      category: "Nómina",
      provider: "Recursos Humanos",
      amount: 15000.0,
      description: "Pago de sueldos enero 2024",
      status: "Conciliado",
      hasReceipt: true,
    },
    {
      id: "EG-2024-002",
      date: "2024-01-10",
      category: "Servicios",
      provider: "Empresa Eléctrica",
      amount: 450.0,
      description: "Factura de electricidad",
      status: "Validado",
      hasReceipt: true,
    },
    {
      id: "EG-2024-003",
      date: "2024-01-08",
      category: "Mantenimiento",
      provider: "Ferretería Central",
      amount: 280.0,
      description: "Materiales para reparación de aulas",
      status: "Pendiente",
      hasReceipt: false,
    },
    {
      id: "EG-2024-004",
      date: "2024-01-05",
      category: "Otros",
      provider: "Papelería Escolar",
      amount: 120.0,
      description: "Suministros de oficina",
      status: "Validado",
      hasReceipt: true,
    },
  ]

  const categoryStats = [
    { name: "Nómina", amount: 15000, percentage: 65, color: "bg-[#4338ca]" },
    { name: "Servicios", amount: 3200, percentage: 14, color: "bg-[#10b981]" },
    { name: "Mantenimiento", amount: 2800, percentage: 12, color: "bg-[#f59e0b]" },
    { name: "Otros", amount: 2100, percentage: 9, color: "bg-[#8b5cf6]" },
  ]

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "Conciliado":
        return <Badge className="bg-[#d1fae5] text-[#10b981] border-[#10b981]/20">Conciliado</Badge>
      case "Validado":
        return <Badge className="bg-[#dbeafe] text-[#3b82f6] border-[#3b82f6]/20">Validado</Badge>
      case "Pendiente":
        return <Badge className="bg-[#fef3c7] text-[#f59e0b] border-[#f59e0b]/20">Pendiente</Badge>
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0])
    }
  }

  return (
    <div className="flex-1 space-y-6 p-8 bg-[#f0f4f8]">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight text-[#1f2937]">Egresos y Gastos</h2>
          <p className="text-[#6b7280]">Gestión y control de gastos operativos del colegio</p>
        </div>
        <div className="flex items-center space-x-3">
          <Button variant="outline" size="sm" className="border-[#6b7280] text-[#6b7280]">
            <Download className="mr-2 h-4 w-4" />
            Exportar
          </Button>
          <Dialog>
            <DialogTrigger asChild>
              <Button size="sm" className="bg-[#4338ca] hover:bg-[#3730a3] text-white">
                <Plus className="mr-2 h-4 w-4" />
                Registrar Egreso
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl bg-white">
              <DialogHeader>
                <DialogTitle className="text-[#1f2937]">Registrar Nuevo Egreso</DialogTitle>
                <DialogDescription className="text-[#6b7280]">
                  Complete los datos del gasto realizado por el colegio
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="category" className="text-[#1f2937]">
                      Categoría del Egreso *
                    </Label>
                    <Select value={category} onValueChange={setCategory}>
                      <SelectTrigger className="bg-white border-[#e5e7eb]">
                        <SelectValue placeholder="Seleccionar categoría" />
                      </SelectTrigger>
                      <SelectContent className="bg-white">
                        <SelectItem value="nomina">Nómina</SelectItem>
                        <SelectItem value="mantenimiento">Mantenimiento</SelectItem>
                        <SelectItem value="servicios">Servicios</SelectItem>
                        <SelectItem value="otros">Otros</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="amount" className="text-[#1f2937]">
                      Monto Total *
                    </Label>
                    <Input
                      id="amount"
                      type="number"
                      placeholder="0.00"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      className="bg-white border-[#e5e7eb]"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="provider" className="text-[#1f2937]">
                      Proveedor/Beneficiario
                    </Label>
                    <Input
                      id="provider"
                      placeholder="Nombre del proveedor"
                      value={provider}
                      onChange={(e) => setProvider(e.target.value)}
                      className="bg-white border-[#e5e7eb]"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="expenseDate" className="text-[#1f2937]">
                      Fecha del Egreso *
                    </Label>
                    <Input
                      id="expenseDate"
                      type="date"
                      value={expenseDate}
                      onChange={(e) => setExpenseDate(e.target.value)}
                      className="bg-white border-[#e5e7eb]"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="description" className="text-[#1f2937]">
                    Descripción del Gasto
                  </Label>
                  <Textarea
                    id="description"
                    placeholder="Detalle el motivo y naturaleza del gasto..."
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    className="bg-white border-[#e5e7eb]"
                    rows={3}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="receipt" className="text-[#1f2937]">
                    Comprobante del Gasto
                  </Label>
                  <div className="flex items-center space-x-2">
                    <Input
                      id="receipt"
                      type="file"
                      accept=".pdf,.jpg,.jpeg,.png"
                      onChange={handleFileChange}
                      className="bg-white border-[#e5e7eb]"
                    />
                    <Button type="button" variant="outline" size="sm">
                      <Upload className="h-4 w-4" />
                    </Button>
                  </div>
                  <p className="text-xs text-[#6b7280]">Formatos: PDF, JPG, PNG. Tamaño máximo: 5MB</p>
                </div>
              </div>
              <div className="flex justify-end space-x-2">
                <Button variant="outline">Cancelar</Button>
                <Button className="bg-[#4338ca] hover:bg-[#3730a3] text-white">
                  <FileText className="mr-2 h-4 w-4" />
                  Registrar Egreso
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Tabs defaultValue="history" className="space-y-4">
        <TabsList className="bg-white border border-[#e5e7eb]">
          <TabsTrigger value="history" className="data-[state=active]:bg-[#4338ca] data-[state=active]:text-white">
            Historial de Egresos
          </TabsTrigger>
          <TabsTrigger value="reports" className="data-[state=active]:bg-[#4338ca] data-[state=active]:text-white">
            Reportes y Gráficas
          </TabsTrigger>
          <TabsTrigger
            value="reconciliation"
            className="data-[state=active]:bg-[#4338ca] data-[state=active]:text-white"
          >
            Conciliación y Alertas
          </TabsTrigger>
        </TabsList>

        <TabsContent value="history" className="space-y-4">
          <Card className="bg-white border-0 shadow-sm">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-[#1f2937]">Historial de Egresos</CardTitle>
                  <CardDescription className="text-[#6b7280]">
                    Visualización completa de todos los gastos registrados
                  </CardDescription>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="relative">
                    <Search className="absolute left-2 top-2.5 h-4 w-4 text-[#9ca3af]" />
                    <Input placeholder="Buscar egresos..." className="pl-8 bg-white border-[#e5e7eb]" />
                  </div>
                  <Button variant="outline" size="sm" className="border-[#6b7280] text-[#6b7280]">
                    <Filter className="mr-2 h-4 w-4" />
                    Filtros
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow className="border-[#e5e7eb]">
                    <TableHead className="text-[#6b7280]">ID</TableHead>
                    <TableHead className="text-[#6b7280]">Fecha</TableHead>
                    <TableHead className="text-[#6b7280]">Categoría</TableHead>
                    <TableHead className="text-[#6b7280]">Proveedor</TableHead>
                    <TableHead className="text-[#6b7280]">Monto</TableHead>
                    <TableHead className="text-[#6b7280]">Estado</TableHead>
                    <TableHead className="text-[#6b7280]">Comprobante</TableHead>
                    <TableHead className="text-[#6b7280]">Acciones</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {expenses.map((expense) => (
                    <TableRow key={expense.id} className="border-[#e5e7eb]">
                      <TableCell className="text-[#1f2937] font-medium">{expense.id}</TableCell>
                      <TableCell className="text-[#6b7280]">{expense.date}</TableCell>
                      <TableCell className="text-[#6b7280]">{expense.category}</TableCell>
                      <TableCell className="text-[#6b7280]">{expense.provider}</TableCell>
                      <TableCell className="text-[#1f2937] font-medium">${expense.amount.toFixed(2)}</TableCell>
                      <TableCell>{getStatusBadge(expense.status)}</TableCell>
                      <TableCell>
                        {expense.hasReceipt ? (
                          <Button variant="ghost" size="sm" className="text-[#4338ca] hover:text-[#3730a3]">
                            <Eye className="h-4 w-4" />
                          </Button>
                        ) : (
                          <span className="text-[#9ca3af] text-sm">Sin archivo</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-2">
                          <Button variant="ghost" size="sm" className="text-[#6b7280] hover:text-[#4338ca]">
                            <Eye className="h-4 w-4" />
                          </Button>
                          {expense.status === "Pendiente" && (
                            <Button variant="ghost" size="sm" className="text-[#6b7280] hover:text-[#4338ca]">
                              <Edit className="h-4 w-4" />
                            </Button>
                          )}
                          {expense.status !== "Conciliado" && (
                            <Button variant="ghost" size="sm" className="text-[#10b981] hover:text-[#059669]">
                              <CheckCircle className="h-4 w-4" />
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="reports" className="space-y-4">
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            <Card className="bg-white border-0 shadow-sm">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-[#6b7280]">Gasto Total Mes</CardTitle>
                <DollarSign className="h-4 w-4 text-[#ef4444]" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-[#1f2937]">$23,100.00</div>
                <p className="text-xs text-[#ef4444]">+8.2% vs mes anterior</p>
              </CardContent>
            </Card>

            <Card className="bg-white border-0 shadow-sm">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-[#6b7280]">Categoría Principal</CardTitle>
                <TrendingUp className="h-4 w-4 text-[#4338ca]" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-[#1f2937]">Nómina</div>
                <p className="text-xs text-[#6b7280]">65% del total</p>
              </CardContent>
            </Card>

            <Card className="bg-white border-0 shadow-sm">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-[#6b7280]">Proveedor Frecuente</CardTitle>
                <Users className="h-4 w-4 text-[#10b981]" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-[#1f2937]">Empresa Eléctrica</div>
                <p className="text-xs text-[#6b7280]">12 transacciones</p>
              </CardContent>
            </Card>

            <Card className="bg-white border-0 shadow-sm">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-[#6b7280]">Egresos Pendientes</CardTitle>
                <Calendar className="h-4 w-4 text-[#f59e0b]" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-[#1f2937]">3</div>
                <p className="text-xs text-[#f59e0b]">Requieren validación</p>
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-6 md:grid-cols-2">
            <Card className="bg-white border-0 shadow-sm">
              <CardHeader>
                <CardTitle className="text-[#1f2937]">Gastos por Categoría</CardTitle>
                <CardDescription className="text-[#6b7280]">Distribución mensual de egresos</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {categoryStats.map((category, index) => (
                    <div key={index} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium text-[#1f2937]">{category.name}</span>
                        <span className="text-sm text-[#6b7280]">${category.amount.toLocaleString()}</span>
                      </div>
                      <div className="w-full bg-[#f0f4f8] rounded-full h-2">
                        <div
                          className={`${category.color} h-2 rounded-full transition-all duration-300`}
                          style={{ width: `${category.percentage}%` }}
                        ></div>
                      </div>
                      <div className="text-xs text-[#6b7280]">{category.percentage}% del total</div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white border-0 shadow-sm">
              <CardHeader>
                <CardTitle className="text-[#1f2937]">Tendencia Mensual</CardTitle>
                <CardDescription className="text-[#6b7280]">Comparativa de gastos por mes</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px] flex items-center justify-center text-[#9ca3af] border border-dashed border-[#e5e7eb] rounded-lg">
                  <div className="text-center">
                    <BarChart3 className="h-12 w-12 mx-auto mb-2" />
                    <p>Gráfico de barras</p>
                    <p className="text-sm mt-1">Gastos mensuales por categoría</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="reconciliation" className="space-y-4">
          <div className="grid gap-6 md:grid-cols-2">
            <Card className="bg-white border-0 shadow-sm">
              <CardHeader>
                <CardTitle className="text-[#1f2937]">Balance Financiero</CardTitle>
                <CardDescription className="text-[#6b7280]">Conciliación ingresos vs egresos</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-[#d1fae5] rounded-lg">
                  <div>
                    <p className="text-sm text-[#6b7280]">Total Ingresos</p>
                    <p className="text-2xl font-bold text-[#10b981]">$45,231.89</p>
                  </div>
                  <TrendingUp className="h-8 w-8 text-[#10b981]" />
                </div>
                <div className="flex items-center justify-between p-4 bg-[#fee2e2] rounded-lg">
                  <div>
                    <p className="text-sm text-[#6b7280]">Total Egresos</p>
                    <p className="text-2xl font-bold text-[#ef4444]">$23,100.00</p>
                  </div>
                  <DollarSign className="h-8 w-8 text-[#ef4444]" />
                </div>
                <div className="flex items-center justify-between p-4 bg-[#dbeafe] rounded-lg">
                  <div>
                    <p className="text-sm text-[#6b7280]">Balance Actual</p>
                    <p className="text-2xl font-bold text-[#3b82f6]">$22,131.89</p>
                  </div>
                  <PieChart className="h-8 w-8 text-[#3b82f6]" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white border-0 shadow-sm">
              <CardHeader>
                <CardTitle className="text-[#1f2937]">Alertas de Control</CardTitle>
                <CardDescription className="text-[#6b7280]">Situaciones que requieren atención</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <Alert className="bg-[#fef3c7] border-[#f59e0b]/20">
                  <AlertTriangle className="h-4 w-4 text-[#f59e0b]" />
                  <AlertTitle className="text-[#f59e0b]">Sobregiro por Categoría</AlertTitle>
                  <AlertDescription className="text-[#1f2937]">
                    Mantenimiento superó el presupuesto mensual en 15%
                  </AlertDescription>
                </Alert>

                <Alert className="bg-[#dbeafe] border-[#3b82f6]/20">
                  <AlertTriangle className="h-4 w-4 text-[#3b82f6]" />
                  <AlertTitle className="text-[#3b82f6]">Gasto Duplicado Detectado</AlertTitle>
                  <AlertDescription className="text-[#1f2937]">
                    Posible duplicación: Empresa Eléctrica - $450.00
                  </AlertDescription>
                </Alert>

                <Alert className="bg-[#d1fae5] border-[#10b981]/20">
                  <AlertTriangle className="h-4 w-4 text-[#10b981]" />
                  <AlertTitle className="text-[#10b981]">Balance Saludable</AlertTitle>
                  <AlertDescription className="text-[#1f2937]">
                    Los ingresos cubren adecuadamente los gastos operativos
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
