"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Users,
  Plus,
  Search,
  Filter,
  Download,
  DollarSign,
  Calendar,
  CheckCircle,
  Clock,
  AlertCircle,
  FileText,
  Send,
  Edit,
  Trash2,
  Eye,
} from "lucide-react"

export default function PayrollPage() {
  const [selectedPeriod, setSelectedPeriod] = useState("2024-01")
  const [searchTerm, setSearchTerm] = useState("")
  const [filterStatus, setFilterStatus] = useState("all")
  const [showAddEmployee, setShowAddEmployee] = useState(false)
  const [showPayrollGeneration, setShowPayrollGeneration] = useState(false)

  // Datos simulados de empleados
  const employees = [
    {
      id: 1,
      name: "María González",
      position: "Directora",
      department: "Dirección",
      contractType: "Fijo",
      baseSalary: 45000,
      startDate: "2020-03-15",
      bankAccount: "****-1234",
      status: "Activo",
    },
    {
      id: 2,
      name: "Carlos Rodríguez",
      position: "Profesor de Matemáticas",
      department: "Académico",
      contractType: "Fijo",
      baseSalary: 28000,
      startDate: "2021-08-01",
      bankAccount: "****-5678",
      status: "Activo",
    },
    {
      id: 3,
      name: "Ana Martínez",
      position: "Secretaria",
      department: "Administración",
      contractType: "Fijo",
      baseSalary: 22000,
      startDate: "2019-01-10",
      bankAccount: "****-9012",
      status: "Activo",
    },
    {
      id: 4,
      name: "Luis Fernández",
      position: "Conserje",
      department: "Mantenimiento",
      contractType: "Temporal",
      baseSalary: 18000,
      startDate: "2023-09-01",
      bankAccount: "****-3456",
      status: "Activo",
    },
  ]

  // Datos simulados de nómina
  const payrollData = [
    {
      employeeId: 1,
      name: "María González",
      baseSalary: 45000,
      bonuses: 5000,
      overtime: 0,
      deductions: 8500,
      netSalary: 41500,
      status: "Pagado",
      paymentDate: "2024-01-31",
    },
    {
      employeeId: 2,
      name: "Carlos Rodríguez",
      baseSalary: 28000,
      bonuses: 2000,
      overtime: 1500,
      deductions: 5600,
      netSalary: 25900,
      status: "Pendiente",
      paymentDate: null,
    },
    {
      employeeId: 3,
      name: "Ana Martínez",
      baseSalary: 22000,
      bonuses: 1000,
      overtime: 800,
      deductions: 4200,
      netSalary: 19600,
      status: "Procesado",
      paymentDate: null,
    },
    {
      employeeId: 4,
      name: "Luis Fernández",
      baseSalary: 18000,
      bonuses: 500,
      overtime: 600,
      deductions: 3400,
      netSalary: 15700,
      status: "Pendiente",
      paymentDate: null,
    },
  ]

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "Pagado":
        return (
          <Badge className="bg-green-100 text-green-800 border-green-200">
            <CheckCircle className="w-3 h-3 mr-1" />
            Pagado
          </Badge>
        )
      case "Procesado":
        return (
          <Badge className="bg-blue-100 text-blue-800 border-blue-200">
            <Clock className="w-3 h-3 mr-1" />
            Procesado
          </Badge>
        )
      case "Pendiente":
        return (
          <Badge className="bg-yellow-100 text-yellow-800 border-yellow-200">
            <AlertCircle className="w-3 h-3 mr-1" />
            Pendiente
          </Badge>
        )
      default:
        return <Badge variant="secondary">{status}</Badge>
    }
  }

  const totalEmployees = employees.length
  const totalPaidThisMonth = payrollData.filter((p) => p.status === "Pagado").reduce((sum, p) => sum + p.netSalary, 0)
  const totalPayroll = payrollData.reduce((sum, p) => sum + p.netSalary, 0)
  const budgetUsed = ((totalPayroll / 150000) * 100).toFixed(1)

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Gestión de Nómina</h1>
            <p className="text-gray-600 mt-1">Administra pagos del personal docente y administrativo</p>
          </div>
          <div className="flex gap-3">
            <Dialog open={showAddEmployee} onOpenChange={setShowAddEmployee}>
              <DialogTrigger asChild>
                <Button className="bg-indigo-600 hover:bg-indigo-700">
                  <Plus className="w-4 h-4 mr-2" />
                  Agregar Empleado
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Agregar Nuevo Empleado</DialogTitle>
                  <DialogDescription>Completa la información del nuevo empleado</DialogDescription>
                </DialogHeader>
                <div className="grid grid-cols-2 gap-4 py-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Nombre Completo</Label>
                    <Input id="name" placeholder="Nombre del empleado" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="position">Cargo</Label>
                    <Input id="position" placeholder="Posición o cargo" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="department">Departamento</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Seleccionar departamento" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="direccion">Dirección</SelectItem>
                        <SelectItem value="academico">Académico</SelectItem>
                        <SelectItem value="administracion">Administración</SelectItem>
                        <SelectItem value="mantenimiento">Mantenimiento</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="contract">Tipo de Contrato</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Tipo de contrato" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="fijo">Fijo</SelectItem>
                        <SelectItem value="temporal">Temporal</SelectItem>
                        <SelectItem value="honorario">Honorario</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="salary">Salario Base</Label>
                    <Input id="salary" type="number" placeholder="Salario mensual" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="startDate">Fecha de Ingreso</Label>
                    <Input id="startDate" type="date" />
                  </div>
                  <div className="space-y-2 col-span-2">
                    <Label htmlFor="bankAccount">Cuenta Bancaria (Opcional)</Label>
                    <Input id="bankAccount" placeholder="Número de cuenta" />
                  </div>
                </div>
                <div className="flex justify-end gap-3">
                  <Button variant="outline" onClick={() => setShowAddEmployee(false)}>
                    Cancelar
                  </Button>
                  <Button className="bg-indigo-600 hover:bg-indigo-700">Guardar Empleado</Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {/* KPI Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card className="border-l-4 border-l-indigo-500">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Empleados Activos</p>
                  <p className="text-2xl font-bold text-gray-900">{totalEmployees}</p>
                </div>
                <Users className="h-8 w-8 text-indigo-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-l-green-500">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Pagado Este Mes</p>
                  <p className="text-2xl font-bold text-gray-900">RD${totalPaidThisMonth.toLocaleString()}</p>
                </div>
                <DollarSign className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-l-blue-500">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Nómina Total</p>
                  <p className="text-2xl font-bold text-gray-900">RD${totalPayroll.toLocaleString()}</p>
                </div>
                <FileText className="h-8 w-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-l-purple-500">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">% Presupuesto Usado</p>
                  <p className="text-2xl font-bold text-gray-900">{budgetUsed}%</p>
                </div>
                <Calendar className="h-8 w-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="employees" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="employees">Personal Registrado</TabsTrigger>
            <TabsTrigger value="payroll">Nómina por Período</TabsTrigger>
            <TabsTrigger value="history">Historial de Pagos</TabsTrigger>
          </TabsList>

          {/* Employees Tab */}
          <TabsContent value="employees" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Personal Registrado</CardTitle>
                <CardDescription>Gestiona la información del personal docente y administrativo</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex justify-between items-center mb-6">
                  <div className="flex gap-4">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                      <Input
                        placeholder="Buscar empleado..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10 w-64"
                      />
                    </div>
                    <Select value={filterStatus} onValueChange={setFilterStatus}>
                      <SelectTrigger className="w-48">
                        <Filter className="w-4 h-4 mr-2" />
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Todos los empleados</SelectItem>
                        <SelectItem value="activo">Activos</SelectItem>
                        <SelectItem value="inactivo">Inactivos</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <Button variant="outline">
                    <Download className="w-4 h-4 mr-2" />
                    Exportar
                  </Button>
                </div>

                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Nombre</TableHead>
                      <TableHead>Cargo</TableHead>
                      <TableHead>Departamento</TableHead>
                      <TableHead>Contrato</TableHead>
                      <TableHead>Salario Base</TableHead>
                      <TableHead>Fecha Ingreso</TableHead>
                      <TableHead>Estado</TableHead>
                      <TableHead>Acciones</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {employees.map((employee) => (
                      <TableRow key={employee.id}>
                        <TableCell className="font-medium">{employee.name}</TableCell>
                        <TableCell>{employee.position}</TableCell>
                        <TableCell>{employee.department}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{employee.contractType}</Badge>
                        </TableCell>
                        <TableCell>RD${employee.baseSalary.toLocaleString()}</TableCell>
                        <TableCell>{employee.startDate}</TableCell>
                        <TableCell>
                          <Badge className="bg-green-100 text-green-800">{employee.status}</Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button variant="ghost" size="sm">
                              <Eye className="w-4 h-4" />
                            </Button>
                            <Button variant="ghost" size="sm">
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button variant="ghost" size="sm" className="text-red-600">
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Payroll Tab */}
          <TabsContent value="payroll" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle>Nómina por Período</CardTitle>
                    <CardDescription>Genera y gestiona la nómina mensual del personal</CardDescription>
                  </div>
                  <div className="flex gap-3">
                    <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
                      <SelectTrigger className="w-48">
                        <Calendar className="w-4 h-4 mr-2" />
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="2024-01">Enero 2024</SelectItem>
                        <SelectItem value="2023-12">Diciembre 2023</SelectItem>
                        <SelectItem value="2023-11">Noviembre 2023</SelectItem>
                      </SelectContent>
                    </Select>
                    <Dialog open={showPayrollGeneration} onOpenChange={setShowPayrollGeneration}>
                      <DialogTrigger asChild>
                        <Button className="bg-indigo-600 hover:bg-indigo-700">
                          <FileText className="w-4 h-4 mr-2" />
                          Generar Nómina
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Generar Nómina</DialogTitle>
                          <DialogDescription>
                            Configura los parámetros para generar la nómina del período seleccionado
                          </DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4 py-4">
                          <div className="space-y-2">
                            <Label>Período</Label>
                            <Input value="Enero 2024" disabled />
                          </div>
                          <div className="space-y-2">
                            <Label>Incluir Bonificaciones</Label>
                            <Select defaultValue="yes">
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="yes">Sí, incluir bonificaciones</SelectItem>
                                <SelectItem value="no">No incluir</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div className="space-y-2">
                            <Label>Calcular Horas Extra</Label>
                            <Select defaultValue="auto">
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="auto">Cálculo automático</SelectItem>
                                <SelectItem value="manual">Ingreso manual</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                        <div className="flex justify-end gap-3">
                          <Button variant="outline" onClick={() => setShowPayrollGeneration(false)}>
                            Cancelar
                          </Button>
                          <Button className="bg-indigo-600 hover:bg-indigo-700">Generar Nómina</Button>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Empleado</TableHead>
                      <TableHead>Salario Base</TableHead>
                      <TableHead>Bonificaciones</TableHead>
                      <TableHead>Horas Extra</TableHead>
                      <TableHead>Deducciones</TableHead>
                      <TableHead>Salario Neto</TableHead>
                      <TableHead>Estado</TableHead>
                      <TableHead>Acciones</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {payrollData.map((payroll) => (
                      <TableRow key={payroll.employeeId}>
                        <TableCell className="font-medium">{payroll.name}</TableCell>
                        <TableCell>RD${payroll.baseSalary.toLocaleString()}</TableCell>
                        <TableCell>RD${payroll.bonuses.toLocaleString()}</TableCell>
                        <TableCell>RD${payroll.overtime.toLocaleString()}</TableCell>
                        <TableCell>RD${payroll.deductions.toLocaleString()}</TableCell>
                        <TableCell className="font-semibold">RD${payroll.netSalary.toLocaleString()}</TableCell>
                        <TableCell>{getStatusBadge(payroll.status)}</TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            {payroll.status === "Procesado" && (
                              <Button size="sm" className="bg-green-600 hover:bg-green-700">
                                <CheckCircle className="w-4 h-4 mr-1" />
                                Pagar
                              </Button>
                            )}
                            {payroll.status === "Pagado" && (
                              <Button size="sm" variant="outline">
                                <Send className="w-4 h-4 mr-1" />
                                Enviar
                              </Button>
                            )}
                            <Button variant="ghost" size="sm">
                              <Eye className="w-4 h-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>

                <div className="mt-6 p-4 bg-gray-50 rounded-lg">
                  <div className="flex justify-between items-center">
                    <div className="space-y-1">
                      <p className="text-sm text-gray-600">Total Nómina del Período</p>
                      <p className="text-2xl font-bold text-gray-900">RD${totalPayroll.toLocaleString()}</p>
                    </div>
                    <div className="flex gap-3">
                      <Button variant="outline">
                        <Download className="w-4 h-4 mr-2" />
                        Exportar PDF
                      </Button>
                      <Button className="bg-indigo-600 hover:bg-indigo-700">
                        <CheckCircle className="w-4 h-4 mr-2" />
                        Validar Pagos
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* History Tab */}
          <TabsContent value="history" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Historial de Pagos</CardTitle>
                <CardDescription>Consulta el historial completo de pagos realizados</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex justify-between items-center mb-6">
                  <div className="flex gap-4">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                      <Input placeholder="Buscar por empleado..." className="pl-10 w-64" />
                    </div>
                    <Select>
                      <SelectTrigger className="w-48">
                        <SelectValue placeholder="Filtrar por período" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="2024-01">Enero 2024</SelectItem>
                        <SelectItem value="2023-12">Diciembre 2023</SelectItem>
                        <SelectItem value="2023-11">Noviembre 2023</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <Button variant="outline">
                    <Download className="w-4 h-4 mr-2" />
                    Exportar Historial
                  </Button>
                </div>

                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Empleado</TableHead>
                      <TableHead>Período</TableHead>
                      <TableHead>Monto Pagado</TableHead>
                      <TableHead>Fecha de Pago</TableHead>
                      <TableHead>Método</TableHead>
                      <TableHead>Estado</TableHead>
                      <TableHead>Acciones</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {payrollData
                      .filter((p) => p.status === "Pagado")
                      .map((payroll) => (
                        <TableRow key={payroll.employeeId}>
                          <TableCell className="font-medium">{payroll.name}</TableCell>
                          <TableCell>Enero 2024</TableCell>
                          <TableCell>RD${payroll.netSalary.toLocaleString()}</TableCell>
                          <TableCell>{payroll.paymentDate}</TableCell>
                          <TableCell>
                            <Badge variant="outline">Transferencia</Badge>
                          </TableCell>
                          <TableCell>{getStatusBadge(payroll.status)}</TableCell>
                          <TableCell>
                            <div className="flex gap-2">
                              <Button variant="ghost" size="sm">
                                <Eye className="w-4 h-4" />
                              </Button>
                              <Button variant="ghost" size="sm">
                                <Download className="w-4 h-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
