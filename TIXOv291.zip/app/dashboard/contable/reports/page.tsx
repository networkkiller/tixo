"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Switch } from "@/components/ui/switch"
import {
  FileText,
  Download,
  Send,
  TrendingUp,
  TrendingDown,
  DollarSign,
  Users,
  PieChart,
  BarChart3,
  Mail,
  Clock,
  Eye,
  Filter,
} from "lucide-react"

export default function ReportsPage() {
  const [reportType, setReportType] = useState("")
  const [dateFrom, setDateFrom] = useState("")
  const [dateTo, setDateTo] = useState("")
  const [course, setCourse] = useState("")
  const [autoSend, setAutoSend] = useState(false)

  // Datos de ejemplo
  const reportTemplates = [
    {
      id: "monthly-income-expenses",
      name: "Informe Mensual de Ingresos y Egresos",
      description: "Comparativa detallada de ingresos vs egresos con desglose por categoría",
      icon: <BarChart3 className="h-6 w-6 text-[#4338ca]" />,
      lastGenerated: "15/01/2024",
      status: "Disponible",
    },
    {
      id: "billing-by-course",
      name: "Informe de Facturación por Curso",
      description: "Total facturado por cada curso y nivel académico",
      icon: <Users className="h-6 w-6 text-[#10b981]" />,
      lastGenerated: "10/01/2024",
      status: "Disponible",
    },
    {
      id: "debt-by-student",
      name: "Informe de Deuda por Estudiante",
      description: "Listado de estudiantes con deudas activas y montos pendientes",
      icon: <DollarSign className="h-6 w-6 text-[#f59e0b]" />,
      lastGenerated: "08/01/2024",
      status: "Disponible",
    },
    {
      id: "cash-flow-projection",
      name: "Informe de Flujo de Caja Proyectado",
      description: "Estimación de ingresos y egresos para los próximos meses",
      icon: <TrendingUp className="h-6 w-6 text-[#8b5cf6]" />,
      lastGenerated: "05/01/2024",
      status: "Disponible",
    },
  ]

  const kpiData = [
    {
      title: "Total Ingresado Este Mes",
      value: "$45,231.89",
      change: "+20.1%",
      trend: "up",
      color: "text-[#10b981]",
    },
    {
      title: "% de Morosidad Actual",
      value: "12.5%",
      change: "-2.3%",
      trend: "down",
      color: "text-[#ef4444]",
    },
    {
      title: "Gasto Mensual por Categoría",
      value: "$23,100.00",
      change: "+8.2%",
      trend: "up",
      color: "text-[#f59e0b]",
    },
    {
      title: "Balance Proyectado",
      value: "$22,131.89",
      change: "+15.7%",
      trend: "up",
      color: "text-[#3b82f6]",
    },
  ]

  const reportHistory = [
    {
      name: "Informe Mensual Enero 2024",
      type: "Ingresos y Egresos",
      generatedDate: "15/01/2024 - 09:30 AM",
      sentTo: "director@colegio.com",
      status: "Enviado",
    },
    {
      name: "Reporte de Deudas Q4 2023",
      type: "Deuda por Estudiante",
      generatedDate: "28/12/2023 - 14:15 PM",
      sentTo: "director@colegio.com",
      status: "Enviado",
    },
    {
      name: "Flujo de Caja Proyección 2024",
      type: "Flujo de Caja",
      generatedDate: "20/12/2023 - 11:45 AM",
      sentTo: "director@colegio.com",
      status: "Enviado",
    },
  ]

  const getHealthIndicator = () => {
    const balance = 22131.89
    const income = 45231.89
    const percentage = (balance / income) * 100

    if (percentage > 15) {
      return { status: "Superávit", color: "bg-[#10b981]", icon: "🟢" }
    } else if (percentage > 5) {
      return { status: "Estable", color: "bg-[#f59e0b]", icon: "🟡" }
    } else {
      return { status: "Riesgo", color: "bg-[#ef4444]", icon: "🔴" }
    }
  }

  const healthIndicator = getHealthIndicator()

  return (
    <div className="flex-1 space-y-6 p-8 bg-[#f0f4f8]">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight text-[#1f2937]">Informes y Análisis Financieros</h2>
          <p className="text-[#6b7280]">Generación y análisis de reportes financieros institucionales</p>
        </div>
        <div className="flex items-center space-x-3">
          <Dialog>
            <DialogTrigger asChild>
              <Button size="sm" className="bg-[#4338ca] hover:bg-[#3730a3] text-white">
                <FileText className="mr-2 h-4 w-4" />
                Generar Informe
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl bg-white">
              <DialogHeader>
                <DialogTitle className="text-[#1f2937]">Generar Nuevo Informe</DialogTitle>
                <DialogDescription className="text-[#6b7280]">
                  Configure los parámetros para generar un informe personalizado
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="reportType" className="text-[#1f2937]">
                    Tipo de Informe
                  </Label>
                  <Select value={reportType} onValueChange={setReportType}>
                    <SelectTrigger className="bg-white border-[#e5e7eb]">
                      <SelectValue placeholder="Seleccionar tipo de informe" />
                    </SelectTrigger>
                    <SelectContent className="bg-white">
                      <SelectItem value="monthly-income-expenses">Ingresos y Egresos Mensual</SelectItem>
                      <SelectItem value="billing-by-course">Facturación por Curso</SelectItem>
                      <SelectItem value="debt-by-student">Deuda por Estudiante</SelectItem>
                      <SelectItem value="cash-flow-projection">Flujo de Caja Proyectado</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="dateFrom" className="text-[#1f2937]">
                      Fecha Desde
                    </Label>
                    <Input
                      id="dateFrom"
                      type="date"
                      value={dateFrom}
                      onChange={(e) => setDateFrom(e.target.value)}
                      className="bg-white border-[#e5e7eb]"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="dateTo" className="text-[#1f2937]">
                      Fecha Hasta
                    </Label>
                    <Input
                      id="dateTo"
                      type="date"
                      value={dateTo}
                      onChange={(e) => setDateTo(e.target.value)}
                      className="bg-white border-[#e5e7eb]"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="course" className="text-[#1f2937]">
                    Filtrar por Curso (Opcional)
                  </Label>
                  <Select value={course} onValueChange={setCourse}>
                    <SelectTrigger className="bg-white border-[#e5e7eb]">
                      <SelectValue placeholder="Todos los cursos" />
                    </SelectTrigger>
                    <SelectContent className="bg-white">
                      <SelectItem value="all">Todos los cursos</SelectItem>
                      <SelectItem value="1a">1ro A</SelectItem>
                      <SelectItem value="2a">2do A</SelectItem>
                      <SelectItem value="3a">3ro A</SelectItem>
                      <SelectItem value="4a">4to A</SelectItem>
                      <SelectItem value="5a">5to A</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch id="autoSend" checked={autoSend} onCheckedChange={setAutoSend} />
                  <Label htmlFor="autoSend" className="text-[#1f2937]">
                    Enviar automáticamente al Director
                  </Label>
                </div>
              </div>
              <div className="flex justify-end space-x-2">
                <Button variant="outline">Cancelar</Button>
                <Button className="bg-[#4338ca] hover:bg-[#3730a3] text-white">
                  <FileText className="mr-2 h-4 w-4" />
                  Generar Informe
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Tabs defaultValue="templates" className="space-y-4">
        <TabsList className="bg-white border border-[#e5e7eb]">
          <TabsTrigger value="templates" className="data-[state=active]:bg-[#4338ca] data-[state=active]:text-white">
            Informes Disponibles
          </TabsTrigger>
          <TabsTrigger value="kpi" className="data-[state=active]:bg-[#4338ca] data-[state=active]:text-white">
            KPI Financieros
          </TabsTrigger>
          <TabsTrigger value="history" className="data-[state=active]:bg-[#4338ca] data-[state=active]:text-white">
            Historial de Informes
          </TabsTrigger>
        </TabsList>

        <TabsContent value="templates" className="space-y-4">
          <div className="grid gap-6 md:grid-cols-2">
            {reportTemplates.map((template) => (
              <Card key={template.id} className="bg-white border-0 shadow-sm hover:shadow-md transition-shadow">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-center space-x-3">
                      {template.icon}
                      <div>
                        <CardTitle className="text-[#1f2937] text-lg">{template.name}</CardTitle>
                        <CardDescription className="text-[#6b7280]">{template.description}</CardDescription>
                      </div>
                    </div>
                    <Badge className="bg-[#d1fae5] text-[#10b981] border-[#10b981]/20">{template.status}</Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <div className="text-sm text-[#6b7280]">
                      Última generación: <span className="font-medium">{template.lastGenerated}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Button variant="outline" size="sm" className="border-[#6b7280] text-[#6b7280]">
                        <Eye className="mr-2 h-4 w-4" />
                        Vista Previa
                      </Button>
                      <Button size="sm" className="bg-[#4338ca] hover:bg-[#3730a3] text-white">
                        <Download className="mr-2 h-4 w-4" />
                        Generar
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <Card className="bg-white border-0 shadow-sm">
            <CardHeader>
              <CardTitle className="text-[#1f2937]">Indicador de Salud Financiera</CardTitle>
              <CardDescription className="text-[#6b7280]">
                Estado actual de la situación financiera institucional
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between p-6 rounded-lg border border-[#e5e7eb]">
                <div className="flex items-center space-x-4">
                  <div className="text-4xl">{healthIndicator.icon}</div>
                  <div>
                    <h3 className="text-2xl font-bold text-[#1f2937]">{healthIndicator.status}</h3>
                    <p className="text-[#6b7280]">Balance actual: $22,131.89 (49% de los ingresos)</p>
                  </div>
                </div>
                <div className={`px-4 py-2 rounded-full ${healthIndicator.color} text-white font-medium`}>
                  Estado Financiero
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="kpi" className="space-y-4">
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            {kpiData.map((kpi, index) => (
              <Card key={index} className="bg-white border-0 shadow-sm">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-[#6b7280]">{kpi.title}</CardTitle>
                  {kpi.trend === "up" ? (
                    <TrendingUp className={`h-4 w-4 ${kpi.color}`} />
                  ) : (
                    <TrendingDown className={`h-4 w-4 ${kpi.color}`} />
                  )}
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-[#1f2937]">{kpi.value}</div>
                  <p className={`text-xs ${kpi.color} flex items-center mt-1`}>{kpi.change} vs período anterior</p>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="grid gap-6 md:grid-cols-2">
            <Card className="bg-white border-0 shadow-sm">
              <CardHeader>
                <CardTitle className="text-[#1f2937]">Distribución de Ingresos</CardTitle>
                <CardDescription className="text-[#6b7280]">Fuentes de ingresos del mes actual</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[200px] flex items-center justify-center text-[#9ca3af] border border-dashed border-[#e5e7eb] rounded-lg">
                  <div className="text-center">
                    <PieChart className="h-12 w-12 mx-auto mb-2" />
                    <p>Gráfico circular</p>
                    <p className="text-sm mt-1">Distribución de ingresos</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white border-0 shadow-sm">
              <CardHeader>
                <CardTitle className="text-[#1f2937]">Tendencia Financiera</CardTitle>
                <CardDescription className="text-[#6b7280]">Evolución mensual de ingresos y egresos</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[200px] flex items-center justify-center text-[#9ca3af] border border-dashed border-[#e5e7eb] rounded-lg">
                  <div className="text-center">
                    <BarChart3 className="h-12 w-12 mx-auto mb-2" />
                    <p>Gráfico de líneas</p>
                    <p className="text-sm mt-1">Tendencia temporal</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="history" className="space-y-4">
          <Card className="bg-white border-0 shadow-sm">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-[#1f2937]">Historial de Informes Generados</CardTitle>
                  <CardDescription className="text-[#6b7280]">
                    Registro de todos los informes creados y enviados
                  </CardDescription>
                </div>
                <div className="flex items-center space-x-2">
                  <Button variant="outline" size="sm" className="border-[#6b7280] text-[#6b7280]">
                    <Filter className="mr-2 h-4 w-4" />
                    Filtrar
                  </Button>
                  <Button variant="outline" size="sm" className="border-[#6b7280] text-[#6b7280]">
                    <Download className="mr-2 h-4 w-4" />
                    Exportar Lista
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {reportHistory.map((report, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-4 border border-[#e5e7eb] rounded-lg hover:bg-[#f0f4f8] transition-colors"
                  >
                    <div className="flex items-center space-x-4">
                      <div className="w-10 h-10 bg-[#4338ca]/10 rounded-lg flex items-center justify-center">
                        <FileText className="h-5 w-5 text-[#4338ca]" />
                      </div>
                      <div>
                        <h4 className="font-medium text-[#1f2937]">{report.name}</h4>
                        <p className="text-sm text-[#6b7280]">{report.type}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="text-right">
                        <p className="text-sm font-medium text-[#1f2937]">{report.generatedDate}</p>
                        <p className="text-xs text-[#6b7280]">Enviado a: {report.sentTo}</p>
                      </div>
                      <Badge className="bg-[#d1fae5] text-[#10b981] border-[#10b981]/20">{report.status}</Badge>
                      <div className="flex items-center space-x-2">
                        <Button variant="ghost" size="sm" className="text-[#6b7280] hover:text-[#4338ca]">
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="sm" className="text-[#6b7280] hover:text-[#4338ca]">
                          <Download className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="sm" className="text-[#6b7280] hover:text-[#4338ca]">
                          <Send className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white border-0 shadow-sm">
            <CardHeader>
              <CardTitle className="text-[#1f2937]">Configuración de Envío Automático</CardTitle>
              <CardDescription className="text-[#6b7280]">
                Programar informes recurrentes para el Director
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between p-4 border border-[#e5e7eb] rounded-lg">
                <div className="flex items-center space-x-3">
                  <Mail className="h-5 w-5 text-[#4338ca]" />
                  <div>
                    <p className="font-medium text-[#1f2937]">Informe Mensual de Ingresos y Egresos</p>
                    <p className="text-sm text-[#6b7280]">Primer lunes de cada mes a las 09:00 AM</p>
                  </div>
                </div>
                <Switch defaultChecked />
              </div>
              <div className="flex items-center justify-between p-4 border border-[#e5e7eb] rounded-lg">
                <div className="flex items-center space-x-3">
                  <Clock className="h-5 w-5 text-[#f59e0b]" />
                  <div>
                    <p className="font-medium text-[#1f2937]">Reporte de Deudas Semanales</p>
                    <p className="text-sm text-[#6b7280]">Cada viernes a las 16:00 PM</p>
                  </div>
                </div>
                <Switch />
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
