"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Textarea } from "@/components/ui/textarea"
import {
  Search,
  Download,
  DollarSign,
  Calendar,
  CheckCircle,
  Clock,
  AlertCircle,
  FileText,
  Send,
  Edit,
  Eye,
  Plus,
  CreditCard,
  User,
  Phone,
  Mail,
  BookOpen,
} from "lucide-react"

export default function StudentProfilePage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedStudent, setSelectedStudent] = useState(null)
  const [showNewInvoice, setShowNewInvoice] = useState(false)
  const [showPaymentRecord, setShowPaymentRecord] = useState(false)

  // Datos simulados de estudiantes
  const students = [
    {
      id: 1,
      name: "Ana García Pérez",
      course: "3ro A",
      level: "Primaria",
      guardian: "María Pérez",
      guardianPhone: "809-555-0123",
      guardianEmail: "maria.perez@email.com",
      status: "Activo",
      totalDebt: 15000,
      lastPayment: "2024-01-15",
      riskLevel: "Medio",
    },
    {
      id: 2,
      name: "Carlos Rodríguez López",
      course: "5to B",
      level: "Primaria",
      guardian: "Juan Rodríguez",
      guardianPhone: "809-555-0456",
      guardianEmail: "juan.rodriguez@email.com",
      status: "Activo",
      totalDebt: 0,
      lastPayment: "2024-01-30",
      riskLevel: "Bajo",
    },
    {
      id: 3,
      name: "Sofía Martínez Cruz",
      course: "1ro C",
      level: "Secundaria",
      guardian: "Carmen Cruz",
      guardianPhone: "809-555-0789",
      guardianEmail: "carmen.cruz@email.com",
      status: "Activo",
      totalDebt: 45000,
      lastPayment: "2023-11-20",
      riskLevel: "Alto",
    },
  ]

  // Datos simulados de facturas para el estudiante seleccionado
  const invoices = [
    {
      id: "INV-2024-001",
      issueDate: "2024-01-01",
      dueDate: "2024-01-31",
      concept: "Mensualidad Enero",
      amount: 15000,
      status: "Pendiente",
      daysOverdue: 5,
    },
    {
      id: "INV-2023-012",
      issueDate: "2023-12-01",
      dueDate: "2023-12-31",
      concept: "Mensualidad Diciembre",
      amount: 15000,
      status: "Pagada",
      daysOverdue: 0,
    },
    {
      id: "INV-2023-011",
      issueDate: "2023-11-01",
      dueDate: "2023-11-30",
      concept: "Mensualidad Noviembre",
      amount: 15000,
      status: "Pagada",
      daysOverdue: 0,
    },
  ]

  // Datos simulados de pagos
  const payments = [
    {
      id: 1,
      date: "2023-12-28",
      amount: 15000,
      method: "Transferencia",
      reference: "TRF-001234",
      invoice: "INV-2023-012",
      notes: "Pago mensualidad diciembre",
    },
    {
      id: 2,
      date: "2023-11-25",
      amount: 15000,
      method: "Efectivo",
      reference: "REC-005678",
      invoice: "INV-2023-011",
      notes: "Pago mensualidad noviembre",
    },
  ]

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "Pagada":
        return (
          <Badge className="bg-green-100 text-green-800 border-green-200">
            <CheckCircle className="w-3 h-3 mr-1" />
            Pagada
          </Badge>
        )
      case "Parcial":
        return (
          <Badge className="bg-blue-100 text-blue-800 border-blue-200">
            <Clock className="w-3 h-3 mr-1" />
            Parcial
          </Badge>
        )
      case "Pendiente":
        return (
          <Badge className="bg-yellow-100 text-yellow-800 border-yellow-200">
            <AlertCircle className="w-3 h-3 mr-1" />
            Pendiente
          </Badge>
        )
      case "Vencida":
        return (
          <Badge className="bg-red-100 text-red-800 border-red-200">
            <AlertCircle className="w-3 h-3 mr-1" />
            Vencida
          </Badge>
        )
      default:
        return <Badge variant="secondary">{status}</Badge>
    }
  }

  const getRiskBadge = (risk: string) => {
    switch (risk) {
      case "Alto":
        return <Badge className="bg-red-100 text-red-800 border-red-200">🔴 Alto</Badge>
      case "Medio":
        return <Badge className="bg-yellow-100 text-yellow-800 border-yellow-200">🟡 Medio</Badge>
      case "Bajo":
        return <Badge className="bg-green-100 text-green-800 border-green-200">🟢 Bajo</Badge>
      default:
        return <Badge variant="secondary">{risk}</Badge>
    }
  }

  const getComplianceBadge = (debt: number) => {
    if (debt === 0) {
      return <Badge className="bg-green-100 text-green-800 border-green-200">🟢 Al día</Badge>
    } else if (debt > 0 && debt <= 15000) {
      return <Badge className="bg-yellow-100 text-yellow-800 border-yellow-200">🟡 Pago parcial</Badge>
    } else {
      return <Badge className="bg-red-100 text-red-800 border-red-200">🔴 Vencido</Badge>
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Perfil Financiero del Estudiante</h1>
            <p className="text-gray-600 mt-1">Vista detallada de la situación financiera por estudiante</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Student List */}
          <Card className="lg:col-span-1">
            <CardHeader>
              <CardTitle>Lista de Estudiantes</CardTitle>
              <CardDescription>Selecciona un estudiante para ver su perfil financiero</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    placeholder="Buscar estudiante..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>

                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {students.map((student) => (
                    <div
                      key={student.id}
                      className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                        selectedStudent?.id === student.id
                          ? "border-indigo-500 bg-indigo-50"
                          : "border-gray-200 hover:border-gray-300"
                      }`}
                      onClick={() => setSelectedStudent(student)}
                    >
                      <div className="flex justify-between items-start">
                        <div>
                          <p className="font-medium text-gray-900">{student.name}</p>
                          <p className="text-sm text-gray-600">
                            {student.course} - {student.level}
                          </p>
                          <p className="text-sm text-gray-500">{student.guardian}</p>
                        </div>
                        <div className="text-right">
                          {getComplianceBadge(student.totalDebt)}
                          {student.totalDebt > 0 && (
                            <p className="text-sm text-red-600 mt-1">RD${student.totalDebt.toLocaleString()}</p>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Student Profile */}
          <div className="lg:col-span-2 space-y-6">
            {selectedStudent ? (
              <>
                {/* Student Info */}
                <Card>
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="flex items-center gap-2">
                          <User className="w-5 h-5" />
                          {selectedStudent.name}
                        </CardTitle>
                        <CardDescription>
                          {selectedStudent.course} - {selectedStudent.level}
                        </CardDescription>
                      </div>
                      <div className="flex gap-2">
                        {getComplianceBadge(selectedStudent.totalDebt)}
                        {getRiskBadge(selectedStudent.riskLevel)}
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-4">
                        <div className="flex items-center gap-3">
                          <BookOpen className="w-4 h-4 text-gray-500" />
                          <div>
                            <p className="text-sm text-gray-600">Curso Actual</p>
                            <p className="font-medium">
                              {selectedStudent.course} - {selectedStudent.level}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <User className="w-4 h-4 text-gray-500" />
                          <div>
                            <p className="text-sm text-gray-600">Tutor Responsable</p>
                            <p className="font-medium">{selectedStudent.guardian}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <Phone className="w-4 h-4 text-gray-500" />
                          <div>
                            <p className="text-sm text-gray-600">Teléfono</p>
                            <p className="font-medium">{selectedStudent.guardianPhone}</p>
                          </div>
                        </div>
                      </div>
                      <div className="space-y-4">
                        <div className="flex items-center gap-3">
                          <Mail className="w-4 h-4 text-gray-500" />
                          <div>
                            <p className="text-sm text-gray-600">Email</p>
                            <p className="font-medium">{selectedStudent.guardianEmail}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <DollarSign className="w-4 h-4 text-gray-500" />
                          <div>
                            <p className="text-sm text-gray-600">Deuda Actual</p>
                            <p
                              className={`font-medium ${selectedStudent.totalDebt > 0 ? "text-red-600" : "text-green-600"}`}
                            >
                              RD${selectedStudent.totalDebt.toLocaleString()}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <Calendar className="w-4 h-4 text-gray-500" />
                          <div>
                            <p className="text-sm text-gray-600">Último Pago</p>
                            <p className="font-medium">{selectedStudent.lastPayment}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Financial Details */}
                <Tabs defaultValue="invoices" className="space-y-6">
                  <div className="flex justify-between items-center">
                    <TabsList className="grid w-full max-w-md grid-cols-3">
                      <TabsTrigger value="invoices">Facturas</TabsTrigger>
                      <TabsTrigger value="payments">Pagos</TabsTrigger>
                      <TabsTrigger value="plan">Plan de Pago</TabsTrigger>
                    </TabsList>
                    <div className="flex gap-3">
                      <Dialog open={showNewInvoice} onOpenChange={setShowNewInvoice}>
                        <DialogTrigger asChild>
                          <Button className="bg-indigo-600 hover:bg-indigo-700">
                            <FileText className="w-4 h-4 mr-2" />
                            Nueva Factura
                          </Button>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader>
                            <DialogTitle>Emitir Nueva Factura</DialogTitle>
                            <DialogDescription>Crear una nueva factura para {selectedStudent.name}</DialogDescription>
                          </DialogHeader>
                          <div className="space-y-4 py-4">
                            <div className="space-y-2">
                              <Label htmlFor="concept">Concepto</Label>
                              <Select>
                                <SelectTrigger>
                                  <SelectValue placeholder="Seleccionar concepto" />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="mensualidad">Mensualidad</SelectItem>
                                  <SelectItem value="matricula">Matrícula</SelectItem>
                                  <SelectItem value="materiales">Materiales</SelectItem>
                                  <SelectItem value="otros">Otros</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                            <div className="space-y-2">
                              <Label htmlFor="amount">Monto</Label>
                              <Input id="amount" type="number" placeholder="0.00" />
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                              <div className="space-y-2">
                                <Label htmlFor="issueDate">Fecha de Emisión</Label>
                                <Input id="issueDate" type="date" />
                              </div>
                              <div className="space-y-2">
                                <Label htmlFor="dueDate">Fecha de Vencimiento</Label>
                                <Input id="dueDate" type="date" />
                              </div>
                            </div>
                            <div className="space-y-2">
                              <Label htmlFor="notes">Observaciones (Opcional)</Label>
                              <Textarea id="notes" placeholder="Notas adicionales..." />
                            </div>
                          </div>
                          <div className="flex justify-end gap-3">
                            <Button variant="outline" onClick={() => setShowNewInvoice(false)}>
                              Cancelar
                            </Button>
                            <Button className="bg-indigo-600 hover:bg-indigo-700">Emitir Factura</Button>
                          </div>
                        </DialogContent>
                      </Dialog>

                      <Dialog open={showPaymentRecord} onOpenChange={setShowPaymentRecord}>
                        <DialogTrigger asChild>
                          <Button variant="outline">
                            <CreditCard className="w-4 h-4 mr-2" />
                            Registrar Pago
                          </Button>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader>
                            <DialogTitle>Registrar Pago</DialogTitle>
                            <DialogDescription>Registrar un nuevo pago para {selectedStudent.name}</DialogDescription>
                          </DialogHeader>
                          <div className="space-y-4 py-4">
                            <div className="space-y-2">
                              <Label htmlFor="invoice">Factura</Label>
                              <Select>
                                <SelectTrigger>
                                  <SelectValue placeholder="Seleccionar factura" />
                                </SelectTrigger>
                                <SelectContent>
                                  {invoices
                                    .filter((inv) => inv.status === "Pendiente")
                                    .map((invoice) => (
                                      <SelectItem key={invoice.id} value={invoice.id}>
                                        {invoice.id} - {invoice.concept} (RD${invoice.amount.toLocaleString()})
                                      </SelectItem>
                                    ))}
                                </SelectContent>
                              </Select>
                            </div>
                            <div className="space-y-2">
                              <Label htmlFor="paymentAmount">Monto Pagado</Label>
                              <Input id="paymentAmount" type="number" placeholder="0.00" />
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                              <div className="space-y-2">
                                <Label htmlFor="paymentDate">Fecha de Pago</Label>
                                <Input id="paymentDate" type="date" />
                              </div>
                              <div className="space-y-2">
                                <Label htmlFor="paymentMethod">Método de Pago</Label>
                                <Select>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Método" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="efectivo">Efectivo</SelectItem>
                                    <SelectItem value="transferencia">Transferencia</SelectItem>
                                    <SelectItem value="cheque">Cheque</SelectItem>
                                    <SelectItem value="tarjeta">Tarjeta</SelectItem>
                                  </SelectContent>
                                </Select>
                              </div>
                            </div>
                            <div className="space-y-2">
                              <Label htmlFor="reference">Referencia/Recibo</Label>
                              <Input id="reference" placeholder="Número de referencia" />
                            </div>
                            <div className="space-y-2">
                              <Label htmlFor="paymentNotes">Observaciones</Label>
                              <Textarea id="paymentNotes" placeholder="Notas del pago..." />
                            </div>
                          </div>
                          <div className="flex justify-end gap-3">
                            <Button variant="outline" onClick={() => setShowPaymentRecord(false)}>
                              Cancelar
                            </Button>
                            <Button className="bg-green-600 hover:bg-green-700">Registrar Pago</Button>
                          </div>
                        </DialogContent>
                      </Dialog>
                    </div>
                  </div>

                  {/* Invoices Tab */}
                  <TabsContent value="invoices">
                    <Card>
                      <CardHeader>
                        <CardTitle>Facturas Generadas</CardTitle>
                        <CardDescription>Historial completo de facturas del estudiante</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Número</TableHead>
                              <TableHead>Concepto</TableHead>
                              <TableHead>Emisión</TableHead>
                              <TableHead>Vencimiento</TableHead>
                              <TableHead>Monto</TableHead>
                              <TableHead>Estado</TableHead>
                              <TableHead>Acciones</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {invoices.map((invoice) => (
                              <TableRow key={invoice.id}>
                                <TableCell className="font-medium">{invoice.id}</TableCell>
                                <TableCell>{invoice.concept}</TableCell>
                                <TableCell>{invoice.issueDate}</TableCell>
                                <TableCell>{invoice.dueDate}</TableCell>
                                <TableCell>RD${invoice.amount.toLocaleString()}</TableCell>
                                <TableCell>{getStatusBadge(invoice.status)}</TableCell>
                                <TableCell>
                                  <div className="flex gap-2">
                                    <Button variant="ghost" size="sm">
                                      <Eye className="w-4 h-4" />
                                    </Button>
                                    <Button variant="ghost" size="sm">
                                      <Download className="w-4 h-4" />
                                    </Button>
                                    {invoice.status === "Pendiente" && (
                                      <Button variant="ghost" size="sm">
                                        <Send className="w-4 h-4" />
                                      </Button>
                                    )}
                                  </div>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </CardContent>
                    </Card>
                  </TabsContent>

                  {/* Payments Tab */}
                  <TabsContent value="payments">
                    <Card>
                      <CardHeader>
                        <CardTitle>Historial de Pagos</CardTitle>
                        <CardDescription>Registro cronológico de pagos realizados</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Fecha</TableHead>
                              <TableHead>Monto</TableHead>
                              <TableHead>Método</TableHead>
                              <TableHead>Referencia</TableHead>
                              <TableHead>Factura</TableHead>
                              <TableHead>Observaciones</TableHead>
                              <TableHead>Acciones</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {payments.map((payment) => (
                              <TableRow key={payment.id}>
                                <TableCell>{payment.date}</TableCell>
                                <TableCell className="font-medium">RD${payment.amount.toLocaleString()}</TableCell>
                                <TableCell>
                                  <Badge variant="outline">{payment.method}</Badge>
                                </TableCell>
                                <TableCell>{payment.reference}</TableCell>
                                <TableCell>{payment.invoice}</TableCell>
                                <TableCell>{payment.notes}</TableCell>
                                <TableCell>
                                  <div className="flex gap-2">
                                    <Button variant="ghost" size="sm">
                                      <Eye className="w-4 h-4" />
                                    </Button>
                                    <Button variant="ghost" size="sm">
                                      <Edit className="w-4 h-4" />
                                    </Button>
                                    <Button variant="ghost" size="sm">
                                      <Download className="w-4 h-4" />
                                    </Button>
                                  </div>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </CardContent>
                    </Card>
                  </TabsContent>

                  {/* Payment Plan Tab */}
                  <TabsContent value="plan">
                    <Card>
                      <CardHeader>
                        <div className="flex justify-between items-center">
                          <div>
                            <CardTitle>Plan de Pagos</CardTitle>
                            <CardDescription>Acuerdos especiales y reestructuraciones de deuda</CardDescription>
                          </div>
                          <Button className="bg-indigo-600 hover:bg-indigo-700">
                            <Plus className="w-4 h-4 mr-2" />
                            Crear Plan
                          </Button>
                        </div>
                      </CardHeader>
                      <CardContent>
                        {selectedStudent.totalDebt > 0 ? (
                          <div className="space-y-4">
                            <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                              <div className="flex items-center gap-2 mb-2">
                                <AlertCircle className="w-5 h-5 text-yellow-600" />
                                <h4 className="font-medium text-yellow-800">Plan de Pago Activo</h4>
                              </div>
                              <p className="text-sm text-yellow-700">
                                Deuda total: RD${selectedStudent.totalDebt.toLocaleString()} - Plan de 3 cuotas
                              </p>
                            </div>

                            <Table>
                              <TableHeader>
                                <TableRow>
                                  <TableHead>Cuota</TableHead>
                                  <TableHead>Fecha Pactada</TableHead>
                                  <TableHead>Monto</TableHead>
                                  <TableHead>Estado</TableHead>
                                  <TableHead>Observaciones</TableHead>
                                  <TableHead>Acciones</TableHead>
                                </TableRow>
                              </TableHeader>
                              <TableBody>
                                <TableRow>
                                  <TableCell>1/3</TableCell>
                                  <TableCell>2024-02-15</TableCell>
                                  <TableCell>RD$5,000</TableCell>
                                  <TableCell>
                                    <Badge className="bg-red-100 text-red-800 border-red-200">Vencido</Badge>
                                  </TableCell>
                                  <TableCell>Primera cuota del plan</TableCell>
                                  <TableCell>
                                    <Button variant="ghost" size="sm">
                                      <Edit className="w-4 h-4" />
                                    </Button>
                                  </TableCell>
                                </TableRow>
                                <TableRow>
                                  <TableCell>2/3</TableCell>
                                  <TableCell>2024-03-15</TableCell>
                                  <TableCell>RD$5,000</TableCell>
                                  <TableCell>
                                    <Badge className="bg-yellow-100 text-yellow-800 border-yellow-200">Pendiente</Badge>
                                  </TableCell>
                                  <TableCell>Segunda cuota del plan</TableCell>
                                  <TableCell>
                                    <Button variant="ghost" size="sm">
                                      <Edit className="w-4 h-4" />
                                    </Button>
                                  </TableCell>
                                </TableRow>
                                <TableRow>
                                  <TableCell>3/3</TableCell>
                                  <TableCell>2024-04-15</TableCell>
                                  <TableCell>RD$5,000</TableCell>
                                  <TableCell>
                                    <Badge className="bg-gray-100 text-gray-800 border-gray-200">Programado</Badge>
                                  </TableCell>
                                  <TableCell>Cuota final del plan</TableCell>
                                  <TableCell>
                                    <Button variant="ghost" size="sm">
                                      <Edit className="w-4 h-4" />
                                    </Button>
                                  </TableCell>
                                </TableRow>
                              </TableBody>
                            </Table>
                          </div>
                        ) : (
                          <div className="text-center py-8">
                            <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-4" />
                            <h3 className="text-lg font-medium text-gray-900 mb-2">Sin Deudas Pendientes</h3>
                            <p className="text-gray-600">Este estudiante está al día con sus pagos</p>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  </TabsContent>
                </Tabs>

                {/* Quick Actions */}
                <Card>
                  <CardHeader>
                    <CardTitle>Acciones Rápidas</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-wrap gap-3">
                      <Button variant="outline">
                        <Send className="w-4 h-4 mr-2" />
                        Enviar Recordatorio
                      </Button>
                      <Button variant="outline">
                        <Download className="w-4 h-4 mr-2" />
                        Estado de Cuenta
                      </Button>
                      <Button variant="outline">
                        <Phone className="w-4 h-4 mr-2" />
                        Contactar Tutor
                      </Button>
                      <Button variant="outline">
                        <FileText className="w-4 h-4 mr-2" />
                        Historial Completo
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </>
            ) : (
              <Card>
                <CardContent className="flex items-center justify-center py-12">
                  <div className="text-center">
                    <User className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">Selecciona un Estudiante</h3>
                    <p className="text-gray-600">
                      Elige un estudiante de la lista para ver su perfil financiero completo
                    </p>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
