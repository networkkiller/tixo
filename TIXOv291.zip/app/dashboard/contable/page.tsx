"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import {
  DollarSign,
  TrendingUp,
  AlertTriangle,
  FileText,
  Plus,
  BarChart3,
  ArrowUpRight,
  Clock,
  Users,
  CreditCard,
} from "lucide-react"
import Link from "next/link"

export default function ContableDashboard() {
  return (
    <div className="flex-1 space-y-6 p-8 bg-[#f0f4f8]">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight text-[#1f2937]">Dashboard Financiero</h2>
          <p className="text-[#6b7280]">Vista ejecutiva del estado financiero del colegio</p>
        </div>
        <div className="flex items-center space-x-3">
          <Link href="/dashboard/contable/billing">
            <Button className="bg-[#4338ca] hover:bg-[#3730a3] text-white">
              <Plus className="mr-2 h-4 w-4" />
              Nueva Factura
            </Button>
          </Link>
          <Link href="/dashboard/contable/expenses">
            <Button variant="outline" className="border-[#4338ca] text-[#4338ca] hover:bg-[#4338ca]/5">
              <FileText className="mr-2 h-4 w-4" />
              Registrar Egreso
            </Button>
          </Link>
        </div>
      </div>

      {/* Métricas principales */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Link href="/dashboard/contable/billing">
          <Card className="bg-white border-0 shadow-sm hover:shadow-md transition-shadow cursor-pointer">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-[#6b7280]">Total Facturado</CardTitle>
              <DollarSign className="h-4 w-4 text-[#4338ca]" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-[#1f2937]">$45,231.89</div>
              <p className="text-xs text-[#10b981] flex items-center mt-1">
                <ArrowUpRight className="mr-1 h-3 w-3" />
                +20.1% vs mes anterior
              </p>
            </CardContent>
          </Card>
        </Link>

        <Card className="bg-white border-0 shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-[#6b7280]">Total Recaudado</CardTitle>
            <TrendingUp className="h-4 w-4 text-[#10b981]" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-[#1f2937]">$32,845.50</div>
            <p className="text-xs text-[#10b981] flex items-center mt-1">
              <ArrowUpRight className="mr-1 h-3 w-3" />
              +12.5% vs mes anterior
            </p>
          </CardContent>
        </Card>

        <Link href="/dashboard/contable/accounts-receivable">
          <Card className="bg-white border-0 shadow-sm hover:shadow-md transition-shadow cursor-pointer">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-[#6b7280]">Deudas Pendientes</CardTitle>
              <AlertTriangle className="h-4 w-4 text-[#f59e0b]" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-[#1f2937]">$12,386.39</div>
              <p className="text-xs text-[#f59e0b] flex items-center mt-1">
                <Clock className="mr-1 h-3 w-3" />8 facturas por vencer
              </p>
            </CardContent>
          </Card>
        </Link>

        <Link href="/dashboard/contable/expenses">
          <Card className="bg-white border-0 shadow-sm hover:shadow-md transition-shadow cursor-pointer">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-[#6b7280]">Egresos del Mes</CardTitle>
              <FileText className="h-4 w-4 text-[#ef4444]" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-[#1f2937]">$28,419.20</div>
              <p className="text-xs text-[#6b7280] flex items-center mt-1">12 categorías de gastos</p>
            </CardContent>
          </Card>
        </Link>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-7">
        {/* Gráfica principal */}
        <Card className="col-span-4 bg-white border-0 shadow-sm">
          <CardHeader>
            <CardTitle className="text-[#1f2937]">Ingresos vs Egresos</CardTitle>
            <CardDescription className="text-[#6b7280]">Comparativa mensual del año en curso</CardDescription>
          </CardHeader>
          <CardContent className="pl-2">
            <div className="h-[300px] flex items-center justify-center text-[#9ca3af] border border-dashed border-[#e5e7eb] rounded-lg">
              <div className="text-center">
                <BarChart3 className="h-12 w-12 mx-auto mb-2" />
                <p>Gráfico de barras comparativo</p>
                <p className="text-sm mt-1">Ingresos vs Egresos por mes</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Alertas */}
        <Card className="col-span-3 bg-white border-0 shadow-sm">
          <CardHeader>
            <CardTitle className="text-[#1f2937]">Alertas Activas</CardTitle>
            <CardDescription className="text-[#6b7280]">Situaciones que requieren atención</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <Alert className="bg-[#fee2e2] border-[#ef4444]/20">
              <AlertTriangle className="h-4 w-4 text-[#ef4444]" />
              <AlertTitle className="text-[#ef4444]">Pagos Vencidos</AlertTitle>
              <AlertDescription className="text-[#1f2937]">12 estudiantes con más de 2 pagos vencidos</AlertDescription>
            </Alert>

            <Alert className="bg-[#fef3c7] border-[#f59e0b]/20">
              <AlertTriangle className="h-4 w-4 text-[#f59e0b]" />
              <AlertTitle className="text-[#f59e0b]">Facturas Sin Enviar</AlertTitle>
              <AlertDescription className="text-[#1f2937]">
                8 facturas generadas sin enviar a los padres
              </AlertDescription>
            </Alert>

            <Alert className="bg-[#dbeafe] border-[#3b82f6]/20">
              <AlertTriangle className="h-4 w-4 text-[#3b82f6]" />
              <AlertTitle className="text-[#3b82f6]">Egresos No Conciliados</AlertTitle>
              <AlertDescription className="text-[#1f2937]">3 egresos pendientes de conciliación</AlertDescription>
            </Alert>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-7">
        {/* Próximos vencimientos */}
        <Card className="col-span-3 bg-white border-0 shadow-sm">
          <CardHeader>
            <CardTitle className="text-[#1f2937]">Próximos Vencimientos</CardTitle>
            <CardDescription className="text-[#6b7280]">Facturas que vencen en los próximos 7 días</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                {
                  familia: "Familia Rodríguez",
                  concepto: "Mensualidad Octubre",
                  monto: "$350.00",
                  vencimiento: "Vence mañana",
                  color: "text-[#ef4444]",
                },
                {
                  familia: "Familia Martínez",
                  concepto: "Mensualidad Octubre",
                  monto: "$350.00",
                  vencimiento: "Vence en 3 días",
                  color: "text-[#f59e0b]",
                },
                {
                  familia: "Familia López",
                  concepto: "Mensualidad Octubre",
                  monto: "$350.00",
                  vencimiento: "Vence en 5 días",
                  color: "text-[#3b82f6]",
                },
                {
                  familia: "Familia García",
                  concepto: "Mensualidad Octubre",
                  monto: "$350.00",
                  vencimiento: "Vence en 7 días",
                  color: "text-[#3b82f6]",
                },
              ].map((item, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between border-b border-[#e5e7eb] pb-3 last:border-b-0"
                >
                  <div>
                    <p className="text-sm font-medium text-[#1f2937]">{item.familia}</p>
                    <p className="text-xs text-[#6b7280]">{item.concepto}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium text-[#1f2937]">{item.monto}</p>
                    <p className={`text-xs ${item.color}`}>{item.vencimiento}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Actividad reciente */}
        <Card className="col-span-4 bg-white border-0 shadow-sm">
          <CardHeader>
            <CardTitle className="text-[#1f2937]">Actividad Reciente</CardTitle>
            <CardDescription className="text-[#6b7280]">Últimas transacciones registradas</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                {
                  tipo: "Pago recibido",
                  detalle: "Familia Torres - Mensualidad",
                  monto: "+$350.00",
                  fecha: "Hoy, 10:23 AM",
                  color: "text-[#10b981]",
                  bg: "bg-[#10b981]/10",
                },
                {
                  tipo: "Egreso registrado",
                  detalle: "Pago servicios - Electricidad",
                  monto: "-$120.50",
                  fecha: "Hoy, 09:15 AM",
                  color: "text-[#ef4444]",
                  bg: "bg-[#ef4444]/10",
                },
                {
                  tipo: "Factura generada",
                  detalle: "Familia Pérez - Mensualidad",
                  monto: "$350.00",
                  fecha: "Ayer, 15:42 PM",
                  color: "text-[#3b82f6]",
                  bg: "bg-[#3b82f6]/10",
                },
                {
                  tipo: "Pago recibido",
                  detalle: "Familia Díaz - Mensualidad",
                  monto: "+$350.00",
                  fecha: "Ayer, 14:10 PM",
                  color: "text-[#10b981]",
                  bg: "bg-[#10b981]/10",
                },
              ].map((item, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between border-b border-[#e5e7eb] pb-3 last:border-b-0"
                >
                  <div className="flex items-center">
                    <div className={`mr-3 h-8 w-8 rounded-full ${item.bg} flex items-center justify-center`}>
                      <DollarSign className={`h-4 w-4 ${item.color}`} />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-[#1f2937]">{item.tipo}</p>
                      <p className="text-xs text-[#6b7280]">{item.detalle}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className={`text-sm font-medium ${item.color}`}>{item.monto}</p>
                    <p className="text-xs text-[#6b7280]">{item.fecha}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Accesos rápidos */}
      <Card className="bg-white border-0 shadow-sm">
        <CardHeader>
          <CardTitle className="text-[#1f2937]">Accesos Rápidos</CardTitle>
          <CardDescription className="text-[#6b7280]">Acciones frecuentes del área contable</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-3">
            <Link href="/dashboard/contable/student-profile">
              <Button
                variant="outline"
                className="w-full justify-start h-auto p-4 border-[#4338ca]/20 hover:bg-[#4338ca]/5"
              >
                <Users className="mr-3 h-5 w-5 text-[#4338ca]" />
                <div className="text-left">
                  <div className="font-medium text-[#1f2937]">Ver Resumen por Curso</div>
                  <div className="text-sm text-[#6b7280]">Estado financiero por grado</div>
                </div>
              </Button>
            </Link>

            <Link href="/dashboard/contable/reports">
              <Button
                variant="outline"
                className="w-full justify-start h-auto p-4 border-[#8b5cf6]/20 hover:bg-[#8b5cf6]/5"
              >
                <BarChart3 className="mr-3 h-5 w-5 text-[#8b5cf6]" />
                <div className="text-left">
                  <div className="font-medium text-[#1f2937]">Generar Informe</div>
                  <div className="text-sm text-[#6b7280]">Reportes financieros</div>
                </div>
              </Button>
            </Link>

            <Link href="/dashboard/contable/accounts-receivable">
              <Button
                variant="outline"
                className="w-full justify-start h-auto p-4 border-[#d97706]/20 hover:bg-[#d97706]/5"
              >
                <CreditCard className="mr-3 h-5 w-5 text-[#d97706]" />
                <div className="text-left">
                  <div className="font-medium text-[#1f2937]">Gestionar Cobranzas</div>
                  <div className="text-sm text-[#6b7280]">Seguimiento de pagos</div>
                </div>
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
