"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Plus, FileText, Send, Download, Filter, Search, Mail, MessageSquare, Eye, Edit } from "lucide-react"

export default function BillingPage() {
  const [selectedStudent, setSelectedStudent] = useState("")
  const [concept, setConcept] = useState("")
  const [amount, setAmount] = useState("")
  const [issueDate, setIssueDate] = useState("")
  const [dueDate, setDueDate] = useState("")
  const [discount, setDiscount] = useState("")
  const [penalty, setPenalty] = useState("")

  // Datos de ejemplo
  const students = [
    { id: "1", name: "Ana García Pérez", course: "5to A", parent: "Carlos García" },
    { id: "2", name: "Luis Martínez López", course: "3ro B", parent: "María Martínez" },
    { id: "3", name: "Sofia Rodríguez", course: "2do A", parent: "Juan Rodríguez" },
    { id: "4", name: "Diego Torres", course: "4to C", parent: "Carmen Torres" },
  ]

  const invoices = [
    {
      id: "F-2024-001",
      student: "Ana García Pérez",
      course: "5to A",
      concept: "Mensualidad",
      amount: 350.0,
      issueDate: "2024-01-01",
      dueDate: "2024-01-15",
      status: "Pagado",
      paymentDate: "2024-01-10",
    },
    {
      id: "F-2024-002",
      student: "Luis Martínez López",
      course: "3ro B",
      concept: "Mensualidad",
      amount: 350.0,
      issueDate: "2024-01-01",
      dueDate: "2024-01-15",
      status: "Pendiente",
      paymentDate: null,
    },
    {
      id: "F-2024-003",
      student: "Sofia Rodríguez",
      course: "2do A",
      concept: "Materiales",
      amount: 120.0,
      issueDate: "2024-01-05",
      dueDate: "2024-01-20",
      status: "Vencido",
      paymentDate: null,
    },
    {
      id: "F-2024-004",
      student: "Diego Torres",
      course: "4to C",
      concept: "Mensualidad",
      amount: 350.0,
      issueDate: "2024-01-01",
      dueDate: "2024-01-15",
      status: "Pagado",
      paymentDate: "2024-01-12",
    },
  ]

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "Pagado":
        return <Badge className="bg-[#d1fae5] text-[#10b981] border-[#10b981]/20">Pagado</Badge>
      case "Pendiente":
        return <Badge className="bg-[#fef3c7] text-[#f59e0b] border-[#f59e0b]/20">Pendiente</Badge>
      case "Vencido":
        return <Badge className="bg-[#fee2e2] text-[#ef4444] border-[#ef4444]/20">Vencido</Badge>
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  return (
    <div className="flex-1 space-y-6 p-8 bg-[#f0f4f8]">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight text-[#1f2937]">Facturación</h2>
          <p className="text-[#6b7280]">Crear, editar y administrar facturas escolares</p>
        </div>
        <div className="flex items-center space-x-3">
          <Button variant="outline" size="sm" className="border-[#6b7280] text-[#6b7280]">
            <Download className="mr-2 h-4 w-4" />
            Exportar
          </Button>
          <Dialog>
            <DialogTrigger asChild>
              <Button size="sm" className="bg-[#4338ca] hover:bg-[#3730a3] text-white">
                <Plus className="mr-2 h-4 w-4" />
                Nueva Factura
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl bg-white">
              <DialogHeader>
                <DialogTitle className="text-[#1f2937]">Crear Nueva Factura</DialogTitle>
                <DialogDescription className="text-[#6b7280]">
                  Complete los datos para generar una nueva factura
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="student" className="text-[#1f2937]">
                      Estudiante
                    </Label>
                    <Select value={selectedStudent} onValueChange={setSelectedStudent}>
                      <SelectTrigger className="bg-white border-[#e5e7eb]">
                        <SelectValue placeholder="Seleccionar estudiante" />
                      </SelectTrigger>
                      <SelectContent className="bg-white">
                        {students.map((student) => (
                          <SelectItem key={student.id} value={student.id}>
                            {student.name} - {student.course}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="concept" className="text-[#1f2937]">
                      Concepto
                    </Label>
                    <Select value={concept} onValueChange={setConcept}>
                      <SelectTrigger className="bg-white border-[#e5e7eb]">
                        <SelectValue placeholder="Seleccionar concepto" />
                      </SelectTrigger>
                      <SelectContent className="bg-white">
                        <SelectItem value="matricula">Matrícula</SelectItem>
                        <SelectItem value="mensualidad">Mensualidad</SelectItem>
                        <SelectItem value="materiales">Materiales</SelectItem>
                        <SelectItem value="otros">Otros</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="amount" className="text-[#1f2937]">
                      Monto
                    </Label>
                    <Input
                      id="amount"
                      type="number"
                      placeholder="0.00"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      className="bg-white border-[#e5e7eb]"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="discount" className="text-[#1f2937]">
                      Descuento (%)
                    </Label>
                    <Input
                      id="discount"
                      type="number"
                      placeholder="0"
                      value={discount}
                      onChange={(e) => setDiscount(e.target.value)}
                      className="bg-white border-[#e5e7eb]"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="issueDate" className="text-[#1f2937]">
                      Fecha de Emisión
                    </Label>
                    <Input
                      id="issueDate"
                      type="date"
                      value={issueDate}
                      onChange={(e) => setIssueDate(e.target.value)}
                      className="bg-white border-[#e5e7eb]"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="dueDate" className="text-[#1f2937]">
                      Fecha de Vencimiento
                    </Label>
                    <Input
                      id="dueDate"
                      type="date"
                      value={dueDate}
                      onChange={(e) => setDueDate(e.target.value)}
                      className="bg-white border-[#e5e7eb]"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="penalty" className="text-[#1f2937]">
                    Penalidad por Mora (%)
                  </Label>
                  <Input
                    id="penalty"
                    type="number"
                    placeholder="0"
                    value={penalty}
                    onChange={(e) => setPenalty(e.target.value)}
                    className="bg-white border-[#e5e7eb]"
                  />
                </div>
              </div>
              <div className="flex justify-end space-x-2">
                <Button variant="outline">Cancelar</Button>
                <Button className="bg-[#4338ca] hover:bg-[#3730a3] text-white">
                  <FileText className="mr-2 h-4 w-4" />
                  Emitir Factura
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Tabs defaultValue="invoices" className="space-y-4">
        <TabsList className="bg-white border border-[#e5e7eb]">
          <TabsTrigger value="invoices" className="data-[state=active]:bg-[#4338ca] data-[state=active]:text-white">
            Historial de Facturas
          </TabsTrigger>
          <TabsTrigger value="templates" className="data-[state=active]:bg-[#4338ca] data-[state=active]:text-white">
            Plantillas de Cobro
          </TabsTrigger>
          <TabsTrigger value="sending" className="data-[state=active]:bg-[#4338ca] data-[state=active]:text-white">
            Envío de Facturas
          </TabsTrigger>
        </TabsList>

        <TabsContent value="invoices" className="space-y-4">
          <Card className="bg-white border-0 shadow-sm">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-[#1f2937]">Historial de Facturación</CardTitle>
                  <CardDescription className="text-[#6b7280]">Gestión completa de facturas emitidas</CardDescription>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="relative">
                    <Search className="absolute left-2 top-2.5 h-4 w-4 text-[#9ca3af]" />
                    <Input placeholder="Buscar facturas..." className="pl-8 bg-white border-[#e5e7eb]" />
                  </div>
                  <Button variant="outline" size="sm" className="border-[#6b7280] text-[#6b7280]">
                    <Filter className="mr-2 h-4 w-4" />
                    Filtros
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow className="border-[#e5e7eb]">
                    <TableHead className="text-[#6b7280]">Número</TableHead>
                    <TableHead className="text-[#6b7280]">Estudiante</TableHead>
                    <TableHead className="text-[#6b7280]">Curso</TableHead>
                    <TableHead className="text-[#6b7280]">Concepto</TableHead>
                    <TableHead className="text-[#6b7280]">Monto</TableHead>
                    <TableHead className="text-[#6b7280]">Vencimiento</TableHead>
                    <TableHead className="text-[#6b7280]">Estado</TableHead>
                    <TableHead className="text-[#6b7280]">Acciones</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {invoices.map((invoice) => (
                    <TableRow key={invoice.id} className="border-[#e5e7eb]">
                      <TableCell className="text-[#1f2937] font-medium">{invoice.id}</TableCell>
                      <TableCell className="text-[#1f2937]">{invoice.student}</TableCell>
                      <TableCell className="text-[#6b7280]">{invoice.course}</TableCell>
                      <TableCell className="text-[#6b7280]">{invoice.concept}</TableCell>
                      <TableCell className="text-[#1f2937]">${invoice.amount.toFixed(2)}</TableCell>
                      <TableCell className="text-[#6b7280]">{invoice.dueDate}</TableCell>
                      <TableCell>{getStatusBadge(invoice.status)}</TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-2">
                          <Button variant="ghost" size="sm" className="text-[#6b7280] hover:text-[#4338ca]">
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm" className="text-[#6b7280] hover:text-[#4338ca]">
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm" className="text-[#6b7280] hover:text-[#4338ca]">
                            <Send className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="templates" className="space-y-4">
          <Card className="bg-white border-0 shadow-sm">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-[#1f2937]">Plantillas de Cobro</CardTitle>
                  <CardDescription className="text-[#6b7280]">
                    Configurar cobros automáticos recurrentes
                  </CardDescription>
                </div>
                <Button size="sm" className="bg-[#4338ca] hover:bg-[#3730a3] text-white">
                  <Plus className="mr-2 h-4 w-4" />
                  Nueva Plantilla
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <Card className="bg-[#f0f4f8] border border-[#e5e7eb]">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-[#1f2937] text-lg">Mensualidad Básica</CardTitle>
                      <Switch defaultChecked />
                    </div>
                    <CardDescription className="text-[#6b7280]">
                      Cobro mensual automático para todos los grados
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-[#6b7280]">Monto:</span>
                      <span className="text-[#1f2937] font-medium">$350.00</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-[#6b7280]">Frecuencia:</span>
                      <span className="text-[#1f2937]">Mensual</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-[#6b7280]">Día de emisión:</span>
                      <span className="text-[#1f2937]">1 de cada mes</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-[#6b7280]">Vencimiento:</span>
                      <span className="text-[#1f2937]">15 días después</span>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-[#f0f4f8] border border-[#e5e7eb]">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-[#1f2937] text-lg">Matrícula Anual</CardTitle>
                      <Switch />
                    </div>
                    <CardDescription className="text-[#6b7280]">
                      Cobro anual de matrícula para estudiantes nuevos
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-[#6b7280]">Monto:</span>
                      <span className="text-[#1f2937] font-medium">$500.00</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-[#6b7280]">Frecuencia:</span>
                      <span className="text-[#1f2937]">Anual</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-[#6b7280]">Día de emisión:</span>
                      <span className="text-[#1f2937]">1 de febrero</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-[#6b7280]">Vencimiento:</span>
                      <span className="text-[#1f2937]">28 de febrero</span>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="sending" className="space-y-4">
          <Card className="bg-white border-0 shadow-sm">
            <CardHeader>
              <CardTitle className="text-[#1f2937]">Envío de Facturas</CardTitle>
              <CardDescription className="text-[#6b7280]">
                Gestionar el envío automático de facturas por email y WhatsApp
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid gap-4 md:grid-cols-2">
                <Card className="bg-[#f0f4f8] border border-[#e5e7eb]">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-[#1f2937] text-lg flex items-center">
                      <Mail className="mr-2 h-5 w-5" />
                      Envío por Email
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-[#6b7280]">Envío automático</span>
                      <Switch defaultChecked />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-[#6b7280]">Plantilla de email</Label>
                      <Select>
                        <SelectTrigger className="bg-white border-[#e5e7eb]">
                          <SelectValue placeholder="Seleccionar plantilla" />
                        </SelectTrigger>
                        <SelectContent className="bg-white">
                          <SelectItem value="basic">Plantilla básica</SelectItem>
                          <SelectItem value="detailed">Plantilla detallada</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <Button className="w-full bg-[#4338ca] hover:bg-[#3730a3] text-white">
                      <Send className="mr-2 h-4 w-4" />
                      Enviar Facturas Pendientes (28)
                    </Button>
                  </CardContent>
                </Card>

                <Card className="bg-[#f0f4f8] border border-[#e5e7eb]">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-[#1f2937] text-lg flex items-center">
                      <MessageSquare className="mr-2 h-5 w-5" />
                      Envío por WhatsApp
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-[#6b7280]">Envío automático</span>
                      <Switch />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-[#6b7280]">Mensaje personalizado</Label>
                      <Textarea
                        placeholder="Estimado padre de familia, adjuntamos la factura..."
                        className="bg-white border-[#e5e7eb]"
                        rows={3}
                      />
                    </div>
                    <Button className="w-full" variant="outline" className="border-[#6b7280] text-[#6b7280]">
                      <MessageSquare className="mr-2 h-4 w-4" />
                      Configurar WhatsApp
                    </Button>
                  </CardContent>
                </Card>
              </div>

              <Card className="bg-[#f0f4f8] border border-[#e5e7eb]">
                <CardHeader>
                  <CardTitle className="text-[#1f2937]">Historial de Envíos</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between py-2 border-b border-[#e5e7eb]">
                      <div>
                        <p className="text-[#1f2937] font-medium">Facturas de Enero 2024</p>
                        <p className="text-sm text-[#6b7280]">Enviadas por email a 45 familias</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-[#10b981]">Enviado</p>
                        <p className="text-xs text-[#6b7280]">15/01/2024 - 09:30 AM</p>
                      </div>
                    </div>
                    <div className="flex items-center justify-between py-2 border-b border-[#e5e7eb]">
                      <div>
                        <p className="text-[#1f2937] font-medium">Recordatorio de Pago</p>
                        <p className="text-sm text-[#6b7280]">WhatsApp a 12 familias con facturas vencidas</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-[#3b82f6]">Enviado</p>
                        <p className="text-xs text-[#6b7280]">20/01/2024 - 02:15 PM</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
