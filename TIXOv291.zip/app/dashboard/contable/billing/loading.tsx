export default function Loading() {
  return (
    <div className="flex-1 space-y-6 p-8 bg-[#f0f4f8]">
      <div className="animate-pulse">
        <div className="h-8 bg-gray-200 rounded w-1/3 mb-2"></div>
        <div className="h-4 bg-gray-200 rounded w-1/4"></div>
      </div>

      <div className="bg-white p-6 rounded-lg shadow-sm animate-pulse">
        <div className="h-[400px] bg-gray-200 rounded"></div>
      </div>
    </div>
  )
}
