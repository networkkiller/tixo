import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  GraduationCap,
  Users,
  BookOpen,
  Shield,
  MessageSquare,
  CreditCard,
  Settings,
  Star,
  CheckCircle,
  Brain,
  Rocket,
  LogIn,
  ChevronRight,
  BarChart3,
  Cloud,
  Smartphone,
} from "lucide-react"
import Link from "next/link"

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-[#f0f4f8]">
      {/* Header */}
      <header className="border-b border-gray-200 bg-white sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-br from-purple-600 to-blue-600 rounded-xl flex items-center justify-center">
              <GraduationCap className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-900">EduGestión360</h1>
              <p className="text-xs text-gray-500">Gestión Educativa Integral</p>
            </div>
          </div>
          <Link href="/login">
            <Button className="bg-indigo-600 hover:bg-indigo-700 text-white">Iniciar Sesión</Button>
          </Link>
        </div>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-20 text-center">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-5xl font-bold text-gray-900 mb-6">
            El Futuro de la
            <span className="text-indigo-600"> Gestión Educativa</span>
          </h2>
          <p className="text-xl text-gray-600 mb-8 leading-relaxed">
            Plataforma integral que conecta estudiantes, profesores, padres y administradores en un ecosistema educativo
            inteligente y eficiente.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/login">
              <Button size="lg" className="bg-indigo-600 hover:bg-indigo-700 text-white px-8 py-3">
                <Shield className="w-5 h-5 mr-2" />
                Acceder al Sistema
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-24 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-20">
            <Badge className="mb-6 bg-indigo-100 text-indigo-800 border-indigo-200">Tecnología Avanzada</Badge>
            <h2 className="text-5xl md:text-6xl font-bold mb-8 text-gray-900">Características del Futuro</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Descubre las funcionalidades que transformarán la gestión educativa de tu institución con tecnología de
              vanguardia
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
            {[
              {
                icon: Shield,
                title: "Seguridad Digital",
                description: "Autenticación biométrica y encriptación de nivel militar para proteger datos sensibles",
                color: "purple-400",
              },
              {
                icon: Users,
                title: "Gestión Holística",
                description: "Ecosistema unificado que conecta todos los stakeholders educativos en tiempo real",
                color: "purple-600",
              },
              {
                icon: BookOpen,
                title: "Academia Digital",
                description: "Plataforma de aprendizaje adaptativo con realidad aumentada y gamificación",
                color: "blue-600",
              },
              {
                icon: MessageSquare,
                title: "Comunicación 5.0",
                description: "Chatbots inteligentes, traducción automática y notificaciones contextuales",
                color: "purple-600",
              },
              {
                icon: CreditCard,
                title: "FinTech Educativo",
                description: "Pagos digitales, blockchain para certificados y análisis financiero predictivo",
                color: "blue-400",
              },
              {
                icon: BarChart3,
                title: "Analytics Inteligente",
                description: "Análisis predictivo de rendimiento estudiantil con inteligencia artificial avanzada",
                color: "green-500",
              },
              {
                icon: Cloud,
                title: "Nube Educativa",
                description: "Almacenamiento ilimitado en la nube con sincronización automática y acceso global",
                color: "cyan-500",
              },
              {
                icon: Smartphone,
                title: "Movilidad Total",
                description: "Aplicaciones móviles nativas para iOS y Android con funcionalidad offline",
                color: "orange-500",
              },
            ].map((feature, index) => (
              <Card
                key={index}
                className="group bg-white border border-gray-200 transition-all duration-500 hover:shadow-lg hover:-translate-y-2"
              >
                <CardHeader className="pb-4">
                  <div className="w-14 h-14 bg-indigo-100 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                    <feature.icon className="w-7 h-7 text-indigo-600" />
                  </div>
                  <CardTitle className="text-gray-900 text-xl group-hover:text-indigo-600 transition-colors">
                    {feature.title}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-gray-600 leading-relaxed">{feature.description}</CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Roles Section */}
      <section id="roles" className="py-24 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-20">
            <Badge className="mb-6 bg-indigo-100 text-indigo-800 border-indigo-200">Roles Inteligentes</Badge>
            <h2 className="text-5xl md:text-6xl font-bold mb-8 text-gray-900">Permisos Adaptativos</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Cada usuario tiene una experiencia personalizada con IA que se adapta a sus necesidades y comportamientos
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {[
              {
                role: "Super Admin",
                icon: Settings,
                gradient: "from-purple-600 to-blue-600",
                features: [
                  "Control Total del Ecosistema",
                  "Analytics Multitenant",
                  "IA de Optimización Global",
                  "Seguridad Avanzada",
                  "Soporte Predictivo",
                ],
                badge: "Nivel Máximo",
                badgeColor: "purple-400",
              },
              {
                role: "Director",
                icon: Brain,
                gradient: "from-purple-400 to-blue-400",
                features: [
                  "Dashboard Ejecutivo IA",
                  "Gestión Académica Integral",
                  "Análisis Predictivo",
                  "Comunicación Masiva",
                  "Reportes Automáticos",
                ],
                badge: "Liderazgo",
                badgeColor: "blue-400",
              },
              {
                role: "Profesor",
                icon: GraduationCap,
                gradient: "from-purple-600 to-blue-600",
                features: [
                  "Aula Virtual Inmersiva",
                  "IA de Evaluación",
                  "Gamificación Adaptativa",
                  "Comunicación Inteligente",
                  "Recursos Personalizados",
                ],
                badge: "Educador",
                badgeColor: "purple-400",
              },
              {
                role: "Padre de Familia",
                icon: Users,
                gradient: "from-purple-400 to-blue-400",
                features: [
                  "Seguimiento en Tiempo Real",
                  "Alertas Inteligentes",
                  "Comunicación Directa",
                  "Progreso Visualizado",
                  "Pagos Automatizados",
                ],
                badge: "Familia",
                badgeColor: "blue-400",
              },
              {
                role: "Contable",
                icon: CreditCard,
                gradient: "from-purple-400 to-blue-400",
                features: [
                  "Gestión Financiera",
                  "Certificados Digitales",
                  "Análisis Económico",
                  "Pagos Seguros",
                  "Reportes Financieros",
                ],
                badge: "Finanzas",
                badgeColor: "purple-600",
              },
              {
                role: "Coordinador de Registro",
                icon: Users,
                gradient: "from-teal-500 to-cyan-500",
                features: [
                  "Gestión de Estudiantes",
                  "Coordinación Académica",
                  "Seguimiento Disciplinario",
                  "Comunicación Institucional",
                  "Reportes de Progreso",
                ],
                badge: "Coordinación",
                badgeColor: "teal-400",
              },
              {
                role: "Coordinador Académico",
                icon: BookOpen,
                gradient: "from-indigo-500 to-purple-500",
                features: [
                  "Planificación Curricular",
                  "Asignación de Profesores",
                  "Monitoreo de Calificaciones",
                  "Calendario Académico",
                  "Reportes Académicos",
                ],
                badge: "Academia",
                badgeColor: "indigo-400",
              },
            ].map((userRole, index) => (
              <Card
                key={index}
                className="group bg-white border border-gray-200 transition-all duration-500 hover:shadow-lg hover:-translate-y-3 relative overflow-hidden"
              >
                {/* Background Gradient */}
                <div
                  className={`absolute inset-0 bg-gradient-to-br ${userRole.gradient} opacity-5 group-hover:opacity-10 transition-opacity duration-500`}
                ></div>

                <CardHeader className="text-center relative z-10">
                  <div
                    className={`w-20 h-20 bg-gradient-to-br ${userRole.gradient} rounded-3xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300 shadow-xl`}
                  >
                    <userRole.icon className="w-10 h-10 text-white" />
                  </div>

                  <Badge className={`mb-4 bg-${userRole.badgeColor}/10 text-white border-white/10`}>
                    {userRole.badge}
                  </Badge>

                  <CardTitle className="text-gray-900 text-2xl group-hover:text-indigo-600 transition-colors">
                    {userRole.role}
                  </CardTitle>
                </CardHeader>

                <CardContent className="relative z-10">
                  <ul className="space-y-3">
                    {userRole.features.map((feature, featureIndex) => (
                      <li
                        key={featureIndex}
                        className="flex items-center text-gray-600 group-hover:text-gray-900 transition-colors"
                      >
                        <CheckCircle className="w-5 h-5 text-indigo-600 mr-3 flex-shrink-0" />
                        <span className="text-sm font-medium">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-white">
        <div className="container mx-auto px-4">
          <div className="relative bg-indigo-50 rounded-3xl p-16 text-center border border-indigo-100 overflow-hidden">
            {/* Background Elements */}
            <div className="absolute top-0 left-0 w-full h-full">
              <div className="absolute top-10 left-10 w-32 h-32 bg-purple-400/10 rounded-full blur-2xl"></div>
              <div className="absolute bottom-10 right-10 w-40 h-40 bg-blue-400/10 rounded-full blur-2xl"></div>
            </div>

            <div className="relative z-10">
              <Badge className="mb-8 bg-indigo-100 text-indigo-800 border-indigo-200 px-6 py-2">
                <Star className="w-4 h-4 mr-2" />
                Únete a la Revolución Educativa
              </Badge>

              <h2 className="text-5xl md:text-6xl font-bold mb-8 text-gray-900">El Futuro es Ahora</h2>

              <p className="text-xl text-gray-600 mb-12 max-w-3xl mx-auto leading-relaxed">
                Únete a más de 500 instituciones educativas que ya están transformando la educación con
                <span className="text-indigo-600 font-semibold"> EduGestión360</span>. La próxima generación de
                estudiantes te está esperando.
              </p>

              <div className="flex flex-col sm:flex-row gap-6 justify-center">
                <Button
                  size="lg"
                  className="bg-indigo-600 hover:bg-indigo-700 text-white px-12 py-4 shadow-lg transition-all duration-300 group"
                >
                  <Rocket className="w-6 h-6 mr-3 group-hover:animate-bounce" />
                  Comenzar Prueba Gratuita
                  <ChevronRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                </Button>

                <Link href="/login">
                  <Button
                    size="lg"
                    variant="outline"
                    className="border-2 border-indigo-200 text-indigo-600 hover:bg-indigo-50 text-lg px-12 py-4 bg-transparent"
                  >
                    <LogIn className="w-5 h-5 mr-3" />
                    Acceder al Sistema
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-gray-200 mt-20 text-gray-800 py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-12">
            <div className="md:col-span-2">
              <div className="flex items-center space-x-3 mb-6">
                <div className="w-12 h-12 bg-gradient-to-br from-purple-600 to-blue-600 rounded-xl flex items-center justify-center">
                  <GraduationCap className="w-7 h-7 text-white" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-gray-900">EduGestión360</h1>
                  <p className="text-xs text-gray-500">Gestión Educativa Integral</p>
                </div>
              </div>
              <p className="text-gray-600 leading-relaxed max-w-md">
                Revolucionando la educación con inteligencia artificial, análisis predictivo y una experiencia de
                usuario excepcional.
              </p>
            </div>

            <div>
              <h3 className="text-gray-900 font-semibold mb-6">Producto</h3>
              <ul className="space-y-3 text-gray-600">
                <li>
                  <Link href="#" className="hover:text-indigo-600 transition-colors">
                    Características
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-indigo-600 transition-colors">
                    Precios
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-indigo-600 transition-colors">
                    Integraciones
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-indigo-600 transition-colors">
                    API
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="text-gray-900 font-semibold mb-6">Soporte</h3>
              <ul className="space-y-3 text-gray-600">
                <li>
                  <Link href="#" className="hover:text-indigo-600 transition-colors">
                    Centro de Ayuda
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-indigo-600 transition-colors">
                    Documentación
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-indigo-600 transition-colors">
                    Contacto
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-indigo-600 transition-colors">
                    Estado del Sistema
                  </Link>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-200 mt-12 pt-8 text-center text-gray-500">
            <p>&copy; 2024 EduGestión360. Todos los derechos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
