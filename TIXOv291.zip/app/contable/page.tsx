import Link from "next/link"

export default function ContablePage() {
  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-800">Panel Contable</h1>
            <p className="text-gray-600">Gestión Financiera - Colegio San Patricio</p>
          </div>
          <Link href="/" className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700">
            Volver al inicio
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white p-4 rounded-lg shadow-md border border-gray-200">
            <h3 className="text-sm font-medium text-gray-500">Total Facturado</h3>
            <p className="text-2xl font-bold">$45,231.89</p>
            <span className="text-xs text-green-600">+20.1% vs mes anterior</span>
          </div>

          <div className="bg-white p-4 rounded-lg shadow-md border border-gray-200">
            <h3 className="text-sm font-medium text-gray-500">Total Recaudado</h3>
            <p className="text-2xl font-bold">$32,845.50</p>
            <span className="text-xs text-green-600">+12.4% vs mes anterior</span>
          </div>

          <div className="bg-white p-4 rounded-lg shadow-md border border-gray-200">
            <h3 className="text-sm font-medium text-gray-500">Deudas Pendientes</h3>
            <p className="text-2xl font-bold">$12,386.39</p>
            <div className="flex space-x-2 text-xs">
              <span className="text-amber-600">Por vencer: $8,245.12</span>
              <span className="text-red-600">Vencidas: $4,141.27</span>
            </div>
          </div>

          <div className="bg-white p-4 rounded-lg shadow-md border border-gray-200">
            <h3 className="text-sm font-medium text-gray-500">Egresos del Mes</h3>
            <p className="text-2xl font-bold">$28,419.75</p>
            <span className="text-xs text-red-600">+8.2% vs mes anterior</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div className="bg-white p-6 rounded-lg shadow-md border border-gray-200">
            <h2 className="text-xl font-bold mb-4">Facturación</h2>
            <p className="text-gray-600 mb-4">Gestión de facturas y cobros</p>
            <div className="bg-gray-100 h-40 rounded-lg flex items-center justify-center text-gray-400">
              Contenido del módulo
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-md border border-gray-200">
            <h2 className="text-xl font-bold mb-4">Cuentas por Cobrar</h2>
            <p className="text-gray-600 mb-4">Seguimiento de pagos pendientes</p>
            <div className="bg-gray-100 h-40 rounded-lg flex items-center justify-center text-gray-400">
              Contenido del módulo
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-md border border-gray-200">
            <h2 className="text-xl font-bold mb-4">Informes</h2>
            <p className="text-gray-600 mb-4">Reportes financieros</p>
            <div className="bg-gray-100 h-40 rounded-lg flex items-center justify-center text-gray-400">
              Contenido del módulo
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
