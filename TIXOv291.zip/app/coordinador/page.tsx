"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/contexts/auth-context"

export default function CoordinadorPage() {
  const router = useRouter()
  const { user } = useAuth()

  useEffect(() => {
    if (user && user.role === "coordinador") {
      router.push("/dashboard/coordinador")
    } else {
      router.push("/login")
    }
  }, [user, router])

  return null
}
