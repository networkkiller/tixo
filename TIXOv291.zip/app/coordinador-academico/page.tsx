"use client"

import { redirect } from "next/navigation"
import { useAuth } from "@/contexts/auth-context"

export default function CoordinadorAcademicoPage() {
  const { user } = useAuth()

  if (user && user.role === "coordinador-academico") {
    redirect("/dashboard/coordinador-academico")
  } else {
    redirect("/login")
  }
}
