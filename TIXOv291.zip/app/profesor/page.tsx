import Link from "next/link"

export default function ProfesorPage() {
  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-800">Panel Profesor</h1>
            <p className="text-gray-600">María González - Colegio San Patricio</p>
          </div>
          <Link href="/" className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700">
            Volver al inicio
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div className="bg-white p-6 rounded-lg shadow-md border border-gray-200">
            <h2 className="text-xl font-bold mb-4">Mis Cursos</h2>
            <p className="text-gray-600 mb-4">Gestión de clases y materias</p>
            <div className="bg-gray-100 h-40 rounded-lg flex items-center justify-center text-gray-400">
              Contenido del módulo
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-md border border-gray-200">
            <h2 className="text-xl font-bold mb-4">Calificaciones</h2>
            <p className="text-gray-600 mb-4">Registro y gestión de notas</p>
            <div className="bg-gray-100 h-40 rounded-lg flex items-center justify-center text-gray-400">
              Contenido del módulo
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-md border border-gray-200">
            <h2 className="text-xl font-bold mb-4">Comunicación</h2>
            <p className="text-gray-600 mb-4">Mensajes a estudiantes y padres</p>
            <div className="bg-gray-100 h-40 rounded-lg flex items-center justify-center text-gray-400">
              Contenido del módulo
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
