import type { User } from "@/types"

// Mock user database
const users: User[] = [
  {
    id: "1",
    name: "Carlos Rodríguez",
    email: "admin@edugestion360.com",
    role: "super-admin",
    school: "EduGestión360 - Sistema Central",
  },
  {
    id: "2",
    name: "María González",
    email: "director@edugestion360.com",
    role: "director",
    school: "Colegio San José",
  },
  {
    id: "3",
    name: "Ana Martínez",
    email: "profesor@edugestion360.com",
    role: "profesor",
    school: "Colegio San José",
  },
  {
    id: "4",
    name: "Luis Pérez",
    email: "padre@edugestion360.com",
    role: "padre",
    school: "Colegio San José",
  },
  {
    id: "5",
    name: "Carmen López",
    email: "contable@edugestion360.com",
    role: "contable",
    school: "Colegio San José",
  },
  {
    id: "6",
    name: "Roberto Jiménez",
    email: "coordinador@edugestion360.com",
    role: "coordinador",
    school: "Colegio San José",
  },
  {
    id: "7",
    name: "Patricia Morales",
    email: "coordinador-academico@edugestion360.com",
    role: "coordinador-academico",
    school: "Colegio San José",
  },
  {
    id: "8",
    name: "Sandra Vásquez",
    email: "secretario@edugestion360.com",
    role: "secretario",
    school: "Colegio San José",
  },
]

export async function authenticateUser(email: string, password: string): Promise<User | null> {
  console.log("🔐 Attempting authentication for:", email)
  console.log("🔐 Password provided:", password)

  // Simulate API call delay
  await new Promise((resolve) => setTimeout(resolve, 1000))

  // Find user by email
  const user = users.find((u) => u.email === email)
  console.log("🔐 Found user:", user)

  if (user) {
    // Define expected passwords for each role
    const passwordMap: Record<string, string> = {
      "super-admin": "super-admin123",
      director: "director123",
      profesor: "profesor123",
      padre: "padre123",
      contable: "contable123",
      coordinador: "coordinador123",
      "coordinador-academico": "coordinador-academico123",
      secretario: "secretario123",
    }

    const expectedPassword = passwordMap[user.role]
    console.log("🔐 Expected password:", expectedPassword)

    if (password === expectedPassword) {
      console.log("✅ Authentication successful")
      return user
    }
  }

  console.log("❌ Authentication failed")
  return null
}

export function login(email: string, password: string): Promise<User | null> {
  return authenticateUser(email, password)
}

export function logout(): void {
  if (typeof window !== "undefined") {
    localStorage.removeItem("currentUser")
  }
}

export function getCurrentUser(): User | null {
  if (typeof window !== "undefined") {
    const stored = localStorage.getItem("currentUser")
    if (stored) {
      try {
        return JSON.parse(stored)
      } catch {
        return null
      }
    }
  }
  return null
}

export function setCurrentUser(user: User | null): void {
  if (typeof window !== "undefined") {
    if (user) {
      localStorage.setItem("currentUser", JSON.stringify(user))
    } else {
      localStorage.removeItem("currentUser")
    }
  }
}
