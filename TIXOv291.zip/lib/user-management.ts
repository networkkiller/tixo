import type { User } from "@/types"

// Función para crear automáticamente el usuario director al crear un colegio
export function createDirectorUser(schoolData: {
  id: string
  name: string
  directorName: string
  directorPhone: string
  email?: string
}) {
  const directorEmail = schoolData.email || `director@${schoolData.name.toLowerCase().replace(/\s+/g, "")}.edu`

  const directorUser: User = {
    id: `dir_${schoolData.id}_${Date.now()}`,
    name: schoolData.directorName,
    email: directorEmail,
    role: "director",
    school: schoolData.name,
    avatar: undefined,
  }

  // Aquí se integraría con la base de datos para crear el usuario
  console.log("🏫 Creating director user automatically:", directorUser)

  return directorUser
}

// Función para generar contraseña temporal
export function generateTemporaryPassword(length = 8): string {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
  let password = ""
  for (let i = 0; i < length; i++) {
    password += chars.charAt(Math.floor(Math.random() * chars.length))
  }
  return password
}

// Función para validar datos de usuario
export function validateUserData(userData: {
  name: string
  email: string
  phone: string
  school: string
  role: string
}) {
  const errors: string[] = []

  if (!userData.name || userData.name.trim().length < 2) {
    errors.push("El nombre debe tener al menos 2 caracteres")
  }

  if (!userData.email || !isValidEmail(userData.email)) {
    errors.push("El correo electrónico no es válido")
  }

  if (!userData.phone || userData.phone.trim().length < 10) {
    errors.push("El teléfono debe tener al menos 10 caracteres")
  }

  if (!userData.school) {
    errors.push("Debe seleccionar un colegio")
  }

  if (!userData.role) {
    errors.push("Debe seleccionar un rol")
  }

  return {
    isValid: errors.length === 0,
    errors,
  }
}

// Función para validar email
function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  return emailRegex.test(email)
}

// Función para obtener permisos por rol
export function getPermissionsByRole(role: string): string[] {
  const rolePermissions: Record<string, string[]> = {
    director: ["all_modules", "user_management", "reports", "settings", "billing", "academic_oversight"],
    "coordinador-academico": [
      "academic_modules",
      "curriculum",
      "teacher_management",
      "student_tracking",
      "grade_monitoring",
    ],
    "coordinador-registro": ["student_records", "enrollment", "documentation", "attendance", "parent_communication"],
    profesor: ["teaching_modules", "grades", "attendance", "assignments", "student_communication"],
    padre: ["student_tracking", "communication", "payments", "grade_view", "attendance_view"],
    contable: ["financial_modules", "billing", "reports", "payments", "expenses"],
    estudiante: ["student_portal", "assignments", "grades_view", "schedule", "resources"],
  }

  return rolePermissions[role] || []
}

// Función para procesar importación masiva
export function processUserImport(csvData: string): {
  success: boolean
  processedUsers: any[]
  errors: string[]
} {
  const errors: string[] = []
  const processedUsers: any[] = []

  try {
    const lines = csvData.split("\n")
    const headers = lines[0].split(",").map((h) => h.trim())

    // Validar headers requeridos
    const requiredHeaders = ["name", "email", "phone", "school", "role"]
    const missingHeaders = requiredHeaders.filter((h) => !headers.includes(h))

    if (missingHeaders.length > 0) {
      errors.push(`Faltan columnas requeridas: ${missingHeaders.join(", ")}`)
      return { success: false, processedUsers: [], errors }
    }

    // Procesar cada línea
    for (let i = 1; i < lines.length; i++) {
      const line = lines[i].trim()
      if (!line) continue

      const values = line.split(",").map((v) => v.trim())
      const userData: any = {}

      headers.forEach((header, index) => {
        userData[header] = values[index] || ""
      })

      // Validar datos del usuario
      const validation = validateUserData(userData)
      if (!validation.isValid) {
        errors.push(`Línea ${i + 1}: ${validation.errors.join(", ")}`)
        continue
      }

      // Generar contraseña temporal
      userData.password = generateTemporaryPassword()
      userData.status = "Pendiente"
      userData.isAutoCreated = false

      processedUsers.push(userData)
    }

    return {
      success: errors.length === 0,
      processedUsers,
      errors,
    }
  } catch (error) {
    return {
      success: false,
      processedUsers: [],
      errors: ["Error al procesar el archivo CSV"],
    }
  }
}

// Función para exportar usuarios
export function exportUsersToCSV(users: any[]): string {
  const headers = [
    "Iniciales",
    "Nombre",
    "Correo",
    "Rol",
    "Colegio",
    "Estado",
    "Último Acceso",
    "Fecha Creación",
    "Teléfono",
  ]

  const csvContent = [
    headers.join(","),
    ...users.map((user) =>
      [
        user.initials,
        user.name,
        user.email,
        user.role,
        user.school,
        user.status,
        user.lastAccess,
        user.createdAt,
        user.phone,
      ].join(","),
    ),
  ].join("\n")

  return csvContent
}

// Función para obtener estadísticas de usuarios
export function getUserStatistics(users: any[]) {
  const totalUsers = users.length
  const activeUsers = users.filter((u) => u.status === "Activo").length
  const inactiveUsers = users.filter((u) => u.status === "Inactivo").length
  const pendingUsers = users.filter((u) => u.status === "Pendiente").length

  // Estadísticas por rol
  const roleStats = users.reduce((acc, user) => {
    acc[user.role] = (acc[user.role] || 0) + 1
    return acc
  }, {})

  // Estadísticas por colegio
  const schoolStats = users.reduce((acc, user) => {
    acc[user.school] = (acc[user.school] || 0) + 1
    return acc
  }, {})

  // Usuarios creados automáticamente
  const autoCreatedUsers = users.filter((u) => u.isAutoCreated).length

  return {
    total: totalUsers,
    active: activeUsers,
    inactive: inactiveUsers,
    pending: pendingUsers,
    activationRate: totalUsers > 0 ? Math.round((activeUsers / totalUsers) * 100) : 0,
    roleDistribution: roleStats,
    schoolDistribution: schoolStats,
    autoCreated: autoCreatedUsers,
    manuallyCreated: totalUsers - autoCreatedUsers,
  }
}
