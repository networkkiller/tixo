export interface Course {
  id: string
  name: string
  grade: string
  level: string
  modality: string
  section: string
  turn: string
  capacity: number
  teacher?: string | null
  schoolYear: string
  notes: string
  createdAt: string
  createdBy: string
  status: "active" | "inactive"
  studentsCount: number
  subjectsCount: number

  // Estados de configuración
  configurationStatus: {
    hasSubjects: boolean
    hasTeacher: boolean
    hasSchedule: boolean
    hasStudents: boolean
    isComplete: boolean
    completionPercentage: number
  }
}

export interface CourseNotification {
  id: string
  type: "course_created" | "course_updated" | "configuration_pending" | "capacity_full"
  courseId: string
  courseName: string
  targetRole: "coordinador-academico" | "coordinador" | "director"
  message: string
  isRead: boolean
  createdAt: string
  priority: "high" | "medium" | "low"
}

export interface CourseStateUpdate {
  courseId: string
  field: "subjects" | "teacher" | "schedule" | "students"
  value: boolean | number
  updatedBy: string
  updatedAt: string
}

// Servicio de interoperabilidad de cursos
export class CourseInteroperabilityService {
  // Crear curso y disparar notificaciones
  static async createCourse(courseData: Omit<Course, "id" | "createdAt" | "configurationStatus">): Promise<Course> {
    const newCourse: Course = {
      ...courseData,
      id: `course_${Date.now()}`,
      createdAt: new Date().toISOString(),
      configurationStatus: {
        hasSubjects: false,
        hasTeacher: !!courseData.teacher && courseData.teacher !== "unassigned",
        hasSchedule: false,
        hasStudents: false,
        isComplete: false,
        completionPercentage: 0,
      },
    }

    // Calcular porcentaje de completitud inicial
    newCourse.configurationStatus.completionPercentage = this.calculateCompletionPercentage(newCourse)

    // Guardar curso (simulado)
    await this.saveCourse(newCourse)

    // Disparar notificaciones automáticas
    await this.triggerCourseCreationNotifications(newCourse)

    return newCourse
  }

  // Calcular porcentaje de completitud
  static calculateCompletionPercentage(course: Course): number {
    const checks = [
      course.configurationStatus.hasSubjects,
      course.configurationStatus.hasTeacher,
      course.configurationStatus.hasSchedule,
      course.configurationStatus.hasStudents,
    ]

    const completedChecks = checks.filter(Boolean).length
    return Math.round((completedChecks / checks.length) * 100)
  }

  // Obtener estado visual del curso
  static getCourseStatusBadge(course: Course): { color: string; text: string; icon: string } {
    const percentage = course.configurationStatus.completionPercentage

    if (percentage === 100) {
      return { color: "bg-green-100 text-green-800 border-green-200", text: "🟢 Completo", icon: "✅" }
    } else if (percentage >= 50) {
      return { color: "bg-yellow-100 text-yellow-800 border-yellow-200", text: "🟡 Incompleto", icon: "⚠️" }
    } else {
      return { color: "bg-red-100 text-red-800 border-red-200", text: "🔴 Pendiente", icon: "❌" }
    }
  }

  // Disparar notificaciones tras creación
  static async triggerCourseCreationNotifications(course: Course): Promise<void> {
    const notifications: CourseNotification[] = []

    // Notificación al Coordinador Académico
    notifications.push({
      id: `notif_${Date.now()}_academic`,
      type: "course_created",
      courseId: course.id,
      courseName: course.name,
      targetRole: "coordinador-academico",
      message: `Se ha creado el curso ${course.name}. Debes configurar materias y docentes.`,
      isRead: false,
      createdAt: new Date().toISOString(),
      priority: "high",
    })

    // Notificación al Coordinador de Registro
    notifications.push({
      id: `notif_${Date.now()}_registro`,
      type: "course_created",
      courseId: course.id,
      courseName: course.name,
      targetRole: "coordinador",
      message: `El curso ${course.name} ha sido creado. Puedes proceder a asignar estudiantes reinscritos.`,
      isRead: false,
      createdAt: new Date().toISOString(),
      priority: "medium",
    })

    // Enviar notificaciones
    await this.sendNotifications(notifications)
  }

  // Actualizar estado del curso
  static async updateCourseConfiguration(
    courseId: string,
    updates: Partial<Course["configurationStatus"]>,
    updatedBy: string,
  ): Promise<void> {
    const course = await this.getCourseById(courseId)
    if (!course) return

    // Actualizar configuración
    course.configurationStatus = { ...course.configurationStatus, ...updates }
    course.configurationStatus.completionPercentage = this.calculateCompletionPercentage(course)
    course.configurationStatus.isComplete = course.configurationStatus.completionPercentage === 100

    // Guardar cambios
    await this.saveCourse(course)

    // Registrar cambio
    const stateUpdate: CourseStateUpdate = {
      courseId,
      field: Object.keys(updates)[0] as any,
      value: Object.values(updates)[0] as any,
      updatedBy,
      updatedAt: new Date().toISOString(),
    }

    await this.logStateUpdate(stateUpdate)

    // Notificar cambios críticos
    await this.checkAndNotifyCriticalUpdates(course)
  }

  // Verificar y notificar actualizaciones críticas
  static async checkAndNotifyCriticalUpdates(course: Course): Promise<void> {
    const notifications: CourseNotification[] = []

    // Curso completamente configurado
    if (course.configurationStatus.isComplete) {
      notifications.push({
        id: `notif_${Date.now()}_complete`,
        type: "course_updated",
        courseId: course.id,
        courseName: course.name,
        targetRole: "director",
        message: `El curso ${course.name} ha sido completamente configurado y está listo.`,
        isRead: false,
        createdAt: new Date().toISOString(),
        priority: "low",
      })
    }

    // Capacidad completa
    if (course.studentsCount >= course.capacity) {
      notifications.push({
        id: `notif_${Date.now()}_full`,
        type: "capacity_full",
        courseId: course.id,
        courseName: course.name,
        targetRole: "director",
        message: `El curso ${course.name} ha alcanzado su capacidad máxima (${course.capacity} estudiantes).`,
        isRead: false,
        createdAt: new Date().toISOString(),
        priority: "medium",
      })
    }

    if (notifications.length > 0) {
      await this.sendNotifications(notifications)
    }
  }

  // Obtener cursos por estado para cada perfil
  static async getCoursesForAcademicCoordinator(): Promise<{
    newCourses: Course[]
    pendingConfiguration: Course[]
    configured: Course[]
  }> {
    const allCourses = await this.getAllCourses()

    return {
      newCourses: allCourses.filter((c) => c.configurationStatus.completionPercentage === 0),
      pendingConfiguration: allCourses.filter(
        (c) => c.configurationStatus.completionPercentage > 0 && c.configurationStatus.completionPercentage < 100,
      ),
      configured: allCourses.filter((c) => c.configurationStatus.isComplete),
    }
  }

  static async getCoursesForRegistrationCoordinator(): Promise<{
    availableForStudents: Course[]
    partiallyFilled: Course[]
    atCapacity: Course[]
  }> {
    const allCourses = await this.getAllCourses()

    return {
      availableForStudents: allCourses.filter((c) => c.studentsCount === 0),
      partiallyFilled: allCourses.filter((c) => c.studentsCount > 0 && c.studentsCount < c.capacity),
      atCapacity: allCourses.filter((c) => c.studentsCount >= c.capacity),
    }
  }

  // Validaciones automáticas
  static validateCourseForStudentAssignment(course: Course): {
    canAssign: boolean
    warnings: string[]
    blockers: string[]
  } {
    const warnings: string[] = []
    const blockers: string[] = []

    // Validar capacidad
    if (course.studentsCount >= course.capacity) {
      blockers.push("El curso ha alcanzado su capacidad máxima")
    }

    // Validar configuración académica
    if (!course.configurationStatus.hasSubjects) {
      warnings.push("El curso no tiene materias configuradas")
    }

    if (!course.configurationStatus.hasSchedule) {
      warnings.push("El curso no tiene horario generado")
    }

    if (!course.configurationStatus.hasTeacher) {
      warnings.push("El curso no tiene docente encargado asignado")
    }

    // Validar año escolar
    const currentYear = new Date().getFullYear()
    if (!course.schoolYear.includes(currentYear.toString())) {
      blockers.push("El curso no pertenece al año escolar activo")
    }

    return {
      canAssign: blockers.length === 0,
      warnings,
      blockers,
    }
  }

  // Métodos auxiliares (simulados)
  private static async saveCourse(course: Course): Promise<void> {
    // Simular guardado en base de datos
    console.log("💾 Guardando curso:", course.name)
  }

  private static async getCourseById(id: string): Promise<Course | null> {
    // Simular búsqueda en base de datos
    return null
  }

  private static async getAllCourses(): Promise<Course[]> {
    // Simular obtención de todos los cursos
    return []
  }

  private static async sendNotifications(notifications: CourseNotification[]): Promise<void> {
    // Simular envío de notificaciones
    notifications.forEach((notif) => {
      console.log(`📧 Notificación enviada a ${notif.targetRole}: ${notif.message}`)
    })
  }

  private static async logStateUpdate(update: CourseStateUpdate): Promise<void> {
    // Simular registro de cambios
    console.log("📝 Cambio registrado:", update)
  }
}
