export interface Subject {
  id: string
  name: string
  code: string
  area: string
  type: "obligatoria" | "optativa"
  weeklyHours: number
  description: string
  minerdCode?: string
  isActive: boolean
  createdAt: string
  updatedAt: string
}

export interface CourseSubject {
  id: string
  courseId: string
  subjectId: string
  subject: Subject
  order: number
  isAssigned: boolean
  hasGrades: boolean
  teacherId?: string
  teacherName?: string
  status: "pending" | "assigned" | "active"
}

export interface SubjectCatalog {
  inicial: Subject[]
  primaria: Subject[]
  secundaria: Subject[]
}

// Catálogo base de materias según MINERD
export const MINERD_SUBJECTS_CATALOG: SubjectCatalog = {
  inicial: [
    {
      id: "ini_001",
      name: "Desarrollo Personal y Social",
      code: "DPS-INI",
      area: "Desarrollo Integral",
      type: "obligatoria",
      weeklyHours: 8,
      description: "Desarrollo de habilidades sociales y emocionales",
      minerdCode: "DPS-001",
      isActive: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: "ini_002",
      name: "Desarrollo de la Comunicación",
      code: "DCO-INI",
      area: "Comunicación",
      type: "obligatoria",
      weeklyHours: 6,
      description: "Desarrollo del lenguaje oral y escrito",
      minerdCode: "DCO-001",
      isActive: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: "ini_003",
      name: "Desarrollo del Pensamiento Lógico-Matemático",
      code: "DPL-INI",
      area: "Matemáticas",
      type: "obligatoria",
      weeklyHours: 5,
      description: "Conceptos básicos de matemáticas y lógica",
      minerdCode: "DPL-001",
      isActive: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: "ini_004",
      name: "Desarrollo Artístico",
      code: "DAR-INI",
      area: "Artística",
      type: "obligatoria",
      weeklyHours: 4,
      description: "Expresión artística y creatividad",
      minerdCode: "DAR-001",
      isActive: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: "ini_005",
      name: "Desarrollo Físico y Motricidad",
      code: "DFM-INI",
      area: "Educación Física",
      type: "obligatoria",
      weeklyHours: 3,
      description: "Desarrollo motor y actividad física",
      minerdCode: "DFM-001",
      isActive: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
  ],
  primaria: [
    {
      id: "pri_001",
      name: "Lengua Española",
      code: "LEN-PRI",
      area: "Lenguas",
      type: "obligatoria",
      weeklyHours: 8,
      description: "Comprensión lectora, expresión oral y escrita",
      minerdCode: "LEN-001",
      isActive: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: "pri_002",
      name: "Matemática",
      code: "MAT-PRI",
      area: "Matemáticas",
      type: "obligatoria",
      weeklyHours: 8,
      description: "Aritmética, geometría y resolución de problemas",
      minerdCode: "MAT-001",
      isActive: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: "pri_003",
      name: "Ciencias de la Naturaleza",
      code: "CNA-PRI",
      area: "Ciencias",
      type: "obligatoria",
      weeklyHours: 4,
      description: "Conocimiento del medio natural y científico",
      minerdCode: "CNA-001",
      isActive: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: "pri_004",
      name: "Ciencias Sociales",
      code: "CSO-PRI",
      area: "Sociales",
      type: "obligatoria",
      weeklyHours: 4,
      description: "Historia, geografía y educación cívica",
      minerdCode: "CSO-001",
      isActive: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: "pri_005",
      name: "Lenguas Extranjeras (Inglés)",
      code: "ING-PRI",
      area: "Lenguas",
      type: "obligatoria",
      weeklyHours: 3,
      description: "Inglés básico comunicacional",
      minerdCode: "ING-001",
      isActive: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: "pri_006",
      name: "Educación Artística",
      code: "ART-PRI",
      area: "Artística",
      type: "obligatoria",
      weeklyHours: 2,
      description: "Música, artes plásticas y expresión corporal",
      minerdCode: "ART-001",
      isActive: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: "pri_007",
      name: "Educación Física",
      code: "EDF-PRI",
      area: "Educación Física",
      type: "obligatoria",
      weeklyHours: 2,
      description: "Actividad física y deportes",
      minerdCode: "EDF-001",
      isActive: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: "pri_008",
      name: "Formación Integral Humana y Religiosa",
      code: "FIH-PRI",
      area: "Formación Humana",
      type: "obligatoria",
      weeklyHours: 2,
      description: "Valores, ética y formación religiosa",
      minerdCode: "FIH-001",
      isActive: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: "pri_009",
      name: "Educación Tecnológica",
      code: "TEC-PRI",
      area: "Tecnología",
      type: "optativa",
      weeklyHours: 2,
      description: "Introducción a la tecnología y computación",
      minerdCode: "TEC-001",
      isActive: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
  ],
  secundaria: [
    {
      id: "sec_001",
      name: "Lengua Española",
      code: "LEN-SEC",
      area: "Lenguas",
      type: "obligatoria",
      weeklyHours: 6,
      description: "Literatura, gramática y comunicación avanzada",
      minerdCode: "LEN-SEC-001",
      isActive: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: "sec_002",
      name: "Matemática",
      code: "MAT-SEC",
      area: "Matemáticas",
      type: "obligatoria",
      weeklyHours: 6,
      description: "Álgebra, geometría y trigonometría",
      minerdCode: "MAT-SEC-001",
      isActive: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: "sec_003",
      name: "Ciencias de la Naturaleza",
      code: "CNA-SEC",
      area: "Ciencias",
      type: "obligatoria",
      weeklyHours: 4,
      description: "Biología, química y física integradas",
      minerdCode: "CNA-SEC-001",
      isActive: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: "sec_004",
      name: "Ciencias Sociales",
      code: "CSO-SEC",
      area: "Sociales",
      type: "obligatoria",
      weeklyHours: 4,
      description: "Historia dominicana, geografía y cívica",
      minerdCode: "CSO-SEC-001",
      isActive: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: "sec_005",
      name: "Lenguas Extranjeras (Inglés)",
      code: "ING-SEC",
      area: "Lenguas",
      type: "obligatoria",
      weeklyHours: 4,
      description: "Inglés intermedio y avanzado",
      minerdCode: "ING-SEC-001",
      isActive: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: "sec_006",
      name: "Educación Artística",
      code: "ART-SEC",
      area: "Artística",
      type: "obligatoria",
      weeklyHours: 2,
      description: "Artes visuales, música y teatro",
      minerdCode: "ART-SEC-001",
      isActive: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: "sec_007",
      name: "Educación Física",
      code: "EDF-SEC",
      area: "Educación Física",
      type: "obligatoria",
      weeklyHours: 2,
      description: "Deportes y acondicionamiento físico",
      minerdCode: "EDF-SEC-001",
      isActive: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: "sec_008",
      name: "Formación Integral Humana y Religiosa",
      code: "FIH-SEC",
      area: "Formación Humana",
      type: "obligatoria",
      weeklyHours: 2,
      description: "Ética, valores y formación ciudadana",
      minerdCode: "FIH-SEC-001",
      isActive: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: "sec_009",
      name: "Orientación y Psicología",
      code: "ORI-SEC",
      area: "Orientación",
      type: "obligatoria",
      weeklyHours: 1,
      description: "Orientación vocacional y desarrollo personal",
      minerdCode: "ORI-SEC-001",
      isActive: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: "sec_010",
      name: "Educación Tecnológica",
      code: "TEC-SEC",
      area: "Tecnología",
      type: "optativa",
      weeklyHours: 3,
      description: "Informática, programación y tecnología digital",
      minerdCode: "TEC-SEC-001",
      isActive: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: "sec_011",
      name: "Francés",
      code: "FRA-SEC",
      area: "Lenguas",
      type: "optativa",
      weeklyHours: 3,
      description: "Francés básico e intermedio",
      minerdCode: "FRA-SEC-001",
      isActive: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
  ],
}

// Servicio de gestión de materias
export class SubjectsManagementService {
  // Obtener materias por nivel educativo
  static getSubjectsByLevel(level: string): Subject[] {
    switch (level.toLowerCase()) {
      case "inicial":
        return MINERD_SUBJECTS_CATALOG.inicial
      case "primaria":
        return MINERD_SUBJECTS_CATALOG.primaria
      case "secundaria":
        return MINERD_SUBJECTS_CATALOG.secundaria
      default:
        return []
    }
  }

  // Obtener materias asignadas a un curso
  static async getCourseSubjects(courseId: string): Promise<CourseSubject[]> {
    // Simular obtención de materias del curso
    return []
  }

  // Asignar materias a un curso
  static async assignSubjectsToCourse(
    courseId: string,
    subjectIds: string[],
    customOrder?: number[],
  ): Promise<CourseSubject[]> {
    const courseSubjects: CourseSubject[] = []

    for (let i = 0; i < subjectIds.length; i++) {
      const subjectId = subjectIds[i]
      const subject = this.findSubjectById(subjectId)

      if (subject) {
        const courseSubject: CourseSubject = {
          id: `cs_${Date.now()}_${i}`,
          courseId,
          subjectId,
          subject,
          order: customOrder?.[i] || i + 1,
          isAssigned: false,
          hasGrades: false,
          status: "pending",
        }
        courseSubjects.push(courseSubject)
      }
    }

    // Simular guardado
    console.log("📚 Materias asignadas al curso:", courseId, courseSubjects)
    return courseSubjects
  }

  // Buscar materia por ID
  static findSubjectById(subjectId: string): Subject | null {
    const allSubjects = [
      ...MINERD_SUBJECTS_CATALOG.inicial,
      ...MINERD_SUBJECTS_CATALOG.primaria,
      ...MINERD_SUBJECTS_CATALOG.secundaria,
    ]
    return allSubjects.find((subject) => subject.id === subjectId) || null
  }

  // Validar si se puede eliminar una materia del curso
  static canRemoveSubjectFromCourse(courseSubject: CourseSubject): {
    canRemove: boolean
    reason?: string
  } {
    if (courseSubject.hasGrades) {
      return {
        canRemove: false,
        reason: "No se puede eliminar una materia que ya tiene calificaciones registradas",
      }
    }

    if (courseSubject.isAssigned && courseSubject.teacherId) {
      return {
        canRemove: false,
        reason: "No se puede eliminar una materia que tiene docente asignado",
      }
    }

    return { canRemove: true }
  }

  // Calcular cumplimiento curricular
  static calculateCurricularCompliance(
    courseSubjects: CourseSubject[],
    level: string,
  ): {
    totalRequired: number
    assignedRequired: number
    totalOptional: number
    assignedOptional: number
    compliancePercentage: number
    missingSubjects: Subject[]
  } {
    const catalogSubjects = this.getSubjectsByLevel(level)
    const requiredSubjects = catalogSubjects.filter((s) => s.type === "obligatoria")
    const optionalSubjects = catalogSubjects.filter((s) => s.type === "optativa")

    const assignedSubjectIds = courseSubjects.map((cs) => cs.subjectId)
    const assignedRequired = requiredSubjects.filter((s) => assignedSubjectIds.includes(s.id))
    const assignedOptional = optionalSubjects.filter((s) => assignedSubjectIds.includes(s.id))

    const missingSubjects = requiredSubjects.filter((s) => !assignedSubjectIds.includes(s.id))

    const compliancePercentage = Math.round((assignedRequired.length / requiredSubjects.length) * 100)

    return {
      totalRequired: requiredSubjects.length,
      assignedRequired: assignedRequired.length,
      totalOptional: optionalSubjects.length,
      assignedOptional: assignedOptional.length,
      compliancePercentage,
      missingSubjects,
    }
  }

  // Crear plantilla sugerida por nivel
  static getSuggestedTemplate(level: string, grade: string): Subject[] {
    const allSubjects = this.getSubjectsByLevel(level)

    // Filtrar materias obligatorias y algunas optativas recomendadas
    const obligatory = allSubjects.filter((s) => s.type === "obligatoria")
    const recommended = allSubjects.filter((s) => s.type === "optativa").slice(0, 2) // Primeras 2 optativas

    return [...obligatory, ...recommended]
  }

  // Clonar materias de otro curso
  static async cloneSubjectsFromCourse(sourceCourseId: string, targetCourseId: string): Promise<CourseSubject[]> {
    const sourceSubjects = await this.getCourseSubjects(sourceCourseId)
    const subjectIds = sourceSubjects.map((cs) => cs.subjectId)
    const customOrder = sourceSubjects.map((cs) => cs.order)

    return this.assignSubjectsToCourse(targetCourseId, subjectIds, customOrder)
  }

  // Reordenar materias
  static async reorderCourseSubjects(courseId: string, newOrder: { id: string; order: number }[]): Promise<void> {
    // Simular reordenamiento
    console.log("🔄 Reordenando materias del curso:", courseId, newOrder)
  }

  // Actualizar materia del curso
  static async updateCourseSubject(
    courseSubjectId: string,
    updates: Partial<Pick<CourseSubject, "order">>,
  ): Promise<void> {
    // Simular actualización
    console.log("✏️ Actualizando materia del curso:", courseSubjectId, updates)
  }

  // Eliminar materia del curso
  static async removeSubjectFromCourse(courseSubjectId: string): Promise<void> {
    // Simular eliminación
    console.log("🗑️ Eliminando materia del curso:", courseSubjectId)
  }
}
