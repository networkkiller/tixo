export type UserRole =
  | "super-admin"
  | "director"
  | "profesor"
  | "padre"
  | "contable"
  | "coordinador"
  | "coordinador-academico"
  | "secretario"

export interface User {
  id: string
  name: string
  email: string
  role: UserRole
  school: string
  avatar?: string
}

export interface AuthContextType {
  user: User | null
  login: (email: string, password: string) => Promise<boolean>
  logout: () => void
  isLoading: boolean
}

export interface Module {
  id: string
  name: string
  description: string
  icon: string
  path: string
  roles: UserRole[]
  submodules?: Module[]
}

export type RoleModules = {
  [K in UserRole]: Module[]
}

export interface DashboardStats {
  totalStudents: number
  totalTeachers: number
  totalCourses: number
  totalParents: number
  activeUsers: number
  pendingTasks: number
}

export interface Student {
  id: string
  name: string
  email: string
  course: string
  grade: string
  section: string
  status: "active" | "inactive"
  enrollmentDate: string
}

export interface Teacher {
  id: string
  name: string
  email: string
  subjects: string[]
  courses: string[]
  status: "active" | "inactive"
  hireDate: string
}

export interface Course {
  id: string
  name: string
  grade: string
  section: string
  teacher: string
  students: number
  schedule: string
  status: "active" | "inactive"
}

export interface Subject {
  id: string
  name: string
  code: string
  area: string
  grade: string
  hours: number
  teacher?: string
  status: "active" | "inactive"
}

export interface Schedule {
  id: string
  courseId: string
  day: string
  startTime: string
  endTime: string
  subject: string
  teacher: string
  classroom: string
}
